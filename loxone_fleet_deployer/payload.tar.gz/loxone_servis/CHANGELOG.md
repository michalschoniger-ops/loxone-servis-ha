# Changelog

## 3.0.68

- Historie školení používá aktuální pole oficiálního endpointu LOXONE Portálu, takže Menu dostane názvy, termíny, místo, účastníka a stav namísto samotného celkového počtu.
- Synchronizace doplňuje Partner Coache z oficiálního endpointu včetně jména, role, telefonu, mobilu, e-mailu, dostupnosti a odkazů na sjednání schůzky.
- Fotografie Coache se přijímá jen přes HTTPS z domény LOXONE, s povoleným obrazovým MIME typem a limitem 2 MB. Chráněný endpoint ji vydá pouze osobnímu admin Menu tokenu s `no-store`.
- Evora Smart Menu 3.0.45 označuje číslo školení jako počet historických záznamů, přidává kartu Coache s fotografií a přímými kontakty a vystřeďuje rychlé docházkové ikony bez hover tooltipů.
- Menu API vydává současné Stable, Beta a Alpha verze LOXONE Configu včetně bezpečných oficiálních download URL z `updatecheck.xml`; Menu každou verzi ukáže a nabídne její přímé stažení.

## 3.0.67

- Volitelné části LOXONE Portálu nyní vracejí pouze sanitovaný stav `HTTP nnn`, `rejected`, `invalid_response`, `timeout` nebo `request_failed`.
- Diagnostika nikdy neukládá ani nevydává obsah odmítnuté odpovědi, přihlašovací token nebo session cookie.

## 3.0.66

- Přijímá aktuální úspěšnou odpověď `getCustomerLedgerEntries`, která na rozdíl od ostatních částí Portálu nemusí obsahovat obecný příznak `valid`.
- Výslovně neplatná odpověď `valid: false` zůstává izolovanou chybou účetní části a nemůže narušit synchronizaci Miniserverů.

## 3.0.65

- Fakturační read-back LOXONE Portálu používá aktuální oficiální stránku `/invoices/` a stejný šestiměsíční rozsah jako její frontend, takže účetní saldo a pohledávky nejsou vyřazené chybným starším refererem.
- Přidán regresní test refereru a polí `startDate`/`endDate`; ostatní části Hubu, Menu a databázové schéma 26 se nemění.

## 3.0.64

- Synchronizace LOXONE Portálu využije stávající šifrovanou relaci také pro partner status, datum další certifikace, kreditní limit, obrat, otevřené objednávky, účetní saldo, pohledávky po splatnosti a školení. Vedlejší přehledy selhávají odděleně, takže změna jejich formátu nezablokuje import Miniserverů.
- Sanitovaný přehled bez tokenu, cookie a přihlašovacích údajů se ukládá do cache; finanční a partnerská data dostane přes osobní Menu API pouze správce, nikoli technik.
- Evora Smart Menu 3.0.44 zobrazuje nové části Portálu, jejich poslední synchronizaci a červeně zvýrazní částku po splatnosti. Intranet nově každou minutu čte ověřený kalendář zasedaček a nabízí místnosti, aktuální obsazenost a události přímo v menu. Rezervaci umí po samostatné kontrole odeslat přímo přes oficiální endpoint do M365 včetně Teams, účastníků a zakázky a po úspěchu ihned obnoví obsazenost.
- Platné docházkové akce se v horní části Intranetu zobrazují jako stavově řízené ikony; potvrzení i výsledek zůstávají v otevřeném Menu a úspěšný zápis okamžitě spustí nový read-back.

## 3.0.63

- Údržba rozpozná přesným UUID filtrem nedokončené `backup-snapshot-*.sqlite` exporty a smaže jen soubory starší než hodinu.
- Diagnostika předem vrací počet a souhrnnou velikost těchto osiřelých exportů bez zpřístupnění jejich obsahu.
- Živá databáze, její WAL/SHM soubory i právě probíhající export jsou z mazání vyloučené.

## 3.0.62

- Přidána chráněná diagnostika velikosti souborů, volných stránek, tabulek a indexů databáze bez čtení jejich citlivého obsahu.
- Přidána potvrzovaná údržba, která odstraňuje pouze starší nepoužívané plné LoxAPP3 snímky a pro každý Miniserver zachová dvě nejnovější kopie i všechny souhrny změn.
- Po údržbě se databáze optimalizuje a podle dostupného místa zmenší; selhání zmenšení neohrozí integritu ani opětovné použití uvolněných stránek.

## 3.0.61

- Evora Smart Menu 3.0.43 udržuje otevřenou klasickou nabídku při úpravách docházky a Knihy jízd, po každém zápisu vynutí nový read-back a obnoví stejnou otevřenou cestu. Kniha jízd je členěná po měsících a dnech, výběr zakázky má vlastní hledání a řádky Vozidlo i Tachometr zobrazují celý údaj na jedné řádce bez hover tooltipu.
- Profilová karta plného Menu má samostatnou zelenou ikonu Excelu, která otevírá výhradně určený HTTPS sešit na firemním SharePointu. Technická edice toto osobní tlačítko nezobrazuje.
- Tickety se kontrolují každou minutu i během otevřené nabídky. Nová odpověď a Miniserver bez přihlašovacích údajů sdílejí červený číselný badge; přehled ticketů ukazuje čas poslední úspěšné aktualizace a při chybě jej zachová.
- Osobní admin token může přes úzký auditovaný endpoint doplnit nebo kompletně nahradit přihlašovací jméno a heslo jednoho Miniserveru. Menu staré údaje nikdy nenačítá do formuláře, heslo používá zabezpečené pole a odpověď ani audit tajné údaje neobsahují.
- Menu zpřístupňuje ověřené části Evora Intranetu (nástěnku docházky, kalendář dovolených, zasedačky, klienty, kontaktní osoby a nápovědu) bez kopírování přihlášení. Nový přehled LOXONE Portálu ukazuje stav připojení, počet registrovaných produktů, poslední synchronizaci a souhrn Weather Service. Ruční synchronizace používá úzký admin endpoint, znovu využije už běžící úlohu a výsledek čte dynamicky nejvýše 30 sekund.

## 3.0.60

- Osobní admin token Evora Smart Menu dostává úzké, auditované API pouze pro read-only strom složek a změnu časového pravidla konkrétní složky. Umožňuje bezpečně nastavit Melori bez kopírování hesla, session cookie nebo přímého zásahu do databáze; technický token je odmítnut.
- Změna pravidla okamžitě přepočítá čekající firmware frontu a odpověď ani audit neobsahují přihlašovací údaje či cílové adresy. Databázové schéma zůstává 26 a žádný endpoint nevytváří ani neposílá firmware požadavek.

## 3.0.59

- Správce může složce Miniserverů nastavit omezení aktualizací na noci začínající v pátek, sobotu nebo neděli od 22:00 do 04:00 v časové zóně Europe/Prague. Pravidlo se dědí do podsložek, takže jediná politika složky Melori pokryje i její vnořené projekty.
- Požadavek přijatý mimo povolené okno se neodešle Miniserveru, ale trvale se uloží do fronty s přesným termínem příštího provedení. Hub termín ukazuje v seznamu Miniserverů i provozním protokolu, opakovaný požadavek sloučí a při změně pravidla čekající frontu přepočítá.
- Bezprostředně před odesláním Hub časové pravidlo znovu ověří. Po restartu nejistě rozpracovaný síťový příkaz neposílá podruhé a přejde pouze do ověřování výsledného firmware. Databázové schéma se zvyšuje na 26; verze macOS a Windows Menu se nemění.

## 3.0.58

- Plné Evora Smart Menu 3.0.37 pro macOS odstranilo čtyři pevně zapsané Home Assistant odkazy. Podnabídku nyní skládá z aktuálního paměťového snapshotu Hubu, takže ruční i minutová obnova doplní nově založený server bez restartu Menu; změna seznamu, názvu nebo stavu je součástí strukturálního podpisu a během otevřeného AppKit menu se odloží do jeho bezpečného zavření.
- Soukromý řádek `HA Domov` je oddělený od seznamu Hubu. Plné osobní Menu jej zobrazí jen tehdy, když je bezpečná HTTP(S) adresa uložená pod povoleným aliasem v Keychainu právě tohoto Macu; adresa není v databázi Hubu, zdroji, ZIPu ani manifestu a technická edice řádek nezobrazuje.
- Přímé otevření konkrétního Home Assistantu používá nový auditovaný endpoint osobního admin tokenu. Cílová adresa se vrátí až po výslovném kliknutí, znovu projde serverovou HTTP(S) validací, odpověď má `no-store` a Menu odmítne credentials, query i fragment. Pevné zákaznické adresy už zdroj ani instalační ZIP neobsahují.
- Hub zůstává na databázovém schématu 25; technické macOS Menu 3.0.35 a Windows Menu 3.0.34 se nemění.

## 3.0.57

- Windows Menu 3.0.34 provede převzetí starého samostatného Config konektoru jen tehdy, když se chráněný token, adresa Hubu nebo příznak správy neshoduje s aktuálním osobním Menu. Již zdravý skrytý konektor při běžném startu ani diagnostice znovu nerestartuje.
- Při jednorázovém převzetí čeká na bezpečné ukončení přesně ověřeného procesu až 40 sekund, aby doběhl i probíhající long-poll. Token porovnává v DPAPI rozšifrovaných bajtech konstantním průchodem a citlivé buffery vždy vynuluje. Hub zůstává na databázovém schématu 25; brána i úvodní animace se nemění.

## 3.0.56

- Živý test upgradu ve Windows/Parallels odhalil staré samostatné párování Config Launcheru, které Menu 3.0.32 záměrně zachovalo, a proto se Vaverkův skrytý konektor dál hlásil neplatným původním tokenem. Windows Menu 3.0.33 nyní bezpečně ověří přesný běžící PowerShell proces podle PID, času startu a cesty skriptu, požádá jej o ukončení, převezme konfiguraci pod osobní token Menu a spustí nový skrytý konektor.
- Převzetí se provádí při každém startu idempotentně přes jediného agenta navázaného na Menu token; cizí proces se neukončí. Viditelná verze, patnáctiminutová automatická aktualizace, databázové schéma 25, oprava brány a úvodní animace zůstávají beze změny.

## 3.0.55

- Evora Smart Menu 3.0.32 pro Windows po osobním spárování samo připraví a skrytě spustí Config konektor. Technik instaluje a páruje pouze Menu; jeho odvolatelný DPAPI token zároveň autentizuje právě jeden navázaný konektor a zneplatní se společně s ním. Samostatná druhá instalačka ani druhý párovací kód už nejsou potřeba.
- Verze Menu je viditelná v titulku i záhlaví vyhledávacího okna, v systémovém tooltipu a ve stavové nabídce. Menu kontroluje podepsaný manifest při spuštění a každých 15 minut; novější balíček ze stejného Hubu ověří HMAC podpisem a SHA-256, automaticky nainstaluje přes rollbackový updater a po chybě nechá funkční verzi beze změny.
- Hub přidává idempotentní provisioning skrytého konektoru pro aktivní osobní Menu token a databázové schéma 25. Oprava přesně řízeného překódování cesty brány, jedno důvěryhodné Loxone Cloud přesměrování a jednorázová úvodní animace zůstávají součástí vydání.

## 3.0.54

- Loxone Cloud při přesměrování povelu s českým znakem v názvu vstupu vrací cestu chybně překódovanou jako UTF-8 čtené přes Latin-1, na kterou Miniserver odpovídá 404. Hub tuto konkrétní bezeztrátovou chybu opraví jen tehdy, když každý segment výsledné cesty přesně odpovídá původnímu povelu bez cloudového identifikátoru; jiná cesta se odmítne ještě před předáním přihlášení.
- Důvěryhodnost jediné HTTPS domény, šifrované serverové přihlášení, úvodní animace a databázové schéma 24 zůstávají beze změny.

## 3.0.53

- Serverové ovládání brány bezpečně následuje právě jedno HTTP 307/308 přesměrování z důvěryhodné adresy Loxone Cloud na jiný HTTPS server téže služby a až tam znovu odešle šifrovaně uložené Basic přihlášení. Přesměrování na cizí doménu, nešifrovaný protokol, adresu s parametry nebo další přesměrování se odmítne bez předání účtu.
- Úvodní jednorázová animace a oprava JSON požadavku z 3.0.52 zůstávají beze změny; databázové schéma zůstává 24 a Menu se nemění.

## 3.0.52

- Úvodní desktopová obrazovka nově při načtení jednou složí černé části společného motivu, nechá krátce projet světlo přes zeleno-modrou diagonálu a plynule zobrazí text `Vítejte`. Animace se po dokončení zastaví a respektuje systémové `prefers-reduced-motion`.
- Tlačítka `Otevřít bránu` a `Zavřít bránu` už neposílají prázdný POST odmítaný jako nepodporovaný typ dat. Hub přijímá korektní JSON a cílové HTTP povely provádí serverově s Basic přihlášením uloženým odděleně pomocí AES-256-GCM. Adresy, jméno ani heslo se neposílají klientovi a chyby přihlášení nevracejí citlivé údaje.
- Databázové schéma zůstává 24; macOS Menu 3.0.35 a Windows Menu 3.0.31 se nemění.

## 3.0.51

- Plné Evora Smart Menu 3.0.35 má v profilové kartě dvě samostatná tlačítka. Originální LOXONE znak otevírá volby `Podpora` a `Vácha`; zelený WhatsApp glyph otevírá kontakty `Filip Kubín` (`+420 725 959 685`), `Lukáš Majer` (`+420 721 062 300`) a `Jiří Vaverka` (`+420 602 462 104`). Všechny kontakty se předávají přímo nativní aplikaci přes `whatsapp://send`, takže Mac neskončí na mezistránce `api.whatsapp.com`. Pokud aplikace WhatsApp není nainstalovaná, Menu zobrazí srozumitelnou chybu a web samo neotevře.
- Hub zachovává databázové schéma 24, ruční kontrolu flotily, Windows Menu 3.0.31 i technické macOS Menu 3.0.35 beze změny.

## 3.0.50

- Evora Smart Menu se nově páruje vlastním jednorázovým kódem `MENU-…`. Přihlášený správce nebo technik vytvoří kód pro pojmenované zařízení, Windows Menu 3.0.31 nebo plné/technické macOS Menu 3.0.34/3.0.35 jej po HTTPS vymění za osobní odvolatelný token a kód se po prvním použití zneplatní. Kód Loxone Config Launcheru zůstává oddělený a Menu jej odmítne. Technik v Nastavení vidí nejdřív kartu Menu; samostatná karta Config Launcheru je pouze pro správce. Databázové schéma se zvyšuje na 24 o hashované, časově omezené párovací kódy.
- Zdrojové PNG loga už nemá pouze deklarovaný RGBA formát, ale skutečně průhledné čtyři vnější rohy. Windows build průhlednost rohů povinně kontroluje, vytváří plnobarevné vícevelikostní ICO a publikuje instalačku i pod verzovaným názvem `EvoraSmartMenu-Windows-Setup-3.0.31.exe`, takže Průzkumník nepřebírá starou ikonu z cache stejného názvu.
- Podpora v Hubu nabízí vedle telefonu také přímý WhatsApp na `+420 380 429 011`, připraví první zprávu s poli pro příjmení a firemní e-mail a zachovává samostatné volání i WhatsApp kontakt Vácha. Pro oba WhatsApp odkazy používá originální zelený digitální glyph z oficiálního balíčku Meta s průhledným pozadím.
- Evora Smart Menu 3.0.34 přidává tentýž originální WhatsApp glyph do profilové karty správce; kliknutí nejprve ukončí hlavní AppKit menu a následně nabídne přesně volby `Podpora` a `Vácha`. Podpora otevře připravenou první zprávu, zatímco Vácha používá již evidovaný firemní kontakt.
- Sekundový čas během otevřeného nativního menu nově běží nejen v horní liště, ale také v profilové kartě a prvním stavovém řádku podmenu Intranet. Aktualizují se pouze existující textová pole s číslicemi; obrázky, tooltipy, vrstvy, síťová data ani strom menu se při trackingu nepřestavují.
- Evora Smart Menu 3.0.31 pro Windows přidává přímo vedle hledání tlačítko `Obnovit stavy`. To spustí skutečnou kontrolu celé flotily na Hubu, vybraný Miniserver zařadí jako první a otevřený seznam aktualizuje po třech sekundách bez ztráty filtru ani vybraného řádku. Mimo ruční kontrolu zůstává běžné načtení snapshotu jednou za 60 sekund; plánovaný aktivní cyklus Hubu zůstává 120 minut.

## 3.0.49

- Párování Windows Menu 3.0.29 už nelze zaměnit s jednorázovým kódem Loxone Config Launcheru: dialog vyžaduje dlouhý osobní token `esh_worklog_…`, chybu vysvětluje konkrétně a tlačítko otevře přímo zvýrazněnou kartu Evora Smart Menu / WorkLog. Odkaz zachová i za reverzní proxy koncové lomítko před parametry. Opakované vyvolání párování aktivuje jediný existující dialog, takže nevznikají překrytá okna. Hub zachovává schéma 23; instalační balíček dál neobsahuje heslo ani token.
- Remote Connect přijímá vedle nového pole `url` také skutečný formát Loxone `IPHTTPS` a `DataCenter`, takže Exporty fungují i pro Miniservery, které jsou online přes tuto trasu.
- Neznámá úspěšná odpověď nového resolveru už nezablokuje ověřený záložní dotaz na CloudDNS.

## 3.0.48

- Přibývá samostatná Evora Smart Menu technická edice 3.0.31 pro macOS. Instalační PKG vloží aplikaci do `/Applications`, nastaví automatický start aktuálního uživatele a při spuštění otevře osobní párování. Levý klik zobrazí pouze přímé hledání Miniserverů; pravý klik nabízí hledání, připojení, aktualizaci a ukončení. Docházka, pracovní výkazy, tickety a obecné Systémy v technické edici nejsou.
- Windows Menu 3.0.26 dostává jednosouborový bezkonzolový per-user instalátor. Bez oprávnění správce vytvoří položku v nabídce Start a Po spuštění, zachová DPAPI nastavení, ověří nový runtime a po instalaci vyvolá párovací dialog. Při aktualizaci bezpečně ukončí běžící Menu, odstraní starý atribut jen pro čtení a na uvolnění souboru počká s omezeným opakováním. Vložené Evora logo nově používá vícevelikostní 32bitové ICO, takže zachovává zeleno-modré barvy a průhlednost i v Průzkumníku a Finderu.
- Každý správce nebo technik vytváří v Hubu vlastní token pod svým firemním e-mailem. macOS i Windows ověří e-mail a roli proti Hubu před uložením; technická macOS edice používá samostatnou Keychain službu a nesdílí správcovský token plného Menu. Tokenové endpointy, seznam Miniserverů a servisní akce přijímají roli technika, zatímco tickety, kamera, brána, Builder a další správcovské části zůstávají skryté nebo administrátorské. Databázové schéma zůstává 23.
- Evora Smart Menu 3.0.31 ztmavuje skutečný podklad dočasného nativního `NSMenu` okna, nejen vlastní profilovou kartu. Největší veřejný `NSVisualEffectView` používá tmavý HUD materiál s mícháním uvnitř vlastního téměř černého podkladu, takže bílý obsah Safari pod nabídkou už celý systémový povrch nezesvětluje.
- Oprava zachovává běžné nativní řádky, hover, klávesnici i kaskády a neaktivuje Evora aplikaci. `Parkoviště a brána`, Milesight a Loxone Builder zůstávají skryté; Hub zachovává schéma 23 a H.264/fMP4 HLS cestu z 3.0.46.

## 3.0.47

- Evora Smart Menu 3.0.30 na výslovné přání odstraňuje z kořene celou položku `Parkoviště a brána`; živé menu nevytváří kamerový AVPlayer, neotevírá podnabídku brány a při otevření nepředehřívá HLS. Serverová kamera i brána zůstávají beze změny dostupné v Evora Smart Hubu.
- Skryté stavy kamery, NVR, brány a Builderu už nejsou součástí strukturálního podpisu macOS Menu, takže jejich obnova nemůže sama přestavět celý strom. Vlastní karty mají tmavší neutrální povrch a významovou barvu dál používají pouze ikony. Hub zachovává schéma 23 a H.264/fMP4 HLS cestu z 3.0.46.

## 3.0.46

- Jediný publikovaný kanál 7 přechází ze sdíleného MPEG-TS výřezu na jedinou sdílenou H.264/fMP4 HLS relaci. Připnutý `init.mp4` dává každému novému browseru, VLC i AVPlayeru kodekovou inicializaci nezávisle na stáří relace; hotové fragmenty se dál zveřejňují až po úplném načtení do omezené cache Hubu.
- Oprava reaguje na živý opakovaný start Hubu 3.0.45: první VLC klient z rozběhu dekódoval 79 snímků, ale pozdější klient dostal šest kompletních HTTP 200 MPEG-TS segmentů bez přenosného dekódovatelného začátku a za 180 sekund zůstal na nule. Menu zůstává 3.0.29 a schéma 23.

## 3.0.45

- HLS playlist kanálu 7 už klientům neoznamuje právě vznikající segment, který interní brána ještě vrací jako nedostupný. Hub vede omezený souvislý seznam pouze plně načtených segmentů ve vlastní paměti, okamžitě jej vrací klientům a nový segment zařadí až po dokončení na pozadí.
- Oprava navazuje na živý tříminutový VLC důkaz Hubu 3.0.44: NVR bylo 10/10 online, ale jediný předčasně publikovaný segment vrátil 502, VLC ukončilo další čtení a nedekódovalo žádný snímek. Menu zůstává 3.0.29 s opravou problikávání; databázové schéma zůstává 23.

## 3.0.44

- Evora Smart Menu 3.0.29 odstraňuje tři zdroje problikávání nativní nabídky: vlastní povrchy jsou tmavé už před připojením do dočasného AppKit okna, profilová karta se nepřebarvuje při každém `viewWillDraw` a její změny CALayeru probíhají bez implicitní animace. Zároveň je odstraněné úmyslné pulzování celé stavové ikony během synchronizace.
- Sekundový časovač během AppKit trackingu dál neběží; mimo otevřenou nabídku zapisuje pouze text, tooltip nebo obraz, který se skutečně změnil. Stavový vzhled karty se přepočítá jen při změně datového či docházkového stavu.
- `/healthz` hlásí databázové schéma 23 odpovídající už existující migraci kontaktů Intranetu. Hub 3.0.43 migraci obsahoval, ale v health odpovědi ponechal historickou konstantu 22.

## 3.0.43

- Evora Smart Menu 3.0.28 znovu používá skutečné systémové `NSMenu`. AppKit řídí otevření, zavření, umístění, klávesnici i kaskádové podnabídky bez vlastního 440px panelu, ručního přemisťování a snímkové animace. Nabídka při pouhém otevření neaktivuje Evora aplikaci, takže dosavadní okno Safari nemá přejít do neaktivního šedého vzhledu; dialogy se aktivují až po výslovné akci. Tickety, nový ticket a volné jméno spolucestujícího mají nativní dialogovou cestu nezávislou na odstraněném panelovém navigátoru.
- Živá nabídka je výhradně tmavá, používá neutrální text a povrchy a barevně odlišuje pouze ikony. Řádky zachovávají běžný směr zleva doprava s indikátorem podnabídky vpravo; AppKit vybírá stranu kaskády podle volného místa. Klik do globálního i Miniserverového hledání přijme první myš a vrátí field editor až po nativním zpracování kliknutí, takže lze pokračovat v psaní bez aktivace celé aplikace.
- Fleet snapshot zůstává v paměti. Časovače neběží během AppKit trackingu, pomocné procesy a zápis Intranet snapshotu jsou mimo hlavní vlákno a síťové výsledky, profil, úkoly i stavové změny se při otevřené nabídce pouze odloží a sloučí po zavření. Složky vytvářejí lehké řádky až při otevření a karta konkrétního Miniserveru se sestaví teprve při vstupu do jeho podnabídky. Pod jedinou kartou jsou všechny akce klasické řádky `NSMenu`.
- `Parkoviště a brána` je přímo v kořeni Menu. Značková položka Milesight i Loxone Builder jsou na výslovné přání skryté, takže kamera s bránou potřebuje jedinou levou podnabídku místo několika střídajících se kaskád.
- Kamera označí stav `ŽIVĚ` až po dekódovaném snímku a opakovaném postupu přehrávacího času. Ongoing watchdog při zastavení vrátí poslední snapshot, ukáže pravdivý stav `BEZ VIDEA` a provede omezený reconnect.
- Detail Knihy jízd zobrazuje dlouhou trasu, vozidlo, tachometr a validované počáteční i koncové GPS konkrétní jízdy ve více řádcích. Hub ani Menu tím nezavádějí průběžné sledování zařízení a docházkové akce GPS dál neposílají.
- Obsah Hubu 3.0.42 přechází beze změny databázového schématu do 3.0.43, aby nová distribuční verze Menu neměnila již publikovaný artefakt pod stejným číslem.

## 3.0.42

- Databázové schéma 23 dovoluje správci ručně doplnit nebo opravit telefon kontaktu z Evora Intranetu. Ruční číslo zůstává na serveru, API jej validuje a auditovaný zápis je dostupný pouze správci; kontakt bez čísla se v Hubu i macOS Menu dál zobrazí jako běžná karta bez telefonní ikony.
- Otevření webového rozhraní Miniserveru používá skutečný synchronní odkaz na interní autentizovanou route Hubu. Server čerstvě rozliší bezpečnou adresu bez přihlašovacích údajů, dotazu a fragmentu a provede redirect, takže browser nemusí povolovat vyskakovací `about:blank` okno.
- HLS playlist už nečeká na postupné stažení všech oznámených segmentů. Hub zahřeje pouze potřebnou inicializaci a nejnovější segment, zachová sdílenou relaci i při krátkém zaváhání a klient při připojování ponechá viditelný poslední platný snapshot.
- Ovládání brány používá dva explicitní serverové HTTP(S) příkazy pro otevření a zavření místo odhadu Loxone virtuálního vstupu. Adresy se ukládají šifrovaně pomocí AES-256-GCM, klient je nikdy nedostane a server vynucuje shodný origin, zákaz credentials, query, fragmentu a redirectu, omezenou metodu GET/POST, sedmisekundový timeout a jediný souběžný povel.
- Evora Smart Menu 3.0.27 sjednocuje všech šest akcí Miniserveru na výšku 58 bodů, vystřeďuje popisky přes celou kartu nezávisle na ikoně a při jediném nalezeném Miniserveru skryje nesouvisející kořenové položky.

## 3.0.41

- Volitelná adresa Loxone Builderu už nemá ve výchozích add-on options prázdný řetězec. Dokud není samostatná HTTPS služba skutečně nastavená, klíč zůstává nepřítomný a Supervisor může Hub bezpečně spustit; server i UI dál pravdivě zobrazují stav `Nenastaveno`.

## 3.0.40

- Evora Smart Menu 3.0.26 a Hub 3.0.40 přidávají osobní Knihu jízd pod `Intranet`. Data se čtou z přihlášené zaměstnanecké stránky Evora Intranetu a úpravy používají jen akce skutečně deklarované jejím Next.js kódem: účel, zakázku, řidiče, cestovní příkaz a spolucestující. Server znovu ověřuje osobní `canEdit` i všechny identifikátory; GPS souřadnice se do snapshotu Menu ani Hubu neukládají.
- Hub rozděluje Intranet na samostatně volitelné části `Přehled`, `Docházka`, `Dovolené`, `Kniha jízd` a `Lidé`. Desktop používá přehledné záložky a telefon kompaktní volbu; vykreslí se vždy jen vybraná část, takže uživatel nemusí procházet jeden dlouhý sloupec všech záznamů.
- Samostatný Loxone Builder je v Hubu dostupný pod `LOXONE → Builder` a v macOS Menu pod `Systémy`. Hub čte pouze pevný veřejný `/healthz`, používá omezenou cache a přes sebe nepřenáší ZIP, PDF, model ani výsledný `.Loxone` soubor.

## 3.0.39

- Lokální patch go2rtc ponechává číslování a opakované vydávání segmentů v omezené sdílené cache Hubu. Uvnitř go2rtc mění pouze dvě nutné vlastnosti: delší životnost HLS relace a zákaz vrátit MPEG-TS segment tvořený jen 376B PAT/PMT hlavičkou. Odstraňuje se živě doložené zablokování Hubu 3.0.38, který s interní sequence-cache sice vydal první 322kB H.264 segment, ale hned následující playlist skončil po 11 sekundách HTTP 502 a další master po 35 sekundách timeoutem.
- Evora Smart Menu 3.0.24 už při přechodu mezi stránkami otevřené nabídky nevolá `NSMenu.update()`. Výšku i origin interního panelu mění jediným neanimovaným rámem, po layoutu ukotví jeho skutečnou výslednou velikost přesně osm bodů pod horní a od pravé hrany a teprve potom vykreslí obsah. Odstraňuje se tak druhý AppKit přepočet, který dokázal na jeden snímek přisunout nabídku k systémové liště a následně ji vrátit.

## 3.0.38

- Lokální patch go2rtc při vytváření MPEG-TS HLS segmentu už nepovažuje samotný 376B PAT/PMT základ za hotové video. Druhý a každý další segment počká na skutečná TS obrazová data; číslovaná cache přitom dál vrací stejný segment všem klientům. Opravuje se živě doložený stav Hubu 3.0.37, kdy všechny požadavky vracely HTTP 200, ale AVPlayer i VLC dostaly jen hlavičku bez dekódovatelného snímku.

## 3.0.37

- Kanál 7 používá pro Hub i plné macOS Menu jedinou sdílenou, předehřívanou MPEG-TS HLS relaci. Odstraňuje se soupeření paralelní fMP4 relace, které se v živém Hubu 3.0.36 projevilo HTTP 502 a nulou dekódovaných snímků; přímý RTSP zdroj zůstává pouze uvnitř serveru a klienti nikdy nedostanou přihlašovací údaje ani RTSP adresu.
- Evora Smart Menu 3.0.23 před změnou výšky stránky nejprve předpočítá a bez vykreslení nastaví celý nový rám interního AppKit panelu se stejným osmibodovým odstupem. Teprve uvnitř stejné neanimované transakce změní výšku navigátoru, takže přechod nemá zobrazit jediný mezisnímek přisunutý k horní liště.

## 3.0.36

- HLS pumpa kanálu 7 serializuje každý nový segment konkrétní relace a dodržuje jeho deklarovaný půlsekundový rytmus. Playlist se klientovi vrátí až poté, co jsou inicializace i všechny právě odkazované segmenty v omezené sdílené cache; souběžný browser, macOS Menu a keep-warm proto nespotřebují stejný pull segment dvakrát ani nevytvoří několikamilisekundový fragment.
- Webová MPEG-TS a nativní H.264/fMP4 relace se předehřívají souběžně. Obě dál sdílejí jediný přímý RTSP zdroj z NVR a žádné přihlašovací údaje ani RTSP adresa neopouštějí server.
- Evora Smart Menu 3.0.22 při změně stránky nejprve dokončí nový layout a teprve potom jedním neanimovaným `setFrame` nastaví celou výšku i ukotvení interního AppKit okna. Osmibodový odstup od horní i pravé hrany tak nezávisí na opožděném resize callbacku; zámek pohybu a velikosti zůstává jako druhá pojistka.

## 3.0.35

- Předehřívání kanálu 7 nyní udržuje současně webovou MPEG-TS relaci i nativní H.264/fMP4 relaci používanou macOS Menu. Oba klienti sdílejí stále jediný přímý RTSP zdroj z NVR; dočasná chyba jednoho HLS transportu už nepřeruší průběžné zahřívání druhého.

## 3.0.34

- Evora Smart Menu 3.0.21 nahrazuje strom kaskádových podnabídek jediným větším panelem ukotveným přímo pod ikonou v horní liště. Levý i pravý klik používá stejnou nabídku; samostatné aplikační okno se v běžném provozu nevytváří. `Systémy → Miniservery → složka → detail` se proklikávají na místě se šipkou zpět, jemným přechodem, zaoblenými kartami, významovými ikonami a nativním průsvitným materiálem.
- Rám klasické nabídky nyní hlídá přesun i změnu velikosti interního AppKit okna a synchronně zachovává osm bodů od horní i pravé hrany na kořeni, ve všech podnabídkách, dlouhém seznamu, detailu i kameře. Změna stránky tak nemá ani na jeden snímek přicvaknout panel k menu baru. Otevření používá krátké plynulé zvětšení, posun a prolínání s Apple-style křivkou a respektuje Reduce Motion.
- Globální i Miniserverové `NSSearchField` už neposílá akci po každém jednotlivém znaku; průběžný celý dotaz zpracuje jediný debounce delegáta a potvrzovací akce se spustí až nad celou hodnotou. Regresní GUI self-test postupně vkládá `VZT1` i `melori` a ověřuje zachovaný kurzor za posledním znakem.
- Akce detailu Miniserveru používají stejné adaptivní karty, tmavý/světlý kontrast, hover a stisk jako zbytek nabídky. HLS klient přidává Bearer hlavičku ke všem podřízeným zdrojům přes loopback vázaný jen na `127.0.0.1`; nativní route Hubu vrací H.264/fMP4, zatímco browserová route zůstává beze změny.
- Globální i Miniserverové hledání zůstává uvnitř stejného panelu, slučuje rychlé změny dotazu, ignoruje staré výsledky a jediný Miniserver ukáže rovnou jako velkou stavově barevnou kartu. Pod ní je dvousloupcová mřížka akcí včetně capability-gated `Kopírovat heslo`, webového rozhraní a obou režimů Loxone Configu.
- Vlastní AppKit karty jsou při vložení do proklikávací nabídky izolované od interního layoutu `NSMenu`, takže se profil, hledání, kamera ani detail Miniserveru nepřekrývají. Přechody respektují omezení pohybu a stisky řádků i tlačítek mají krátkou nativní odezvu.
- Profilová karta správce používá přibalenou fotografii místo textového kruhu `ES`. Akční tlačítka Miniserveru nově vystřeďují ikonu společně s textem, takže symboly neujíždějí k levému okraji.
- Kořen klasické nabídky používá mřížku 2×3 bez svislého scrollování, poslední kategorie se jmenuje jen `Nastavení` a profil zobrazuje větším písmem `Bc. Michal Schöniger`. Dynamické barvy karet se při změně vzhledu znovu vyhodnotí, takže tmavý režim nekombinuje světlé tlačítko s bílým textem; popover má navíc osmibodový odstup od horní lišty.
- Mírné zmenšení buněk platí pro celý klasický panel: kořenové karty, vnořené řádky Docházky, Systémů, úkolů i nastavení, navigační záhlaví a dvousloupcové akce Miniserveru používají společný kompaktní rytmus.
- Vyhledávací pole první znak pouze zachová v editoru a filtrování spustí až od dvou znaků po 350ms klidu. Při překreslení uchová přesný výběr a pozici kurzoru; starší AppKit callback nemůže přepsat nebo přesunout nové znaky. Znakový regresní self-test ověřuje postupné napsání `VZT1` i `melori`.
- Kořenový panel už nemá duplicitní logo, název ani verze. Malý křížek je součástí pravého horního rohu profilové karty, takže nevytváří samostatný prázdný pás; vyhledávání následuje hned pod profilem. Velké spodní ukončovací tlačítko bylo odstraněno. Panel se stáhne na skutečnou výšku krátké stránky a scrollování se zapne jen při překročení maxima.
- Osobní lístečky se už nesnaží používat Klíčenku. Atomicky se ukládají do privátního lokálního JSON souboru s oprávněním pouze pro aktuální účet Macu; Klíčenka zůstává výhradně pro tokeny a hesla.
- Hover kořenových karet i vnořených řádků nově řídí jediný tracker celého panelu. Opuštění panelu všechny stavy okamžitě vynuluje a jednotlivé buňky už nedrží nekonečnou pulzní animaci, takže po návratu myši nemůže zůstat modře zvýrazněno několik tlačítek současně.
- Přechod mezi stránkami animuje pouze průhlednost. Vodorovný počátek dokumentu zůstává vždy na nule, takže přerušená animace dlouhého seznamu Miniserverů už nemůže ponechat celý obsah posunutý vlevo.
- Načítání, detail, přílohy, editor nového ticketu i odpovědi, kontrola celého návrhu a výsledek odeslání se přepínají jako vnitřní stránky téhož proklikávacího panelu. Klik z horní nabídky už kvůli ticketu nevytváří samostatné loading ani detailní okno.

## 3.0.33

- Miniserverové akce Hubu, plného macOS Menu 3.0.18 a Windows Menu 3.0.22 přidávají bezpečné otevření webového rozhraní přes čerstvě rozlišenou adresu. Hub už nespoléhá na tichý Ingress redirect: po důvěryhodném kliknutí předotevře cílovou kartu, načte validovanou adresu jako JSON a při blokaci nebo chybě zobrazí konkrétní hlášení. URL nesmí obsahovat přihlašovací údaje, dotaz ani fragment.
- Windows Menu 3.0.22 otevírá hledání jedním levým kliknutím a v pravé tray nabídce zobrazuje pouze `Hledat všude…` a `Nastavení připojení k Hubu…`. Složky, stav konektoru, verze, ruční update a ukončení z nabídky odstranilo; podepsaná automatická aktualizace zůstává skrytě aktivní. Hledací okno má obrázky Miniserverů, všechny App/web/Config akce a tlačítko `Kopírovat heslo`, které tajemství načte až po kliknutí a po 60 sekundách podmíněně vyčistí schránku. Opakovaná aktivace znovu použije jedno okno a po úspěšné App/web/Config akci se okno samo zavře.
- macOS Menu 3.0.18 po levém kliknutí otevírá moderní panel se světle šedým plátnem, bílými zaoblenými řádky bez obrysů, větší typografií, plnými názvy pěti hlavních kategorií, barevnými ikonami a nativním pill hledáním. Řádkové hover tracking areas byly odstraněné, takže rychlý scroll nezanechá falešně modré karty. Křížek panel zavře a spuštění koncové akce jej zavře automaticky; původní `NSMenu` zůstává pouze jako diagnostická cesta na pravém kliku. Panel používá stejné líně sestavované podnabídky a akce, takže neduplikuje chování. Balíček obsahuje lokální obrázky Miniserver, Compact a Go.
- Publikuje jedinou hlavní kameru `Parkoviště a brána` na kanálu 7. Přímý RTSP zdroj zůstává pouze na serveru a checksumem připnutý go2rtc jej převádí na autentizované HLS; Hub drží úspornou předehřátou relaci, browser používá native HLS nebo přesně připnutý hls.js fallback a za úspěch považuje až postupující dekódovaný obraz. Aktivní cesta nepoužívá MJPEG.
- NVR diagnostika dostává pravidelnou nepřekrývající se kontrolu, stav posledního pokusu, úspěchu a chyby a úplný inventář názvů, kanálů, online/offline stavů, modelů a firmware, pokud je zařízení vrátí. Stejný přehled používají Hub, macOS Menu 3.0.18 a nativní Windows Menu 3.0.22. Datový model podporuje více rekordérů a oddělené providery; Milesight P2P zůstává pravdivě označeno jako čekající na oficiální licencované NVR SDK.
- Evora Smart Menu 3.0.18 zachovává jediný AVFoundation/HLS přehrávač pro publikovaný kanál 7 s hlídaným startem, omezeným reconnectem a čistým ukončením. Přímý výsledek hledání Miniserveru otevře úplný detail s akcemi.
- Nativní bezkonzolové Evora Smart Menu 3.0.22 pro Windows používá DPAPI, stávající Hub párování a jen HMAC/SHA-256 ověřený aktualizační balíček s rollbackem.
- Windows Config Launcher 3.0.0.12 při použití již běžící přesné verze znovu získá `MainWindowHandle` po Qt navigaci, prioritně fyzicky aktivuje Domů a rozpozná přesné české varianty `Ručně připojit` i `Manuálně připojit`. Stav, kdy je stejný účet přes Remote Connect už připojen, vrátí jako informaci místo falešné chyby. Tok nového okna a bezpečné ponechání Configu při skutečné chybě zůstávají zachované.
- Ruční synchronizace Excelu odesílá platné prázdné JSON tělo místo HTTP 415. Hodinový import se spustí jen s platnou Microsoft Graph relací, bez nepodporovaného anonymního SharePoint fallbacku; při chybě zůstane viditelná poslední lokální sada úkolů. Párování přesunutých a drobně změněných řádků dál aktualizuje stávající úkol místo duplikace a writeback zůstává vypnutý.
- Produkční Home Assistant image používá již kompletně otestovaný katalogový `dist`; build proto nevyžaduje TypeScript zdroje, které nejsou součástí distribučního add-on kontextu.
- Čerstvý HLS master se klientovi vrátí až poté, co relay v omezeném startovním okně skutečně načte a uloží první video segment. Klient tak při prvním otevření nedostane právě oznámený, ale ještě nedokončený fragment; neúspěšná startovní relace se zahodí a bounded keep-warm může navázat čistě.
- Startovní brána před masterem atomicky uloží také inicializační fragment a všechny segmenty právě vráceného playlistu. VLC ani browser tak nemají po platném masteru narazit na 502 při initu nebo prvním, o jeden fragment starším segmentu.

## 3.0.32

- Po živém zátěžovém důkazu Hubu 3.0.31, ve kterém 12 z 20 HLS segmentů skončilo HTTP 502, už Hub ani Evora Smart Menu nevydávají problematický proud za spolehlivé video. Dočasně publikovaná zůstává pouze kamera `Parkoviště - Recepce - 2` a oba klienti načítají obyčejný autentizovaný JPEG snímek přímo přes NVR. Další požadavek začíná až po dokončení předchozího, nejdříve po deseti sekundách; při přechodné chybě zůstává poslední platný obraz. Aktivní klientská cesta nepoužívá HLS, WebRTC ani MJPEG stream.
- Evora Smart Menu 3.0.16 odstraňuje `AVPlayer` a AVFoundation z kamerového náhledu. Globální i Miniserverové hledání vrací odpovídající Miniservery rovnou jako jednotlivé výsledky bez složkového mezikroku a po přímém kliknutí zachová fokus vyhledávacího pole.
- Windows Config Launcher 3.0.0.7 v režimu již spuštěného Configu nejdřív najde a aktivuje přesný UI Automation prvek tlačítka Domů a teprve potom provede stejný tok jako nové okno: Ručně připojit, vyplnit údaje a Připojit. Pro Qt sestavení, která ignorují `InvokePattern`, znovu ověří tentýž prvek a klikne do jeho aktuálních hranic. Verze se publikuje existujícím autentizovaným atomickým self-updaterem se SHA-256, heartbeat potvrzením a rollbackem.

## 3.0.31

- Checksumem připnutý go2rtc 1.9.14 nyní skutečně čte pořadové číslo `n`, serializuje vytváření fragmentů jedné HLS relace a drží poslední čtyři hotové segmenty v paměti. Opakovaný nebo souběžný klient tak dostane stejný očíslovaný fragment místo destruktivního odebrání dalšího bufferu.
- Hub nad touto malou interní cache dál používá jednu sdílenou H.264 relaci a vlastní omezenou cache 12 fragmentů. Interní čtení se už předčasně neruší, protože zrušený HTTP požadavek mohl v původním go2rtc později spotřebovat segment, aniž by jej Hub obdržel.
- Evora Smart Menu zůstává 3.0.15 s opraveným fokusem hledání a přímými výsledky Miniserverů. Publikovaná je pouze kamera `Parkoviště - Recepce - 2`; přenos zůstává H.264/HLS/fMP4 z RTSP bez MJPEG.

## 3.0.30

- HLS brána kromě rychlé HTTP 502 zachytí také zavěšené interní čtení právě vznikajícího segmentu. Jednotlivý loopback pokus má limit 1,5 sekundy a následné časově omezené pokusy zůstávají single-flight, takže všichni klienti stále používají jedinou RTSP/HLS relaci.
- Evora Smart Menu 3.0.15 opravuje fokus globálního i Miniserverového hledání: kliknutí do pole po otevření Menu znovu získá field editor na následujícím AppKit cyklu a uživatel může hned psát. Přímé výsledky Miniserverů bez procházení složek zůstávají zachované.
- Publikovaná zůstává pouze kamera `Parkoviště - Recepce - 2`; transport je H.264/HLS/fMP4 z RTSP bez MJPEG. Windows Config Launcher zůstává 3.0.0.6.

## 3.0.29

- Hub při krátkém závodě mezi zveřejněním nového HLS segmentu v playlistu a jeho skutečnou dostupností v go2rtc drží jeden sdílený požadavek uvnitř serveru a provede omezené čekání. Prohlížeč ani Evora Smart Menu tak nedostanou přechodnou HTTP 502 jen proto, že právě oznámený fragment ještě není kompletní.
- Opakování se týká pouze H.264/HLS video segmentu, je časově omezené na 2,25 sekundy a stále běží single-flight pro všechny klienty. Úspěšný segment se uloží do omezené cache; trvalá chyba zůstane po vyčerpání pokusů pravdivě viditelná.
- Publikovaná zůstává pouze kamera `Parkoviště - Recepce - 2`; transport je RTSP přebalený do HLS/fMP4 bez MJPEG. Evora Smart Menu zůstává 3.0.14 a Windows Config Launcher 3.0.0.6.

## 3.0.28

- Hub a Evora Smart Menu sdílejí pro stejnou kameru a náhledový H.264 profil jednu upstream HLS relaci. Každý init a video segment načte Hub z go2rtc nejvýše jednou; souběžné i pozdější čtení obslouží omezená serverová cache posledních 12 segmentů, protože živý go2rtc endpoint vydává tentýž segment upstreamu jen jednou.
- Vytvoření HLS relace i načtení stejného segmentu je single-flight. Opakované otevření Hubu nebo Menu tak nevytváří další dočasné session, které by po prvních dvou klientech vracely HTTP 502. Cache se při restartu gateway vyčistí a po skutečném vypršení relace se master před znovupoužitím ověří.
- Publikovaná zůstává pouze online kamera `Parkoviště - Recepce - 2`; náhled je H.264/fMP4 přebalený z RTSP, nikoli MJPEG. Evora Smart Menu zůstává 3.0.14 a Windows Config Launcher 3.0.0.6.

## 3.0.27

- Video gateway registruje shodný RTSP zdroj pouze jednou a souběžný neúspěšný klient už nemaže stream používaný Hubem nebo Evora Smart Menu. Publikovaná zůstává pouze kamera `Parkoviště - Recepce - 2`; živý obraz je dál H.264/H.265 přes WebRTC/HLS, nikdy MJPEG.
- Evora Smart Menu 3.0.14 při hledání zobrazuje odpovídající Miniservery přímo pod sebou bez otevírání složek. Bez aktivního hledání zůstává původní složkové členění.
- Volba Loxone Configu je pouze v Evora Smart Menu: uživatel zvolí již spuštěnou přesnou verzi nebo nové okno. Windows Launcher 3.0.0.6 režim přenese až do cílové relace a při chybějícím běžícím Configu vrátí pravdivou chybu místo tichého otevření jinam.
- Schéma databáze 22 ukládá režim spuštění u jednorázové Config úlohy; stávající Hub akce zůstává kompatibilně v režimu nového okna.

## 3.0.26

- Obě kontejnerové build vrstvy načítají systémové balíky přes HTTPS; minimální runtime před prvním stažením převezme důvěryhodný certifikační svazek z build vrstvy, takže se nevypíná ověřování TLS ani se nepoužívá port 80.
- Server i klient drží časový limit až do úplného přečtení odpovědi. Video gateway při neúspěšném startu ukončí vlastní proces, uklidí každý nefunkční kandidát a při vypnutí čeká na skutečný konec potomka; offline kanál už transport vůbec nespouští.
- Service worker přijme shell jen jako úplný celek, čeká na `skipWaiting`, `clients.claim` i zápis cache. Incidenty, úkoly, kamery a flotila při chybě nezobrazí falešný prázdný či nenastavený stav, ale trvalou chybu s bezpečným opakováním a případně posledními daty.
- Responzivní navigace skrývá na středním desktopu skutečné textové popisky, tabulka flotily se vejde při 1280 px, Config zůstává dostupný na iPadu a dotykové ovládání má minimálně 44 px. Tmavé hledání má jednotný podklad a kontrast primárních akcí i ikony Intranetu je zvýšený.
- Evora Smart Menu 3.0.13 průběžně čte výstup pomocných procesů s časovým limitem, při chybě zachová poslední stav a nepřekrývá název kamery stavovým štítkem.
- Windows Launcher 3.0.0.5 používá atomickou výměnu, skrytý restart přes `wscript.exe`, čerstvý autentizovaný heartbeat a automatický rollback na ověřenou předchozí verzi. Uživatelské DPAPI párování se neaktualizuje ani nepřenáší.

## 3.0.25

- Hub i Evora Smart Menu dočasně zobrazují pouze kameru „Parkoviště - Recepce - 2“ (stabilní kanál 7), aby se neotvíralo deset současných problematických relací.
- Omezení je čistě publikační a nedestruktivní: všech deset kanálů, jejich zjištěný stav, vlastní názvy a konfigurace zůstávají v šifrovaně uložené NVR integraci. Obnovení celého seznamu proto později nebude vyžadovat nové připojení NVR.
- Konfigurace a obnova NVR nadále auditují skutečný počet nalezených kanálů, ale klientskému Hubu a Menu vracejí pouze zvolenou kameru. Aktivní obraz zůstává HLS/WebRTC bez MJPEG.

## 3.0.24

- Interní video brána používá checksumem připnutý zdroj go2rtc 1.9.14 s jedinou auditovatelnou změnou: pevná životnost HLS relace po stažení segmentu je 30 sekund místo pěti. Velký segment přenášený přes šifrovanou Home Assistant proxy tak už nemá ukončit zdravý RTSP proud dřív, než si prohlížeč vyžádá další část videa.
- Proud zůstává datově úsporné H.264/H.265 video přebalené bez změny kvality; aktivní přehrávání nepoužívá MJPEG ani sekvenci snapshotů. Neviditelná nebo zavřená relace se po 30 sekundách stále automaticky uvolní.
- Předchozí verze 3.0.23 je podle cíleného živého testu výslovně nehotová: všech deset master playlistů sice vzniklo, ale šest kanálů skončilo po dvou až třech segmentech a i ostatní později ztratily relaci s HTTP 502.

## 3.0.23

- Náhledová mřížka otevírá úsporné HLS video přímo, bez desetisekundového čekání na WebRTC a bez blokujícího serverového preflightu. Deset dlaždic se spouští s 450ms rozestupem místo 1,2 sekundy; detail jedné kamery nadále preferuje nízkolatenční WebRTC.
- Server už při načtení playlistu sám nestahuje a nezahazuje poslední video segment. Každý segment tak spotřebuje pouze skutečný přehrávač a relace se po krátkém zobrazení obrazu sama nerozpojí.
- Pravdivý stav zůstává zachovaný: označení „živě“ se zobrazí až po dvou skutečně dekódovaných snímcích a zamrzlý obraz po osmi sekundách přejde do omezeného automatického obnovení.

## 3.0.22

- HLS relace se během delší mezery mezi klíčovými snímky udržuje skutečným stažením posledního video segmentu. Opravuje to pětisekundové vypršení relace interní brány, které na živém NVR po několika segmentech ukončovalo šest z deseti kanálů.
- Před předáním relace klientovi Hub ověří inicializaci a dva různé video segmenty po dobu až 20 sekund. Průběžné playlisty stejným mechanismem bezpečně obnovují relaci bez MJPEG, překódování nebo zveřejnění RTSP přístupu.
- Nativní HLS Safari a iPhonu smí vyjednat H.264 i HEVC; Hls.js v ostatních prohlížečích dostává pouze H.264. Kamera s HEVC náhledem tak může na podporovaném zařízení hrát bez zbytečného převodu, zatímco nepodporovaný prohlížeč dostane kompatibilní proud.

## 3.0.21

- WebRTC média používají nový vyhrazený TCP/UDP port 28555, který se shoduje uvnitř kontejneru, v Supervisor mapování i v ICE kandidátech. Odstraňuje se konflikt s již obsazeným portem 18555 na HA Práce.
- HLS záloha před předáním klientovi ověří inicializaci a tři po sobě postupující video segmenty. Nefunkční druhý stream uvolní a bezpečně zkusí hlavní H.264 stream; prohlížeč tak nedostane relaci, která se po dvou segmentech zastaví.
- Dlaždice označí stream jako živý až po dvou skutečně dekódovaných video snímcích. Osmisekundové zamrznutí spustí bezpečný přechod z WebRTC na HLS nebo nový pokus; dočasná chyba už nezůstane trvale ve spinneru ani ve falešném stavu „živě“.
- Aktivní multipart/MJPEG endpointy Hubu a Menu byly odstraněny. Volitelná správcovská funkce nastavení třetího MJPEG profilu kamery zůstává oddělená a není používána pro přehrávání obrazu.
- Evora Smart Menu 3.0.12 při stavu přestávky odpočítává 30 minut po sekundách, zobrazuje zbývající `MM:SS` přímo v řádku Intranetu a v horní liště používá výrazné `☕ MM:SS`.

## 3.0.20

- Firemní Milesight RTSP už není pro Hub překódován na sled samostatných JPEGů. Interní, checksumem ověřená video brána přebaluje kompatibilní H.264/H.265 beze změny obrazu; Hub používá WebRTC a při nedostupném přímém mediálním spojení automaticky přejde na zabezpečené HLS přes stejnou HTTPS adresu.
- Mřížka používá úsporný NVR substream a detail hlavní stream. Přenos se spouští jen pro viditelné karty, RTSP přístup zůstává pouze v paměti a správcovské API video brány i její RTSP listener poslouchají výhradně na loopbacku. Veřejně je otevřen pouze šifrovaný WebRTC mediální port.
- Evora Smart Menu 3.0.11 nahrazuje JPEG náhled nativním `AVPlayer` HLS videem s krátkým bufferem, automatickým opakováním a autorizací v HTTP hlavičce; token ani RTSP adresa nejsou v URL.
- Připojovací stav karty zobrazuje pouze vystředěný spinner. Tmavý režim globálního hledání sjednocuje průhledné pozadí inputu s obalem, takže pod ikonou nezůstává odlišný obdélník.

## 3.0.19

- Postranní nabídka Hubu řadí hlavní systémy podle provozní priority: LOXONE, Home Assistant, Milesight, Intranet, Incidenty, Úkoly a Nastavení. Stejné pořadí používá desktop i mobilní vysouvací nabídka.
- Veřejná Home Assistant proxy 0.1.1 ponechává obsluhu `OPTIONS` na HTTP vrstvě Home Assistantu, takže se komponenta při startu znovu správně načte a veřejná adresa funguje také pro Evora Smart Menu.
- Při zavření dlouhého kamerového náhledu proxy vždy ukončí odpovídající upstream relaci. Opuštěný MJPEG stream tak nemůže vyčerpat sdílená spojení a zablokovat další požadavky Hubu nebo Menu.

## 3.0.18

- Přehled Milesight spouští náhledové relace jednotlivých kamer s řízeným rozestupem 700 ms. NVR tak po otevření stránky nedostane deset současných RTSP/FFmpeg inicializací; čekající dlaždice ukazuje pravdivý stav „Čeká na uvolnění NVR“ a vlastní watchdog začne až po skutečném startu přenosu.
- Otevření detailu stále okamžitě pozastaví všechny náhledy a dá hlavnímu 1280×720 streamu prioritu. Po zavření detailu se náhledy znovu obnoví stejným řízeným pořadím.

## 3.0.17

- Živý read-back všech deseti kanálů odhalil, že některé NVR substreamy po připojení nejprve vracejí šedé nebo částečně rozpadlé dekódované snímky. Hub nyní zahazuje poškozené a nízko-informační zahřívací rámce, čeká na dva po sobě jdoucí použitelné JPEGy a FFmpeg nastavuje na zahazování poškozených paketů.
- Při otevření detailu se ukončí všech deset náhledových relací pod modalem, aby hlavní stream nesoutěžil o RTSP relace a výkon NVR. Po zavření detailu se mřížka znovu připojí.
- Náhled i detail mají konečný watchdog a nejvýše dva automatické pokusy. Pokud obraz nedorazí, spinner skončí pravdivým stavem „Obraz momentálně není dostupný“; označení „živě“ se zobrazí až po skutečně načteném rámci.
- Kanál bez potvrzeného NVR Channel Access už nespouští nekonečné zjišťování schopností kamery. Hub ponechá funkční živý obraz a přesně vysvětlí, proč zatím nelze otevřít třetí stream ani VCA nastavení.

## 3.0.16

- Sekce **Milesight** zachovává online i offline kanály NVR, používá oficiální značku a zobrazuje skutečný stav přístupu ke každé kameře. Síťovým cílem zůstává výhradně NVR; kamerové CGI se volá přes ověřený Channel Access port daného kanálu.
- Hub nejdřív načte schopnosti konkrétní kamery. Třetí stream zapne jako MJPEG pouze tehdy, když kamera sama potvrdí podporované rozlišení a snímkovou frekvenci, zvolí nejvyšší potvrzenou kombinaci a po zápisu provede úplný read-back. Ověřený třetí MJPEG stream předává souvisle; při jeho absenci zachová dosavadní sdílený NVR stream.
- U podporovaných VCA událostí lze načíst a upravit tři HTTP cíle, metodu a interval. Uložené heslo se nikdy neposílá klientovi; prázdné pole jej zachová a výslovné smazání je samostatná volba. Uložení se potvrdí novým čtením z kamery.
- Evora Smart Menu 3.0.10 přejmenovává kategorii na **Milesight**, používá oficiální značku a nadále ukazuje vlastní verzi odděleně od živé verze Hubu.
- Windows Config Launcher 3.0.0.4 zachovává při automatickém stažení Home Assistant ingress prefix a zpožděný restart spouští přes bezokenní VBS obálku.
- Microsoft Graph synchronizace Excelu zůstává pouze pro čtení; přesun nebo drobná změna řádku aktualizuje stejný Hub úkol a zápis do Excelu je vypnutý.

## 3.0.15

- Každý kamerový náhled nejprve po dobu nejvýše pěti sekund prověří skutečný druhý stream a potom bez přerušení klienta použije zmenšený hlavní stream. Každý multipart rámec nese bezpečný údaj `substream` nebo `main-fallback`, takže živá kontrola může prokázat skutečný zdroj po jednotlivých kamerách bez zveřejnění RTSP adresy či přístupu.
- Pomalý nebo odpojený odběratel se po pěti sekundách trvalého backpressure odstraní a uvolní sdílený FFmpeg proces. Staré relace tak nezaplní limit a nezpůsobí dalším kamerám HTTP 503.
- Windows Config Launcher 3.0.0.3 nahrazuje přímý minutový start `powershell.exe` bezokenní VBS obálkou přes `wscript.exe`; automatická aktualizace opraví existující watchdog i autostart bez nového párování.
- Evora Smart Menu 3.0.9 a Hub označují výstup jako úsporný náhled, nikoli neověřený druhý stream.

## 3.0.14

- Živý test 3.0.13 odhalil, že cílový starší Milesight NVR nenabízí očekávanou cestu druhého streamu `ch_4xx`. Úsporný stream nyní tuto cestu bezpečně zkusí a bez přerušení klienta automaticky přejde na zmenšený hlavní `ch_1xx`; nikde nezveřejní RTSP adresu ani přístup.
- Detail hlavního streamu používá 1280 px, 10 fps a dva kodérovací workery místo 1600 px/15 fps s jedním workerem. Snižuje tím objem jednotlivých JPEG rámců a zvyšuje skutečnou plynulost na ARM hostiteli.
- Evora Smart Menu 3.0.8 označuje náhled pravdivě jako úsporný stream bez tvrzení, že každý NVR skutečně poskytl samostatný druhý stream.

## 3.0.13

- Nahrazuje periodické JPEG snapshoty souvislým autorizovaným přenosem. Přehled Hubu i Evora Smart Menu 3.0.7 používají úsporný druhý Milesight stream `ch_4xx`; detail po kliknutí otevírá kvalitnější hlavní stream `ch_1xx`.
- Pro stejnou kameru a kvalitu Hub sdílí jediný FFmpeg proces mezi klienty, pomalému klientovi zahazuje starší rámce a po odpojení posledního diváka RTSP relaci okamžitě ukončí. Karty mimo viewport a skrytá karta prohlížeče žádný stream nedrží.
- NVR přístupy i RTSP adresa zůstávají pouze v jednorázovém stdin FFmpegu. Browser i Menu dostávají autorizované `multipart/x-mixed-replace` bez hesla, RTSP URL nebo dlouhodobého tokenu v adrese.

## 3.0.12

- Opravuje HTTP 400 na starším Milesight NVR. Hub už nespojuje podporovaný `get.camera.ipclist` s nepodporovaným systémovým příkazem; načítá pouze seznam, který používá i webové rozhraní tohoto firmwaru.
- Náhled obrazu používá zdokumentované RTSP kanály `ch_1xx` přes TCP. Přihlašovací RTSP adresa se předává FFmpegu pouze jednorázovým stdin, nikdy v argumentech procesu, prohlížeči ani logu.
- Správce a technik mohou každou kameru přejmenovat přímo v kartě. Vlastní název zůstane zachovaný i po obnovení seznamu z NVR.
- Kamery mají v Hubu samostatnou fialovou navigační barvu odlišnou od oranžových incidentů. Evora Smart Menu 3.0.6 používá pro kategorii Kamer stejnou fialovou sémantiku.

## 3.0.11

- Přidává kompatibilitu se starším Milesight NVR, které po prvním anonymním požadavku nabídne pouze HTTP Basic. Hub neposílá přihlášení předem, údaje nevkládá do URL ani logu a cílovou adresu dál omezuje výhradně na privátní IPv4 síť.
- Zachovává preferenci podporovaného Digest přihlášení, pokud jej zařízení nabídne, a zpřesňuje text formuláře: údaje jsou šifrované v Hubu, zatímco způsob LAN přihlášení určuje NVR.
- Evora Smart Menu 3.0.5 opravuje neaktuální záhlaví. Po úspěšném načtení API se text „Hub nepřipojen“ okamžitě změní na skutečnou živou verzi Hubu; `Systémy → Kamery` zůstávají viditelné i před načtením prvního kanálu a nabídnou přímé nastavení NVR.

## 3.0.10

- Opravuje připojení Milesight NVR: Hub už nevyrábí vlastní neplatný Digest nonce, ale nejprve načte skutečnou výzvu zařízení a podepíše přesnou cestu SDK včetně dotazu.
- Digest přihlášení podporuje `MD5`, `MD5-sess`, `qop=auth`, volitelný `opaque` a jeden bezpečný nový pokus při zastaralém nonce. Uživatelské jméno ani heslo se neposílají v URL a heslo se nadále ukládá pouze šifrovaně.
- Evora Smart Menu 3.0.4 zachovává `Systémy → Kamery` se zabezpečeným náhledem konkrétního kanálu a v záhlaví nově rozlišuje vlastní verzi od živě načtené verze Hubu. Excel zůstává pouze pro čtení směrem do Hubu.

## 3.0.9

- Opravuje párování dlouhých Excel požadavků: podobnost se počítá z celého pole „Požadavek“ uloženého v popisu, nikoli ze zkráceného 240znakového titulku. I změna na konci dlouhého textu tak aktualizuje stejné ID úkolu.
- Při dalším importu bezpečně sloučí čerstvý systémový duplikát vzniklý starším párováním pouze tehdy, když jde o téměř totožný řádek, záznam nemá lokálně změněný stav a neobsahuje komentář, přílohu, štítek ani uživatelskou událost.
- Excel zůstává pouze pro čtení směrem do Hubu a Evora Smart Menu zůstává ve verzi 3.0.3.

## 3.0.8

- Přidává tenantově omezené Microsoft Graph device-code připojení pro organizační SharePoint bez klientského tajemství nebo uloženého Office hesla. Obnovovací token je šifrovaný a hodinový import začne až po úspěšném připojení správce.
- Excel běží pouze směrem do Hubu. Přesunutý řádek se nejprve páruje stabilním otiskem a drobná změna místa nebo požadavku omezenou podobností, takže upraví stejné ID úkolu místo vytvoření duplikátu. Runtime neodesílá Graph `PATCH`; dokončení zůstává pouze v Hubu.
- Přidává zabezpečené připojení Milesight NVR v privátní síti HA Práce. Přístupy jsou šifrované AES-256-GCM a nikdy se nevkládají do URL, klientského JavaScriptu ani argumentů procesu.
- Nová stránka Kamery je společně dostupná v desktopové i mobilní navigaci Hubu, automaticky načítá online kanály z NVR a nabízí úsporné náhledy i rychlejší detail vybrané kamery.
- Evora Smart Menu 3.0.3 zobrazuje v `Systémy → Kamery` zabezpečený velký náhled konkrétní kamery a v detailu Miniserveru ověřený poměr prvků online/celkem, počet offline prvků, Health stav, stáří kontroly a odezvu. Globální hledání slučuje rychlé vstupy a během psaní odkládá síťové překreslení, aby se AppKit nezablokoval.

## 3.0.7

- Dokončuje kontrastní audit tmavého režimu napříč formuláři, navigací, modaly, diagnostikou, tickety, úkoly, Intranetem, uživateli, zálohami a mobilní nabídkou. Bílé pomocné plochy a odstíny určené pro světlé pozadí dostaly vlastní tmavé povrchy a čitelné texty.
- Zvyšuje kontrast pomocných textů a placeholderů, zachovává čitelné zakázané hodnoty i automaticky doplněná pole Safari/Chromia a sjednocuje hover, aktivní položky, scrollbar a výběr textu.
- Zelené, červené, oranžové, modré a fialové datové stavy mají samostatné tmavé dvojice popředí a pozadí. Automatický test nově hlídá minimální WCAG AA kontrast klíčových tokenů a stavů.
- Evora Smart Menu a Windows klient zůstávají ve verzi 3.0.1, Config Launcher ve verzi 3.0.0.2; tento balíček mění pouze Hub.

## 3.0.6

- Přidává v Nastavení volbu Světlý, Tmavý a Automaticky podle zařízení. Volba se ukládá v daném prohlížeči, automatický režim živě sleduje systém a motiv se nastaví ještě před vykreslením aplikace bez světlého probliknutí.
- Tmavý režim mění celý povrchový systém Hubu: navigaci, panely, karty, tabulky, formuláře, modaly, detailní zásuvky, tickety, úkoly, Intranet, diagnostiku i mobilní nabídku. Stavové barvy zůstávají významově odlišené.
- Desktopová správa uživatelů drží jméno, e-mail, poznámku hlavního správce, fotografické akce, roli, 2FA, poslední přihlášení a stav v jednom kompaktním řádku; samostatné dotykové rozložení telefonu zůstává zachované.
- Přidává chráněný import původního XLSX pro bezpečné prvotní naplnění Úkolů v situaci, kdy organizační SharePoint vyžaduje Microsoft 365 přihlášení. Import používá stávající šifrovaný administrační token, kontroluje formát i limit 25 MB a nepřenáší Office heslo.
- Evora Smart Menu a Windows klient zůstávají ve verzi 3.0.1, Config Launcher ve verzi 3.0.0.2; tento balíček mění pouze Hub.

## 3.0.5

- Zmenšuje desktopové pole jména na stejnou 36px výšku jako ostatní buňky a omezuje jeho šířku, aniž mění velikost textu.
- Na iPhonu zmenšuje uživatelské karty, avatary a fotografické akce, zachovává bezpečný 16px font editovatelného pole a uzavírá tabulku do šířky viewportu bez vodorovného posunu.
- Přidává zřetelnou stabilní mezeru mezi informační ikonou registrace a verzí firmwaru a v Hubu zobrazuje diagnostiku Windows Launcheru česky.
- Evora Smart Menu a Windows klient zůstávají ve verzi 3.0.1, Config Launcher ve verzi 3.0.0.2; tento balíček mění pouze Hub.

## 3.0.4

- Přidává úsporný interní stav a ruční spuštění synchronizace servisních úkolů z Excelu, chráněné stejným silným tokenem jako šifrovaná záloha.
- Diagnostika vrací jen počty a stav synchronizace, takže už není nutné stahovat velkou databázovou zálohu ani zveřejňovat obsah úkolů.
- Evora Smart Menu a Windows klient zůstávají ve verzi 3.0.1, Config Launcher ve verzi 3.0.0.2; tento balíček mění pouze Hub.

## 3.0.3

- Úkoly načítají aktivní řádky z listu `PROGRAMOVÁNÍ - DOKONČOVÁNÍ` sdíleného Excelu, bezpečně končí před oddílem `HOTOVO` a používají stabilní vazbu na řádek i otisk obsahu, takže hodinová nebo ruční synchronizace nevytváří duplikáty.
- Stav synchronizace, počet načtených řádků, poslední úspěch a případná chyba jsou vidět přímo v centru Úkoly. Sdílený odkaz je pouze pro čtení; Hub proto změnu stavu uchová lokálně a výslovně označí čekající zápis místo nepravdivého potvrzení změny původního Excelu.
- Mobilní stránka už nemůže odjet do prázdného pravého prostoru: kořen aplikace a obsah mají uzavřenou šířku a nabídka se odkrývá uvnitř viewportu bez prvku posunutého mimo obrazovku.
- iPhone správa uživatelů používá kompaktnější avatar, kartu a 44px ovládací prvky. Mezi registrační informační ikonou Miniserveru a verzí firmwaru je samostatná mezera.
- Text diagnostiky Windows Launcheru se dál skládá z českých stavových vět v Hubu; nový cache identifikátor 3.0.3 vynutí načtení této verze i na telefonu.
- Evora Smart Menu a Windows klient zůstávají ve verzi 3.0.1, Config Launcher ve verzi 3.0.0.2; tento balíček mění pouze Hub.

## 3.0.2

- Opravuje živým desktopovým screenshotem potvrzené přetékání a špatné zarovnání v tabulce uživatelů: řádky zůstávají kompaktní, ale jméno, e-mail, kruhový avatar, fotografické akce, role i stav mají čitelné jednotné rozměry.
- Pole globálního hledání používá krátký nezkrácený text „Hledat všude…“; nadále prohledává celou aplikaci, podsložky i datové záznamy.
- Diagnostika Windows Launcheru má čitelnou desktopovou typografii a všechny známé výsledky vysvětluje česky; technické ověřování a data heartbeat se nemění.
- Evora Smart Menu a Windows klient zůstávají ve verzi 3.0.1, Config Launcher ve verzi 3.0.0.2; jejich už ověřené balíčky se tímto čistě hubovým grafickým patchem nemění.

## 3.0.1

- Globální hledání Hubu nyní prochází celou aplikaci, dostupné podsekce i datové záznamy (Miniservery, složky, úkoly, incidenty, tickety a uživatele) a výsledek otevře přímo; nejde už jen o filtr postranní nabídky.
- Mobilní formulář absence, počítadlo, datumová pole, půlden a správa uživatelů používají sjednocené dotykové výšky, typografii a samostatný responzivní layout bez překryvů. Profilové fotografie a stavové tečky mají pevnou kruhovou geometrii.
- Evora Smart Menu 3.0.1 používá významové ikony ve všech vlastních dialozích, nativní setrvačný posun ticketu dvěma prsty a rekurzivní hledání v celé nabídce včetně podsložek.
- Windows Config Launcher 3.0.0.2 má bezpečné atomické přepárování, minutový uživatelský watchdog, ověřený heartbeat nové verze, úplný rollback při neúspěchu a bezpečné odebrání počítače z Hubu bez mazání lokálních Windows souborů.
- Windows klient Evora Smart Menu 3.0.1 odděluje trvalý online heartbeat od sběru pracovních dat, stav vysvětluje přímo v `WORK status` a minutový watchdog jej po pádu obnoví bez samovolného zapnutí sběru. Instalátor Config Launcheru navíc bezpečně zvládá přechod ze starších verzí bez runtime souboru.

## 3.0.0

- Evora Smart Hub a Evora Smart Menu jsou sjednocené do společného vydání 3.0.0. Hlavní hledání Hubu prochází bez diakritiky celou aplikaci: obrazovky a podsekce, Miniservery, složky, úkoly, incidenty, tickety a uživatele podle oprávnění; nalezený datový záznam rovnou otevře.
- Evora Smart Menu používá pro Evora Intranet stejnou zelenou značku `e` jako Hub. Detail ticketu ukazuje animovaný stav načítání, komunikaci dělí podle účastníků a přesný trackpadový posun zobrazuje plynule.
- Docházkové relace přes půlnoc se slučují do jediného pracovního záznamu přiřazeného dni začátku. Součet, historie i aktivní stav tak neztrácejí Home office nebo práci ukončenou po půlnoci.
- Sledování práce se automaticky řídí ověřeným aktivním stavem Evora Intranetu; při práci běží, při pauze se pozastaví a mimo docházku zůstává neaktivní.
- Windows Config Launcher 3.0.0.2 běží v oznamovací oblasti Windows s vlastní značkou a stavovou tečkou, umí ruční kontrolu aktualizace, otevření diagnostiky, DNS/TLS/health preflight a bezpečné znovupárování bez předčasného zneplatnění funkčního tokenu. Přihlášenou relaci hlídá minutová uživatelská úloha a neúspěšná výměna automaticky obnoví předchozí funkční instalaci. Hub může vybraný počítač odebrat bez mazání jeho lokálních Windows souborů.
- Správa uživatelů, složek, podpory a žádostí o absenci dostala kompaktní a responzivní geometrii bez přetékání textu; avatar zůstává skutečně kruhový.

## 2.2.5

- Hlavní nabídka Hubu má globální hledání bez ohledu na diakritiku. Prohledává i skryté podsložky LOXONE, Podpora a Nastavení, při shodě je otevře a po volbě obnoví běžný stav menu.
- Evora Smart Menu 5.8.5 dostalo stejné globální hledání. Prochází všechny nativní podsložky včetně Miniserverů, docházky, ticketů a systémových akcí a spouští přímo původní nalezenou položku.
- Správcovský Evora Intranet načítá z oficiálních stránek také pracovní kontakty a dovolené/absence. Telefon lze vytočit přímo a novou žádost nebo zrušení Hub zapisuje přes oficiální Intranet API s potvrzením a auditním záznamem bez poznámky.
- Postranní menu má jednotné řádky s jemně barevným pozadím podle sekce. Intranet používá bílou značku `e` na zeleném podkladu; aktivní stav je výraznější, ale geometrie se nemění.
- Desktopová správa uživatelů používá kompaktní padesátipixelové řádky a menší jednotné editory, avatary a stavová tlačítka. Mobilní uživatelské karty zůstávají samostatně dotykové.
- Evora Smart Menu 5.8.5 má značku Hubu v liště, barevné ikony a čitelné hodnoty, živý pracovní čas, přesný stav sledování a zobrazuje jen právě použitelnou akci pozastavit/pokračovat. Počet nepřečtených upozornění se v menu vůbec nevykresluje.
- Integrační balíček nově přenáší i značku Evora Smart Hubu a ověřuje její přítomnost před instalací. Uživatelské názvy v Hubu i instalátoru používají jednotně `Evora Smart Menu`.

## 2.2.4

- Windows Launcher 2.1.1.0 dostal výslovné bezpečné znovuspojení. Hub vytvoří nový jednorázový kód, balíček nabízí dvojklik `Opravit-parovani.cmd` a po úspěchu zneplatní starý token stejného Windows agenta; běžná aktualizace dál zachovává platné párování.
- Launcher nyní odmítnutý uložený token rozpozná jako chybu párování a uživatele nasměruje na opravný postup místo neurčité chyby spojení.
- Mobilní Intranet používá stejnou třísloupcovou geometrii jako ostatní řádky nabídky a stav s časem zůstává zarovnaný vpravo. Profilová fotografie je čistě kruhová bez barevného podkladu mimo snímek.
- WorkLogAI 5.8.3 vkládá symboly přímo do titulku položky NSMenuItem, takže macOS menu již nemůže potlačit samostatnou vlastnost ikony.

## 2.2.3

- Mobilní nabídka zobrazuje právě jedno odhlášení: profil a mobilní tlačítko tvoří jeden spodní blok a desktopový účet je na telefonu výslovně skrytý.
- Intranet má samostatný pravý sloupec pro stavovou tečku a čas, takže název ani běžící čas se nepřekrývají. Úplný stav zůstává dostupný jako popis prvku.
- Interní centrum i položka nabídky používají kratší jednotný název `Úkoly`.

## 2.2.2

- Živý sekundový čas Evora Intranetu je izolovaný pouze v malém stavovém řádku menu. Už každou sekundu nepřekresluje celou flotilu 137 Miniserverů ani otevřenou postranní nabídku.
- Mobilní panel se otevírá kompozičním posunem přes GPU místo průběžné změny polohy a jeho trvalá loga už neanimují náročný stín. Přihlašovací a aktualizační animace zůstávají zachované.
- Z karty Docházkové akce byl odstraněn počet upozornění a vysvětlující text je přitažen přímo pod nadpis.
- Intranet je v menu jednotná jednořádková položka se stavem vpravo. Home Assistant používá vloženou značku bez rizika rozbitého obrázku a přihlašovací, horní i mobilní logo dostalo viditelnou transformovou animaci s podporou systémového omezení pohybu.
- Velké mobilní akční a souhrnné buňky používají společnou výšku 76 px, jednotnou velikost hlavního a pomocného textu i ikon; navigační řádky a běžná ovládací tlačítka zůstávají ve svém jednotném dotykovém rozměru.

## 2.2.1

- Provozní log už nikdy neukládá query string požadavku. Starší klient tedy může dál používat původní URL, ale jeho API klíč, token ani jiný parametr se do logu nedostane.
- Zachovává všechny funkce, menu a správcovskou integraci Evora Intranetu z verze 2.2.0.

## 2.2.0

- Správce má v Evora Smart Hubu nové centrum `Evora Intranet → Docházka`. Bezpečně zobrazuje aktuální stav, právě běžící pracovní čas, příchod, odchod, Home office, služební cestu, měsíční souhrny, historii aktuálního a předchozího měsíce i přítomnost kolegů.
- Přihlašovací údaje a obnovovací token Evora Intranetu jsou odděleně šifrované pomocí AES-256-GCM. Integrace automaticky obnovuje relaci, rozlišuje přesné stavy dat, neposílá GPS a její API je dostupné pouze správci.
- Nativní WorkLogAI zobrazuje běžící docházku v liště i menu s přesností na sekundy jako `HH:MM:SS`; historie si zachovává čitelný hodinový souhrn.
- Mobilní i desktopové menu má jednotnou hierarchii: Podpora je pod LOXONE a Provozní log, Uživatelé a Nástroje jsou pod Nastavením. V každém rozvržení se zobrazuje jen jedno odhlášení.
- Horní akce flotily používají samostatné srozumitelné ikony a na telefonu stejně velké dvousloupcové dotykové buňky bez přetékání textu.

## 2.1.2

- Aktualizace Home Assistantu respektují příznak `supported_features`: záloha se vyžádá jen u entit, které ji skutečně podporují. Při zastaralém příznaku Hub bezpečně zopakuje instalaci bez nepodporované zálohy, takže fungují také HACS karty a doplňky bez funkce BACKUP.
- Odmítnutý token, nedostupný Home Assistant a odmítnutá aktualizační služba už nekončí neurčitou „Vnitřní chybou aplikace“, ale přesným bezpečným hlášením bez URL nebo tokenu.
- Mobilní akční tlačítka mají stejnou šířku a výšku; filtry, uložené pohledy a jejich tlačítka používají jednotnou dotykovou výšku 44 px.

## 2.1.1

- Opravuje provozní pád plánovače, který mohl při dočasném síťovém selhání jednoho 1-Wire Miniserveru ukončit celý proces Hubu. Chyba se nyní bezpečně zapíše do auditu bez hesla, tokenu nebo adresy a další monitoring pokračuje.
- Odděleně zachytává také neočekávané chyby odpojených běhů plánovače, takže jedna chybná kontrola neshodí web, health endpoint ani ostatní Miniservery.

## 2.1.0

- Každý Miniserver a dílčí zdroj rozlišuje osm explicitních stavů: načítání, aktuální, zastaralý, nedostupný, odmítnuté přihlášení, chybějící přístup, údaj neposkytnutý zdrojem a interní chyba Hubu.
- Nové centrum incidentů slučuje opakované výpadky a provozní závady podle stabilního fingerprintu, hlídá závažnost, odpovědnou osobu a SLA a uchovává komentáře i historii; po potvrzeném zotavení automaticky uzavírá průběžně monitorované incidenty.
- Gateway a samostatné Miniservery mají servisní profil se zákazníkem, kontaktem, adresou, smlouvou, zárukou, další kontrolou, vlastními poli a barevnými tagy. Client profil je pouze pro čtení a dědí kontakt své Gateway.
- Interní servisní úkoly nahrazují sdílený Excel: mají číslo, prioritu, stav, odpovědnou osobu, termín, připomenutí, vazbu na incident a Miniserver, kontakt, komentáře, historii, uložené pohledy a šifrované fotografie nebo PDF do 8 MB.
- Tester připojení postupně ověřuje DNS a síť, Remote Connect, Miniserver, TLS, přihlášení, `/data/status`, LoxAPP3 a Health Check, Partner Portal a osobní Windows Launcher. Chybějící přístup, odmítnuté heslo a síťová chyba mají odlišné výsledky.
- Windows Launcher 2.1.0.0 hlásí podpis, nainstalované Configy, UI Automation, oprávnění, spojení s Hubem, bezpečný protokol a automatickou aktualizaci. Aktualizaci stahuje z ověřeného manifestu Hubu a přijme ji pouze při přesné shodě SHA-256; při selhání ponechá Config otevřený pro ruční připojení a vrátí přesný krok chyby.
- Schéma databáze 18 přidává servisní profily, tagy, uložené pohledy, incidenty, interní úkoly, šifrované přílohy a historii testeru připojení.

## 2.0.10

- průběžná fronta obnovuje Miniservery jednotlivě s minimálním 30sekundovým rozestupem místo automatického nárazu celé flotily
- `/data/status`, firmware a dostupnost se obnovují v dvouhodinovém cyklu, Health Check po 12 hodinách, LoxAPP3 po 24 hodinách a 1‑Wire po 10 minutách
- V2 statistiky čtou aktuální `statisticV2.groups[].dataPoints[]`, takže lze vybrat skutečný výstup a stáhnout BIN
- inventář zachovává a zobrazuje dostupné Air RSSI, počet skoků, baterii, název produktu a produktové číslo
- rozšířené přesné produktové fotografie z oficiálního Loxone Shop CDN; obecné typy se nepřiřazují odhadem
- aplikace i manifest ZIPu přesně vysvětlují obsah anonymizovaného servisního balíčku
- přehled Miniserveru ukazuje stáří Health Checku a LoxAPP3 a úvod aplikace popisuje její účel a bezpečnostní model

## 2.0.9

- Mobilní nabídka znovu zobrazuje všechny tři názvy podpory, používá jednotnou velikost textu a ikon a po otevření nezachovává kompoziční transformaci ani rozmazávací filtr. Značka v hlavičce, přihlášení a aktualizační obrazovce má jemnou animaci respektující omezení pohybu v systému.
- Složky dostávají odlišné barvy z řízené palety. Databázová migrace jednorázově rozliší také staré duplicitní barvy bez změny přiřazení Miniserverů.
- Veřejná komunikace ticketů je rozdělena do čitelných zpráv podle účastníka a času; události se soubory jsou vizuálně odlišené. Stejné čitelné členění používá WorkLog AI.
- Během aktualizace HA Práce se po dříve úspěšném načtení zobrazí lokální animovaný stav a aplikace se sama znovu připojí. Service worker ukládá pouze statický shell a výslovně vynechává API, health endpoint i autentizovaná data.
- Stažení aktuálního programu nejdřív ověří všechny časově odpovídající archivy proti živému LoxAPP3. Pokud přesná shoda na SD kartě není, nabídne nejnovější validní zálohu s jasným prefixem `ZALOHA_` místo zavádějící chyby.
- Správce může bezpečně vypsat až 250 historických programových záloh z `/dev/fslist/prog/` a stáhnout pouze název, který je po kliknutí znovu ověřen v aktuálním katalogu. Obsahuje-li archiv bezpečný `sps.loxone`, vydá se přímo jako `.Loxone`; jinak zůstane původní ZIP.
- Databázové schéma je 16. Kontrola závislostí, TypeScript, ESLint, automatické testy, produkční build a nativní typecheck WorkLog AI jsou součástí vydání.

## 2.0.8

- Informační tlačítko u sériového čísla na iPhonu otevírá skutečné dotykové okno s názvem projektu, datem registrace z Partner Portálu a sériovým číslem; už není závislé na desktopovém hover efektu.
- Souhrn Firmware je při otevření přehledu Miniserverů sbalený do kompaktního řádku a čtyři firmware karty se zobrazí až po klepnutí.
- Všechny tři položky Podpory používají stejný pevný sloupec pro ikonu a shodný začátek textu, takže Partner Portal už není opticky posunutý.

## 2.0.7

- Profilové fotografie a úprava jména fungují také pro migrovaný hlavní účet s trvalým identifikátorem `owner-*`; povolený formát ID zůstává úzce omezený proti průchodu cestou.
- Dostupnost flotily rozlišuje čtyři vzájemně výlučné stavy: ověřeně online, bez přístupu, neodpovídá a neověřeno. Souhrn dostupnosti je oddělený od souhrnu firmware, takže se počty už významově nemíchají.
- Chyba aktualizace ticketů ani detailu už nesmaže lokální cache a nezobrazuje falešné globální hlášení. Seznam i komunikace jasně uvedou, že používají poslední uložená data, a nabídnou samostatné opakování.
- Mobilní a desktopové vnořené menu má jednotnou výšku, velikost textu a ikon. Automatická úvodní kontrola už nezobrazuje nesouvisející červený toast nad otevřeným detailem; případná chyba složky zůstává přímo v jejím panelu.
- Odkaz do Loxone App na iPhonu používá oficiální cíl `loc=home`, zachovává první otevření jako přímé klepnutí uživatele a při studeném startu provede právě jedno bezpečné zopakování kompletního cíle. Systémové potvrzení Passkey na iOS zůstává povinnou bezpečnostní součástí Face ID.
- WorkLogAI integrace je vydaná společně s Hubem 2.0.7 a při neúspěšné kontrole Portálu dál zachová již načtené tickety.

## 2.0.6

- WorkLogAI zobrazuje přílohy, u kterých Partner Portál poskytl pouze název, jako statický přehled bez falešného tlačítka pro stažení a bez následné technické chybové hlášky.
- Skutečně dostupné přílohy zůstávají oddělené a lze je bezpečně otevřít přes Evora Smart Hub.

## 2.0.5

- Při převodu komunikace na přílohy odlišuje skutečné souborové/download odkazy od běžných webových odkazů v textu ticketu.
- Zachovává šifrovanou cache, správné schéma 15, rychlé načítání Hubu i WorkLogAI a všechny opravy vydání 2.0.4.

## 2.0.4

- Opravuje stavový endpoint tak, aby po migraci správně hlásil databázové schéma 15 používané cache ticketů.
- Zachovává všechny opravy 2.0.3 pro přílohy, lokální cache, mobilní rozvržení, profilové fotografie a Windows Launcher 2.0.0.3.

## 2.0.3

- Windows Config Launcher 2.0.0.3 se umí bezpečně aktualizovat přímo ve stejném Windows účtu: ukončí jen přesně rozpoznaný starý helper daného uživatele, zachová stávající DPAPI token a bez nového párování spustí opravenou verzi.
- Hub rozpozná helper starší než 2.0.0.2, jasně vyžádá aktualizaci a do té doby mu nepředá přístupové údaje ani novou úlohu. Verze 2.0.0.2 zůstává funkční a pouze nabídne dostupnou aktualizaci.
- Stejný stav aktualizace se zobrazuje v Config Bridge, Nastavení i WorkLog AI, takže starší automatizace už neskončí neurčitou chybou až po vyplnění připojovacího dialogu.
- Mobilní nabídka používá stejnou hierarchii jako desktop v pravém výsuvném panelu; Config zůstává na telefonu zcela skrytý. Podpora má jednotnou výšku položek a mobilní karta bezpečně odděluje SN, datum registrace a firmware.
- Detail Miniserveru na iOS už nepoužívá rozmazávací vrstvu ani kompoziční animaci. Správa uživatelů má stabilní sloupce a profilová fotografie se načítá přímo z autentizovaného obrazového endpointu bez mezikroku přes FileReader.
- Centrum ticketů využívá celou výšku okna, oba sloupce se posouvají samostatně a tlačítko Odpovědět je dostupné i u uzavřeného ticketu v Hubu i WorkLog AI.
- Ticketový seznam a veřejná komunikace se ukládají do lokální cache; obsah komunikace a reference příloh jsou v databázi šifrované. Běžné otevření Hubu i WorkFlowAI už znovu nestahuje všech 140 ticketů; explicitní aktualizace porovná souhrny, přepíše jen změněné záznamy a detail načte znovu pouze po změně. Skutečné přílohy a odkazy vložené do zpráv se zobrazí samostatně a WorkFlowAI je umí bezpečně otevřít přes Hub.

## 2.0.2

- Správce má přímo v Evora Smart Hubu bezpečné centrum Loxone ticketů: seznam a filtrování, detail veřejné komunikace a příloh, založení ticketu i odpověď. Každé odeslání nejdřív ukáže úplný náhled a potom vyžádá heslo správce; technikům a uživatelům zůstávají jen původní externí odkazy.
- Stejné správcovské funkce ticketů jsou dostupné v nativním menu WorkLog AI. Token integrace nadále funguje jen aktivnímu správci a odpojení Macu vyčistí také načtené tickety.
- Účty mají samostatné zobrazované jméno. Správce je může upravit v sekci Uživatelé, přihlašovací e-mail zůstává beze změny a hlavní účet se doplní jako `Bc. Michal Schöniger`.
- Uložený vestavěný login Miniserveru se bez ohledu na původní zápis normalizuje na přesné `admin`, takže Windows Config Launcher už neposílá chybné `ADMIN`.
- Mobilní karty uživatelů a ticketů jsou upravené pro iPhone bez překrytí jména, fotografie, rolí a ovládacích prvků.

## 2.0.1

- Windows Config Launcher 2.0.0.2 používá pro uživatelské jméno a heslo přímý UI Automation `ValuePattern`, takže jej neovlivní Caps Lock. Vyhledává dialog uvnitř správného procesu, neduplikuje stav spuštění a úspěch potvrdí až po osmisekundové kontrole, že Config přihlášení neodmítl.
- Aktualizace Home Assistantu vyžadují pouze výslovné potvrzení bez hesla; správce může jedním potvrzením spustit všechny čekající aktualizace.
- Opravena skutečná příčina nezobrazených profilových fotografií v relaci. Správce může fotografii nahrát nebo odstranit také ostatním uživatelům.
- Passkey lze odstranit i přes Home Assistant Ingress a každý telefon či počítač si může zaregistrovat vlastní Face ID, Touch ID nebo Windows Hello klíč.
- Partner Portal a Tickety jsou přesunuty pod Podporu. Inventář ukazuje jen přesně rozpoznané produktové fotografie a neznámému prvku už nepřiřazuje zavádějící obecný obrázek.
- WorkLog AI zobrazuje u každého Miniserveru zelený nebo šedý stav a má vyhledávání podle projektu, složky, typu i SN bez ohledu na diakritiku.
- U SN je nové informační kolečko s datem registrace z Partner Portálu. Tlačítko Config používá vlastní rozpoznatelnou ikonu místo obecného dokumentu.

## 2.0.0

- Nové Miniservery importované z Partner Portálu se okamžitě označí jako `Nový z Portálu`, řadí se před ostatní, mají samostatný filtr a vyžádají doplnění loginu a hesla. Po uložení přístupu označení automaticky zmizí.
- Ruční synchronizace Portálu se sleduje až do skutečného dokončení a potom bez reloadu obnoví stránku Miniservery. Pozadí úloh po restartu sloučí staré duplicitní synchronizace do jediného pokusu.
- Přidáno bezpečné doplnění hesla pro automatické znovupřihlášení staršího portálového propojení, které dosud mělo jen obnovovací token.
- Partner Portal synchronizuje také svůj jednoznačný příznak aktivního Weather Service. U Miniserveru s aktivní službou se zobrazí původní zelená ikona Loxone; neaktivní ani nezjištěná služba se nezobrazuje.
- Windows Config Launcher 2.0.0.1 čeká na plně spuštěný Config, umí se vrátit z otevřeného projektu na Domů, otevře ruční připojení a po ustálení externí adresy znovu ověří login, heslo i aktivní tlačítko Připojit.
- WorkLog AI používá skutečné obrázky typů Miniserverů; Compact má transparentní pozadí. Odkaz ke stažení Configu se doplní z přesné čtyřdílné verze firmware i tehdy, když starší záznam nemá URL.
- Profilové fotografie z iPhonu i velké obrázky se před uložením převádějí na JPEG do 512 px a uživatel dostane konkrétní chybu nepodporovaného formátu. V postranní nabídce zůstává pouze LOXONE podpora a spodní panely Nastavení využívají celou šířku.

## 1.0.3

- Přidán osobní Windows Loxone Config Launcher. Každý uživatel páruje vlastní zařízení jednorázovým kódem; token je ve Windows chráněný pomocí DPAPI a Hub odešle přístupy pouze aktivnímu požadavku stejného uživatele.
- Launcher hledá přesnou verzi `LoxoneConfig.exe` podle firmwaru, bezpečně otevře ověřené okno ručního připojení, vyplní SN do externí adresy, login a heslo a při chybě nic jiného nespustí. Chybějící Config vrátí do Hubu i Windows s oficiálním odkazem ke stažení.
- Přidána integrace WorkLog AI výhradně pro správce na macOS. Osobní odvolatelný token je uložený v Klíčence; menu zobrazuje složky a Miniservery a nabízí Loxone App nebo Config přes Windows agenta správce.
- Loxone Partner Portal umí při zneplatnění obnovovacího tokenu provést jeden automatický nový login uloženým odděleně šifrovaným heslem. Odmítnuté údaje se smažou a dočasné chyby mají bezpečný odklad dalšího pokusu.
- Nastavení, Config Bridge, WorkLog panel a portál byly ověřeny v produkčním sestavení na šířkách iPhonu 390 a 430 bodů bez vodorovného přetečení, deformovaných obrázků nebo oříznutých ovládacích prvků.

## 1.0.2

- Opravena synchronizace Loxone Partner Portalu podle aktuálního přihlašovacího toku: aplikace nejprve vytvoří a ověří portálovou relaci a teprve poté načte registrované produkty.
- Denní import přijímá pouze skutečné Miniservery, normalizuje jejich typ a bezpečně odmítne neověřenou nebo neúplnou odpověď místo falešně úspěšné prázdné synchronizace.
- Živým testem bylo ověřeno načtení všech 137 registrovaných Miniserverů bez ukládání hesla k portálu.

## 1.0.1

- Správce může bezpečně propojit Loxone Partner Portal a jednou denně synchronizovat nově registrované Miniservery podle sériového čísla, typu, názvu projektu a data registrace.
- Heslo k Partner Portalu se používá pouze pro jednorázové přihlášení a nikdy se neukládá. Obnovovací token je uložený šifrovaně v centrálním HA Práce; při vypršení přístupu aplikace vyžádá nové připojení.
- Synchronizace je nedestruktivní: doplní nové záznamy a portálem spravované názvy, ale nepřepisuje servisní přístupy, složky, topologii, poznámky ani politiku firmware a sama nic nemaže.
- Mobilní nabídka má vždy dostupné odhlášení, Config se na telefonu nezobrazuje a profilová fotografie se správně načte i přes Home Assistant Ingress.
- Kontakty podpory používají přímé ikony telefonu a WhatsAppu; nefunkční prázdné vložení cizího chatu bylo odstraněno.
- Opraveno zarovnání ukazatele v grafu 1-Wire a přímý odkaz na seznam tiketů v Loxone Partner Portalu.

## 1.0.0

- Přidán viditelný bezpečný prostup do Loxone Configu: aplikace nabídne odpovídající verzi Configu, aktuální projekt, adresu Miniserveru a kopírování přístupů bez vkládání hesla do URL nebo příkazové řádky.
- Složky a podsložky mají volitelnou barvu; barevná hierarchie se propisuje do přehledu i správce složek.
- Home Assistant Fleet se jmenuje `Servery`, rozlišuje aktuální a čekající aktualizace a po potvrzení umí instalovat HA Core, Supervisor, OS, add-on i integrační aktualizace a restartovat vybraný Home Assistant.
- Miniservery se automaticky řadí: online a aktuální, ostatní online, nedostupné a nakonec zařízení bez přístupu.
- LOXONE navigace obsahuje Miniservery, Config, Partner Portal, tickety a podporu včetně dnešní pracovní doby, oficiálního chatu a bezpečného náhradního otevření oficiální stránky.
- Kontakty na českou LOXONE podporu a LOXONE Vácha jsou dostupné v postranní i mobilní nabídce včetně přímého volání a WhatsAppu.
- Známé rodiny Loxone prvků zobrazují při najetí nebo klepnutí oficiální produktový náhled; neznámý typ používá bezpečný obecný obrázek.
- Uživatelé mohou nahrát, změnit a odstranit vlastní profilovou fotografii. Fotografie se zobrazuje jako kruhový avatar u účtu a ve správě uživatelů.
- Interní servis, správa uživatelů a schopnosti backendu zůstávají skryté technikům podle rolí; restarty a aktualizace vyžadují opětovné potvrzení heslem a zapisují se do auditu.

## 0.5.2

- Počty Loxone prvků vycházejí pouze z posledního úplného `/data/status` snapshotu: fyzické SN se deduplikují, souhrnné řádky se ignorují a prvky odstraněné z nového snapshotu už nezůstávají falešně offline.
- Stav Miniserveru je oddělen od stavu jeho prvků. Řádek ukazuje `Odpovídá` nebo `Neodpovídá`; skutečný výpadek prvku se zobrazí oranžově jako `Online: x/y prvků`.
- Detail složky slučuje Miniservery všech podsložek a nabízí společný přehled prvků, souhrnný počet online/offline, vyhledávání a historii 1-Wire teplot.
- Graf 1-Wire má časovou a teplotní stupnici a při najetí nebo dotyku ukáže přesný čas a hodnotu vzorku. Jednotlivé prvky i 1-Wire lze vyhledávat.
- Sériové číslo je v přehledu zvýrazněné, firmware je kompaktnější a mobilní karty respektují iPhone safe-area bez automatického přiblížení.
- Přihlašování podporuje Passkeys přes WebAuthn: Face ID, Touch ID a Windows Hello. Registrace i přihlášení vyžadují ověření uživatele a jednorázovou krátce platnou challenge.
- Generátor hesel má jako výchozí délku 32 znaků, velká písmena a čísla; malá písmena a symboly zůstávají volitelné.
- Technik nevidí servisní úlohy, uživatelskou správu ani interní schopnosti backendu; chráněná API používají stejná oprávnění jako rozhraní.
- Zelené LOXONE a modré Home Assistant pozadí plynule vyplňuje dostupnou plochu na iPhonu, iPadu i Macu.

## 0.5.1

- LOXONE v navigaci nyní funguje jako rozbalovací rodič položky Config bez spojovací grafiky.
- Přechod na Home Assistant podnabídku Config automaticky skryje.
- 1-Wire teploty se ukládají samostatně každých 10 minut přes poslední ověřenou trasu bez dalších dotazů na Remote Connect.
- Offline 1-Wire čidlo se dál promítá jako offline prvek.

## 0.5.0

- Mobilní karty Miniserverů jsou výrazně kompaktnější; stav spojení a počet online prvků jsou v horním řádku a verze firmware je vedlejší údaj.
- Každý Miniserver může sledovat vždy aktuální Stable verzi, nebo zůstat připnutý na právě zjištěném firmware. Hromadná aktualizace zahrne jen online zařízení s cílem `Vždy aktuální`.
- Každý přihlášený uživatel si může bezpečně změnit vlastní heslo. Role Technik nevidí servisní úlohy, integrace, schopnosti backendu ani jejich chráněná API.
- Všech šest souhrnných karet flotily je klikacích. Každá vysvětlí přesnou definici ukazatele a otevře odpovídající filtrovaný seznam Miniserverů.
- Config je v navigaci vizuálně vnořený pod LOXONE. Složky zůstávají ve výchozím stavu sbalené a samostatný Miniserver se nezobrazuje s nadbytečnou rolí.
- MELCloud dohled běží každých 30 sekund a zobrazuje aktuální i cílovou teplotu, výkon ventilátoru a svislou i vodorovnou polohu lamel.
- Dohled větrné elektrárny na HA Herškovič používá autorizovaný Home Assistant Ingress a samostatně vyhodnocuje logger i oba střídače.
- Detail 1-Wire čidel zobrazuje teploty a offline čidlo se započítá mezi offline prvky Miniserveru.
- Stable, Beta a Alpha Config se kontrolují každé 4 hodiny a předchozí oficiální odkazy se uchovávají v archivu verzí.

## 0.4.15

- SolarInvert Logger na HA Herškovič se kontroluje přes autorizovaný Home Assistant Ingress, takže centrální HA Práce nepotřebuje přímý přístup na vzdálený port 8765.
- Dohled dál vyhodnocuje health/ready stav loggeru a oba střídače samostatně; Ingress relace ani dlouhodobý HA token se neukládají do výsledků nebo logů.

## 0.4.14

- Levá nabídka používá originální značky LOXONE a Home Assistant; přihlašovací karta už nezobrazuje nadbytečné pravé logo EVORA SMART.
- Stránky LOXONE a Home Assistant mají výraznější zelený a modrý nádech. Nezařazené projekty se zobrazují jako `Ostatní`.
- Projektové číslo lze upravit přímo v seznamu. Miniservery bez přístupu nebo nedostupné se v každé složce automaticky řadí na konec.
- Zelený stav `Aktuální` se zobrazí jen při shodě online a celkového počtu prvků; chybějící prvek přepne stav do oranžového upozornění.
- Teploty online 1-Wire čidel rodiny 28 se ukládají do centrální databáze na HA Práce. Detailní vzorky se uchovávají 13 měsíců a denní minimum, průměr a maximum 5 let; HA Domov zůstává bezstavovým klientem.
- Detail Miniserveru má záložku `1-Wire` s grafem a rozsahy 24 hodin, 7 dní, 30 dní, 13 měsíců a 5 let.
- HA Vágner samostatně hlídá stav integrace MELCloud, všech pět klimatizačních jednotek, lokální ping a příliš dlouho čekající zápis.
- HA Herškovič samostatně hlídá větrnou elektrárnu přes SolarInvert Logger na `homeassistant-herskovic.skunk-atria.ts.net:8765`, jeho health/ready stav, USB, cloud, Loxone spojení a každý ze dvou střídačů zvlášť.
- Specializované aplikační dohledy běží každé 2 minuty; běžný dohled Home Assistant instalací zůstává dvouhodinový.

## 0.4.13

- Složky projektů jsou po otevření přehledu ve výchozím stavu sbalené; podsložky se zobrazí až po rozbalení svého rodiče.
- V seznamu se role zobrazuje pouze u skutečné Gateway nebo Clienta. Samostatný Miniserver nemá zbytečný štítek a z názvu se samostatně zvýrazní projektové číslo `ESM-26-001` nebo `PRO-21-0029`.
- Online teplotní 1-Wire čidla rodiny 28 zobrazují aktuální hodnotu ve stupních Celsia; hodnota se načítá postupně přes uloženou trasu a bez dalšího volání Remote Connect resolveru.
- Offline 1-Wire čidlo se započítá mezi offline prvky. Chyba samostatného čtení teploty ale nevytváří falešný offline stav Miniserveru ani čidla.
- Stable, Beta a Alpha kanály z `updatecheck.xml` se kontrolují nejvýše jednou za 4 hodiny i při chybě zdroje. Při změně se původní verze a její oficiální odkaz přesunou do trvalého archivu ke stažení.

## 0.4.12

- Detail Miniserveru má novou záložku Exporty pro strukturu LoxAPP3, systémové statistiky, katalog statistik a měsíční XML statistiky.
- Statistiky V2 lze stáhnout v oficiálním binárním raw formátu s výběrem prvku, skupiny, výstupu, období a seskupení.
- Správce může stáhnout aktuální kompilovaný programový ZIP ze SD karty. Aplikace jej vydá jen po přesném porovnání vloženého LoxAPP3 s právě běžícím projektem a nezaměňuje jej za editovatelný soubor `.Loxone`.
- Všechny exporty jsou pouze na vyžádání, zapisují se do auditu, mají pevné limity velikosti a v celé centrální instalaci probíhá nejvýše jeden vzdálený export současně.
- Souběžné požadavky na stejný export se sloučí a omezená fronta brání tomu, aby HA Domov nebo více otevřených prohlížečů zatížilo Remote Connect duplicitními dotazy.
- Otevření Loxone App na iPhonu už necílí na nadřazený rámec Home Assistantu. Přímé klepnutí naviguje aktivní rámec, takže Safari i HA Companion mohou předat oficiální `loxone://ms` odkaz nainstalované aplikaci.

## 0.4.11

- Opravené přístupy k monitorovaným Home Assistantům používají správné HTTPS Tailscale adresy; dlouhodobé tokeny zůstávají uložené šifrovaně pouze na centrálním HA Práce.
- Individuální kontrola Home Assistantu už neukládá jeho UUID do vazby určené pro sériová čísla Miniserverů, takže neselhává chybou databázového cizího klíče.
- Potvrzené smazání Home Assistantu posílá platný JSON požadavek; server už chybu nepodporovaného typu dat nevydává za vnitřní selhání aplikace.
- Bezpečnostní CSRF token je stabilní v rámci jedné přihlášené relace, takže otevření aplikace ve druhé kartě nezneplatní formulář v první kartě.
- Pokud klient přesto narazí na zastaralý CSRF token po aktualizaci, bezpečně jej jednou obnoví a původní změnu jednou zopakuje bez duplicitních zápisů.

## 0.4.10

- Po restartu čekají automatická hromadná kontrola i automatické opakování chyb celý nastavený interval. Restart tak nemůže okamžitě spustit vlnu dotazů na Remote Connect; ruční kontrola jednoho Miniserveru zůstává dostupná.

- Opraveno kritické zahlcování Remote Connect: pravidelná kontrola nejprve používá naposledy funkční dynamickou trasu a resolver zavolá pouze po skutečném selhání této trasy.
- Resolverové požadavky jsou globálně řazené nejvýše po jednom za 10 sekund, souběžné dotazy na stejné SN se sloučí a odpověď HTTP 429 aktivuje nejméně 30minutovou pojistku bez dalších pokusů.
- HA Práce je jediný vykonavatel kontrol LOXONE: HA Domov zůstává bezstavový klient bez vlastního plánovače a všechny požadavky z klienta i webu se na centrálním serveru sloučí podle SN nebo hromadné úlohy.
- Ověřování probíhající aktualizace kontroluje firmware nejvýše jednou za 2 minuty; automatické denní procházení topologie bylo zrušeno a zůstává jen jako vědomě spuštěná servisní akce.
- Odkaz „Otevřít a přihlásit“ už nevkládá do Loxone App zastaralý dynamický Remote Connect port; stabilní CloudDNS adresa podle SN vyřeší aktuální trasu až při otevření.
- Přehled LOXONE nově samostatně ukazuje počet Miniserverů, které odpovídají, které potvrzeně neodpovídají a kolik jich ještě nebylo ověřeno.
- Odpověď s odmítnutým přihlášením se správně počítá jako síťově odpovídající Miniserver, ale zůstává označená „Bez přístupu“.

## 0.4.9

- Aplikace se nově jmenuje Evora Smart Hub a používá diagonálně spojenou identitu LOXONE a Home Assistant.
- Hlavní navigace rozlišuje zelenou část LOXONE a modrou část Home Assistant; rozhraní zůstává responzivní pro iPhone, iPad, Mac a Home Assistant Ingress.
- „Flotila“ se přejmenovala na „LOXONE“ a „Firmware“ na „Config“.
- Uživatel s rolí pouze pro čtení neuvidí Servis ani Uživatele; servisní API je nově stejně omezené i na backendu.
- Slug, databáze a šifrované přístupy zůstávají beze změny, takže aktualizace zachová veškerá produkční data.

## 0.4.8

- Přidána samostatná záložka Home Assistant s dvouhodinovým monitoringem Tailscale, Nabu Casa a privátních LAN adres.
- Přehled ukazuje dostupnost, odezvu a poslední kontrolu; volitelný dlouhodobý token bezpečně načte verzi Core a název instalace.
- Přístupy k Home Assistantu se ukládají šifrovaně, zobrazují se jen na vyžádání a nikdy se nevkládají do URL.
- Krátký výpadek Miniserveru už okamžitě nepřepíše naposledy potvrzený online stav; následují dvě opakované kontroly s pětiminutovým odstupem.
- Tlačítko `+` ve správci složek má vlastní akční buňku a nepřekrývá počet zařízení ani sousední pole.
- Desktopové rozhraní používá kompaktní levé menu a přihlašovací stránku ve stylu Loxone Partner Portalu; tablet a telefon zůstávají bez vodorovného posouvání.
- Partner Portal je dostupný bezpečným externím odkazem; soukromá data se bez oficiálního OAuth/API oprávnění nenačítají ani nescrapují.

## 0.4.7

- Složky lze vkládat do dalších složek; výběry ukazují úplnou cestu jako `Dolní Morava / Melori` a API brání cyklům.
- Migrace zachová všechna dosavadní přiřazení Miniserverů; při smazání rodiče se podsložky bezpečně posunou o úroveň výš.
- Safari používá pro textová pole i výběry shodnou výšku 44 px a nativní výběr už nerozbíjí dvousloupcový formulář.
- Otevření Loxone App probíhá přímo z klepnutí bez prázdného okna; citlivé přístupy se dál načítají jen na vyžádání.
- UI respektuje oprávnění rolí a nenabízí divákům či technikům operace, které backend nepovoluje.
- Lokální URL Miniserveru je omezena na soukromé adresy a odkazy na Loxone Config pouze na oficiální domény Loxone.
- Anonymizovaný servisní balíček odstraňuje identifikátory i z vnořených dat; statická aktiva mají bezpečnou cache politiku a přísnější CSP.
- Skrytá karta neprovádí zbytečné 30sekundové obnovování a selhání načtení je v UI zřetelně označeno jako zastaralý stav.
- Přidána automatická kontrola ESLint a rozšířené testy zabezpečení, hierarchie, rolí a responzivního rozhraní.

## 0.4.6

- Formulářové dialogy už v Safari a Home Assistant Ingressu nepřetékají vodorovně mimo dostupnou plochu.
- Dvousloupcová pole se mohou bezpečně zmenšit podle šířky iframe; ovládací prvky nikdy nepřesáhnou svůj sloupec.
- Dialog se posouvá pouze svisle uvnitř okna a na telefonu respektuje skutečnou dynamickou výšku displeje.

## 0.4.5

- Nezařazený Client se už vizuálně neodsazuje pod nesouvisející Miniserver; stromová větev vznikne jen při konkrétní a platné vazbě na zobrazenou Gateway.
- Client bez doložené rodičovské Gateway je v seznamu výslovně označen jako „bez přiřazené Gateway“.
- Správce složek má u každé složky tlačítko `+` s vyhledáváním a hromadným výběrem Miniserverů.
- Členství ve složce se ukládá atomicky a může bezpečně přesunout Miniserver z jiné složky.

## 0.4.4

- Neplatný přihlašovací formulář vrací bezpečnou odpověď `400 VALIDATION_ERROR` místo interní chyby 500.
- Globální zpracování chyb se registruje před pluginy a routami, takže se do odpovědi nepropíší interní detaily frameworku.

## 0.4.3

- Při krátkém výpadku CloudDNS aplikace ověří Miniserver přes naposledy úspěšně potvrzenou trasu, která není starší než 6 hodin.
- Samotná chyba CloudDNS už neoznačí Miniserver jako nedostupný; zobrazí se jako odložená kontrola a interní kód `resolver_error` nahradí srozumitelné upozornění.
- Přidána bezpečně ohraničená veřejná cesta `/api/loxone-servis/` pro HA Práce a Tailscale Funnel.
- HA Domov umí klientský režim i tehdy, když veřejná HTTPS adresa hlavní instalace používá cestu za názvem hostitele.

## 0.4.2

- Hromadná kontrola omezuje počet souběžných cloudových resolverů na dva.
- Přechodnou chybu nebo timeout resolveru zopakuje až třikrát s odstupem, než Miniserver označí jako nedostupný.

## 0.4.1

- Klíček v seznamu jedním klepnutím zkopíruje heslo; dialog s přístupy otevírá pouze telefon.
- Spuštění Loxone App používá oficiální `loxone://ms` URL schéma a ověřenou adresu Miniserveru.
- Opravena bílá stránka Safari při lokálním HTTP přístupu přes Home Assistant Ingress.
- HTML, JS a CSS se po aktualizaci neposílají ze zastaralé cache.

## 0.4.0

- Automatické rozpoznání role Gateway, Client nebo samostatný Miniserver z LoxAPP3 WebService.
- Jednoznačně doložené vazby Client → Gateway se zobrazují hierarchicky; neurčené vazby se nehádají.
- Přidány editovatelné složky projektů pro přehledné seskupení více Miniserverů.
- Role, vazbu i složku lze ručně upravit; ruční nastavení automatická kontrola nepřepíše.

## 0.3.0

- HA Práce může fungovat jako jediný hlavní server a HA Domov jako bezstavový klient.
- Změny, uživatelé a přístupy se zapisují jen do jedné centrální databáze.
- Přidána autentizovaná plně šifrovaná záloha databáze a chráněné konfigurace.
- Přidán denní GitHub backup workflow a ověřovací nástroj obnovy.

## 0.2.1

- bezpečný Node.js backend a migrace původní databáze
- stable/beta/alpha verze z oficiálního Loxone XML
- diagnostika Miniserveru, prvků, projektu, uživatelů a provozních režimů
- potvrzované aktualizace, restarty a hromadné operace
- vlastní účty, role, audit a TOTP 2FA
- kompaktní desktopové a iPhone rozhraní
- opravené automatické sestavení vícearchitekturního obrazu
