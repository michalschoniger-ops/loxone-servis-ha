# Evora Config Launcher pro Windows

Pomocník patří vždy konkrétnímu uživateli Evora Smart Hubu a běží jen v jeho Windows účtu. Stejný instalační balíček lze použít na více počítačích, ale každý počítač se musí spárovat vlastním jednorázovým kódem vytvořeným přihlášeným uživatelem v Nastavení Hubu.

## Instalace

1. Rozbalte celý ZIP do jedné složky.
2. V Evora Smart Hubu otevřete **Nastavení → Loxone Config Launcher** a vytvořte párovací kód.
3. V rozbalené složce otevřete Windows Terminal / PowerShell a jednou spusťte `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install-EvoraConfigLauncher.ps1`.
4. Vložte HTTPS adresu Hubu a jednorázový párovací kód.

Instalátor zkopíruje helper do `%LOCALAPPDATA%\EvoraSmartHub\ConfigLauncher`, uloží token pomocí Windows DPAPI pro aktuálního uživatele a vytvoří skrytý autostart. Běžný běh helperu nezobrazuje PowerShell okno.

Helper hledá přesnou verzi `LoxoneConfig.exe` podle `FileVersion`. Pokud chybí, nic jiného nespustí a Hub i Windows dostanou bezpečnou chybu s odkazem ke stažení požadované verze.

Po spuštění helper čeká až 45 sekund na připravené okno přesné verze Configu. Je-li otevřený projekt, přejde ověřeným tlačítkem Domů, otevře `Připojit manuálně…`, nejprve vloží SN do externí adresy a nechá pole ustálit. Teprve potom opakovaně ověří login i heslo a stiskne `Připojit` až ve chvíli, kdy jsou všechna pole přesná a tlačítko je aktivní. Nepoužívá pevné souřadnice obrazovky.

Přístupy k Miniserveru nejsou v párovacím tokenu, konfiguračním souboru, frontě, URL, příkazové řádce ani logu. Hub je odešle jen aktivnímu spárovanému helperu pro jeden konkrétní požadavek.

## Parallels na Macu

Instalace se provádí uvnitř Windows virtuálního počítače, nikoli v macOS. Windows musí být spuštěný, uživatel přihlášený a jeho plocha odemčená; síť Parallels musí dosáhnout na HTTPS adresu Hubu. Není potřeba sdílet macOS hesla ani složky. Po jednorázové instalaci běží helper po přihlášení skrytě a běžně neotevírá okno PowerShellu.

## Samostatný počítač jen s Windows

Funguje stejným způsobem na běžném Windows 10/11 bez Macu a bez Parallels. Každý počítač se páruje vlastním kódem. Nutný je nainstalovaný Loxone Config požadované přesné verze a dostupnost Hubu přes HTTPS. Když Windows neběží, uživatel je odhlášený nebo je plocha zamčená, Hub úlohu nemůže bezpečně provést přes UI Automation.
