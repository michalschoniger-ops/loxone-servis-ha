# Evora Config Launcher pro Windows

Pomocník patří vždy konkrétnímu uživateli Evora Smart Hubu a běží jen v jeho Windows účtu. Stejný instalační balíček lze použít na více počítačích, ale každý počítač se musí spárovat vlastním jednorázovým kódem vytvořeným přihlášeným uživatelem v Nastavení Hubu.

## Instalace

1. Rozbalte celý ZIP do jedné složky.
2. V Evora Smart Hubu otevřete **Nastavení → Loxone Config Launcher** a vytvořte párovací kód.
3. V rozbalené složce otevřete Windows Terminal / PowerShell a jednou spusťte `powershell.exe -NoProfile -ExecutionPolicy Bypass -File .\Install-EvoraConfigLauncher.ps1`.
4. Vložte HTTPS adresu Hubu a jednorázový párovací kód.

Instalátor zkopíruje helper do `%LOCALAPPDATA%\EvoraSmartHub\ConfigLauncher`, uloží token pomocí Windows DPAPI pro aktuálního uživatele a vytvoří skrytý autostart i úlohu hlídače pro tento Windows účet. Hlídač jednou za minutu ověří spuštění; pojmenovaný mutex zabrání vzniku druhé kopie. Launcher proto zůstává online po celou dobu přihlášené relace a je offline pouze tehdy, když je Windows vypnutý nebo uživatel není přihlášený. Běžný běh helperu nezobrazuje PowerShell okno.

Od verze 3.0.0.0 zůstává v oznamovací oblasti Windows malá ikona Evora. Barevná tečka rozlišuje online, offline, probíhající kontrolu a start. Z nabídky ikony lze otevřít Hub, ihned ověřit spojení a aktualizaci, přejít k novému párovacímu kódu, otevřít bezpečný diagnostický protokol nebo Launcher ukončit. Staré uložené adresy bez schématu se při načtení jednorázově převedou na HTTPS.

Verze 3.0.0.2 před odesláním párovacího kódu samostatně ověří DNS, HTTPS certifikát a `/healthz` cílového Hubu. Chyba `HUB_DNS_FAILED` proto znamená, že Windows neumí přeložit název Hubu (u adresy v tailnetu typicky neběží Tailscale nebo MagicDNS); není to odmítnutý ani chybný párovací kód. Opravný skript dovolí původní adresu změnit. Instalátor před přijetím nové verze čeká na její skutečný autentizovaný heartbeat; pokud nepřijde, atomicky vrátí původní skript i DPAPI konfiguraci a znovu je spustí.

## Aktualizace už nainstalovaného Launcheru

Od verze 2.1.0.0 se Launcher aktualizuje automaticky z Hubu. Aktualizace se nainstaluje pouze tehdy, když přišla v autorizované HTTPS odpovědi a stažený skript přesně odpovídá očekávanému SHA-256 otisku i číslu verze. Původní skript zůstane jako `.bak`; při jakémkoli nesouladu pokračuje stávající verze a Hub zobrazí varování.

Při přechodu ze starší verze bez automatického updateru rozbalte nový ZIP a ve **stejném Windows účtu**, ve kterém jste Launcher původně spárovali, znovu spusťte `Install-EvoraConfigLauncher.ps1`. Instalátor rozpozná existující `config.json`, ukončí pouze helper aktuálního uživatele spuštěný z přesné instalační cesty, nahradí skript a znovu ho skrytě spustí. HTTPS adresu ani nový párovací kód už nevyžaduje; původní DPAPI token zůstane beze změny.

Pokud aktualizace párovací kód přesto vyžádá, byla spuštěna v jiném Windows účtu nebo v tomto účtu původní spárování neexistuje. V takovém případě vytvořte nový kód v Hubu pod účtem uživatele, kterému má Launcher patřit.

## Změna párování nebo neplatný starý token

Párovací kód se ve Windows trvale neukládá. Je jednorázový a po úspěšném použití jej Hub vymění za uživatelský token chráněný pomocí DPAPI. Běžná aktualizace proto správně zachovává původní token; samotné spuštění instalátoru jej nezmění.

Chcete-li Launcher připojit znovu, v Hubu zvolte **Nový kód / znovu spárovat**, stáhněte a rozbalte aktuální ZIP a dvakrát klikněte na `Opravit-parovani.cmd`. Opravný skript nabídne zachování nebo změnu stávající HTTPS adresy a názvu tohoto Windows agenta, ověří dostupnost Hubu i nový kód a teprve potom přepíše chráněný token a Launcher restartuje. Starý token zůstane na Hubu platný až do prvního úspěšného přihlášeného heartbeat nového helperu; ten pak bezpečně zneplatní pouze starší párování stejného uživatele a stejného počítače. Když ověření selže, funkční instalace ani původní místní konfigurace se nenahrazují.

Tlačítko **Odebrat počítač** v Hubu okamžitě zneplatní vybraný token a ukončí jeho čekající úlohy. Lokální skript, konfiguraci ani autostart ve Windows nemaže; případné odinstalování se provádí přímo v daném Windows účtu.

Helper hledá přesnou verzi `LoxoneConfig.exe` podle `FileVersion`. Pokud chybí, nic jiného nespustí a Hub i Windows dostanou bezpečnou chybu s odkazem ke stažení požadované verze.

Po spuštění helper čeká až 45 sekund na připravené okno přesné verze Configu. Je-li otevřený projekt, přejde ověřeným tlačítkem Domů, otevře `Připojit manuálně…`, nejprve vloží SN do externí adresy a nechá pole ustálit. Teprve potom opakovaně ověří login i heslo a stiskne `Připojit` až ve chvíli, kdy jsou všechna pole přesná a tlačítko je aktivní. Nepoužívá pevné souřadnice obrazovky.

Přístupy k Miniserveru nejsou v párovacím tokenu, konfiguračním souboru, frontě, URL, příkazové řádce ani logu. Hub je odešle jen aktivnímu spárovanému helperu pro jeden konkrétní požadavek.

V Nastavení Hubu je vidět samostatná diagnostika podpisu, automatických aktualizací, nalezených Configů, Windows UI Automation, oprávnění, spojení s Hubem a bezpečného logování. Při chybě Launcher zapíše pouze kód a přesnou fázi automatizace; heslo ani token se do diagnostiky nedostanou. Otevřený Config zůstane dostupný pro ruční připojení.

## Parallels na Macu

Instalace se provádí uvnitř Windows virtuálního počítače, nikoli v macOS. Windows musí být spuštěný, uživatel přihlášený a jeho plocha odemčená; síť Parallels musí dosáhnout na HTTPS adresu Hubu. Není potřeba sdílet macOS hesla ani složky. Po jednorázové instalaci běží helper po přihlášení skrytě a běžně neotevírá okno PowerShellu.

## Samostatný počítač jen s Windows

Funguje stejným způsobem na běžném Windows 10/11 bez Macu a bez Parallels. Každý počítač se páruje vlastním kódem. Nutný je nainstalovaný Loxone Config požadované přesné verze a dostupnost Hubu přes HTTPS. Když Windows neběží, uživatel je odhlášený nebo je plocha zamčená, Hub úlohu nemůže bezpečně provést přes UI Automation.
