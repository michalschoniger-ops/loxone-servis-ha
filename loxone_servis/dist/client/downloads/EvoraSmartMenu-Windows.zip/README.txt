﻿Evora Smart Menu 3.0.21 pro Windows

Runtime je nativnĂ­ WinForms aplikace bez konzolovĂ©ho okna. PĹ™ipojenĂ­ je uloĹľenĂ© oddÄ›lenÄ›
v profilu aktuĂˇlnĂ­ho uĹľivatele a token je chrĂˇnÄ›nĂ˝ pomocĂ­ Windows DPAPI.
