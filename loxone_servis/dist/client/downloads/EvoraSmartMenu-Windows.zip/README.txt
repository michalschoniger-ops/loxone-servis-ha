﻿Evora Smart Menu 3.0.34 pro Windows

Runtime je nativnĂ­ WinForms aplikace bez konzolovĂ©ho okna. PĹ™ipojenĂ­ je uloĹľenĂ© oddÄ›lenÄ›
v profilu aktuĂˇlnĂ­ho uĹľivatele a token je chrĂˇnÄ›nĂ˝ pomocĂ­ Windows DPAPI. InstalĂˇtor po
spuĹˇtÄ›nĂ­ otevĹ™e osobnĂ­ pĂˇrovĂˇnĂ­ s Evora Smart Hubem; technik se do Hubu pĹ™ihlaĹˇuje svĂ˝m
firemnĂ­m e-mailem a balĂ­ÄŤek neobsahuje ĹľĂˇdnĂ© heslo ani token.
