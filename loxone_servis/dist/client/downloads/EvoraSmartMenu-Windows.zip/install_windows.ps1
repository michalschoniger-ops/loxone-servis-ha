param(
  [switch]$NonInteractive
)

$ErrorActionPreference = "Stop"
$SourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallRoot = Join-Path $env:LOCALAPPDATA "Evora\SmartMenu"
$AppSource = Join-Path $SourceRoot "EvoraSmartMenu.exe"
$UpdaterSource = Join-Path $SourceRoot "EvoraSmartMenuUpdater.exe"
if (-not (Test-Path -LiteralPath $AppSource) -or -not (Test-Path -LiteralPath $UpdaterSource)) {
  throw "V rozbaleném balíčku chybí nativní aplikace nebo updater."
}

New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
Get-Process -Name "EvoraSmartMenu" -ErrorAction SilentlyContinue |
  Where-Object { $_.Path -and ([IO.Path]::GetFullPath($_.Path) -eq [IO.Path]::GetFullPath((Join-Path $InstallRoot "EvoraSmartMenu.exe"))) } |
  Stop-Process -Force -ErrorAction SilentlyContinue

Copy-Item -LiteralPath $AppSource -Destination (Join-Path $InstallRoot "EvoraSmartMenu.exe") -Force
Copy-Item -LiteralPath $UpdaterSource -Destination (Join-Path $InstallRoot "EvoraSmartMenuUpdater.exe") -Force
$ReadmeSource = Join-Path $SourceRoot "README.txt"
if (Test-Path -LiteralPath $ReadmeSource) { Copy-Item -LiteralPath $ReadmeSource -Destination (Join-Path $InstallRoot "README.txt") -Force }

$Startup = [Environment]::GetFolderPath("Startup")
$Shell = New-Object -ComObject WScript.Shell
$ShortcutPath = Join-Path $Startup "Evora Smart Menu.lnk"
$Shortcut = $Shell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = Join-Path $InstallRoot "EvoraSmartMenu.exe"
$Shortcut.WorkingDirectory = $InstallRoot
$Shortcut.WindowStyle = 7
$Shortcut.Description = "Evora Smart Menu pro Windows"
$Shortcut.Save()

Start-Process -FilePath (Join-Path $InstallRoot "EvoraSmartMenu.exe") -WorkingDirectory $InstallRoot
Write-Host "Evora Smart Menu 3.0.17 bylo nainstalováno pro aktuální Windows účet."
if (-not $NonInteractive) { Read-Host "Enter" | Out-Null }
