param(
  [switch]$NonInteractive
)

$ErrorActionPreference = "Stop"
$SourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$InstallRoot = Join-Path $env:LOCALAPPDATA "Evora\SmartMenu"
$AppSource = Join-Path $SourceRoot "EvoraSmartMenu.exe"
$UpdaterSource = Join-Path $SourceRoot "EvoraSmartMenuUpdater.exe"
if (-not (Test-Path -LiteralPath $AppSource) -or -not (Test-Path -LiteralPath $UpdaterSource)) {
  throw "V rozbaleném balíčku chybí nativní aplikace nebo updater."
}

New-Item -ItemType Directory -Force -Path $InstallRoot | Out-Null
$InstalledApp = Join-Path $InstallRoot "EvoraSmartMenu.exe"
$RunningApps = @(Get-Process -Name "EvoraSmartMenu" -ErrorAction SilentlyContinue |
  Where-Object { $_.Path -and ([IO.Path]::GetFullPath($_.Path) -eq [IO.Path]::GetFullPath($InstalledApp)) })
foreach ($RunningApp in $RunningApps) {
  Stop-Process -Id $RunningApp.Id -Force -ErrorAction Stop
  try { $RunningApp.WaitForExit(5000) } catch { }
}
if (Get-Process -Name "EvoraSmartMenu" -ErrorAction SilentlyContinue |
    Where-Object { $_.Path -and ([IO.Path]::GetFullPath($_.Path) -eq [IO.Path]::GetFullPath($InstalledApp)) }) {
  throw "The running Evora Smart Menu could not be stopped safely."
}

Copy-Item -LiteralPath $AppSource -Destination $InstalledApp -Force
Copy-Item -LiteralPath $UpdaterSource -Destination (Join-Path $InstallRoot "EvoraSmartMenuUpdater.exe") -Force
$ReadmeSource = Join-Path $SourceRoot "README.txt"
if (Test-Path -LiteralPath $ReadmeSource) { Copy-Item -LiteralPath $ReadmeSource -Destination (Join-Path $InstallRoot "README.txt") -Force }

$Startup = [Environment]::GetFolderPath("Startup")
if ([string]::IsNullOrWhiteSpace($Startup)) {
  $Startup = Join-Path $env:APPDATA "Microsoft\Windows\Start Menu\Programs\Startup"
}
New-Item -ItemType Directory -Force -Path $Startup | Out-Null
$Shell = New-Object -ComObject WScript.Shell
$ShortcutPath = Join-Path $Startup "Evora Smart Menu.lnk"
$Shortcut = $Shell.CreateShortcut($ShortcutPath)
$Shortcut.TargetPath = $InstalledApp
$Shortcut.WorkingDirectory = $InstallRoot
$Shortcut.WindowStyle = 7
$Shortcut.Description = "Evora Smart Menu pro Windows"
$Shortcut.Save()

Start-Process -FilePath $InstalledApp -ArgumentList "--pair" -WorkingDirectory $InstallRoot
Write-Host "Evora Smart Menu 3.0.34 installed for current Windows user. Personal Hub pairing is open."
if (-not $NonInteractive) { Read-Host "Enter" | Out-Null }
