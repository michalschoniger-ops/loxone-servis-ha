# WorkLog AI – Evora Smart Hub

Tento balíček doplní do stávajícího macOS menu WorkLog AI složku **Evora Smart Hub**. Nemění ani nemaže databázi WorkLogAI, výkazy, pracovní záznamy, screenshoty ani oddělený Codex účet.

Integrace je určena výhradně správci Evora Smart Hubu. Technik ani běžný uživatel nemůže vytvořit ani použít její token. Po instalaci menu načte složky a Miniservery správce a u každého nabídne:

- otevření a přihlášení v Loxone App,
- předání do osobního Windows Loxone Config Launcheru,
- oficiální odkaz ke stažení odpovídajícího Loxone Configu,
- skutečnou ikonu typu Miniserveru místo stavové tečky; nedostupná zařízení jsou pouze zesvětlená,
- seznam všech Loxone ticketů, detail veřejné komunikace a příloh,
- založení ticketu a veřejnou odpověď po úplném náhledu a samostatném potvrzení heslem.

Přílohy jsou v nativním menu vypsané a bezpečně se otevřou v centru ticketů v Hubu. Žádný návrh se neposílá automaticky ani pouhým zavřením dialogu.

## Instalace

1. Poklepejte na `install.command`.
2. V Evora Smart Hubu otevřete **Nastavení → WorkLog AI · Evora Smart Hub**.
3. Vytvořte osobní token a zkopírujte ho. Hub ho zobrazí pouze jednou.
4. V menu WorkLog AI otevřete **Evora Smart Hub → Nastavit připojení…**.
5. Vložte adresu Hubu a token.

Token se ukládá do macOS Klíčenky jako údaj dostupný jen tomuto uživatelskému účtu. V konfiguračních souborech WorkLogAI se neukládá. Odvolat ho lze kdykoli v Nastavení Hubu.

Instalátor před změnou zálohuje původní zdroj i spustitelný soubor do `~/Documents/WorkLogAI/backups/evora-integration-*` a potom restartuje pouze menu WorkLogAI.
