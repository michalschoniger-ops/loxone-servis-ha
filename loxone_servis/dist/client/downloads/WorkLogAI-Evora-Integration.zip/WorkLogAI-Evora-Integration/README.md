# WorkLog AI – Evora Smart Hub

Tento balíček doplní do stávajícího macOS menu WorkLog AI složku **Evora Smart Hub**. Nemění ani nemaže databázi WorkLogAI, výkazy, pracovní záznamy, screenshoty ani oddělený Codex účet.

Integrace je určena výhradně správci Evora Smart Hubu. Technik ani běžný uživatel nemůže vytvořit ani použít její token. Po instalaci menu načte složky a Miniservery správce a u každého nabídne:

- otevření a přihlášení v Loxone App,
- předání do osobního Windows Loxone Config Launcheru,
- oficiální odkaz ke stažení odpovídajícího Loxone Configu,
- skutečnou ikonu typu Miniserveru místo stavové tečky; nedostupná zařízení jsou pouze zesvětlená,
- seznam všech Loxone ticketů z lokální cache Hubu, detail veřejné komunikace a příloh,
- přehlednou konverzaci po jednotlivých účastnících, časech a událostech se soubory,
- založení ticketu a veřejnou odpověď po úplném náhledu a samostatném potvrzení heslem.

WorkLogAI 5.8.2 navíc používá Evora Intranet jako primární zdroj docházky. Zobrazuje příchod, odchod, Home office, služební cestu, souhrny a historii aktuálního i předchozího měsíce. Aktivní pracovní čas běží v horní liště po sekundách ve formátu `HH:MM:SS`.

Přílohy jsou v nativním menu vypsané samostatně. Pokud Portál poskytne bezpečný odkaz, WorkLog AI je přes Hub načte a otevře v odpovídající aplikaci macOS; pokud poskytne jen název souboru vložený do textu zprávy, menu jej zobrazí bez nefunkčního tlačítka. Žádný návrh se neposílá automaticky ani pouhým zavřením dialogu.

Běžné otevření menu používá uložený seznam a znovu nevolá celý Loxone Portál. **Aktualizovat změny** provede jednu kontrolu souhrnů; Hub zachová nezměněné detaily a znovu načte jen nový nebo změněný ticket.

## Instalace

1. Poklepejte na `install.command`.
2. V Evora Smart Hubu otevřete **Nastavení → WorkLog AI · Evora Smart Hub**.
3. Vytvořte osobní token a zkopírujte ho. Hub ho zobrazí pouze jednou.
4. V menu WorkLog AI otevřete **Evora Smart Hub → Nastavit připojení…**.
5. Vložte adresu Hubu a token.

Token se ukládá do macOS Klíčenky jako údaj dostupný jen tomuto uživatelskému účtu. V konfiguračních souborech WorkLogAI se neukládá. Odvolat ho lze kdykoli v Nastavení Hubu.

Instalátor před změnou zálohuje původní zdroj i spustitelný soubor do privátního runtime `~/Library/Application Support/WorkLogAI/backups/evora-integration-*` a potom restartuje pouze menu WorkLogAI. Docházkové heslo zůstává jen v macOS Klíčence.
