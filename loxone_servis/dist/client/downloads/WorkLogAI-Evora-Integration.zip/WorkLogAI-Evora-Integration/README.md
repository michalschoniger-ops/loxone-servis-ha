# Evora Smart Menu – Evora Smart Hub

Tento balíček aktualizuje stávající macOS aplikaci na **Evora Smart Menu 3.0.30**. Stavová ikona používá přímo systémové `NSMenu`; otevření, zavření, umístění, klávesnici a kaskádové podnabídky proto řídí AppKit. Běžný provoz nevytváří vlastní 440px plovoucí panel, nepřesouvá interní okno menu, nevyrábí snímek pro zavírací animaci a při pouhém otevření nabídky neaktivuje Evora aplikaci ani neodsouvá dosavadní okno Safari do neaktivního vzhledu. Živá nabídka má od prvního snímku výhradně tmavý vzhled se ztmavenými kartami, neutrální text a plochy; barevné zůstávají ikony. Profilová karta se nepřebarvuje při každém kreslení, implicitní animace jejích vrstev jsou vypnuté a stavová ikona při synchronizaci nepulzuje. Řádky zůstávají v běžném směru zleva doprava s ikonou a textem vlevo a indikátorem podnabídky vpravo; AppKit umístí kaskádu na dostupnou stranu obrazovky. Profil, hledání a kategorie zůstávají v kořenové nabídce; `Parkoviště a brána`, Milesight ani Loxone Builder se v macOS Menu nevytvářejí. Detail Miniserveru používá jedinou informační kartu následovanou běžnými nativními řádky akcí. Ticket, nový ticket a volné jméno spolucestujícího se otevírají v nativním dialogu až po výslovné akci uživatele. Historický jednostránkový navigátor je dostupný pouze pro deterministické offscreen rendery a self-testy, nikdy jako živé stavové menu. Balíček nemění ani nemaže databázi, výkazy, pracovní záznamy, screenshoty ani oddělený Codex účet.

Kořen už nezobrazuje duplicitní logo, název ani verze. Profilová karta správce s přibalenou lokální fotografií `profile-photo.jpeg` a větším jménem **Bc. Michal Schöniger** obsahuje v pravém horním rohu malý červený křížek pro ukončení; nevzniká nad ní samostatný prázdný řádek. Vyhledávání následuje hned pod profilem. Kliknutí do pole nejprve dokončí nativní zpracování myši a potom vrátí jeho field editor, takže lze dál psát bez aktivace celé aplikace. Jediný nalezený Miniserver skryje všechny nesouvisející kořenové položky. V detailu zůstává jen informační karta; `Kopírovat heslo`, Loxone App, web, oba režimy Configu a případné stažení jsou klasické položky systémového menu.

Integrace je určena výhradně správci Evora Smart Hubu. Technik ani běžný uživatel nemůže vytvořit ani použít její token. Po instalaci menu načte složky a Miniservery správce a u každého nabídne:

- otevření a přihlášení v Loxone App,
- předání do osobního Windows Loxone Config Launcheru,
- oficiální odkaz ke stažení odpovídajícího Loxone Configu,
- ostrý obrázek konkrétního typu Miniserveru, firmware a jednoznačný barevný stav online/offline,
- seznam všech Loxone ticketů z lokální cache Hubu, detail veřejné komunikace a příloh,
- přehlednou konverzaci po jednotlivých účastnících, časech a událostech se soubory,
- založení ticketu a veřejnou odpověď po úplném náhledu a samostatném potvrzení heslem.

Evora Smart Menu používá Evora Intranet jako primární zdroj docházky. Zobrazuje příchod, odchod, Home office, služební cestu, souhrny a historii aktuálního i předchozího měsíce. Aktivní pracovní čas běží v horní liště po sekundách ve formátu `HH:MM:SS`; přestávka místo toho ukazuje `☕ MM:SS` a odpočítává 30 minut. Nabízí přímé volání kontaktům z Intranetu a nativní žádost o dovolenou či absenci. Hledání Miniserverů při psaní skryje složky a nabídne přímo jednotlivé odpovídající servery; jediný výsledek otevře úplný detail s akcemi. Složky, detailní položky a rozsáhlý seznam ticketů se sestavují až při otevření konkrétní stránky. Po dobu otevřeného `NSMenu` se časovače, síťové výsledky a pomocné procesy nesmějí dotknout jeho struktury; změny se sloučí a použijí až po zavření. Změny stavu skryté kamery, NVR, brány a Builderu nejsou součástí podpisu stromu a nemohou kvůli sobě menu přestavět. Kamera a brána zůstávají serverovou funkcí Evora Smart Hubu, ale macOS Menu pro ně nevytváří položku, AVPlayer ani HLS prewarm. Detail Miniserveru ukazuje ověřený poměr online/celkem, počet offline prvků, Health stav, stáří poslední kontroly a odezvu; neznámou hodnotu nevydává za nulu.

V aktuální verzi 3.0.30 se celý fleet snapshot drží v paměti. Minutová obnova upraví jen skutečně změněné malé stavové hodnoty; otevřené menu se nikdy nepřestavuje ani nepřebarvuje po sekundách. Složka vytvoří své lehké položky až při otevření a konkrétní Miniserver teprve potom sestaví jedinou kartu a klasické akční řádky z nejnovějšího snapshotu. Text i ztmavené plochy jsou neutrální a významovou barvu mají pouze ikony.

Menu 3.0.30 obsahuje pod `Intranet` osobní Knihu jízd načtenou z přihlášené zaměstnanecké stránky Evora Intranetu. Uživatel vidí trasu, čas, vozidlo, kilometry, tachometr a případné validované počáteční a koncové GPS konkrétní jízdy. Podle zdrojového `canEdit` může změnit účel, ruční zakázku, řidiče, cestovní příkaz a spolucestující. Lze vybrat zaměstnance i zadat jiné jméno; volné jméno se zadává v nativním dialogu. Menu průběžnou polohu Macu nesleduje a docházkové akce GPS neposílají.

Kontakt bez telefonního čísla zůstává v Menu běžnou čitelnou kartou, pouze bez telefonní ikony. Chybějící číslo může správce doplnit v Hubu; Menu žádnou adresu ani telefon neodhaduje.

Loxone Builder je na výslovné přání v macOS Menu skrytý. Jeho samostatná stránka a budoucí plná integrace zůstávají v Evora Smart Hubu.

Obrázkové přílohy se zobrazí přímo v komunikaci. Po výslovném kliknutí se načítání, detail, nový ticket, odpověď, kontrola celého návrhu i výsledek odeslání zobrazují v nativních dialozích; pouhé otevření systémového menu žádné okno nevytváří. Ostatní dostupné soubory lze přes Hub bezpečně načíst a po výslovném kliknutí otevřít v odpovídající aplikaci macOS; pokud Portál poskytne jen název souboru vložený do textu zprávy, menu jej zobrazí bez nefunkčního tlačítka. Žádný návrh se neposílá automaticky ani pouhým zavřením nabídky.

Hover kořenových karet a vnořených řádků řídí jediný tracker celého panelu. Po opuštění nabídky resetuje všechny stavy, takže po návratu nezůstane zvýrazněno více tlačítek. Přechod stránky animuje jen průhlednost a vodorovná souřadnice dlouhého obsahu zůstává pevně na nule.

Běžné otevření menu používá uložený seznam a znovu nevolá celý Loxone Portál ani Intranet. Fleet snapshot se obnovuje na pozadí jednou za minutu a při přechodné chybě zůstane viditelný poslední platný stav. Shodná struktura se nepřestavuje: změní se jen souhrnný stav a již vytvořený detail se při příštím otevření porovná s malým podpisem svých údajů. Dlouhé nebo víceřádkové názvy ticketů se v menu zobrazí jako jeden bezpečně zkrácený řádek; celý text zůstává v detailu. **Aktualizovat změny** provede jednu kontrolu souhrnů; Hub zachová nezměněné detaily a znovu načte jen nový nebo změněný ticket.

## Instalace

1. Poklepejte na `install.command`.
2. V Evora Smart Hubu otevřete **Nastavení → Nástroje a zabezpečení → Evora Smart Menu · Evora Smart Hub**.
3. Vytvořte osobní token a zkopírujte ho. Hub ho zobrazí pouze jednou.
4. V Evora Smart Menu otevřete **Systémy → Nastavit připojení…**.
5. Vložte adresu Hubu a token.

Token se ukládá do macOS Klíčenky jako údaj dostupný jen tomuto uživatelskému účtu. V konfiguračních souborech WorkLogAI se neukládá. Odvolat ho lze kdykoli v Nastavení Hubu. Obrázky typů Miniserver, Compact a Go jsou součástí instalačního balíčku a detail je zobrazí okamžitě bez síťového čekání; autentizované stažení z Hubu zůstává pouze jako fallback.

Osobní lístečky nejsou tajemství a do Klíčenky se neukládají. Menu je zapisuje atomicky do lokálního souboru `user-data/personal-notes.json` s přístupem pouze pro aktuální účet Macu; tokeny a hesla zůstávají v Klíčence.

Instalátor před změnou zálohuje původní zdroj, značku a spustitelný soubor do privátního runtime `~/Library/Application Support/WorkLogAI/backups/evora-integration-*` a potom restartuje pouze Evora Smart Menu. Docházkové heslo zůstává jen v macOS Klíčence.
