import Foundation
import Security

struct KeychainTarget {
    let service: String
    let account: String
}

func target(for alias: String) -> KeychainTarget? {
    let service = "cz.worklogai.credentials.v1"
    switch alias {
    case "intranet-email":
        return KeychainTarget(service: service, account: "intranet.email")
    case "intranet-password":
        return KeychainTarget(service: service, account: "intranet.password")
    case "evora-token":
        return KeychainTarget(service: service, account: "smart-hub.token")
    case "home-assistant-domov-url":
        return KeychainTarget(service: service, account: "home-assistant.domov.url")
    case "local-miniservers":
        return KeychainTarget(service: service, account: "miniservers.local")
    case "evora-technician-token":
        return KeychainTarget(
            service: "cz.evorasmart.smartmenu.technician.credentials.v1",
            account: "smart-hub.token"
        )
    case "selftest":
        return KeychainTarget(service: "cz.worklogai.keychain-helper.selftest", account: "probe")
    default:
        return nil
    }
}

func identity(_ target: KeychainTarget) -> [CFString: Any] {
    [
        kSecClass: kSecClassGenericPassword,
        kSecAttrService: target.service,
        kSecAttrAccount: target.account
    ]
}

guard CommandLine.arguments.count == 3,
      let target = target(for: CommandLine.arguments[2])
else {
    exit(64)
}

let command = CommandLine.arguments[1]
switch command {
case "read":
    var query = identity(target)
    query[kSecMatchLimit] = kSecMatchLimitOne
    query[kSecReturnData] = true
    var result: CFTypeRef?
    let status = SecItemCopyMatching(query as CFDictionary, &result)
    guard status == errSecSuccess, let data = result as? Data else {
        exit(status == errSecItemNotFound ? 3 : 1)
    }
    FileHandle.standardOutput.write(data)

case "store":
    let value = FileHandle.standardInput.readDataToEndOfFile()
    guard !value.isEmpty else { exit(65) }
    let itemIdentity = identity(target)
    let deleteStatus = SecItemDelete(itemIdentity as CFDictionary)
    guard deleteStatus == errSecSuccess || deleteStatus == errSecItemNotFound else {
        exit(1)
    }
    var item = itemIdentity
    item[kSecValueData] = value
    item[kSecAttrAccessible] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
    guard SecItemAdd(item as CFDictionary, nil) == errSecSuccess else { exit(1) }

case "delete":
    let status = SecItemDelete(identity(target) as CFDictionary)
    guard status == errSecSuccess || status == errSecItemNotFound else { exit(1) }

default:
    exit(64)
}
