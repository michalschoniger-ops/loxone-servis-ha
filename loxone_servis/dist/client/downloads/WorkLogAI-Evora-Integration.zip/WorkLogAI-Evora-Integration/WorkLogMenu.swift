import Cocoa
import AVFoundation
import Darwin

final class MenuSearchField: NSSearchField {
    override var acceptsFirstResponder: Bool { true }

    private func restoreKeyboardFocus() {
        guard let window else { return }
        if window.firstResponder === self { return }
        if let editor = currentEditor(), window.firstResponder === editor { return }
        _ = window.makeFirstResponder(self)
    }

    override func mouseDown(with event: NSEvent) {
        restoreKeyboardFocus()
        super.mouseDown(with: event)
        // NSMenu can reclaim the first responder at the end of its click
        // tracking cycle. Restore the field editor on the next AppKit turn so
        // typing after a deliberate click continues in this search field.
        DispatchQueue.main.async { [weak self] in
            self?.restoreKeyboardFocus()
        }
    }
}

final class EvoraCameraPlayerView: NSView {
    private let playerLayer = AVPlayerLayer()

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        wantsLayer = true
        layer?.backgroundColor = NSColor.black.cgColor
        layer?.borderColor = NSColor.separatorColor.cgColor
        layer?.borderWidth = 1
        playerLayer.videoGravity = .resizeAspect
        layer?.addSublayer(playerLayer)
    }

    required init?(coder: NSCoder) {
        nil
    }

    override func layout() {
        super.layout()
        playerLayer.frame = bounds
    }

    func show(_ player: AVPlayer?) {
        playerLayer.player = player
    }
}

final class EvoraCameraHLSPlayer: NSObject {
    private weak var playerView: EvoraCameraPlayerView?
    private let onReady: () -> Void
    private let onFailure: (String) -> Void
    private var endpoint: URL?
    private var authorizationToken = ""
    private var player: AVPlayer?
    private var itemObservation: NSKeyValueObservation?
    private var playerObservation: NSKeyValueObservation?
    private var notificationObservers: [NSObjectProtocol] = []
    private var startupWorkItem: DispatchWorkItem?
    private var reconnectWorkItem: DispatchWorkItem?
    private var stopped = false
    private var playedInAttempt = false
    private var consecutiveFailures = 0
    private let failuresBeforeMessage = 3

    init(
        playerView: EvoraCameraPlayerView,
        onReady: @escaping () -> Void,
        onFailure: @escaping (String) -> Void
    ) {
        self.playerView = playerView
        self.onReady = onReady
        self.onFailure = onFailure
        super.init()
    }

    func start(url: URL, token: String) {
        guard player == nil, endpoint == nil else { return }
        stopped = false
        endpoint = url
        authorizationToken = token
        consecutiveFailures = 0
        beginPlayback()
    }

    func stop() {
        stopped = true
        reconnectWorkItem?.cancel()
        reconnectWorkItem = nil
        startupWorkItem?.cancel()
        startupWorkItem = nil
        tearDownPlayer(clearView: true)
        endpoint = nil
        authorizationToken = ""
    }

    private func tearDownPlayer(clearView: Bool) {
        itemObservation?.invalidate()
        itemObservation = nil
        playerObservation?.invalidate()
        playerObservation = nil
        notificationObservers.forEach(NotificationCenter.default.removeObserver)
        notificationObservers.removeAll()
        player?.pause()
        player = nil
        if clearView { playerView?.show(nil) }
    }

    private func beginPlayback() {
        guard !stopped, player == nil, let endpoint else { return }
        reconnectWorkItem = nil
        playedInAttempt = false
        let headers = ["Authorization": "Bearer \(authorizationToken)"]
        let asset = AVURLAsset(
            url: endpoint,
            options: ["AVURLAssetHTTPHeaderFieldsKey": headers]
        )
        let item = AVPlayerItem(asset: asset)
        item.preferredForwardBufferDuration = 0.5
        let player = AVPlayer(playerItem: item)
        player.automaticallyWaitsToMinimizeStalling = false
        self.player = player
        playerView?.show(player)

        itemObservation = item.observe(\.status, options: [.initial, .new]) { [weak self] item, _ in
            guard let self, !self.stopped else { return }
            if item.status == .failed {
                self.scheduleReconnect("Živý přenos teď není dostupný")
            }
        }
        playerObservation = player.observe(\.timeControlStatus, options: [.initial, .new]) { [weak self] player, _ in
            guard let self, !self.stopped, player.timeControlStatus == .playing else { return }
            self.playedInAttempt = true
            self.consecutiveFailures = 0
            self.startupWorkItem?.cancel()
            self.startupWorkItem = nil
            DispatchQueue.main.async { [weak self] in self?.onReady() }
        }
        notificationObservers = [
            NotificationCenter.default.addObserver(
                forName: AVPlayerItem.failedToPlayToEndTimeNotification,
                object: item,
                queue: .main
            ) { [weak self] _ in self?.scheduleReconnect("Živý přenos byl přerušen") },
            NotificationCenter.default.addObserver(
                forName: AVPlayerItem.didPlayToEndTimeNotification,
                object: item,
                queue: .main
            ) { [weak self] _ in self?.scheduleReconnect("Živý přenos byl ukončen") },
        ]
        let startup = DispatchWorkItem { [weak self] in
            self?.scheduleReconnect("Živý přenos se nepodařilo načíst")
        }
        startupWorkItem?.cancel()
        startupWorkItem = startup
        DispatchQueue.main.asyncAfter(deadline: .now() + 8, execute: startup)
        player.play()
    }

    private func scheduleReconnect(_ message: String) {
        guard !stopped, reconnectWorkItem == nil else { return }
        startupWorkItem?.cancel()
        startupWorkItem = nil
        tearDownPlayer(clearView: false)
        if playedInAttempt {
            consecutiveFailures = 0
        } else {
            consecutiveFailures += 1
        }
        playedInAttempt = false
        if consecutiveFailures >= failuresBeforeMessage {
            DispatchQueue.main.async { [weak self] in self?.onFailure(message) }
        }
        let delay = min(10.0, max(1.0, pow(2.0, Double(max(0, min(consecutiveFailures, 4) - 1)))))
        let reconnect = DispatchWorkItem { [weak self] in
            guard let self, !self.stopped else { return }
            self.reconnectWorkItem = nil
            self.beginPlayback()
        }
        reconnectWorkItem = reconnect
        DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: reconnect)
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate, NSMenuDelegate, NSSearchFieldDelegate {

    struct IntranetAttendanceEvent: Codable {
        let id: String?
        let kind: String
        let source: String?
        let ts: String
    }

    struct IntranetAttendanceResponse: Decodable {
        let hrProfileId: String
        let greeting: String
        let uvazekH: Double
        let events: [IntranetAttendanceEvent]
    }

    struct IntranetPerson: Codable {
        let name: String
        let state: String
        let since: Double?
        var phone: String? = nil
    }

    struct IntranetHistoryDay {
        let date: Date
        let events: [(event: IntranetAttendanceEvent, date: Date)]
        let arrival: Date?
        let departure: Date?
        let workedSeconds: Int
    }

    struct IntranetAttendanceSession {
        let date: Date
        let startedAt: Date
        var endedAt: Date?
        var events: [(event: IntranetAttendanceEvent, date: Date)]
        var arrival: Date?
        var departure: Date?
        var worked: TimeInterval
        var activeStart: Date?
        var baseState: String
        var baseSince: Date?
        var temporaryState: String?
        var temporarySince: Date?
    }

    struct IntranetSnapshot: Codable {
        var dataState: String
        var fetchedAt: Double
        var summaryFetchedAt: Double
        var rosterFetchedAt: Double
        var currentState: String
        var currentSince: Double?
        var hrProfileId: String
        var todayWorkedSeconds: Int
        var lastArrival: Double?
        var lastDeparture: Double?
        var greeting: String
        var workloadHours: Double
        var cards: [String: String]
        var people: [IntranetPerson]
        var notificationsUnread: Int
        var historyFetchedAt: Double?
        var historyEvents: [IntranetAttendanceEvent]?
        var errorCode: String?
        var errorMessage: String?

        static var empty: IntranetSnapshot {
            IntranetSnapshot(
                dataState: "not_configured",
                fetchedAt: 0,
                summaryFetchedAt: 0,
                rosterFetchedAt: 0,
                currentState: "none",
                currentSince: nil,
                hrProfileId: "",
                todayWorkedSeconds: 0,
                lastArrival: nil,
                lastDeparture: nil,
                greeting: "",
                workloadHours: 0,
                cards: [:],
                people: [],
                notificationsUnread: 0,
                historyFetchedAt: nil,
                historyEvents: [],
                errorCode: nil,
                errorMessage: nil
            )
        }
    }

    struct IntranetServiceError: LocalizedError {
        let code: String
        let message: String

        var errorDescription: String? { message }
    }

    struct EvoraMiniServer: Decodable {
        let serial: String
        let project: String
        let type: String
        let folderName: String
        let folderColor: String?
        let connectionState: String
        let currentFirmware: String?
        let elementsOnline: Int?
        let elementsTotal: Int?
        let offlineDevices: Int?
        let lastCheckedAt: String?
        let lastLatencyMs: Double?
        let consecutiveFailures: Int?
        let healthVerdict: String?
        let healthRefreshedAt: String?
        let dataState: String?
        let hasCredentials: Bool
        let loxoneAppAvailable: Bool
        let loxoneConfigAvailable: Bool
        let configVersion: String?
        let configDownloadUrl: String?
        let deviceImageUrl: String?
    }

    struct EvoraCamera: Decodable {
        let id: Int
        let name: String
        let online: Bool
        let model: String?
        let firmware: String?
    }

    struct EvoraLauncherAgent: Decodable {
        let name: String
        let available: Bool
        let helperVersion: String?
        let requiredHelperVersion: String?
        let latestHelperVersion: String?
        let updateRequired: Bool?
        let updateAvailable: Bool?
    }

    struct EvoraFleetResponse: Decodable {
        let appVersion: String?
        let launcherAgent: EvoraLauncherAgent?
        let cameras: [EvoraCamera]?
        let items: [EvoraMiniServer]
    }

    struct EvoraConfigJob: Decodable {
        let id: String
        let state: String
        let message: String
        let requiredVersion: String
        let configUrl: String?
    }

    struct EvoraActionResponse: Decodable {
        let action: String
        let url: String?
        let job: EvoraConfigJob?
    }

    struct EvoraJobResponse: Decodable {
        let job: EvoraConfigJob
    }

    struct EvoraPortalTicketSummary: Decodable {
        let id: String
        let ticketNumber: String
        let subject: String
        let status: String
        let createdTime: String
        let threadCount: Int
        let contactName: String
    }

    struct EvoraPortalTicketAttachment: Decodable {
        let id: String
        let name: String
        let token: String
        let downloadable: Bool?

        var canDownload: Bool { downloadable != false && !token.isEmpty }
    }

    struct EvoraPortalTicketAuthor: Decodable {
        let type: String
        let firstName: String
        let lastName: String
        let isLoxone: Bool
    }

    struct EvoraPortalTicketThread: Decodable {
        let id: String
        let createdTime: String
        let content: String
        let author: EvoraPortalTicketAuthor
        let attachments: [EvoraPortalTicketAttachment]
    }

    struct EvoraPortalTicketDetail: Decodable {
        let id: String
        let ticketNumber: String
        let subject: String
        let status: String
        let createdTime: String
        let threadCount: Int
        let contactName: String
        let threads: [EvoraPortalTicketThread]
        let attachments: [EvoraPortalTicketAttachment]
    }

    struct EvoraPortalTicketListResponse: Decodable {
        let items: [EvoraPortalTicketSummary]
    }

    struct EvoraPortalTicketDetailResponse: Decodable {
        let ticket: EvoraPortalTicketDetail
    }

    struct EvoraConfirmationResponse: Decodable {
        let confirmationId: String
        let expiresAt: String
    }

    struct EvoraPortalMutationResponse: Decodable {
        let ok: Bool
        let ticketId: String?
        let ticketNumber: String?
    }

    struct EvoraPortalDraft {
        let ticketId: String?
        let ticketNumber: String?
        let subject: String
        let body: String

        var isReply: Bool { ticketId != nil }
    }

    struct EvoraErrorResponse: Decodable {
        let error: String
        let code: String?
    }

    struct EvoraServiceError: LocalizedError {
        let message: String

        var errorDescription: String? {
            message
        }
    }

    var statusItem: NSStatusItem!
    private var clockTimer: Timer?
    private var refreshTimer: Timer?
    private var intranetTimer: Timer?
    private var statusPulseDimmed = false

    var menu: NSMenu!
    var macStatusItem: NSMenuItem!
    var windowsStatusItem: NSMenuItem!
    var trackingStatusItem: NSMenuItem!
    var shiftStatusItem: NSMenuItem!
    private weak var shiftStatusTitleField: NSTextField?
    private weak var shiftStatusDetailField: NSTextField?
    private weak var brandedHeaderSubtitleField: NSTextField?

    var startAgentItem: NSMenuItem!
    var restartAgentItem: NSMenuItem!
    var stopAgentItem: NSMenuItem!
    var pauseAgentItem: NSMenuItem!
    var resumeAgentItem: NSMenuItem!
    var intranetOfficeItem: NSMenuItem!
    var intranetHomeItem: NSMenuItem!
    var intranetEndItem: NSMenuItem!
    var evoraMenu: NSMenu!
    var evoraStatusItem: NSMenuItem!
    var intranetMenu: NSMenu!

    private var mainMenuSearchQuery = ""
    private var mainMenuSearchWorkItem: DispatchWorkItem?
    private var mainMenuSearchRevision = 0
    private var evoraRebuildDeferred = false
    private weak var mainMenuSearchField: NSSearchField?
    private weak var mainMenuSearchItem: NSMenuItem?
    private weak var mainMenuNoResultsItem: NSMenuItem?
    private var mainMenuOriginalHidden: [ObjectIdentifier: Bool] = [:]

    private var evoraRefreshInFlight = false
    private var evoraTicketsRefreshInFlight = false
    private var evoraLastRefresh = Date.distantPast
    private var evoraServers: [EvoraMiniServer] = []
    private var evoraCameras: [EvoraCamera] = []
    private var evoraCameraMenus: [ObjectIdentifier: Int] = [:]
    private var evoraCameraPreviewViews: [Int: EvoraCameraPlayerView] = [:]
    private var evoraCameraPreviewLabels: [Int: NSTextField] = [:]
    private var evoraCameraPreviewStreams: [Int: EvoraCameraHLSPlayer] = [:]
    private var evoraLauncherAgent: EvoraLauncherAgent?
    private var evoraHubVersion: String?
    private var evoraTickets: [EvoraPortalTicketSummary] = []
    private var evoraTicketsStatus = "Tickety: načítám…"
    private var evoraStatus = "Kontroluji připojení…"
    private var evoraSearchQuery = ""
    private weak var evoraSearchField: NSSearchField?
    private var evoraFolderMenuItems: [(item: NSMenuItem, folder: String, color: NSColor, servers: [(item: NSMenuItem, server: EvoraMiniServer)])] = []
    private var evoraFlatSearchMenuItems: [(item: NSMenuItem, folder: String, server: EvoraMiniServer)] = []
    private var evoraDeviceImageCache: [String: NSImage] = [:]
    private var evoraDeviceImageRequests: Set<String> = []
    private weak var evoraNoResultsItem: NSMenuItem?
    private let evoraKeychainAlias = "evora-token"
    private let evoraMenuVersion = "3.0.15"
    private var evoraTokenCache: String?
    private var evoraCredentialsLoaded = false
    private let evoraHubDefaultsKey = "EvoraSmartHubURL"
    private let defaultEvoraHubURL = "https://homeassistant-work.skunk-atria.ts.net:8443/api/loxone-servis"
    private lazy var evoraSession: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 30
        return URLSession(configuration: configuration)
    }()

    private var intranetSnapshot = IntranetSnapshot.empty
    private var intranetCredentialCache: [String: String] = [:]
    private var intranetCredentialsLoaded = false
    private var intranetRefreshInFlight = false
    private var intranetAccessToken = ""
    private var intranetRefreshToken = ""
    private var intranetCookieHeader = ""
    private var intranetTokenExpiresAt = Date.distantPast
    private var intranetRetryAfter = Date.distantPast
    private var intranetFailureCount = 0
    private var trackingReconciliationInFlight = false
    private let intranetBaseURL = "https://intranet.evora.cz"
    private let intranetSupabaseURL = "https://wknmzrjafskktgmkifux.supabase.co"
    private let intranetSupabaseKey = "sb_publishable_G7YKpiRaxEgGvuDxW6eemg_IG30Bw2F"
    private let intranetCookieName = "sb-wknmzrjafskktgmkifux-auth-token"
    private let intranetEmailAccount = "intranet-email"
    private let intranetPasswordAccount = "intranet-password"
    private lazy var intranetSession: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.timeoutIntervalForRequest = 25
        configuration.timeoutIntervalForResource = 40
        return URLSession(configuration: configuration)
    }()

    let home = FileManager.default.homeDirectoryForCurrentUser.path

    var runtimeRoot: String {
        "\(home)/Library/Application Support/WorkLogAI"
    }

    var workPath: String {
        "\(runtimeRoot)/bin/work"
    }

    var keychainHelperPath: String {
        "\(runtimeRoot)/bin/worklog-keychain-helper"
    }

    private lazy var evoraSmartHubLogo: NSImage = {
        let path = "\(runtimeRoot)/app/evora-hub-mark.png"
        let image = NSImage(contentsOfFile: path) ?? loxoneLikeIcon()
        image.isTemplate = false
        return image
    }()

    private lazy var milesightMenuLogo: NSImage = {
        let encoded = "iVBORw0KGgoAAAANSUhEUgAAARgAAABLCAYAAACr45hhAAAACXBIWXMAAAsTAAALEwEAmpwYAAAGtmlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDggNzkuMTY0MDM2LCAyMDE5LzA4LzEzLTAxOjA2OjU3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpwaG90b3Nob3A9Imh0dHA6Ly9ucy5hZG9iZS5jb20vcGhvdG9zaG9wLzEuMC8iIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKSIgeG1wOkNyZWF0ZURhdGU9IjIwMjAtMTAtMjNUMTA6MTA6NTUrMDg6MDAiIHhtcDpNb2RpZnlEYXRlPSIyMDIxLTEwLTI2VDEzOjI0OjQ0KzA4OjAwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIxLTEwLTI2VDEzOjI0OjQ0KzA4OjAwIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOmM3MDQzNWY4LWE0MDktMzk0OS04YTIwLWI3NzU1NzBmOTYzZiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpGRENBMDlDQ0Y1NjAxMUU5QjVDOUMxMjI4NDY3MzA1MiIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOkZEQ0EwOUNDRjU2MDExRTlCNUM5QzEyMjg0NjczMDUyIiBkYzpmb3JtYXQ9ImltYWdlL3BuZyIgcGhvdG9zaG9wOkNvbG9yTW9kZT0iMyIgcGhvdG9zaG9wOklDQ1Byb2ZpbGU9InNSR0IgSUVDNjE5NjYtMi4xIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RkRDQTA5QzlGNTYwMTFFOUI1QzlDMTIyODQ2NzMwNTIiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6RkRDQTA5Q0FGNTYwMTFFOUI1QzlDMTIyODQ2NzMwNTIiLz4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NzhlNDI5NmUtMjkwZi0yMzQxLWI5MTktZGQxMzNlMjc1ZTQ4IiBzdEV2dDp3aGVuPSIyMDIwLTEwLTIzVDExOjAwOjQzKzA4OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPHJkZjpsaSBzdEV2dDphY3Rpb249InNhdmVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOmM3MDQzNWY4LWE0MDktMzk0OS04YTIwLWI3NzU1NzBmOTYzZiIgc3RFdnQ6d2hlbj0iMjAyMS0xMC0yNlQxMzoyNDo0NCswODowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIDIxLjAgKFdpbmRvd3MpIiBzdEV2dDpjaGFuZ2VkPSIvIi8+IDwvcmRmOlNlcT4gPC94bXBNTTpIaXN0b3J5PiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pkj8VOsAABlZSURBVHic7Z15uBxFtcB/FwIEBiEIEQUeCMMqW1gExIMEkNEgDxGfD+UK856K4Cgiojx4iOKKuMGHOi48lwsOiqDmsUgcZVGOIhAgLGERLrIGkS0kTDYg8Y/qSyYzVV3VNX23pH/fd7/kdk91152uPnXqbNW3bNkyhujr66MgnUq9tRlwLbB15CXuBA5q1kpP5dergoKxQ7tMWW0U+zHuqNRbWwN/JF643ATsVwiXglWFQsAEUqm3tgeuA7aKvMS1QKVZKz2fW6cKCsY4E0a7A+OBSr21M3ANsFHkJX4HHNGslRbk16uCgrFPocF4qNRbewN/Il64XA4cVgiXglWRQsCkUKm3pgJNYFLkJS4C3tWslZbk1aeCgvFEIWAcVOqtg4HfAutFXuJ84JhmrfRyfr0qKBhfFALGQqXeOgy4Elg78hLnAccVwqVgVacw8nZQqbf6gZ8S/92c3ayVTs2vRwUF45dCg2mjUm99CLiAeOFyWiFcCgqWU2gwCZV662PAt3u4xInNWum8vPpTULAyEC1gKvXWmsBtwBsyNFsM/Apjn3gh9t55U6m3TgXOimy+FPhIs1b6YY5dKihYKYheIiWu1w8Cy3yfbWMt4CjgB7H3zZtKvfUVehMuxxTCpaDATpSAKVcbbwdo1kp/JW5ZcVSl3jo05t55Uam3+ir11jnAaZGXeBET49LIsVsFBSsVmQVMudooAxeWq40Nk0OnA49E3LteqbdiY0x6olJvrQ58D/hE5CUWYqJzL8utUwUFKyExGsxemLD5cwASW8pxEdf5N+CrEe16IhEuFxDXZ4B5wKHNWmlGfr0qKFg56ctaD6ZcbZzD8pl/2uBA/wyASr11AXB0xvsvA/Zv1krXZ2wXRWKYvhg4PPIS8zAZ0TeGfFhEVgNuwNie2vl/Vf2cp+01wKs7Dquqfiy0s6siSQT21y2nqs1a6faR7k8sIrI98AvLqVNVdUQnNxGZDPzecurLqnpJ58F2mRLjRdqr7f8/KFcbOw4O9L8AnARMI1tSYB9wfqXemtKslRZF9CWYSr21DnAppo8xPA0c2KyV7gQoVxt7A4sHB/pnpbTZnhW/ryF+lHYjEdkUOMBy6rdhXV2lOQDYtePYUmBwFPrSC0L33wHw95HuCGYM2/ryqK9hpiVSudqYAOzedmhz4MsAzVrpGeDjWa6XsB1wRkS7YCr11quAK4gXLo9jNK0h4XIAMAP/oLUJF4CbPe32dhy/ydOuAN5oOXbPWAqLCMT2dzwP/G2kO4J9PL6ICVNJJasNZmdgYsexE8rVxj4AzVrp55gcnqycUqm3bBKyZyr11vrAH7BrBCE8BExt1kp3A5Srjbdh/sY5gwP98z1tbQLmJfwPxiWYgpZmqyqVems17N/dePzebH/HzaqaJSwkL2x9uV1VF/saZhUwthv1AT8qVxtDdoaPAL4Xr5MJwI8SA2xuVOqtyZgSl64X1scgpsTlAwDlauMwTH2XtQnTJmz3nRXwYGyz1+Oq+kTAPVdltsWe/e7TGMcUIrI2ZjLvZLQ0WNt4DOpLHgIGTDTvaQDNWulRICYfZw+MHScX2opzx2pGdwH7NmulxwDK1UY/8GtgjeR86qwoIhMd904d7Ilh2PZAx+MsPNKsLJrf7oBtsh1xASMiW9PtbAjuS1YB47INAJxWrjZ2Sv7/fUAzXhvgC5V6qxzRbgUq9dbmmPq5O0Ze4iaMQfefAOVq41iMa7v9oftmxSnYjei+wb4d8CrL8XE1C48StvG5CLOTw3jCJShHQ4PpqS/BXqRytbEusEPKR9YE/q9cbezbrJWWVuqtY4FZdLto01gb41U6qFkrRa01k8r/1wGbxrQH/gIcMlScu1xtnICp79LOIuAOz3WeAv7bcvwqT7vCwBvPdLoF8dxmrfTSKPSlF2xj4LFRWiLbBMx84L6Qxlnc1Hvg13j2BmrAd5q10r2VeutLwBcz3AOMMfYDeFy5NpLi3L8HNs7aNuFaTBDdAoByteFKgpw1OND/YtqFVHWQONeo7YEuo9BgvDRrJVusxnhkLC2RbePxJlVdGtI4yxIpbXnUzqS2/59NnHr6zUq99bosDSr11p6Yyv+xwuVyYFqbcDkLdxLkcGoTVjerqmY1nBeMQ0RkI+xb44z4BCMiE4DdeulLFgFjG/g2Xrl5s1Z6EaONBEm7NtYHvhv64Uq99SbgauIr/18M/EezVlpcrjb6ytXGuaQbqodFwIjIWhjbzYjcr2BM4nrPRmMM7Ep3WApk6MtwaDArSLdmrTQTODfDfYZ4V6XeOsL3oUq9dSBGuMQmTl4A9DdrpSXlamN1jIH6RE+b4XrYu2FfthYCZtXBtUSeOdIdIQdhFyRgytXGazHJiT4eGBzof9Zy/AziQpzrlXprkutkUpz7CuKLc38f+K9mrfRyIlwuAD7safMc8EDk/Xy4Hmhhf1l1sE3ko7VEtgm7Oar6eOgFQjWY0OWRVbIldg3fi2tjY+CbthOVeus9mNyiWOFyNlBr81btgymG5eOmwYH+4Yqm3MdybBEwbpL0CnpmLBl4bcIukzYd6kUKXR45v4hmrfSHSr31E+yu2zQ+UKm3LmrWSlcPHajUW0djKv/HVuQ7s1krfb7jWGi0r1ebEJH7gckdhy9T1WM8TW2Da5aqpnqsPH2ZBOyL8QJuC2yJsVVNxCwr52PSF+ZgtMybgd+paq45L20JnDthAjM3BUrAuhgb3dKkL09iXPyDwL2YDPKHPNc+EBME2cl7VDXKs5QEmB2AGRdbAZtgJrP1MKVf5yV9/CvwK1WdbbnGbzHffTs3qurbHPfcCrsdseulTqJ9pwJvwsR7bY4Zc2sl/ZsPPIyZnGYAfw71/CTXfxUmWbeTQ0RkbkrT+bStdkIFTOjL55NuJwOHkN3T8+NKvTUNM+BOAr6RsX07pzRrJVs6f+jf6Ivg3QLY2nLqHk+7DYBtLKcy218S6/+7gWOB/Ul/zhsk/26FyeA9OrmGAqepakzAZHs/3gt8FLt2ZmOnjt9/CRzpabMPxjHQyazAewKv9Pf9mFALn9b+WozAngZ8XkSuBk5S1TuTa60O7IcRoO3cm3JNb3KsiOyBsRG+G1jH08edgHcA/wv8TUROVtUrPG2G2BP7BL5m8uNihTw7rwZQrjb6CFsivYTngTZrpeeAmHommwOzgSX0JlxqDuECEV4yB7EZ1Ll4D0TkEMx39QvgIOILuwtwvYicJSL+QkHd/XgjZrBdSLhwsRFif7Jp2H9X1adCbyIi+2NCKn5C+Fho5yDgFhE5Pvl9e7qFC6RPULb7LgLuEJEtRWQ6xth7NH7h0sm2wOUi8qnAz8fm760wXkMG3zaE7c18++BAv7emS7NWurRSb00nruhTbDLkUowx90LbyXK1sREQkqLwyOBA/5Oez8QGyvUkYERkTZIdJUM+n4FTMd/f6aENROQozBJ2Dc9HQwixP1iDwUIunmganyOfkiFrAN9LNKGFjs+kjQObIJ6F0QLr2AVWVr4uIjeo6p89n4sRshAhYHoy8Dr4KGZ9a1Nr8+ZFjBu6q/JWG3n+jbbBfp+qPu9pZxtcQR4rEVkHuAwzi9p4AuNtuwFTfmJu8rMM2BCzpHsr8D6MXaST00TkUlX11v8QkSMwWkundrww6cN1mDDzxzC2AjDjcBLGLrMFJhZoH0xe1q2e+22GWa50EmIrG/Icphn3n8Pk1d2Psbu8iNEeNsOEFeyMqSjQzrnY3crPqur9jr64gtq2S/roYhHGZrUQs3SZjP0ZtnMq8O+ez4TaXTtZYUIIETChNwoWMM1aaU6l3jqF4d++ZCHw3oDi3LnYmJIBu0fWdgnWlHhf/Y8k+/rn2IXLo8ApwCWq6ton+yHgFuBiETkT45nrFHZ9mKXtBz192QS78X06cJyq/jOtPR0vpYhsrKotTxvX+AzRfL6LW7jcBHwBuCrNOJrY3D6J+X6G/u7VHf1KE3o7YfeIbtDx+wvAJZjv9CZV/YelTzsAJ2BKp9h4q4hMUFVrjpaIvBYjQDuZQXoO0iJVfaz9QIiAycvA28n5mBlzasZ2oSzE5BVdE/DZvP7GHbDPHj7BtDl2w3eI/eEzwGGW41cBR2aJn1DVx0XkHZiqaRt2nH57wCVOpzsT/BaMNydzwqGq+pajYBfML+Mp6iUix2JfTi4FPg2cE1LcSVUfBk4UkSsxL31a2ESa0AsZg98HPuuzLanqPUBNRB7GXlh/Ikbre8xyDtxC+wxVzRTwl2rkLVcba2BX2zqZT7p1vIsk/uTDGBUvb+YBBwUKFwh7uEvxR1O6jJk+wRQ1C4vILsBnLaeuAw6PCc5S1Wexq+SbiIjTBpDYgN5vOfW5GOGSAdt3d1ea5pNoHedYTi3FCOVvZa0cp6pN/NvgpI2DtGX6fOCdqvqRLIZrzFJtnuNcmj3T9j4sJiIey+dFmkK6S2qImwcH+rPmG9Gsle4HzszazsPTGOFyQ8iHy9XGUFyIj7sHB/p96rptkCzB/2BiI3jPo3ugPA8cpapLPG3TcE0WaZ6L3ehO11iCKVc6LCTLwz0tp3wC/WvYNc3PquqlPXTpx6QXwk7rl2tyWggcrKqZ9+BKKid2xeckpAkqVyXGzPFYPgGTl+s2jW/iMeRl4ElMoagsalwu8S8p15oV8LLb2j2StkQQkamYGJdOvppD3RBXf12eEbDXChoMqdvaAztg96w4x6OIvAF4j+XUHfS4T1eiqbl2fnjQpX2ISAn3Hu81Ve0lktemPT6qqgscfXGFpUTlw/kEzHDZX14hKQb0Icy6uRceB2So8n8GchGisXVUE8OwbRb2DapPWI7Nx7gze+U1lmMve5ZckyzHNkq0jOEipkTmx+j2+oCxL/Q6BsGt/aWNH1etpStU9ac99mcTy7G0d2Rb7N7dKCGXl4DpKVeiWSvdRm8BdIOY+rkxSYihQWA+Ieqqo+r7blyG4bRZ+HWAbW/vC1XVtebOwustx2KKZ00GvjSMQsY2PhfgWBYkdqL3Wk49jHGh58Fcx/G0ceCywX2yl44kmtGWllNpBvDYQFErTi9SudpYD3suQidzBgf6g7MrUzgTE/5sC7NPYzbw9qHi3FlI9nkKMWKH1HV1DZLYPZDSBuQ7sQuz6Z57ASAi62Eml4nJTx/LZ60SJr+lk7s9l7XGd2CKwR8mIj/DGJ9n5mj0tWmft6ZoIofQ7fYF48bPbEN0MMlxPKuB92FXzEwGpmBXIv6a0sY2Hufifr6ppLmp34hdlewkl1olzVppUaXe+hBmEIZyO3Bws1bKYllvZ0fCQq5vHRzo970UNskfslGWbXAtxbh3XRzuOP4VERlKhZiU/LsOxlA/AX8AVhp/8pz/PSYo0DZB7Mjy6oALROQGzHO+DpP8l9l4mCxJbbs2pL08/+k4npf2AiatpZOXSbczRkcie4jRRmzjcWbsfkxpqutwRPCm0qyV/gj8MMN99+9BuEC+Nibb9xWyUZatD3e73KxJxKc4rrUn5qXbFRMRuwVmmbI+vQkX8Gxbmxiy34WxhaWxDiYo8IvA9cCTIjIgIlk3xpuCfYK0vjyJ8dIWjDiPuB0wXNjscHeoqtVALiIbY55TJ8MlYJzOg2QJOSXPvqQJmGE38Do4BVM6II1rMa5oX/i9j7wieF11VH3t1gZ2sZxKWx7tSe/CIit3qaq3iryq3oV5wb6BsYWEsAFwDHCNiNyYZAuHkHU7jR2xG6//kpNxd4iskdyuiTyPGjBZvUFTsIelRL/jaUukkBSB3KvdN2ul5yv11keB3zg+chWmfm7oAE4jLyEaO0hiNthy3etJTN7MYswSa8jYuwDjdn6Z5TtutjA5NS9hQs9J/n0pOT6kPc1P2j2U/mcsR1WfAz4tIp/HLOUOxURrh5To2AtQETlUVa8O+GwnT6XUjnFpSL6lXzBJPRebjSftedres6X0GLohIhtiT+CNGVv5CphytbEpdvdWJ/cNDvTn4bVYgWatNL1Sb11Cd7zCdODIZq3USxAZAOVqo0TYxmzPDA70+zwosXsZxWxq5TJK75eDUTA3VPUF4GfJDyKyHfBmzPKugnvfqonABSKypSd+yLp3c8rnd3ccz7PWbYzb3PZSzw7IwfIRIyxs47inLYtdGsxoLY/a+Tgmw3doRrgIOKZZK+Wlzu5GWPmHEA3N9n09ZktEC2i3ELNtrYttHW1i3MgjRrLEug8T7YqI7I0pnPQ+y8c3wdhLrJvUicirsRuT015km20E8i1HanupXyC92JhtDOSxPHJpRmnOg9z74rLBjEj8SxrNWukfmC1P7sPUz81TuEC+WeKxdVRt7W7zuHFttp57cnSzjgiqeqOqHoWpumfDls07RIzmZxPMSwIyvLNgG1MzXc9GRLbBvqTKw+xg+47uSTRLW1/Wx/4d9dQXlwYzEikCXpq10nQCYzsiyMvA66qj6ov8dRW58gmmzixnAJ+mNJb5MfB1uuNH0rKSY9R/237fz6V8PhMp9VxiMqjzmLht105z4e+FPSylp1VKlwZTrjZWI0zALCFjzdMxRl7LwNhBEmtQs1n5o4uCjzbJ7G5z4T6S0symKTyQZIJ3kRQ+txFbTtSGK6YqbaLJFIkcioi4EnjT+jLFcdxbZCwN2xJpO8I2MbvNtz/zWKVcbUzGHg7fyUODA/2+OJuYQDmIU/PBnoj4ek+bMUtSAsK2TXCaW9wacxRx+w3TSlBkxPU8fVpDJ74lci99SRtbNofHY4lXMBqbgMlt+44xTJ5GbFsu070BtVhsfXhaVR/0tLMth3ZJapyMR2xbeDyFI2lQRF6PPZ4l7VnNw55VDPkVPLM9zydcm5SJyBrYtYbhin/xpbvYBExa6YkgehEwaZJ5rJOX/SVm3Z3WhxChbXOr9gHnxlT/H02S/p5kOfXLlAjozLNzsgxzedk+ndP3ltUD0/O+zynYJr1bPZpR5z5e4C7bEUyhwaTjExSuOqo+weRaI4cMrisdxw8Hfp4Yj8c8yUv9JUxsTDsvkb6XuW12fgm/reBax/G3AF/LkvEtIruLyNfafi/RvZ8TjHBQW9IX16Tnu+4ky7FdRGStXvqzgpGrXG2shT2BrJO5RGZXjhFCjNjeuq7Ep7bHBuaB2e/oy9gr6R8JHCoiFwFNzG5+3iCpZFBOxsSf7Apspaqf8bT5CuY7uhFjlHw4xFWe2DymYUoR2Gbas1Q1reyG7btz5vq08VPgeMe5TwFvFpFvYfnO2nY53Bc4AiOUzmv7yO7YJ+u05+laIsfs4d6Oy9jsG1s27WYD4NfJs56tqnOT+kXrY5I6n0tqEjvptKJPIWwvm+Hcn3lYKVcbZeyu3k5mR5bIDNlLOnr2UtUFInIicLHjIyVMbMmxACLyDGbbkhZmW9E+VsywXpfuAkNp22QMcTwrxnAsEpFHMDaiJzDfQwuTTrIuRoBtgal/49IWLgM6t/R9hZRdG7zatKreKCK/wSRk2ngTplo/IrKE5Z4tVxZ6+7OyCT1fGs1YyqAGeBD7e3FI8oNIV47tQZhaOk46BUyxPFpOrIE3xAtgG5APqurTAfdEVX+ZLLNCSjxuSJhAbce3xLMFiE3EBGrZgrVC+A5wsifx8A3Ezc5DfBgj4Hx1jnzbo3be0zZh3Osq/pVoRLYSo8MlYJ7xaIVghGuWzdaC8hA7Z5KeN7kfB+Rl4HXVUY01DGcS2qp6NmapMRwpArHJnTFch8mjOiGgdrGr+mDQeEwE+H6Y5WMvXMeKG+LZ3pu073BPhiGoLaUvIWPr22R7r0M8pV0CZkxE8A4zeWkwrjqqvnaxa+QuVHUGZjZ+NyZXqxe34pOYzOJv41/iPQ1cjlGPs6ZvLEruczqwk6oeoKqh9VhcuT7BW+ao6tOq+jZMVcAZhHtK5mCWjm9J+rwMXtmkzBYiEFMis1cDryuBN2TpvQg4EGN4D0luDOpr5xKpjr+K3eLBgf7xHJp+Acla24MvmvI57C5WX5mBhY520wP61EWyHPt18jOUCLgNJnhtEsvtLe1lGBZhYkPmYYTFQ8kAC71nk0QLSDSyTTGxKa9OftZK7jshuUcLeBYz6z/aQ95Uk+7Snf+MqeeSbANyWRKPshPGwD0Z812tjalGuBhTQGvQFc+Ce7ve61NuP5PuMbBQVZ8J7L6LicDJluPWpNFOkp0GzgDOEJFNMQmlr0uuux7mOS7A2NmCoo37li1bbqvt6xtXYRQFBaOOiPwK41lq5wlg09gyk+OddpkynFtKFBSs1IjIa7Dv7nDJqipcOikETEFBPJ/E7m06f6Q7MlYplkgFBREkFfpux9ib2pmhqtNGoUtjhmKJVFDQAyKyDibQsVO4LAX+Z+R7NHYpBExBQQaS2jJXYk+p+Yaq3jGyPRrbFAKmYKVGREp5bV0rIgdjXMxTLaf/gnHxFrRR2GAKVmqSnS6PxySuzsQUArsFuD8kfibRWA4FjsO94d3dwFRV7WUTwJWGFWRKIWAKVmZEROkuCQEm8PBBTFWAOZjAyRdYHlS2GWZTPFvd5HZuAw5VVd9mgasMhYApWCVIooznkV5AvBd+ApyQwx5GKxXtMiXPoscFBWONnRke4XIncEqSC1aQQmHkLViZeQY4C5Oc2+u+UQsx+V7TgF0L4RJGsUQqWCVIjLX7Jj9DtpWNkp/2ifZFTALoHIx9ZjbGQ3RDQNW8AlZcIv0Lil3doJVdHgwAAAAASUVORK5CYII="
        guard let data = Data(base64Encoded: encoded),
              let source = NSImage(data: data)
        else { return sf("video.fill", color: evoraCameraMenuColor()) ?? NSImage() }
        let image = NSImage(size: NSSize(width: 16, height: 16))
        image.lockFocus()
        source.draw(
            in: NSRect(x: 0, y: 0, width: 16, height: 16),
            from: NSRect(x: 0, y: 0, width: 75, height: 75),
            operation: .sourceOver,
            fraction: 1,
            respectFlipped: true,
            hints: [.interpolation: NSImageInterpolation.high]
        )
        image.unlockFocus()
        image.isTemplate = false
        return image
    }()

    var intranetSnapshotPath: String {
        "\(runtimeRoot)/intranet_state.json"
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        statusItem = NSStatusBar.system.statusItem(
            withLength: NSStatusItem.variableLength
        )

        if let button = statusItem.button {
            button.toolTip = "Evora Smart Menu"
            button.font = NSFont.monospacedDigitSystemFont(
                ofSize: NSFont.systemFontSize,
                weight: .semibold
            )
        }

        buildMenu()
        loadIntranetSnapshot()
        rebuildIntranetMenu()
        loadIntranetCredentialsAsync()
        loadEvoraTokenAsync()
        refreshAll()

        clockTimer = Timer(
            timeInterval: 1.0,
            target: self,
            selector: #selector(tickClock),
            userInfo: nil,
            repeats: true
        )

        if let clockTimer {
            RunLoop.main.add(clockTimer, forMode: .common)
        }

        refreshTimer = Timer(
            timeInterval: 5.0,
            target: self,
            selector: #selector(refreshAll),
            userInfo: nil,
            repeats: true
        )

        if let refreshTimer {
            RunLoop.main.add(refreshTimer, forMode: .common)
        }

        intranetTimer = Timer(
            timeInterval: 60.0,
            target: self,
            selector: #selector(refreshIntranetTimerFired),
            userInfo: nil,
            repeats: true
        )

        if let intranetTimer {
            RunLoop.main.add(intranetTimer, forMode: .common)
        }
    }

    func applicationWillTerminate(_ notification: Notification) {
        stopAllEvoraCameraPreviewStreams()
    }

    private var refreshInFlight = false
    private var cachedAgent = false
    private var cachedWindows = "NIKDY"

    // MARK: - Work CLI

    private func runBoundedProcess(
        executable: String,
        arguments: [String],
        input: String? = nil,
        timeout: TimeInterval,
        mergeStandardError: Bool
    ) -> (status: Int32, output: String, timedOut: Bool)? {
        let process = Process()
        let outputPipe = Pipe()
        let inputPipe = Pipe()
        let stateLock = NSLock()
        var didTimeOut = false

        process.executableURL = URL(fileURLWithPath: executable)
        process.arguments = arguments
        process.standardOutput = outputPipe
        process.standardError = mergeStandardError ? outputPipe : FileHandle.nullDevice
        if input != nil { process.standardInput = inputPipe }

        do {
            try process.run()
            if let input {
                inputPipe.fileHandleForWriting.write(Data(input.utf8))
                inputPipe.fileHandleForWriting.closeFile()
            }
            let timeoutWork = DispatchWorkItem {
                guard process.isRunning else { return }
                stateLock.lock()
                didTimeOut = true
                stateLock.unlock()
                process.terminate()
                DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + 0.5) {
                    if process.isRunning { Darwin.kill(process.processIdentifier, SIGKILL) }
                }
            }
            DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + timeout, execute: timeoutWork)

            // Drain the pipe while the process runs. Waiting first can deadlock
            // when a verbose child fills the pipe buffer.
            let data = outputPipe.fileHandleForReading.readDataToEndOfFile()
            process.waitUntilExit()
            timeoutWork.cancel()
            stateLock.lock()
            let timedOut = didTimeOut
            stateLock.unlock()
            return (
                process.terminationStatus,
                String(data: data, encoding: .utf8) ?? "",
                timedOut
            )
        } catch {
            return nil
        }
    }

    func runWork(_ args: [String]) -> String {
        guard let result = runBoundedProcess(
            executable: workPath,
            arguments: args,
            timeout: 30,
            mergeStandardError: true
        ) else { return "CHYBA: příkaz se nepodařilo spustit" }
        return result.timedOut ? "CHYBA: příkaz překročil časový limit" : result.output
    }

    func quick() -> [String: Any]? {
        let out = runWork(["rychle"])

        guard
            let data = out.data(using: .utf8),
            let json = try? JSONSerialization.jsonObject(
                with: data
            ) as? [String: Any]
        else {
            return nil
        }

        return json
    }

    // MARK: - Evora Intranet

    func runKeychainHelper(
        _ command: String,
        alias: String,
        input: String? = nil
    ) -> (success: Bool, output: String) {
        guard let result = runBoundedProcess(
            executable: keychainHelperPath,
            arguments: [command, alias],
            input: input,
            timeout: 10,
            mergeStandardError: false
        ) else { return (false, "") }
        return (!result.timedOut && result.status == 0, result.output)
    }

    func readKeychainValue(alias: String) -> String? {
        let result = runKeychainHelper("read", alias: alias)
        return result.success && !result.output.isEmpty ? result.output : nil
    }

    func intranetCredential(_ account: String) -> String? {
        intranetCredentialCache[account]
    }

    func loadIntranetCredentialsAsync() {
        DispatchQueue.global(qos: .utility).async { [weak self] in
            guard let self else { return }
            let email = self.readKeychainValue(alias: self.intranetEmailAccount)
            let password = self.readKeychainValue(alias: self.intranetPasswordAccount)
            DispatchQueue.main.async {
                self.intranetCredentialCache.removeAll()
                if let email { self.intranetCredentialCache[self.intranetEmailAccount] = email }
                if let password { self.intranetCredentialCache[self.intranetPasswordAccount] = password }
                self.intranetCredentialsLoaded = true
                self.rebuildIntranetMenu()
                self.refreshIntranet(forceAll: true)
            }
        }
    }

    @discardableResult
    func saveIntranetCredential(_ value: String, account: String) -> Bool {
        let saved = runKeychainHelper("store", alias: account, input: value).success
        if saved {
            intranetCredentialCache[account] = value
            intranetCredentialsLoaded = true
        }
        return saved
    }

    @discardableResult
    func storeIntranetCredentials(email: String, password: String) -> Bool {
        guard saveIntranetCredential(email, account: intranetEmailAccount),
              saveIntranetCredential(password, account: intranetPasswordAccount)
        else {
            deleteIntranetCredentials()
            return false
        }
        return true
    }

    func deleteIntranetCredentials() {
        for account in [intranetEmailAccount, intranetPasswordAccount] {
            _ = runKeychainHelper("delete", alias: account)
        }
        intranetCredentialCache.removeAll()
        intranetCredentialsLoaded = true
        intranetAccessToken = ""
        intranetRefreshToken = ""
        intranetCookieHeader = ""
        intranetTokenExpiresAt = .distantPast
        intranetRetryAfter = .distantPast
        intranetFailureCount = 0
    }

    func hasIntranetCredentials() -> Bool {
        intranetCredential(intranetEmailAccount) != nil
            && intranetCredential(intranetPasswordAccount) != nil
    }

    func intranetBase64URL(_ data: Data) -> String {
        data.base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }

    func intranetCookieHeader(for sessionObject: [String: Any]) throws -> String {
        let compact = try JSONSerialization.data(withJSONObject: sessionObject)
        let value = "base64-\(intranetBase64URL(compact))"
        let characters = Array(value)
        let chunkSize = 3_180
        guard characters.count > chunkSize else {
            return "\(intranetCookieName)=\(value)"
        }
        var parts: [String] = []
        var offset = 0
        var index = 0
        while offset < characters.count {
            let end = min(offset + chunkSize, characters.count)
            parts.append("\(intranetCookieName).\(index)=\(String(characters[offset..<end]))")
            offset = end
            index += 1
        }
        return parts.joined(separator: "; ")
    }

    func applyIntranetSessionObject(_ object: [String: Any]) throws {
        guard
            let token = object["access_token"] as? String,
            !token.isEmpty
        else {
            throw IntranetServiceError(
                code: "internal_error",
                message: "Přihlášení neobsahuje přístupovou relaci."
            )
        }
        let expiresAt: Double
        if let value = object["expires_at"] as? Double {
            expiresAt = value
        } else if let value = object["expires_at"] as? Int {
            expiresAt = Double(value)
        } else {
            let expiresIn = (object["expires_in"] as? Double)
                ?? Double(object["expires_in"] as? Int ?? 3_600)
            expiresAt = Date().timeIntervalSince1970 + expiresIn
        }
        intranetAccessToken = token
        if let refreshToken = object["refresh_token"] as? String,
           !refreshToken.isEmpty {
            intranetRefreshToken = refreshToken
        }
        intranetCookieHeader = try intranetCookieHeader(for: object)
        intranetTokenExpiresAt = Date(timeIntervalSince1970: expiresAt)
    }

    func authenticateIntranet(
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        guard
            let email = intranetCredential(intranetEmailAccount),
            let password = intranetCredential(intranetPasswordAccount)
        else {
            completion(.failure(IntranetServiceError(
                code: "not_configured",
                message: "Připojení k Evora Intranetu není nastavené."
            )))
            return
        }
        guard let url = URL(string: "\(intranetSupabaseURL)/auth/v1/token?grant_type=password") else {
            completion(.failure(IntranetServiceError(code: "internal_error", message: "Neplatná adresa přihlášení.")))
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue(intranetSupabaseKey, forHTTPHeaderField: "apikey")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.httpBody = try? JSONSerialization.data(withJSONObject: [
            "email": email,
            "password": password
        ])
        intranetSession.dataTask(with: request) { [weak self] data, response, error in
            guard let self else { return }
            if error != nil {
                completion(.failure(IntranetServiceError(
                    code: "unavailable",
                    message: "Evora Intranet není dostupný."
                )))
                return
            }
            guard let http = response as? HTTPURLResponse else {
                completion(.failure(IntranetServiceError(code: "internal_error", message: "Přihlášení nevrátilo platnou odpověď.")))
                return
            }
            guard (200..<300).contains(http.statusCode), let data else {
                let code = [400, 401, 403].contains(http.statusCode) ? "auth_denied" : "unavailable"
                let message = code == "auth_denied"
                    ? "Evora Intranet odmítl e-mail nebo heslo."
                    : "Přihlášení k Evora Intranetu se nezdařilo."
                completion(.failure(IntranetServiceError(code: code, message: message)))
                return
            }
            do {
                guard let object = try JSONSerialization.jsonObject(with: data) as? [String: Any]
                else {
                    throw IntranetServiceError(code: "internal_error", message: "Přihlašovací relaci nelze zpracovat.")
                }
                try self.applyIntranetSessionObject(object)
                completion(.success(()))
            } catch let serviceError as IntranetServiceError {
                completion(.failure(serviceError))
            } catch {
                completion(.failure(IntranetServiceError(code: "internal_error", message: "Přihlašovací relaci nelze zpracovat.")))
            }
        }.resume()
    }

    func refreshIntranetSession(
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        guard !intranetRefreshToken.isEmpty else {
            authenticateIntranet(completion: completion)
            return
        }
        guard let url = URL(string: "\(intranetSupabaseURL)/auth/v1/token?grant_type=refresh_token") else {
            completion(.failure(IntranetServiceError(code: "internal_error", message: "Neplatná adresa obnovení přihlášení.")))
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue(intranetSupabaseKey, forHTTPHeaderField: "apikey")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.httpBody = try? JSONSerialization.data(withJSONObject: [
            "refresh_token": intranetRefreshToken
        ])
        intranetSession.dataTask(with: request) { [weak self] data, response, error in
            guard let self else { return }
            if error != nil {
                completion(.failure(IntranetServiceError(code: "unavailable", message: "Evora Intranet není dostupný.")))
                return
            }
            guard let http = response as? HTTPURLResponse else {
                completion(.failure(IntranetServiceError(code: "internal_error", message: "Obnovení přihlášení nevrátilo platnou odpověď.")))
                return
            }
            guard (200..<300).contains(http.statusCode), let data else {
                if [400, 401, 403].contains(http.statusCode) {
                    self.intranetRefreshToken = ""
                    self.authenticateIntranet(completion: completion)
                } else {
                    completion(.failure(IntranetServiceError(code: "unavailable", message: "Přihlášení se nepodařilo obnovit.")))
                }
                return
            }
            do {
                guard let object = try JSONSerialization.jsonObject(with: data) as? [String: Any]
                else {
                    throw IntranetServiceError(code: "internal_error", message: "Obnovenou relaci nelze zpracovat.")
                }
                try self.applyIntranetSessionObject(object)
                completion(.success(()))
            } catch let serviceError as IntranetServiceError {
                completion(.failure(serviceError))
            } catch {
                completion(.failure(IntranetServiceError(code: "internal_error", message: "Obnovenou relaci nelze zpracovat.")))
            }
        }.resume()
    }

    func ensureIntranetSession(
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        if !intranetCookieHeader.isEmpty,
           intranetTokenExpiresAt.timeIntervalSinceNow > 45 {
            completion(.success(()))
            return
        }
        refreshIntranetSession(completion: completion)
    }

    func intranetRequest(
        path: String,
        method: String = "GET",
        body: [String: Any]? = nil,
        retryAuthentication: Bool = true,
        completion: @escaping (Result<Data, Error>) -> Void
    ) {
        ensureIntranetSession { [weak self] sessionResult in
            guard let self else { return }
            switch sessionResult {
            case .failure(let error):
                completion(.failure(error))
            case .success:
                guard let url = URL(string: "\(self.intranetBaseURL)\(path)") else {
                    completion(.failure(IntranetServiceError(code: "internal_error", message: "Neplatná adresa Evora Intranetu.")))
                    return
                }
                var request = URLRequest(url: url)
                request.httpMethod = method
                request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
                request.setValue(self.intranetCookieHeader, forHTTPHeaderField: "Cookie")
                request.setValue("application/json, text/html", forHTTPHeaderField: "Accept")
                if let body {
                    request.httpBody = try? JSONSerialization.data(withJSONObject: body)
                    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                }
                self.intranetSession.dataTask(with: request) { data, response, error in
                    if error != nil {
                        completion(.failure(IntranetServiceError(code: "unavailable", message: "Evora Intranet není dostupný.")))
                        return
                    }
                    guard let http = response as? HTTPURLResponse else {
                        completion(.failure(IntranetServiceError(code: "internal_error", message: "Evora Intranet nevrátil platnou odpověď.")))
                        return
                    }
                    let redirectedToLogin = http.url?.path == "/login"
                    if (http.statusCode == 401 || redirectedToLogin), retryAuthentication {
                        self.intranetAccessToken = ""
                        self.intranetCookieHeader = ""
                        self.intranetTokenExpiresAt = .distantPast
                        self.intranetRequest(
                            path: path,
                            method: method,
                            body: body,
                            retryAuthentication: false,
                            completion: completion
                        )
                        return
                    }
                    if http.statusCode == 403 {
                        completion(.failure(IntranetServiceError(code: "permission_denied", message: "Účet nemá k této části Evora Intranetu oprávnění.")))
                        return
                    }
                    guard (200..<300).contains(http.statusCode), !redirectedToLogin else {
                        completion(.failure(IntranetServiceError(
                            code: redirectedToLogin ? "auth_denied" : "source_unavailable",
                            message: redirectedToLogin
                                ? "Přihlášení k Evora Intranetu už neplatí."
                                : "Evora Intranet požadovaná data neposkytl."
                        )))
                        return
                    }
                    completion(.success(data ?? Data()))
                }.resume()
            }
        }
    }

    func parseIntranetDate(_ value: String) -> Date? {
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = fractional.date(from: value) { return date }
        return ISO8601DateFormatter().date(from: value)
    }

    func intranetStateLabel(_ state: String) -> String {
        switch state {
        case "in_building": return "V práci"
        case "home_office": return "Home office"
        case "on_break": return "Na přestávce"
        case "doctor": return "U lékaře"
        case "offsite": return "Služebně mimo"
        case "vacation": return "Dovolená"
        case "sick": return "Omluvená absence"
        case "away", "none": return "Po pracovní době"
        default: return "Stav neověřen"
        }
    }

    func intranetDataStateLabel(_ state: String) -> String {
        switch state {
        case "loading": return "Načítám"
        case "current": return "Aktuální"
        case "stale": return "Zastaralá data"
        case "auth_denied": return "Přihlášení odmítnuto"
        case "permission_denied": return "Bez oprávnění"
        case "not_configured": return "Není nastaven přístup"
        case "source_unavailable": return "Zdroj údaj neposkytuje"
        case "unavailable": return "Intranet neodpovídá"
        default: return "Interní chyba Evora Smart Menu"
        }
    }

    func deriveIntranetAttendance(
        events: [IntranetAttendanceEvent],
        now: Date = Date()
    ) -> (state: String, since: Double?, worked: Int, arrival: Double?, departure: Double?) {
        guard let latest = intranetAttendanceSessions(events: events, now: now).last else {
            return ("none", nil, 0, nil, nil)
        }
        let calendar = intranetCalendar()
        let belongsToToday = calendar.isDate(latest.date, inSameDayAs: now)
            || (latest.endedAt.map { calendar.isDate($0, inSameDayAs: now) } ?? false)
        let isOpen = latest.departure == nil
        if (!isOpen && !belongsToToday) || (isOpen && now.timeIntervalSince(latest.startedAt) > 36 * 60 * 60) {
            return ("none", nil, 0, nil, nil)
        }
        var worked = latest.worked
        if let activeStart = latest.activeStart {
            worked += max(0, now.timeIntervalSince(activeStart))
        }
        return (
            latest.temporaryState ?? latest.baseState,
            (latest.temporarySince ?? latest.baseSince)?.timeIntervalSince1970,
            max(0, Int(worked)),
            latest.arrival?.timeIntervalSince1970,
            latest.departure?.timeIntervalSince1970
        )
    }

    func intranetAttendanceSessions(
        events: [IntranetAttendanceEvent],
        now: Date = Date()
    ) -> [IntranetAttendanceSession] {
        let calendar = intranetCalendar()
        let parsed = events.compactMap { event -> (IntranetAttendanceEvent, Date)? in
            guard let date = parseIntranetDate(event.ts), date <= now else { return nil }
            return (event, date)
        }.sorted { $0.1 < $1.1 }
        var sessions: [IntranetAttendanceSession] = []
        var session: IntranetAttendanceSession?

        func makeSession(_ date: Date) -> IntranetAttendanceSession {
            IntranetAttendanceSession(
                date: calendar.startOfDay(for: date),
                startedAt: date,
                endedAt: nil,
                events: [],
                arrival: nil,
                departure: nil,
                worked: 0,
                activeStart: nil,
                baseState: "none",
                baseSince: nil,
                temporaryState: nil,
                temporarySince: nil
            )
        }

        for (event, date) in parsed {
            if var current = session,
               date.timeIntervalSince(current.startedAt) > 36 * 60 * 60 {
                current.activeStart = nil
                current.baseState = "away"
                current.baseSince = current.events.last?.date ?? current.startedAt
                sessions.append(current)
                session = nil
            }
            if session == nil { session = makeSession(date) }
            guard var current = session else { continue }
            current.events.append((event: event, date: date))
            switch event.kind {
            case "arrival", "home_start":
                current.baseState = event.kind == "arrival" ? "in_building" : "home_office"
                current.baseSince = date
                current.temporaryState = nil
                current.temporarySince = nil
                if current.activeStart == nil { current.activeStart = date }
                if current.arrival == nil { current.arrival = date }
            case "break_out", "doctor_out":
                if let start = current.activeStart { current.worked += max(0, date.timeIntervalSince(start)) }
                current.activeStart = nil
                current.temporaryState = event.kind == "break_out" ? "on_break" : "doctor"
                current.temporarySince = date
            case "offsite_out":
                current.temporaryState = "offsite"
                current.temporarySince = date
                if current.activeStart == nil { current.activeStart = date }
            case "break_in", "doctor_in", "offsite_in":
                current.temporaryState = nil
                current.temporarySince = nil
                if current.baseState == "none" {
                    current.baseState = "in_building"
                    current.baseSince = date
                }
                if current.activeStart == nil { current.activeStart = date }
            case "departure", "home_end":
                if let start = current.activeStart { current.worked += max(0, date.timeIntervalSince(start)) }
                current.activeStart = nil
                current.temporaryState = nil
                current.temporarySince = nil
                current.baseState = "away"
                current.baseSince = date
                current.departure = date
                current.endedAt = date
                sessions.append(current)
                session = nil
                continue
            default:
                break
            }
            session = current
        }
        if let session { sessions.append(session) }
        return sessions
    }

    func intranetCalendar() -> Calendar {
        var calendar = Calendar(identifier: .gregorian)
        calendar.locale = Locale(identifier: "cs_CZ")
        calendar.timeZone = TimeZone(identifier: "Europe/Prague") ?? .current
        return calendar
    }

    func intranetMonthStart(offset: Int = 0, from date: Date = Date()) -> Date {
        let calendar = intranetCalendar()
        let components = calendar.dateComponents([.year, .month], from: date)
        let start = calendar.date(from: components) ?? calendar.startOfDay(for: date)
        return calendar.date(byAdding: .month, value: offset, to: start) ?? start
    }

    func intranetMonthKey(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "cs_CZ")
        formatter.timeZone = intranetCalendar().timeZone
        formatter.dateFormat = "yyyy-MM"
        return formatter.string(from: date)
    }

    func intranetMonthTitle(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "cs_CZ")
        formatter.timeZone = intranetCalendar().timeZone
        formatter.dateFormat = "LLLL yyyy"
        return formatter.string(from: date).prefix(1).uppercased()
            + formatter.string(from: date).dropFirst()
    }

    func intranetDayTitle(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "cs_CZ")
        formatter.timeZone = intranetCalendar().timeZone
        formatter.dateFormat = "EEE d. M."
        return formatter.string(from: date)
    }

    func mergeIntranetHistory(
        existing: [IntranetAttendanceEvent],
        incoming: [IntranetAttendanceEvent],
        now: Date = Date()
    ) -> [IntranetAttendanceEvent] {
        var merged: [String: IntranetAttendanceEvent] = [:]
        for event in existing + incoming {
            let key = "\(event.kind)|\(event.ts)"
            merged[key] = IntranetAttendanceEvent(
                id: nil,
                kind: event.kind,
                source: nil,
                ts: event.ts
            )
        }
        let start = intranetMonthStart(offset: -1, from: now)
        let end = intranetMonthStart(offset: 1, from: now)
        return merged.values.filter { event in
            guard let date = parseIntranetDate(event.ts) else { return false }
            return date >= start && date < end
        }.sorted {
            (parseIntranetDate($0.ts) ?? .distantPast)
                < (parseIntranetDate($1.ts) ?? .distantPast)
        }
    }

    func collectIntranetHistoryEvents(
        from value: Any,
        ownProfileId: String,
        output: inout [IntranetAttendanceEvent]
    ) {
        if let dictionary = value as? [String: Any] {
            if let kind = dictionary["kind"] as? String,
               let ts = dictionary["ts"] as? String,
               parseIntranetDate(ts) != nil {
                let profileId = dictionary["hr_profile_id"] as? String
                if profileId == nil || ownProfileId.isEmpty || profileId == ownProfileId {
                    output.append(IntranetAttendanceEvent(
                        id: dictionary["id"] as? String,
                        kind: kind,
                        source: dictionary["source"] as? String,
                        ts: ts
                    ))
                }
            }
            for child in dictionary.values {
                collectIntranetHistoryEvents(
                    from: child,
                    ownProfileId: ownProfileId,
                    output: &output
                )
            }
        } else if let array = value as? [Any] {
            for child in array {
                collectIntranetHistoryEvents(
                    from: child,
                    ownProfileId: ownProfileId,
                    output: &output
                )
            }
        }
    }

    func parseIntranetHistory(
        _ html: String,
        ownProfileId: String
    ) -> [IntranetAttendanceEvent] {
        var events: [IntranetAttendanceEvent] = []
        for object in nextFlightObjects(from: html) {
            collectIntranetHistoryEvents(
                from: object,
                ownProfileId: ownProfileId,
                output: &events
            )
        }
        return mergeIntranetHistory(existing: [], incoming: events)
    }

    func intranetHistoryDays(
        monthStart: Date,
        events: [IntranetAttendanceEvent],
        now: Date = Date()
    ) -> [IntranetHistoryDay] {
        let calendar = intranetCalendar()
        let monthEnd = calendar.date(byAdding: .month, value: 1, to: monthStart)
            ?? monthStart.addingTimeInterval(32 * 86_400)
        return intranetAttendanceSessions(events: events, now: now)
            .filter { $0.date >= monthStart && $0.date < monthEnd }
            .sorted { $0.date > $1.date }
            .map { session in
            var worked = session.worked
            if let start = session.activeStart {
                worked += max(0, now.timeIntervalSince(start))
            }
            return IntranetHistoryDay(
                date: session.date,
                events: session.events,
                arrival: session.arrival,
                departure: session.departure,
                workedSeconds: max(0, Int(worked))
            )
        }
    }

    func nextFlightObjects(from html: String) -> [Any] {
        guard let regex = try? NSRegularExpression(
            pattern: #"self\.__next_f\.push\((\[.*?\])\)</script>"#,
            options: [.dotMatchesLineSeparators]
        ) else { return [] }
        let ns = html as NSString
        var payload = ""
        for match in regex.matches(in: html, range: NSRange(location: 0, length: ns.length)) {
            guard match.numberOfRanges > 1,
                  let range = Range(match.range(at: 1), in: html),
                  let data = String(html[range]).data(using: .utf8),
                  let array = try? JSONSerialization.jsonObject(with: data) as? [Any],
                  array.count > 1,
                  (array[0] as? Int) == 1,
                  let part = array[1] as? String
            else { continue }
            payload += part
        }
        var objects: [Any] = []
        for line in payload.split(separator: "\n", omittingEmptySubsequences: true) {
            guard let colon = line.firstIndex(of: ":") else { continue }
            let raw = line[line.index(after: colon)...]
            guard let data = String(raw).data(using: .utf8),
                  let object = try? JSONSerialization.jsonObject(with: data)
            else { continue }
            objects.append(object)
        }
        return objects
    }

    func findIntranetDictionary(
        in value: Any,
        requiredKeys: Set<String>
    ) -> [String: Any]? {
        if let dictionary = value as? [String: Any] {
            if requiredKeys.isSubset(of: Set(dictionary.keys)) { return dictionary }
            for child in dictionary.values {
                if let found = findIntranetDictionary(in: child, requiredKeys: requiredKeys) {
                    return found
                }
            }
        } else if let array = value as? [Any] {
            for child in array {
                if let found = findIntranetDictionary(in: child, requiredKeys: requiredKeys) {
                    return found
                }
            }
        }
        return nil
    }

    func cleanIntranetHTML(_ value: String) -> String {
        var text = value.replacingOccurrences(
            of: #"<!--.*?-->"#,
            with: "",
            options: .regularExpression
        )
        text = text.replacingOccurrences(
            of: #"<[^>]+>"#,
            with: "",
            options: .regularExpression
        )
        guard let data = ("<span>\(text)</span>").data(using: .utf8),
              let attributed = try? NSAttributedString(
                data: data,
                options: [.documentType: NSAttributedString.DocumentType.html,
                          .characterEncoding: String.Encoding.utf8.rawValue],
                documentAttributes: nil
              )
        else { return text.trimmingCharacters(in: .whitespacesAndNewlines) }
        return attributed.string.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    func intranetCardValue(label: String, html: String) -> String? {
        let escaped = NSRegularExpression.escapedPattern(for: label)
        let pattern = #"<div class="text-xs text-muted">"# + escaped
            + #"</div>\s*<div class="text-lg[^"]*">(.*?)</div>"#
        guard let regex = try? NSRegularExpression(
            pattern: pattern,
            options: [.dotMatchesLineSeparators]
        ) else { return nil }
        let ns = html as NSString
        guard let match = regex.firstMatch(
            in: html,
            range: NSRange(location: 0, length: ns.length)
        ), match.numberOfRanges > 1,
        let range = Range(match.range(at: 1), in: html)
        else { return nil }
        let value = cleanIntranetHTML(String(html[range]))
        return value.isEmpty ? nil : value
    }

    func parseIntranetSummary(_ html: String) -> (cards: [String: String], workload: Double) {
        let labels: [(String, String)] = [
            ("workload", "Úvazek"),
            ("worked_month", "Odpracováno (měsíc)"),
            ("balance_month", "Saldo (měsíc)"),
            ("overtime_ordered", "Přesčas (nařízený)"),
            ("vacation_remaining", "Dovolená – zbývá"),
            ("sickday_remaining", "Sickday – zbývá")
        ]
        var cards: [String: String] = [:]
        for (key, label) in labels {
            if let value = intranetCardValue(label: label, html: html) {
                cards[key] = value
            }
        }
        let normalized = (cards["workload"] ?? "")
            .replacingOccurrences(of: ",", with: ".")
        let workload = normalized.range(of: #"[0-9]+(?:\.[0-9]+)?"#, options: .regularExpression)
            .flatMap { Double(normalized[$0]) } ?? 0
        return (cards, workload)
    }

    func parseIntranetRoster(
        _ html: String,
        ownProfileId: String,
        now: Date = Date()
    ) -> (people: [IntranetPerson], ownState: String?)? {
        var root: [String: Any]?
        for object in nextFlightObjects(from: html) where root == nil {
            root = findIntranetDictionary(
                in: object,
                requiredKeys: ["employees", "events", "absences", "fetchedAt"]
            )
        }
        guard let root,
              let employees = root["employees"] as? [[String: Any]],
              let rawEvents = root["events"] as? [[String: Any]]
        else { return nil }
        let rawAbsences = root["absences"] as? [[String: Any]] ?? []
        var eventsByPerson: [String: [IntranetAttendanceEvent]] = [:]
        for value in rawEvents {
            guard let personId = value["hr_profile_id"] as? String,
                  let kind = value["kind"] as? String,
                  let ts = value["ts"] as? String
            else { continue }
            let date = parseIntranetDate(ts)
            if let date, now.timeIntervalSince(date) > 86_400 { continue }
            eventsByPerson[personId, default: []].append(IntranetAttendanceEvent(
                id: value["id"] as? String,
                kind: kind,
                source: value["source"] as? String,
                ts: ts
            ))
        }
        var absencesByPerson: [String: String] = [:]
        for value in rawAbsences {
            guard let personId = value["hr_profile_id"] as? String,
                  let type = value["type"] as? String,
                  let status = value["status"] as? String,
                  ["approved", "auto_approved", "announced"].contains(status)
            else { continue }
            if type == "vacation" {
                absencesByPerson[personId] = "vacation"
            } else if type == "sick" || type == "sickday" {
                absencesByPerson[personId] = "sick"
            } else if type == "home_office" {
                absencesByPerson[personId] = "home_office"
            }
        }
        let activeStates: Set<String> = ["in_building", "home_office", "on_break", "doctor", "offsite"]
        let people = employees.compactMap { employee -> IntranetPerson? in
            guard let id = employee["id"] as? String,
                  let name = employee["name"] as? String,
                  !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            else { return nil }
            let derived = deriveIntranetAttendance(events: eventsByPerson[id] ?? [], now: now)
            let state = activeStates.contains(derived.state)
                ? derived.state
                : (absencesByPerson[id] ?? derived.state)
            return IntranetPerson(name: name, state: state, since: derived.since, phone: nil)
        }.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        let ownState: String?
        if ownProfileId.isEmpty {
            ownState = nil
        } else {
            let ownEvents = eventsByPerson[ownProfileId] ?? []
            let ownDerived = deriveIntranetAttendance(events: ownEvents, now: now)
            ownState = activeStates.contains(ownDerived.state)
                ? ownDerived.state
                : (absencesByPerson[ownProfileId] ?? ownDerived.state)
        }
        return (people, ownState)
    }

    func normalizedIntranetPersonName(_ value: String, sorted: Bool = false) -> String {
        let folded = value.folding(
            options: [.caseInsensitive, .diacriticInsensitive],
            locale: Locale(identifier: "cs_CZ")
        ).split(whereSeparator: { $0.isWhitespace }).map(String.init)
        return (sorted ? folded.sorted() : folded).joined(separator: " ")
    }

    func parseIntranetTeamPhones(_ html: String) -> [String: String] {
        var phones: [String: String] = [:]

        func walk(_ value: Any) {
            if let values = value as? [Any] {
                values.forEach(walk)
                return
            }
            guard let object = value as? [String: Any] else { return }
            if let href = object["href"] as? String,
               href.lowercased().hasPrefix("tel:"),
               let ariaLabel = object["aria-label"] as? String {
                let name = ariaLabel.replacingOccurrences(
                    of: #"^Zavolat\s+"#,
                    with: "",
                    options: [.regularExpression, .caseInsensitive]
                ).trimmingCharacters(in: .whitespacesAndNewlines)
                let phone = String(href.dropFirst(4)).trimmingCharacters(in: .whitespacesAndNewlines)
                let safePhone = phone.filter { "+0123456789".contains($0) }
                if !name.isEmpty, safePhone.count >= 6 {
                    phones[normalizedIntranetPersonName(name)] = safePhone
                    phones[normalizedIntranetPersonName(name, sorted: true)] = safePhone
                }
            }
            object.values.forEach(walk)
        }

        nextFlightObjects(from: html).forEach(walk)
        return phones
    }

    func loadIntranetSnapshot() {
        let url = URL(fileURLWithPath: intranetSnapshotPath)
        guard let data = try? Data(contentsOf: url),
              var snapshot = try? JSONDecoder().decode(IntranetSnapshot.self, from: data)
        else { return }
        if snapshot.fetchedAt > 0,
           Date().timeIntervalSince1970 - snapshot.fetchedAt > 150 {
            snapshot.dataState = "stale"
        }
        intranetSnapshot = snapshot
    }

    func saveIntranetSnapshot() {
        let url = URL(fileURLWithPath: intranetSnapshotPath)
        do {
            try FileManager.default.createDirectory(
                at: url.deletingLastPathComponent(),
                withIntermediateDirectories: true
            )
            var cacheSnapshot = intranetSnapshot
            cacheSnapshot.people = cacheSnapshot.people.map { person in
                var sanitized = person
                sanitized.phone = nil
                return sanitized
            }
            let data = try JSONEncoder().encode(cacheSnapshot)
            try data.write(to: url, options: .atomic)
            try FileManager.default.setAttributes(
                [.posixPermissions: 0o600],
                ofItemAtPath: url.path
            )
        } catch {
            // Cache neobsahuje přihlašovací údaje; selhání zápisu se ukáže
            // jako interní chyba při příští obnově, ne do systémového logu.
        }
    }

    func applyIntranetError(_ error: Error) {
        let serviceError = error as? IntranetServiceError
        let code = serviceError?.code ?? "internal_error"
        let now = Date().timeIntervalSince1970
        intranetFailureCount += 1
        let retryDelay: TimeInterval
        switch code {
        case "auth_denied", "permission_denied":
            retryDelay = 15 * 60
        case "unavailable":
            retryDelay = min(15 * 60, 60 * pow(2, Double(min(intranetFailureCount - 1, 4))))
        default:
            retryDelay = 5 * 60
        }
        intranetRetryAfter = Date(timeIntervalSinceNow: retryDelay)
        intranetSnapshot.dataState = code
        intranetSnapshot.errorCode = code
        intranetSnapshot.errorMessage = serviceError?.message ?? "Interní chyba Evora Smart Menu."
        if intranetSnapshot.fetchedAt == 0 || now - intranetSnapshot.fetchedAt > 300 {
            _ = runWork(["intranet-sync", "off"])
        }
        saveIntranetSnapshot()
        rebuildIntranetMenu()
        applyIntranetStatusToUI()
    }

    func syncWorkLogCollectionFromIntranet() {
        let age = Date().timeIntervalSince1970 - intranetSnapshot.fetchedAt
        let desired: String
        if intranetSnapshot.dataState != "current" || age > 300 {
            desired = "off"
        } else if intranetSnapshot.currentState == "in_building" {
            desired = "office"
        } else if intranetSnapshot.currentState == "home_office" {
            desired = "homeoffice"
        } else {
            desired = "off"
        }
        _ = runWork(["intranet-sync", desired])
    }

    func parseIntranetUnreadNotifications(_ data: Data) -> Int? {
        guard let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
        else { return nil }
        if let value = object["unread"] as? Int { return max(0, value) }
        if let value = object["unread"] as? NSNumber { return max(0, value.intValue) }
        return nil
    }

    @objc func refreshIntranetTimerFired() {
        refreshIntranet(forceAll: false)
    }

    @objc func refreshIntranetNow() {
        refreshIntranet(forceAll: true)
    }

    func refreshIntranet(forceAll: Bool) {
        guard !intranetRefreshInFlight else { return }
        guard intranetCredentialsLoaded else { return }
        guard forceAll || Date() >= intranetRetryAfter else {
            if intranetSnapshot.fetchedAt > 0,
               Date().timeIntervalSince1970 - intranetSnapshot.fetchedAt > 150,
               intranetSnapshot.dataState == "current" {
                intranetSnapshot.dataState = "stale"
                saveIntranetSnapshot()
                rebuildIntranetMenu()
                applyIntranetStatusToUI()
            }
            return
        }
        guard hasIntranetCredentials() else {
            intranetSnapshot = .empty
            saveIntranetSnapshot()
            _ = runWork(["intranet-sync", "off"])
            rebuildIntranetMenu()
            applyIntranetStatusToUI()
            return
        }
        intranetRefreshInFlight = true
        if intranetSnapshot.fetchedAt == 0 {
            intranetSnapshot.dataState = "loading"
            rebuildIntranetMenu()
        }
        intranetRequest(path: "/api/attendance/me", method: "POST") { [weak self] result in
            guard let self else { return }
            switch result {
            case .failure(let error):
                DispatchQueue.main.async {
                    self.intranetRefreshInFlight = false
                    self.applyIntranetError(error)
                }
            case .success(let data):
                do {
                    let response = try JSONDecoder().decode(IntranetAttendanceResponse.self, from: data)
                    let now = Date()
                    let derived = self.deriveIntranetAttendance(events: response.events, now: now)
                    var updated = self.intranetSnapshot
                    updated.dataState = "current"
                    updated.fetchedAt = now.timeIntervalSince1970
                    updated.currentState = derived.state
                    updated.currentSince = derived.since
                    updated.hrProfileId = response.hrProfileId
                    updated.todayWorkedSeconds = derived.worked
                    updated.lastArrival = derived.arrival
                    updated.lastDeparture = derived.departure
                    updated.greeting = response.greeting
                    updated.workloadHours = response.uvazekH
                    updated.errorCode = nil
                    updated.errorMessage = nil

                    let summaryDue = forceAll || now.timeIntervalSince1970 - updated.summaryFetchedAt > 600
                    let rosterDue = forceAll || now.timeIntervalSince1970 - updated.rosterFetchedAt > 300
                    let historyDue = forceAll
                        || now.timeIntervalSince1970 - (updated.historyFetchedAt ?? 0) > 600
                    updated.historyEvents = self.mergeIntranetHistory(
                        existing: updated.historyEvents ?? [],
                        incoming: response.events,
                        now: now
                    )
                    if !response.events.isEmpty {
                        updated.historyFetchedAt = now.timeIntervalSince1970
                    }

                    let finish: (IntranetSnapshot) -> Void = { finalSnapshot in
                        DispatchQueue.main.async {
                            self.intranetSnapshot = finalSnapshot
                            self.intranetRefreshInFlight = false
                            self.intranetFailureCount = 0
                            self.intranetRetryAfter = .distantPast
                            self.saveIntranetSnapshot()
                            self.syncWorkLogCollectionFromIntranet()
                            self.rebuildIntranetMenu()
                            self.applyIntranetStatusToUI()
                        }
                    }

                    let loadNotifications: (IntranetSnapshot) -> Void = { snapshotAfterRoster in
                        self.intranetRequest(path: "/api/notifications") { notificationsResult in
                            var finalSnapshot = snapshotAfterRoster
                            if case .success(let notificationsData) = notificationsResult,
                               let unread = self.parseIntranetUnreadNotifications(notificationsData) {
                                finalSnapshot.notificationsUnread = unread
                            }
                            finish(finalSnapshot)
                        }
                    }

                    let loadRoster: (IntranetSnapshot) -> Void = { snapshotAfterSummary in
                        guard rosterDue else { finish(snapshotAfterSummary); return }
                        self.intranetRequest(path: "/nastenka") { rosterResult in
                            var snapshotWithRoster = snapshotAfterSummary
                            if case .success(let rosterData) = rosterResult,
                               let html = String(data: rosterData, encoding: .utf8),
                               let roster = self.parseIntranetRoster(
                                   html,
                                   ownProfileId: snapshotWithRoster.hrProfileId,
                                   now: now
                               ) {
                                snapshotWithRoster.people = roster.people
                                if ["vacation", "sick", "home_office"].contains(roster.ownState),
                                   !["in_building", "home_office", "on_break", "doctor", "offsite"].contains(snapshotWithRoster.currentState),
                                   let ownState = roster.ownState {
                                    snapshotWithRoster.currentState = ownState
                                    snapshotWithRoster.currentSince = nil
                                }
                                snapshotWithRoster.rosterFetchedAt = now.timeIntervalSince1970
                            }
                            self.intranetRequest(path: "/tym") { contactsResult in
                                var finalSnapshot = snapshotWithRoster
                                if case .success(let contactsData) = contactsResult,
                                   let html = String(data: contactsData, encoding: .utf8) {
                                    let phones = self.parseIntranetTeamPhones(html)
                                    finalSnapshot.people = finalSnapshot.people.map { person in
                                        var updatedPerson = person
                                        let key = self.normalizedIntranetPersonName(person.name)
                                        let sortedKey = self.normalizedIntranetPersonName(person.name, sorted: true)
                                        updatedPerson.phone = phones[key] ?? phones[sortedKey]
                                        return updatedPerson
                                    }
                                }
                                loadNotifications(finalSnapshot)
                            }
                        }
                    }

                    let loadAttendanceHistory: (IntranetSnapshot) -> Void = { snapshotAfterSummary in
                        guard historyDue else {
                            loadRoster(snapshotAfterSummary)
                            return
                        }
                        let currentMonth = self.intranetMonthKey(
                            self.intranetMonthStart(from: now)
                        )
                        let previousMonth = self.intranetMonthKey(
                            self.intranetMonthStart(offset: -1, from: now)
                        )
                        self.intranetRequest(path: "/dochazka?month=\(currentMonth)") { currentResult in
                            var withCurrent = snapshotAfterSummary
                            if case .success(let currentData) = currentResult,
                               let html = String(data: currentData, encoding: .utf8) {
                                let events = self.parseIntranetHistory(
                                    html,
                                    ownProfileId: withCurrent.hrProfileId
                                )
                                withCurrent.historyEvents = self.mergeIntranetHistory(
                                    existing: withCurrent.historyEvents ?? [],
                                    incoming: events,
                                    now: now
                                )
                                withCurrent.historyFetchedAt = now.timeIntervalSince1970
                            }
                            self.intranetRequest(path: "/dochazka?month=\(previousMonth)") { previousResult in
                                var withPrevious = withCurrent
                                if case .success(let previousData) = previousResult,
                                   let html = String(data: previousData, encoding: .utf8) {
                                    let events = self.parseIntranetHistory(
                                        html,
                                        ownProfileId: withPrevious.hrProfileId
                                    )
                                    withPrevious.historyEvents = self.mergeIntranetHistory(
                                        existing: withPrevious.historyEvents ?? [],
                                        incoming: events,
                                        now: now
                                    )
                                    withPrevious.historyFetchedAt = now.timeIntervalSince1970
                                }
                                loadRoster(withPrevious)
                            }
                        }
                    }

                    guard summaryDue else {
                        loadAttendanceHistory(updated)
                        return
                    }
                    self.intranetRequest(path: "/moje") { summaryResult in
                        var withSummary = updated
                        if case .success(let summaryData) = summaryResult,
                           let html = String(data: summaryData, encoding: .utf8) {
                            let parsed = self.parseIntranetSummary(html)
                            if !parsed.cards.isEmpty {
                                withSummary.cards = parsed.cards
                                if parsed.workload > 0 { withSummary.workloadHours = parsed.workload }
                                withSummary.summaryFetchedAt = now.timeIntervalSince1970
                            }
                        }
                        loadAttendanceHistory(withSummary)
                    }
                } catch {
                    DispatchQueue.main.async {
                        self.intranetRefreshInFlight = false
                        self.applyIntranetError(IntranetServiceError(
                            code: "internal_error",
                            message: "Docházková data Evora Intranetu mají neočekávaný formát."
                        ))
                    }
                }
            }
        }
    }

    func formatIntranetDuration(_ seconds: Int) -> String {
        let roundedMinutes = max(0, Int((Double(seconds) / 60.0).rounded()))
        let hours = roundedMinutes / 60
        let minutes = roundedMinutes % 60
        if hours == 0 { return "\(minutes) min" }
        if minutes == 0 { return "\(hours) h" }
        return "\(hours) h \(minutes) min"
    }

    func formatIntranetLiveClock(_ seconds: Int) -> String {
        let safeSeconds = max(0, seconds)
        let hours = safeSeconds / 3600
        let minutes = (safeSeconds % 3600) / 60
        let secondsPart = safeSeconds % 60
        return String(format: "%02d:%02d:%02d", hours, minutes, secondsPart)
    }

    func intranetBreakRemainingSeconds(
        state: String,
        since: Double?,
        now: Date = Date()
    ) -> Int? {
        guard state == "on_break", let since else { return nil }
        let remaining = 30 * 60 - max(0, now.timeIntervalSince1970 - since)
        return max(0, Int(ceil(remaining)))
    }

    func formatIntranetBreakCountdown(_ seconds: Int) -> String {
        let safeSeconds = max(0, seconds)
        return String(format: "%02d:%02d", safeSeconds / 60, safeSeconds % 60)
    }

    func formatIntranetTime(_ timestamp: Double?) -> String {
        guard let timestamp else { return "—" }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "cs_CZ")
        formatter.timeZone = TimeZone(identifier: "Europe/Prague")
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: Date(timeIntervalSince1970: timestamp))
    }

    func displayedIntranetWorkedSeconds() -> Int {
        var seconds = intranetSnapshot.todayWorkedSeconds
        let activeWorkStates: Set<String> = ["in_building", "home_office", "offsite"]
        if intranetSnapshot.dataState == "current",
           activeWorkStates.contains(intranetSnapshot.currentState),
           intranetSnapshot.fetchedAt > 0 {
            seconds += max(0, Int(Date().timeIntervalSince1970 - intranetSnapshot.fetchedAt))
        }
        return seconds
    }

    func applyIntranetStatusToUI() {
        guard shiftStatusItem != nil else { return }
        let state = intranetSnapshot.dataState
        let ready = state == "current" && !intranetSnapshot.hrProfileId.isEmpty
        let activeWorkStates: Set<String> = ["in_building", "home_office", "offsite"]
        let canStart = ["none", "away"].contains(intranetSnapshot.currentState)
        intranetOfficeItem?.isEnabled = ready && canStart
        intranetHomeItem?.isEnabled = ready && canStart
        intranetEndItem?.isEnabled = ready
            && ["in_building", "home_office"].contains(intranetSnapshot.currentState)
        if state == "current" || state == "stale" {
            let stateLabel = intranetStateLabel(intranetSnapshot.currentState)
            let duration = formatIntranetLiveClock(displayedIntranetWorkedSeconds())
            let breakRemaining = intranetBreakRemainingSeconds(
                state: intranetSnapshot.currentState,
                since: intranetSnapshot.currentSince
            )
            let breakCountdown = breakRemaining.map(formatIntranetBreakCountdown)
            let color: NSColor
            switch intranetSnapshot.currentState {
            case "in_building", "home_office", "offsite": color = .systemGreen
            case "on_break", "doctor": color = .systemOrange
            case "vacation", "sick": color = .systemBlue
            default: color = .systemBlue
            }
            let stale = state == "stale" ? " · ZASTARALÉ" : ""
            shiftStatusTitleField?.stringValue = breakCountdown == nil ? "Intranet" : "Intranet · PŘESTÁVKA"
            shiftStatusTitleField?.textColor = breakCountdown == nil ? .labelColor : .systemOrange
            shiftStatusDetailField?.stringValue = breakCountdown.map { "\(stateLabel) · zbývá \($0)\(stale)" }
                ?? "\(stateLabel) · dnes \(duration)\(stale)"
            shiftStatusDetailField?.textColor = state == "stale" ? .systemOrange : color
            shiftStatusItem.toolTip = breakCountdown.map { "\(stateLabel) · zbývá \($0)\(stale)" }
                ?? "\(stateLabel) · dnes \(duration)\(stale)"
            if let button = statusItem.button {
                button.title = breakCountdown.map { " ☕ \($0)" }
                    ?? (activeWorkStates.contains(intranetSnapshot.currentState) ? " \(duration)" : "")
                configureStatusButton(button)
                button.toolTip = breakCountdown.map { "Evora Smart Menu · \(stateLabel) · zbývá \($0)" }
                    ?? (activeWorkStates.contains(intranetSnapshot.currentState)
                        ? "Evora Smart Menu · \(stateLabel) · \(duration)"
                        : "Evora Smart Menu · \(stateLabel)")
            }
        } else {
            let statusColor: NSColor
            switch state {
            case "loading": statusColor = .systemBlue
            case "stale", "unavailable", "source_unavailable": statusColor = .systemOrange
            case "not_configured": statusColor = .systemRed
            default: statusColor = .systemRed
            }
            shiftStatusTitleField?.stringValue = "Intranet"
            shiftStatusTitleField?.textColor = .labelColor
            shiftStatusDetailField?.stringValue = intranetDataStateLabel(state)
            shiftStatusDetailField?.textColor = statusColor
            shiftStatusItem.toolTip = intranetDataStateLabel(state)
            if let button = statusItem.button {
                button.title = ""
                configureStatusButton(button)
                button.toolTip = "Evora Smart Menu · \(intranetDataStateLabel(state))"
            }
        }
        updateStatusButtonAnimation()
    }

    func intranetPunchLabel(_ kind: String) -> String {
        switch kind {
        case "arrival": return "Příchod"
        case "departure": return "Odchod"
        case "home_start": return "Začít Home office"
        case "home_end": return "Ukončit Home office"
        case "break_out": return "Začít přestávku"
        case "break_in": return "Ukončit přestávku"
        case "doctor_out": return "Odchod k lékaři"
        case "doctor_in": return "Návrat od lékaře"
        case "offsite_out": return "Začít služební cestu"
        case "offsite_in": return "Ukončit služební cestu"
        default: return kind
        }
    }

    func intranetAvailablePunches() -> [String] {
        switch intranetSnapshot.currentState {
        case "in_building": return ["departure", "break_out", "doctor_out", "offsite_out"]
        case "home_office": return ["home_end", "break_out", "doctor_out"]
        case "on_break": return ["break_in"]
        case "doctor": return ["doctor_in"]
        case "offsite": return ["offsite_in"]
        case "vacation", "sick": return []
        default: return ["arrival", "home_start", "doctor_out", "offsite_out"]
        }
    }

    func intranetPunchMenuItem(_ kind: String) -> NSMenuItem {
        let symbol: String
        switch kind {
        case "arrival": symbol = "building.2"
        case "departure", "home_end": symbol = "rectangle.portrait.and.arrow.right"
        case "home_start": symbol = "house"
        case "break_out", "break_in": symbol = "cup.and.saucer"
        case "doctor_out", "doctor_in": symbol = "cross.case"
        default: symbol = "car"
        }
        let entry = item(
            intranetPunchLabel(kind),
            symbol: symbol,
            action: #selector(performIntranetPunch(_:))
        )
        entry.representedObject = kind
        entry.isEnabled = intranetSnapshot.dataState == "current"
            && !intranetSnapshot.hrProfileId.isEmpty
        return entry
    }

    func intranetHistoryMenuItem(now: Date = Date()) -> NSMenuItem {
        let parent = NSMenuItem(
            title: "Historie docházky",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(to: parent, title: "Historie docházky", symbol: "calendar")
        let historyMenu = NSMenu(title: "Historie docházky")
        historyMenu.autoenablesItems = false
        let allEvents = intranetSnapshot.historyEvents ?? []

        for offset in [0, -1] {
            let monthStart = intranetMonthStart(offset: offset, from: now)
            let monthItem = NSMenuItem(
                title: intranetMonthTitle(monthStart),
                action: nil,
                keyEquivalent: ""
            )
            applyMenuIcon(
                to: monthItem,
                title: intranetMonthTitle(monthStart),
                symbol: offset == 0 ? "calendar.badge.clock" : "calendar"
            )
            let monthMenu = NSMenu(title: intranetMonthTitle(monthStart))
            monthMenu.autoenablesItems = false
            let days = intranetHistoryDays(
                monthStart: monthStart,
                events: allEvents,
                now: now
            )

            if days.isEmpty {
                monthMenu.addItem(readOnlyItem(
                    "Zdroj zatím neposkytl záznamy pro tento měsíc",
                    symbol: "info.circle",
                    color: .labelColor
                ))
            } else {
                for day in days {
                    let summary = day.workedSeconds > 0
                        ? formatIntranetDuration(day.workedSeconds)
                        : "bez vypočteného času"
                    let dayItem = NSMenuItem(
                        title: "\(intranetDayTitle(day.date)) · \(summary)",
                        action: nil,
                        keyEquivalent: ""
                    )
                    applyMenuIcon(
                        to: dayItem,
                        title: "\(intranetDayTitle(day.date)) · \(summary)",
                        symbol: "clock"
                    )
                    let dayMenu = NSMenu(title: intranetDayTitle(day.date))
                    dayMenu.autoenablesItems = false
                    dayMenu.addItem(metricItem(
                        label: "Příchod",
                        value: formatIntranetTime(day.arrival?.timeIntervalSince1970),
                        symbol: "rectangle.portrait.and.arrow.right",
                        valueColor: .labelColor
                    ))

                    var breakStart: Date?
                    var breakIntervals: [String] = []
                    for entry in day.events {
                        if entry.event.kind == "break_out" {
                            breakStart = entry.date
                        } else if entry.event.kind == "break_in", let start = breakStart {
                            breakIntervals.append(
                                "\(formatIntranetTime(start.timeIntervalSince1970))–\(formatIntranetTime(entry.date.timeIntervalSince1970))"
                            )
                            breakStart = nil
                        }
                    }
                    if let start = breakStart {
                        breakIntervals.append("od \(formatIntranetTime(start.timeIntervalSince1970))")
                    }
                    dayMenu.addItem(metricItem(
                        label: "Pauza",
                        value: breakIntervals.isEmpty ? "bez pauzy" : breakIntervals.joined(separator: ", "),
                        symbol: "cup.and.saucer",
                        valueColor: .labelColor
                    ))
                    dayMenu.addItem(metricItem(
                        label: "Odchod",
                        value: formatIntranetTime(day.departure?.timeIntervalSince1970),
                        symbol: "rectangle.portrait.and.arrow.forward",
                        valueColor: .labelColor
                    ))
                    dayMenu.addItem(.separator())
                    dayMenu.addItem(metricItem(
                        label: "Odpracováno",
                        value: formatIntranetDuration(day.workedSeconds),
                        symbol: "clock",
                        valueColor: .labelColor
                    ))
                    dayItem.submenu = dayMenu
                    monthMenu.addItem(dayItem)
                }
            }
            monthItem.submenu = monthMenu
            historyMenu.addItem(monthItem)
        }

        if let fetchedAt = intranetSnapshot.historyFetchedAt, fetchedAt > 0 {
            historyMenu.addItem(.separator())
            historyMenu.addItem(readOnlyItem(
                "Aktualizováno \(formatIntranetTime(fetchedAt))",
                symbol: "checkmark.circle",
                color: .labelColor
            ))
        }
        parent.submenu = historyMenu
        return parent
    }

    func rebuildIntranetMenu() {
        guard intranetMenu != nil else { return }
        defer {
            if !mainMenuSearchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                applyMainMenuSearchFilter()
            }
        }
        intranetMenu.removeAllItems()

        let statusTitle: String
        if intranetSnapshot.dataState == "current" || intranetSnapshot.dataState == "stale" {
            if let breakRemaining = intranetBreakRemainingSeconds(
                state: intranetSnapshot.currentState,
                since: intranetSnapshot.currentSince
            ) {
                statusTitle = "Na přestávce · zbývá \(formatIntranetBreakCountdown(breakRemaining))"
            } else {
                statusTitle = "\(intranetStateLabel(intranetSnapshot.currentState)) · dnes \(formatIntranetLiveClock(displayedIntranetWorkedSeconds()))"
            }
        } else {
            statusTitle = intranetDataStateLabel(intranetSnapshot.dataState)
        }
        intranetMenu.addItem(readOnlyItem(
            statusTitle,
            symbol: "clock",
            color: .labelColor,
            weight: .semibold
        ))

        if intranetSnapshot.fetchedAt > 0 {
            intranetMenu.addItem(readOnlyItem(
                "Poslední úspěšná obnova: \(formatIntranetTime(intranetSnapshot.fetchedAt))",
                symbol: "checkmark.circle",
                color: .labelColor
            ))
        }

        if intranetSnapshot.dataState != "current",
           let message = intranetSnapshot.errorMessage {
            intranetMenu.addItem(readOnlyItem(
                "Poslední obnova selhala · \(message)",
                symbol: "exclamationmark.triangle",
                color: .systemRed,
                weight: .semibold
            ))
        }

        intranetMenu.addItem(.separator())
        if !intranetSnapshot.cards.isEmpty {
            let cardRows: [(String, String, String, NSColor)] = [
                ("worked_month", "Odpracováno za měsíc", "clock.fill", .systemGreen),
                ("balance_month", "Saldo za měsíc", "equal.circle", .systemTeal),
                ("overtime_ordered", "Nařízený přesčas", "timer", .systemOrange),
                ("vacation_remaining", "Zbývající dovolená", "sun.max.fill", .systemYellow),
                ("sickday_remaining", "Zbývající sick days", "cross.case.fill", .systemBlue)
            ]
            for (key, label, symbol, symbolColor) in cardRows {
                let value = intranetSnapshot.cards[key] ?? "Zdroj údaj neposkytuje"
                intranetMenu.addItem(metricItem(
                    label: label,
                    value: value,
                    symbol: symbol,
                    symbolColor: symbolColor,
                    valueColor: .labelColor
                ))
            }
        }
        intranetMenu.addItem(intranetHistoryMenuItem())

        intranetMenu.addItem(.separator())
        let available = intranetAvailablePunches()
        if let primary = available.first {
            intranetMenu.addItem(intranetPunchMenuItem(primary))
        }
        if available.count > 1 {
            let more = NSMenuItem(title: "Další docházkové akce", action: nil, keyEquivalent: "")
            applyMenuIcon(to: more, title: "Další docházkové akce", symbol: "ellipsis.circle")
            let submenu = NSMenu(title: "Další docházkové akce")
            for kind in available.dropFirst() {
                submenu.addItem(intranetPunchMenuItem(kind))
            }
            more.submenu = submenu
            intranetMenu.addItem(more)
        }

        if !intranetSnapshot.people.isEmpty {
            let roster = NSMenuItem(title: "Kdo je kde a kontakty", action: nil, keyEquivalent: "")
            applyMenuIcon(to: roster, title: "Kdo je kde a kontakty", symbol: "person.3")
            let rosterMenu = NSMenu(title: "Kdo je kde a kontakty")
            let groups = [
                "in_building", "home_office", "offsite", "on_break",
                "vacation", "sick", "doctor", "away", "none"
            ]
            for state in groups {
                let people = intranetSnapshot.people.filter { $0.state == state }
                guard !people.isEmpty else { continue }
                let group = NSMenuItem(
                    title: "\(intranetStateLabel(state)) (\(people.count))",
                    action: nil,
                    keyEquivalent: ""
                )
                applyMenuIcon(
                    to: group,
                    title: "\(intranetStateLabel(state)) (\(people.count))",
                    symbol: "person.2"
                )
                let peopleMenu = NSMenu(title: intranetStateLabel(state))
                peopleMenu.autoenablesItems = false
                for person in people {
                    let suffix = person.since.map { " · od \(formatIntranetTime($0))" } ?? ""
                    if let phone = person.phone, !phone.isEmpty {
                        let contact = item(
                            "\(person.name)\(suffix)",
                            symbol: "phone.fill",
                            action: #selector(callIntranetContact(_:))
                        )
                        contact.representedObject = phone
                        contact.toolTip = "Zavolat \(person.name)"
                        peopleMenu.addItem(contact)
                    } else {
                        peopleMenu.addItem(readOnlyItem(
                            "\(person.name)\(suffix)",
                            color: .labelColor
                        ))
                    }
                }
                group.submenu = peopleMenu
                rosterMenu.addItem(group)
            }
            roster.submenu = rosterMenu
            intranetMenu.addItem(roster)
        }

        intranetMenu.addItem(item(
            "Dovolená a absence…",
            symbol: "calendar.badge.plus",
            action: #selector(requestIntranetLeave),
            color: .systemGreen
        ))

        intranetMenu.addItem(.separator())
        intranetMenu.addItem(item(
            intranetRefreshInFlight ? "Aktualizuji…" : "Aktualizovat nyní",
            symbol: "arrow.clockwise",
            action: #selector(refreshIntranetNow)
        ))
        intranetMenu.items.last?.isEnabled = !intranetRefreshInFlight && hasIntranetCredentials()
        intranetMenu.addItem(linkItem(
            "Otevřít Evora Intranet",
            symbol: "globe",
            url: "https://intranet.evora.cz/moje"
        ))
        intranetMenu.addItem(item(
            hasIntranetCredentials() ? "Nastavit připojení…" : "Připojit Evora Intranet…",
            symbol: "key",
            action: #selector(configureIntranetConnection)
        ))
    }

    @objc func configureIntranetConnection() {
        NSApp.activate(ignoringOtherApps: true)
        let alert = makeContextualAlert(
            "Evora Intranet",
            "Přihlášení se uloží pouze do macOS Klíčenky. Evora Smart Menu neukládá heslo, přístupový token ani GPS do svých souborů."
        )
        alert.addButton(withTitle: "Uložit a připojit")
        alert.addButton(withTitle: hasIntranetCredentials() ? "Odpojit" : "Zrušit")
        if hasIntranetCredentials() { alert.addButton(withTitle: "Zrušit") }

        let container = NSView(frame: NSRect(x: 0, y: 0, width: 380, height: 112))
        let emailLabel = NSTextField(labelWithString: "Firemní e-mail")
        emailLabel.frame = NSRect(x: 0, y: 90, width: 380, height: 18)
        let email = NSTextField(frame: NSRect(x: 0, y: 60, width: 380, height: 26))
        email.stringValue = intranetCredential(intranetEmailAccount) ?? ""
        email.placeholderString = "jmeno@evorasmart.cz"
        let passwordLabel = NSTextField(labelWithString: "Heslo")
        passwordLabel.frame = NSRect(x: 0, y: 36, width: 380, height: 18)
        let password = NSSecureTextField(frame: NSRect(x: 0, y: 4, width: 380, height: 26))
        password.placeholderString = hasIntranetCredentials() ? "Ponechte prázdné pro zachování" : "Heslo"
        container.addSubview(emailLabel)
        container.addSubview(email)
        container.addSubview(passwordLabel)
        container.addSubview(password)
        alert.accessoryView = container

        let response = alert.runModal()
        if response == .alertSecondButtonReturn {
            if hasIntranetCredentials() {
                deleteIntranetCredentials()
                intranetSnapshot = .empty
                saveIntranetSnapshot()
                _ = runWork(["intranet-sync", "off"])
                rebuildIntranetMenu()
                applyIntranetStatusToUI()
            }
            return
        }
        guard response == .alertFirstButtonReturn else { return }
        let emailValue = email.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        let passwordValue = password.stringValue
        guard emailValue.contains("@"), !emailValue.contains(" ") else {
            showAlert("Evora Intranet", "Zadejte platný firemní e-mail.")
            return
        }
        guard !passwordValue.isEmpty || intranetCredential(intranetPasswordAccount) != nil else {
            showAlert("Evora Intranet", "Heslo je povinné.")
            return
        }
        let passwordToStore = passwordValue.isEmpty
            ? (intranetCredential(intranetPasswordAccount) ?? "")
            : passwordValue
        guard storeIntranetCredentials(email: emailValue, password: passwordToStore) else {
            showAlert("Evora Intranet", "Přístup se nepodařilo bezpečně uložit do macOS Klíčenky.")
            return
        }
        intranetAccessToken = ""
        intranetRefreshToken = ""
        intranetCookieHeader = ""
        intranetTokenExpiresAt = .distantPast
        intranetRetryAfter = .distantPast
        intranetFailureCount = 0
        intranetSnapshot.dataState = "loading"
        rebuildIntranetMenu()
        refreshIntranet(forceAll: true)
    }

    @objc func performIntranetPunch(_ sender: NSMenuItem) {
        guard let kind = sender.representedObject as? String else { return }
        executeIntranetPunch(kind)
    }

    @objc func callIntranetContact(_ sender: NSMenuItem) {
        guard let phone = sender.representedObject as? String,
              let url = URL(string: "tel:\(phone)")
        else { return }
        NSWorkspace.shared.open(url)
    }

    @objc func requestIntranetLeave() {
        guard intranetSnapshot.dataState == "current",
              !intranetSnapshot.hrProfileId.isEmpty
        else {
            showAlert("Evora Intranet", "Docházková data nejsou aktuální. Nejdřív je obnovte.")
            return
        }

        NSApp.activate(ignoringOtherApps: true)
        let alert = makeContextualAlert(
            "Dovolená a absence",
            "Žádost se odešle přímo do Evora Intranetu ke schválení vedoucímu."
        )
        alert.addButton(withTitle: "Požádat o schválení")
        alert.addButton(withTitle: "Zrušit")

        let width: CGFloat = 430
        let container = NSView(frame: NSRect(x: 0, y: 0, width: width, height: 194))

        let typeLabel = NSTextField(labelWithString: "Typ")
        typeLabel.frame = NSRect(x: 0, y: 170, width: 90, height: 18)
        let typePopup = NSPopUpButton(frame: NSRect(x: 0, y: 138, width: width, height: 27))
        typePopup.addItems(withTitles: ["Dovolená", "Sick day", "Nemoc", "Lékař"])

        let fromLabel = NSTextField(labelWithString: "Od")
        fromLabel.frame = NSRect(x: 0, y: 112, width: 190, height: 18)
        let toLabel = NSTextField(labelWithString: "Do")
        toLabel.frame = NSRect(x: 220, y: 112, width: 190, height: 18)
        let fromPicker = NSDatePicker(frame: NSRect(x: 0, y: 80, width: 202, height: 27))
        let toPicker = NSDatePicker(frame: NSRect(x: 220, y: 80, width: 210, height: 27))
        for picker in [fromPicker, toPicker] {
            picker.datePickerStyle = .textFieldAndStepper
            picker.datePickerElements = .yearMonthDay
            picker.dateValue = Date()
        }

        let halfDay = NSButton(checkboxWithTitle: "Půlden", target: nil, action: nil)
        halfDay.frame = NSRect(x: 0, y: 48, width: 120, height: 24)
        let noteLabel = NSTextField(labelWithString: "Poznámka")
        noteLabel.frame = NSRect(x: 0, y: 27, width: 100, height: 18)
        let note = NSTextField(frame: NSRect(x: 0, y: 0, width: width, height: 25))
        note.placeholderString = "Volitelné"

        [typeLabel, typePopup, fromLabel, toLabel, fromPicker, toPicker, halfDay, noteLabel, note]
            .forEach(container.addSubview)
        alert.accessoryView = container

        guard alert.runModal() == .alertFirstButtonReturn else { return }
        let calendar = Calendar(identifier: .gregorian)
        guard calendar.startOfDay(for: fromPicker.dateValue) <= calendar.startOfDay(for: toPicker.dateValue) else {
            showAlert("Dovolená a absence", "Datum „Od“ nesmí být později než datum „Do“.")
            return
        }
        let typeKeys = ["vacation", "sickday", "sick", "doctor"]
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.timeZone = TimeZone(identifier: "Europe/Prague")
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let noteValue = note.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        let body: [String: Any] = [
            "action": "create",
            "hr_profile_id": intranetSnapshot.hrProfileId,
            "type": typeKeys[max(0, min(typePopup.indexOfSelectedItem, typeKeys.count - 1))],
            "date_from": dateFormatter.string(from: fromPicker.dateValue),
            "date_to": dateFormatter.string(from: toPicker.dateValue),
            "portion": halfDay.state == .on ? 0.5 : 1.0,
            "note": noteValue.isEmpty ? NSNull() : noteValue,
            "propustky": []
        ]
        let loadingPanel = presentEvoraLoadingPanel(
            title: "Odesílám žádost",
            detail: "Evora Intranet zpracovává žádost o volno."
        )
        intranetRequest(path: "/api/hr/leave", method: "POST", body: body) { [weak self] result in
            guard let self else { return }
            DispatchQueue.main.async {
                loadingPanel.orderOut(nil)
                loadingPanel.close()
                switch result {
                case .success:
                    self.showAlert("Dovolená a absence", "Žádost byla odeslána ke schválení.")
                    self.refreshIntranet(forceAll: true)
                case .failure(let error):
                    self.showAlert("Dovolená a absence", error.localizedDescription)
                }
            }
        }
    }

    func executeIntranetPunch(_ kind: String) {
        guard intranetSnapshot.dataState == "current",
              !intranetSnapshot.hrProfileId.isEmpty
        else {
            showAlert("Evora Intranet", "Docházková data nejsou aktuální. Nejdřív je obnovte.")
            return
        }
        guard intranetAvailablePunches().contains(kind) else {
            showAlert(
                "Evora Intranet",
                "Akce „\(intranetPunchLabel(kind))“ neodpovídá aktuálnímu stavu „\(intranetStateLabel(intranetSnapshot.currentState))“. Nejdřív obnovte data."
            )
            return
        }
        NSApp.activate(ignoringOtherApps: true)
        let confirmation = makeContextualAlert(
            intranetPunchLabel(kind),
            "Tato akce se zapíše do Evora Intranetu jako oficiální docházka. GPS se z Evora Smart Menu neodesílá.",
            iconContext: "Evora Intranet docházka"
        )
        confirmation.addButton(withTitle: "Ano, zapsat")
        confirmation.addButton(withTitle: "Zrušit")
        guard confirmation.runModal() == .alertFirstButtonReturn else { return }

        let body: [String: Any] = [
            "action": "save",
            "hr_profile_id": intranetSnapshot.hrProfileId,
            "kind": kind,
            "ts": ISO8601DateFormatter().string(from: Date()),
            "source": "web",
            "lat": NSNull(),
            "lng": NSNull(),
            "gps_accuracy": NSNull(),
            "location": NSNull(),
            "client_ref": UUID().uuidString.lowercased()
        ]
        intranetRequest(path: "/api/attendance/events", method: "POST", body: body) { [weak self] result in
            guard let self else { return }
            if case .success = result,
               ["arrival", "home_start"].contains(kind) {
                _ = self.runWork(["spustit"])
            }
            DispatchQueue.main.async {
                switch result {
                case .success:
                    self.refreshIntranet(forceAll: false)
                case .failure(let error):
                    self.showAlert("Evora Intranet", error.localizedDescription)
                }
            }
        }
    }

    // MARK: - Evora Smart Hub

    func evoraToken() -> String? {
        evoraTokenCache
    }

    func loadEvoraTokenAsync() {
        DispatchQueue.global(qos: .utility).async { [weak self] in
            guard let self else { return }
            let token = self.readKeychainValue(alias: self.evoraKeychainAlias)
            DispatchQueue.main.async {
                self.evoraTokenCache = token
                self.evoraCredentialsLoaded = true
                self.rebuildEvoraMenu()
                self.refreshEvoraMenu()
            }
        }
    }

    @discardableResult
    func saveEvoraToken(_ token: String) -> Bool {
        let saved = runKeychainHelper("store", alias: evoraKeychainAlias, input: token).success
        if saved {
            evoraTokenCache = token
            evoraCredentialsLoaded = true
        }
        return saved
    }

    func deleteEvoraToken() {
        _ = runKeychainHelper("delete", alias: evoraKeychainAlias)
        evoraTokenCache = nil
        evoraCredentialsLoaded = true
    }

    func evoraHubURL() -> String {
        let configured = UserDefaults.standard.string(forKey: evoraHubDefaultsKey)
            ?? defaultEvoraHubURL
        return configured.trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
    }

    func validEvoraHubURL(_ value: String) -> String? {
        let normalized = value.trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard
            let url = URL(string: normalized),
            let scheme = url.scheme?.lowercased(),
            let host = url.host,
            !host.isEmpty,
            url.query == nil,
            url.fragment == nil,
            scheme == "https" || (scheme == "http" && ["127.0.0.1", "localhost"].contains(host.lowercased()))
        else {
            return nil
        }
        return normalized
    }

    func evoraEndpoint(_ path: String) -> URL? {
        let suffix = path.hasPrefix("/") ? path : "/\(path)"
        return URL(string: "\(evoraHubURL())\(suffix)")
    }

    func evoraRequest<T: Decodable>(
        path: String,
        method: String = "GET",
        body: [String: Any]? = nil,
        headers: [String: String] = [:],
        completion: @escaping (Result<T, Error>) -> Void
    ) {
        guard let token = evoraToken() else {
            completion(.failure(EvoraServiceError(message: "Nejdřív nastavte osobní token z Evora Smart Hubu.")))
            return
        }
        guard let url = evoraEndpoint(path) else {
            completion(.failure(EvoraServiceError(message: "Adresa Evora Smart Hubu není platná.")))
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        for (name, value) in headers {
            request.setValue(value, forHTTPHeaderField: name)
        }
        if let body {
            request.httpBody = try? JSONSerialization.data(withJSONObject: body)
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        evoraSession.dataTask(with: request) { data, response, error in
            if let error {
                completion(.failure(EvoraServiceError(message: "Evora Smart Hub není dostupný: \(error.localizedDescription)")))
                return
            }
            guard let http = response as? HTTPURLResponse else {
                completion(.failure(EvoraServiceError(message: "Evora Smart Hub nevrátil platnou odpověď.")))
                return
            }
            let payload = data ?? Data()
            guard (200..<300).contains(http.statusCode) else {
                let message = (try? JSONDecoder().decode(EvoraErrorResponse.self, from: payload).error)
                    ?? "Požadavek na Evora Smart Hub selhal (HTTP \(http.statusCode))."
                completion(.failure(EvoraServiceError(message: message)))
                return
            }
            do {
                completion(.success(try JSONDecoder().decode(T.self, from: payload)))
            } catch {
                completion(.failure(EvoraServiceError(message: "Evora Smart Hub vrátil nečitelná data.")))
            }
        }.resume()
    }

    func downloadEvoraPortalAttachment(
        _ attachment: EvoraPortalTicketAttachment,
        completion: @escaping (Result<URL, Error>) -> Void
    ) {
        guard attachment.canDownload else {
            completion(.failure(EvoraServiceError(message: "Portál poskytl pouze název této přílohy, ne bezpečný odkaz ke stažení.")))
            return
        }
        guard let token = evoraToken(),
              let url = evoraEndpoint("/api/integrations/worklog/v1/portal-tickets/attachments/download") else {
            completion(.failure(EvoraServiceError(message: "Připojení k Evora Smart Hubu není nastavené.")))
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/octet-stream", forHTTPHeaderField: "Accept")
        request.httpBody = try? JSONSerialization.data(withJSONObject: ["token": attachment.token])
        evoraSession.dataTask(with: request) { data, response, error in
            if let error {
                completion(.failure(EvoraServiceError(message: "Přílohu se nepodařilo načíst: \(error.localizedDescription)")))
                return
            }
            guard let http = response as? HTTPURLResponse else {
                completion(.failure(EvoraServiceError(message: "Hub nevrátil platnou odpověď přílohy.")))
                return
            }
            let payload = data ?? Data()
            guard (200..<300).contains(http.statusCode) else {
                let message = (try? JSONDecoder().decode(EvoraErrorResponse.self, from: payload).error)
                    ?? "Přílohu se nepodařilo načíst (HTTP \(http.statusCode))."
                completion(.failure(EvoraServiceError(message: message)))
                return
            }
            let safeName = attachment.name
                .replacingOccurrences(of: "[^\\p{L}\\p{N} ._()-]", with: "_", options: .regularExpression)
                .prefix(180)
            let directory = FileManager.default.temporaryDirectory
                .appendingPathComponent("WorkLogAI-Evora-Attachments", isDirectory: true)
                .appendingPathComponent(UUID().uuidString, isDirectory: true)
            do {
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
                let target = directory.appendingPathComponent(safeName.isEmpty ? "priloha" : String(safeName))
                try payload.write(to: target, options: .atomic)
                completion(.success(target))
            } catch {
                completion(.failure(EvoraServiceError(message: "Staženou přílohu se nepodařilo bezpečně uložit.")))
            }
        }.resume()
    }

    func evoraConnectionLabel(_ state: String) -> String {
        switch state {
        case "online": return "Online"
        case "no_access": return "Online · bez přístupu"
        case "unavailable", "error", "offline": return "Offline"
        default: return "Stav neověřen"
        }
    }

    func evoraRelativeCheckLabel(_ value: String?) -> String? {
        guard let value, let date = parseIntranetDate(value) else { return nil }
        let age = max(0, Date().timeIntervalSince(date))
        if age < 60 { return "kontrola právě" }
        if age < 3_600 { return "kontrola před \(max(1, Int(age / 60))) min" }
        if age < 86_400 { return "kontrola před \(max(1, Int(age / 3_600))) h" }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "cs_CZ")
        formatter.dateFormat = "d. M. HH:mm"
        return "kontrola \(formatter.string(from: date))"
    }

    func evoraHealthLabel(_ value: String?) -> String? {
        guard let value, !value.isEmpty else { return nil }
        switch value.lowercased() {
        case "ok", "good", "healthy": return "Health OK"
        case "warning": return "Health varování"
        case "critical", "error", "failed": return "Health kritický"
        default: return "Health \(value)"
        }
    }

    func evoraServerMatchesSearch(_ server: EvoraMiniServer, folder: String, query: String) -> Bool {
        let normalized = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.isEmpty else { return true }
        let haystack = "\(server.project) \(server.serial) \(server.type) \(folder)"
        return haystack.range(of: normalized, options: [.caseInsensitive, .diacriticInsensitive]) != nil
    }

    func menuSearchMatches(_ item: NSMenuItem, query: String) -> Bool {
        let title = item.attributedTitle?.string.isEmpty == false
            ? item.attributedTitle?.string ?? item.title
            : item.title
        let searchable = "\(title) \(item.toolTip ?? "")"
        return searchable.range(
            of: query,
            options: [.caseInsensitive, .diacriticInsensitive]
        ) != nil
    }

    @discardableResult
    func filterMenuTree(_ targetMenu: NSMenu, query: String, forceVisible: Bool = false) -> Bool {
        var hasVisibleResult = false
        for menuItem in targetMenu.items {
            if menuItem === mainMenuSearchItem || menuItem === mainMenuNoResultsItem {
                continue
            }
            let identifier = ObjectIdentifier(menuItem)
            if mainMenuOriginalHidden[identifier] == nil {
                mainMenuOriginalHidden[identifier] = menuItem.isHidden
            }
            let originallyHidden = mainMenuOriginalHidden[identifier] ?? false
            if originallyHidden || menuItem.isSeparatorItem {
                menuItem.isHidden = true
                continue
            }
            if menuItem.view != nil {
                menuItem.isHidden = !forceVisible
                hasVisibleResult = hasVisibleResult || forceVisible
                continue
            }

            let ownMatch = forceVisible || menuSearchMatches(menuItem, query: query)
            let childMatch = menuItem.submenu.map {
                filterMenuTree($0, query: query, forceVisible: ownMatch)
            } ?? false
            let visible = ownMatch || childMatch
            menuItem.isHidden = !visible
            hasVisibleResult = hasVisibleResult || visible
        }
        return hasVisibleResult
    }

    func restoreMainMenuVisibility(_ targetMenu: NSMenu) {
        for menuItem in targetMenu.items {
            if let hidden = mainMenuOriginalHidden[ObjectIdentifier(menuItem)] {
                menuItem.isHidden = hidden
            }
            if let submenu = menuItem.submenu {
                restoreMainMenuVisibility(submenu)
            }
        }
    }

    func applyMainMenuSearchFilter() {
        guard menu != nil else { return }
        let query = mainMenuSearchQuery.trimmingCharacters(in: .whitespacesAndNewlines)
        if query.isEmpty {
            restoreMainMenuVisibility(menu)
            mainMenuOriginalHidden.removeAll()
            mainMenuSearchItem?.isHidden = false
            mainMenuNoResultsItem?.isHidden = true
            return
        }
        let hasResults = filterMenuTree(menu, query: query)
        mainMenuSearchItem?.isHidden = false
        mainMenuNoResultsItem?.isHidden = hasResults
    }

    func scheduleMainMenuSearchFilter() {
        mainMenuSearchWorkItem?.cancel()
        mainMenuSearchRevision += 1
        let revision = mainMenuSearchRevision
        let queryIsEmpty = mainMenuSearchQuery
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .isEmpty
        let work = DispatchWorkItem { [weak self] in
            guard let self, revision == self.mainMenuSearchRevision else { return }
            if queryIsEmpty, self.evoraRebuildDeferred {
                self.rebuildEvoraMenu()
            }
            self.applyMainMenuSearchFilter()
        }
        mainMenuSearchWorkItem = work
        // Changing NSMenuItem visibility synchronously from AppKit's text
        // editor callback can re-enter menu layout and freeze menu tracking.
        // Coalescing keystrokes onto the next run-loop turn avoids that cycle.
        DispatchQueue.main.asyncAfter(deadline: .now() + (queryIsEmpty ? 0 : 0.075), execute: work)
    }

    func applyEvoraSearchFilter() {
        let query = evoraSearchQuery.trimmingCharacters(in: .whitespacesAndNewlines)
        if query.isEmpty {
            for folderEntry in evoraFolderMenuItems {
                folderEntry.item.isHidden = false
                applyMenuIcon(
                    to: folderEntry.item,
                    title: "\(folderEntry.folder)  (\(folderEntry.servers.count))",
                    symbol: "folder.fill",
                    color: folderEntry.color
                )
                folderEntry.servers.forEach { $0.item.isHidden = false }
            }
            evoraFlatSearchMenuItems.forEach { $0.item.isHidden = true }
            evoraNoResultsItem?.isHidden = true
            return
        }
        for folderEntry in evoraFolderMenuItems {
            folderEntry.item.isHidden = true
        }
        var visibleTotal = 0
        for entry in evoraFlatSearchMenuItems {
            let matches = evoraServerMatchesSearch(entry.server, folder: entry.folder, query: query)
            entry.item.isHidden = !matches
            if matches { visibleTotal += 1 }
        }
        evoraNoResultsItem?.isHidden = visibleTotal > 0
    }

    func controlTextDidChange(_ notification: Notification) {
        guard let field = notification.object as? NSSearchField else { return }
        if field === mainMenuSearchField {
            mainMenuSearchQuery = field.stringValue
            scheduleMainMenuSearchFilter()
        } else if field === evoraSearchField {
            evoraSearchQuery = field.stringValue
            applyEvoraSearchFilter()
        }
    }

    func evoraPortalTicketIsClosed(_ status: String) -> Bool {
        let normalized = status.lowercased()
        return normalized.contains("closed")
            || normalized.contains("resolved")
            || normalized.contains("solved")
            || normalized.contains("uzavřen")
    }

    func evoraPortalTicketStatus(_ status: String) -> String {
        let normalized = status.lowercased()
        if normalized == "open" || normalized == "opened" { return "Otevřený" }
        if evoraPortalTicketIsClosed(status) { return "Uzavřený" }
        if normalized.contains("await") || normalized.contains("waiting") || normalized.contains("pending") || normalized.contains("hold") || normalized.contains("ček") { return "Čeká" }
        return status.isEmpty ? "Neznámý" : status
    }

    func evoraPortalTicketColor(_ status: String) -> NSColor {
        let normalized = status.lowercased()
        if evoraPortalTicketIsClosed(status) { return .systemBlue }
        if normalized.contains("await") || normalized.contains("waiting") || normalized.contains("pending") || normalized.contains("hold") || normalized.contains("ček") {
            return .systemOrange
        }
        if normalized.contains("open") || normalized.contains("otevřen") || normalized.contains("new") {
            return .systemGreen
        }
        return .systemPurple
    }

    func evoraTicketsMenuItem() -> NSMenuItem {
        let parent = NSMenuItem(
            title: "LOXONE tickety  (\(evoraTickets.count))",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(
            to: parent,
            title: "LOXONE tickety  (\(evoraTickets.count))",
            symbol: "ticket"
        )
        let submenu = NSMenu(title: "LOXONE tickety")
        let ticketStatusColor: NSColor = evoraTicketsRefreshInFlight
            ? .systemOrange
            : evoraTicketsStatus.lowercased().contains("selhala") || evoraTicketsStatus.lowercased().contains("nepřipojeno")
            ? .systemRed
            : .labelColor
        let status = readOnlyItem(evoraTicketsStatus, symbol: "ticket", color: ticketStatusColor, weight: .medium)
        submenu.addItem(status)
        submenu.addItem(.separator())
        submenu.addItem(item("Nový ticket…", symbol: "plus.bubble", action: #selector(createEvoraPortalTicket)))
        submenu.addItem(item("Aktualizovat změny", symbol: "arrow.clockwise", action: #selector(refreshEvoraTickets)))
        submenu.addItem(linkItem("Otevřít centrum v Evora Smart Hubu", symbol: "rectangle.portrait.and.arrow.right", url: "\(evoraHubURL())?page=tickets"))
        submenu.addItem(.separator())
        if evoraTickets.isEmpty {
            let empty = readOnlyItem(
                evoraTicketsRefreshInFlight ? "Načítám tickety…" : "Žádné tickety nejsou dostupné.",
                symbol: evoraTicketsRefreshInFlight ? "arrow.clockwise" : "tray",
                color: evoraTicketsRefreshInFlight ? .systemOrange : .labelColor
            )
            submenu.addItem(empty)
        } else {
            for ticket in evoraTickets {
                let ticketItem = item(
                    "#\(ticket.ticketNumber) · \(ticket.subject) — \(evoraPortalTicketStatus(ticket.status))",
                    symbol: "bubble.left.and.bubble.right",
                    action: #selector(showEvoraPortalTicket(_:)),
                    color: evoraPortalTicketColor(ticket.status)
                )
                ticketItem.representedObject = ticket.id
                ticketItem.toolTip = "\(evoraPortalTicketStatus(ticket.status)) · \(ticket.contactName)"
                submenu.addItem(ticketItem)
            }
        }
        parent.submenu = submenu
        return parent
    }

    func addHomeAssistantMenu(to target: NSMenu) {
        let homeAssistant = NSMenuItem(
            title: "Home Assistant odkazy",
            action: nil,
            keyEquivalent: ""
        )
        let links = NSMenu(title: "Home Assistant odkazy")
        links.autoenablesItems = false
        links.addItem(linkItem("Herškovič", symbol: "person.crop.circle", url: "https://homeassistant-herskovic.skunk-atria.ts.net", color: .systemBlue))
        links.addItem(linkItem("Vágner", symbol: "person.crop.circle", url: "https://homeassistant-vagner.skunk-atria.ts.net", color: .systemTeal))
        links.addItem(linkItem("Evora", symbol: "building.2.fill", url: "https://homeassistant-work.skunk-atria.ts.net", color: .systemGreen))
        links.addItem(linkItem("Domov", symbol: "house.fill", url: "https://homeassistant.skunk-atria.ts.net", color: .systemOrange))
        homeAssistant.submenu = links
        applyMenuIcon(to: homeAssistant, title: "Home Assistant odkazy", symbol: "house.fill", color: .systemCyan)
        target.addItem(homeAssistant)
    }

    func evoraConnectionColor(_ state: String) -> NSColor {
        let normalized = state.lowercased()
        if normalized == "online" || normalized == "no_access" { return .systemGreen }
        if normalized.contains("pause") || normalized.contains("wait") { return .systemOrange }
        if normalized == "unavailable" || normalized == "error" || normalized == "offline" { return .systemRed }
        return .systemPurple
    }

    func loadEvoraDeviceImage(path: String, into imageView: NSImageView) {
        if let cached = evoraDeviceImageCache[path] {
            imageView.image = cached
            return
        }
        guard !evoraDeviceImageRequests.contains(path), let url = evoraEndpoint(path) else { return }
        evoraDeviceImageRequests.insert(path)
        evoraSession.dataTask(with: url) { [weak self, weak imageView] data, response, _ in
            guard let self else { return }
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            let image = status >= 200 && status < 300
                ? data.flatMap(NSImage.init(data:))
                : nil
            DispatchQueue.main.async {
                self.evoraDeviceImageRequests.remove(path)
                guard let image else { return }
                image.isTemplate = false
                self.evoraDeviceImageCache[path] = image
                imageView?.image = image
                self.rebuildEvoraMenu()
            }
        }.resume()
    }

    func evoraMiniserverSummaryItem(_ server: EvoraMiniServer) -> NSMenuItem {
        let item = NSMenuItem(title: server.project, action: nil, keyEquivalent: "")
        let width: CGFloat = 390
        let height: CGFloat = 104
        let view = NSView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        let connectionColor = evoraConnectionColor(server.connectionState)

        let imageView = NSImageView(frame: NSRect(x: 12, y: 28, width: 66, height: 48))
        imageView.image = sf("server.rack", color: connectionColor)
        imageView.imageScaling = .scaleProportionallyUpOrDown
        view.addSubview(imageView)
        if let path = server.deviceImageUrl, !path.isEmpty {
            loadEvoraDeviceImage(path: path, into: imageView)
        }

        let title = NSTextField(labelWithString: server.project)
        title.frame = NSRect(x: 90, y: 78, width: 286, height: 17)
        title.font = NSFont.systemFont(ofSize: 12, weight: .semibold)
        title.textColor = .labelColor
        title.lineBreakMode = .byTruncatingTail
        view.addSubview(title)

        let identity = NSTextField(labelWithString: "\(server.serial) · \(server.type)")
        identity.frame = NSRect(x: 90, y: 60, width: 286, height: 16)
        identity.font = NSFont.systemFont(ofSize: 9.5, weight: .regular)
        identity.textColor = .secondaryLabelColor
        identity.lineBreakMode = .byTruncatingTail
        view.addSubview(identity)

        let status = NSTextField(labelWithString: "\(evoraConnectionLabel(server.connectionState)) · FW \(server.currentFirmware ?? "neznámý")")
        status.frame = NSRect(x: 90, y: 43, width: 286, height: 16)
        status.font = NSFont.monospacedDigitSystemFont(ofSize: 9.5, weight: .semibold)
        status.textColor = connectionColor
        status.lineBreakMode = .byTruncatingTail
        view.addSubview(status)

        let deviceText: String
        let deviceColor: NSColor
        if let total = server.elementsTotal, let online = server.elementsOnline, total > 0 {
            let offline = max(0, server.offlineDevices ?? (total - online))
            deviceText = offline > 0
                ? "Prvky \(online)/\(total) · \(offline) offline"
                : "Prvky \(online)/\(total) · vše online"
            deviceColor = offline > 0 ? .systemRed : .systemGreen
        } else {
            deviceText = "Prvky · zatím neověřeno"
            deviceColor = .secondaryLabelColor
        }
        let devices = NSTextField(labelWithString: deviceText)
        devices.frame = NSRect(x: 90, y: 25, width: 286, height: 16)
        devices.font = NSFont.monospacedDigitSystemFont(ofSize: 9.5, weight: .semibold)
        devices.textColor = deviceColor
        devices.lineBreakMode = .byTruncatingTail
        view.addSubview(devices)

        var diagnostics = [String]()
        if let health = evoraHealthLabel(server.healthVerdict) { diagnostics.append(health) }
        if let check = evoraRelativeCheckLabel(server.lastCheckedAt) { diagnostics.append(check) }
        if let latency = server.lastLatencyMs { diagnostics.append("\(Int(latency.rounded())) ms") }
        if let failures = server.consecutiveFailures, failures > 0 { diagnostics.append("\(failures)× chyba") }
        let diagnosticText = diagnostics.isEmpty ? "Diagnostika zatím neověřena" : diagnostics.joined(separator: " · ")
        let healthState = server.healthVerdict?.lowercased() ?? ""
        let diagnosticColor: NSColor = healthState == "critical" || (server.consecutiveFailures ?? 0) >= 3
            ? .systemRed
            : healthState == "warning" || server.dataState == "stale" || (server.consecutiveFailures ?? 0) > 0
            ? .systemOrange
            : .secondaryLabelColor
        let diagnostic = NSTextField(labelWithString: diagnosticText)
        diagnostic.frame = NSRect(x: 90, y: 7, width: 286, height: 16)
        diagnostic.font = NSFont.monospacedDigitSystemFont(ofSize: 9, weight: .regular)
        diagnostic.textColor = diagnosticColor
        diagnostic.lineBreakMode = .byTruncatingTail
        diagnostic.toolTip = diagnosticText
        view.addSubview(diagnostic)

        item.view = view
        item.isEnabled = false
        return item
    }

    func evoraMiniserverMenuItem(_ server: EvoraMiniServer) -> NSMenuItem {
        let connectionColor = evoraConnectionColor(server.connectionState)
        let serverItem = NSMenuItem(
            title: "\(evoraConnectionLabel(server.connectionState)) · \(server.project)",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(
            to: serverItem,
            title: "\(evoraConnectionLabel(server.connectionState)) · \(server.project)",
            symbol: "server.rack",
            color: connectionColor
        )
        let serverMenu = NSMenu(title: server.project)
        serverMenu.addItem(evoraMiniserverSummaryItem(server))
        serverMenu.addItem(.separator())

        let appAction = item(
            "Otevřít v Loxone App",
            symbol: "iphone",
            action: #selector(runEvoraAction(_:))
        )
        appAction.representedObject = [
            "serial": server.serial,
            "action": "loxone_app"
        ] as NSDictionary
        appAction.isEnabled = server.loxoneAppAvailable
        serverMenu.addItem(appAction)

        let configTitle: String
        if evoraLauncherAgent?.updateRequired == true {
            configTitle = "Otevřít v Loxone Config · aktualizujte Launcher"
        } else if server.loxoneConfigAvailable {
            configTitle = "Otevřít v Loxone Config"
        } else {
            configTitle = "Otevřít v Loxone Config · Launcher offline"
        }
        let configAction = item(
            configTitle,
            symbol: "doc.badge.gearshape",
            action: #selector(runEvoraAction(_:))
        )
        configAction.representedObject = [
            "serial": server.serial,
            "action": "loxone_config"
        ] as NSDictionary
        configAction.isEnabled = server.loxoneConfigAvailable
        serverMenu.addItem(configAction)

        if let download = server.configDownloadUrl {
            serverMenu.addItem(.separator())
            serverMenu.addItem(
                linkItem(
                    "Stáhnout Loxone Config \(server.configVersion ?? "")",
                    symbol: "arrow.down.circle",
                    url: download
                )
            )
        }
        serverItem.submenu = serverMenu
        return serverItem
    }

    func evoraCameraPreviewItem(_ camera: EvoraCamera) -> NSMenuItem {
        let item = NSMenuItem()
        let view = NSView(frame: NSRect(x: 0, y: 0, width: 356, height: 226))

        let title = NSTextField(labelWithString: camera.name)
        title.frame = NSRect(x: 10, y: 202, width: 218, height: 18)
        title.font = NSFont.systemFont(ofSize: 12, weight: .semibold)
        title.lineBreakMode = .byTruncatingTail
        view.addSubview(title)

        let state = NSTextField(labelWithString: camera.online ? "MILESIGHT · ŽIVĚ" : "OFFLINE")
        state.frame = NSRect(x: 238, y: 202, width: 108, height: 18)
        state.alignment = .right
        state.font = NSFont.monospacedSystemFont(ofSize: 9, weight: .bold)
        state.textColor = camera.online ? .systemGreen : .systemRed
        view.addSubview(state)

        let playerView = EvoraCameraPlayerView(frame: NSRect(x: 10, y: 8, width: 336, height: 189))
        view.addSubview(playerView)

        let loading = NSTextField(labelWithString: camera.online ? "Připojuji úsporné plynulé video…" : "Kamera je offline")
        loading.frame = NSRect(x: 28, y: 91, width: 300, height: 20)
        loading.alignment = .center
        loading.textColor = .secondaryLabelColor
        loading.font = NSFont.systemFont(ofSize: 11, weight: .medium)
        view.addSubview(loading)

        evoraCameraPreviewViews[camera.id] = playerView
        evoraCameraPreviewLabels[camera.id] = loading
        item.view = view
        item.isEnabled = false
        return item
    }

    func evoraCameraMenuColor() -> NSColor {
        .systemPurple
    }

    func evoraCamerasMenuItem() -> NSMenuItem {
        let parent = NSMenuItem(
            title: "Milesight  (\(evoraCameras.count))",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(to: parent, title: "Milesight  (\(evoraCameras.count))", image: milesightMenuLogo)
        let camerasMenu = NSMenu(title: "Milesight")
        camerasMenu.autoenablesItems = false
        if evoraCameras.isEmpty {
            camerasMenu.addItem(readOnlyItem(
                "NVR zatím nemá načtené kamery",
                symbol: "video.slash.fill",
                color: evoraCameraMenuColor()
            ))
            camerasMenu.addItem(.separator())
            camerasMenu.addItem(linkItem(
                "Připojit NVR v Evora Smart Hubu",
                symbol: "rectangle.portrait.and.arrow.right",
                url: "\(evoraHubURL())?page=cameras"
            ))
        }
        for camera in evoraCameras.sorted(by: { $0.id < $1.id }) {
            let cameraItem = NSMenuItem(
                title: "\(camera.online ? "Online" : "Offline") · \(camera.name)",
                action: nil,
                keyEquivalent: ""
            )
            applyMenuIcon(
                to: cameraItem,
                title: "\(camera.online ? "Online" : "Offline") · \(camera.name)",
                symbol: "video.fill",
                color: camera.online ? .systemGreen : .systemRed
            )
            let previewMenu = NSMenu(title: "Kamera · \(camera.name)")
            previewMenu.autoenablesItems = false
            previewMenu.delegate = self
            previewMenu.addItem(evoraCameraPreviewItem(camera))
            previewMenu.addItem(.separator())
            previewMenu.addItem(linkItem(
                "Otevřít hlavní stream v Hubu",
                symbol: "rectangle.portrait.and.arrow.right",
                url: "\(evoraHubURL())?page=cameras&camera=\(camera.id)"
            ))
            cameraItem.submenu = previewMenu
            camerasMenu.addItem(cameraItem)
            evoraCameraMenus[ObjectIdentifier(previewMenu)] = camera.id
        }
        parent.submenu = camerasMenu
        return parent
    }

    func startEvoraCameraPreviewStream(_ cameraId: Int) {
        stopEvoraCameraPreviewStream(cameraId)
        guard let token = evoraToken(),
              let url = evoraEndpoint("/api/integrations/worklog/v1/cameras/\(cameraId)/hls/index.m3u8?quality=preview"),
              let playerView = evoraCameraPreviewViews[cameraId]
        else { return }
        evoraCameraPreviewLabels[cameraId]?.stringValue = "Připojuji úsporné plynulé video…"
        evoraCameraPreviewLabels[cameraId]?.isHidden = false
        let stream = EvoraCameraHLSPlayer(
            playerView: playerView,
            onReady: { [weak self] in
                guard let self else { return }
                self.evoraCameraPreviewLabels[cameraId]?.isHidden = true
            },
            onFailure: { [weak self] message in
                guard let self else { return }
                self.evoraCameraPreviewLabels[cameraId]?.stringValue = message
                self.evoraCameraPreviewLabels[cameraId]?.isHidden = false
            }
        )
        evoraCameraPreviewStreams[cameraId] = stream
        stream.start(url: url, token: token)
    }

    func stopEvoraCameraPreviewStream(_ cameraId: Int) {
        evoraCameraPreviewStreams.removeValue(forKey: cameraId)?.stop()
    }

    func stopAllEvoraCameraPreviewStreams() {
        let streams = Array(evoraCameraPreviewStreams.values)
        evoraCameraPreviewStreams.removeAll()
        streams.forEach { $0.stop() }
    }

    func seedEvoraMenuForSelfTest(servers: [EvoraMiniServer], cameras: [EvoraCamera] = [], status: String) {
        guard CommandLine.arguments.dropFirst().first == "--self-test-menu-structure" else { return }
        evoraServers = servers
        evoraCameras = cameras
        evoraStatus = status
    }

    func seedEvoraHubVersionForSelfTest(_ version: String) -> String {
        guard CommandLine.arguments.dropFirst().first == "--self-test-menu-structure" else { return "" }
        evoraHubVersion = version
        updateBrandedHeaderSubtitle()
        return brandedHeaderSubtitleField?.stringValue ?? ""
    }

    func seedEvoraSearchForSelfTest(_ query: String) -> (foldersVisible: Int, serverTitles: [String]) {
        guard CommandLine.arguments.dropFirst().first == "--self-test-menu-structure" else { return (0, []) }
        evoraSearchQuery = query
        evoraSearchField?.stringValue = query
        applyEvoraSearchFilter()
        let foldersVisible = evoraFolderMenuItems.filter { !$0.item.isHidden }.count
        let serverTitles = evoraFlatSearchMenuItems
            .filter { !$0.item.isHidden }
            .map { entry in
                let attributed = entry.item.attributedTitle?.string ?? ""
                return attributed.isEmpty ? entry.item.title : attributed
            }
        return (foldersVisible, serverTitles)
    }

    func rebuildEvoraMenu() {
        guard evoraMenu != nil else { return }
        if !mainMenuSearchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            evoraRebuildDeferred = true
            return
        }
        evoraRebuildDeferred = false
        stopAllEvoraCameraPreviewStreams()
        defer {
            if !mainMenuSearchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                applyMainMenuSearchFilter()
            }
        }
        evoraMenu.removeAllItems()
        evoraFolderMenuItems.removeAll()
        evoraFlatSearchMenuItems.removeAll()
        evoraCameraMenus.removeAll()
        evoraCameraPreviewViews.removeAll()
        evoraCameraPreviewLabels.removeAll()
        evoraNoResultsItem = nil

        addHomeAssistantMenu(to: evoraMenu)
        evoraMenu.addItem(.separator())
        evoraMenu.addItem(evoraCamerasMenuItem())
        evoraMenu.addItem(.separator())

        let normalizedEvoraStatus = evoraStatus.lowercased()
        let evoraStatusColor: NSColor = normalizedEvoraStatus.contains("chyba")
            || normalizedEvoraStatus.contains("nepřipojeno")
            || normalizedEvoraStatus.contains("offline")
            ? .systemRed
            : normalizedEvoraStatus.contains("načítám") || normalizedEvoraStatus.contains("aktualiz")
            ? .systemOrange
            : .systemGreen
        evoraStatusItem = item(
            evoraStatus,
            symbol: "network",
            action: #selector(refreshEvoraMenu),
            color: evoraStatusColor
        )
        evoraStatusItem.toolTip = "Kliknutím znovu načtete stav Evora Smart Hubu."
        evoraMenu.addItem(evoraStatusItem)
        evoraMenu.addItem(.separator())
        let searchItem = NSMenuItem()
        let searchContainer = NSView(frame: NSRect(x: 0, y: 0, width: 310, height: 38))
        let searchField = MenuSearchField(frame: NSRect(x: 10, y: 5, width: 290, height: 28))
        searchField.placeholderString = "Hledat Miniserver…"
        searchField.stringValue = evoraSearchQuery
        searchField.sendsSearchStringImmediately = true
        searchField.delegate = self
        searchContainer.addSubview(searchField)
        searchItem.view = searchContainer
        evoraSearchField = searchField
        evoraMenu.addItem(searchItem)
        evoraMenu.addItem(.separator())
        evoraMenu.addItem(
            linkItem(
                "Otevřít Evora Smart Hub",
                symbol: "network",
                url: evoraHubURL()
            )
        )
        evoraMenu.addItem(
            item(
                "Obnovit Miniservery",
                symbol: "arrow.clockwise",
                action: #selector(refreshEvoraMenu)
            )
        )
        evoraMenu.addItem(
            item(
                "Nastavit připojení…",
                symbol: "key",
                action: #selector(configureEvoraConnection)
            )
        )
        evoraMenu.addItem(.separator())
        evoraMenu.addItem(evoraTicketsMenuItem())

        guard !evoraServers.isEmpty else {
            evoraMenu.addItem(.separator())
            let empty = readOnlyItem(
                !evoraCredentialsLoaded
                    ? "Načítám zabezpečené připojení…"
                    : evoraToken() == nil
                    ? "Vložte osobní token z Nastavení Hubu."
                    : "Žádné Miniservery nejsou dostupné.",
                symbol: evoraToken() == nil ? "key" : "server.rack",
                color: evoraToken() == nil ? .systemOrange : .labelColor
            )
            evoraMenu.addItem(empty)
            return
        }

        evoraMenu.addItem(.separator())
        let noResultsItem = readOnlyItem(
            "Žádný Miniserver neodpovídá hledání",
            symbol: "magnifyingglass",
            color: .systemOrange
        )
        noResultsItem.isHidden = true
        evoraNoResultsItem = noResultsItem
        evoraMenu.addItem(noResultsItem)
        let grouped = Dictionary(grouping: evoraServers, by: { $0.folderName })
        for folder in grouped.keys.sorted(by: { $0.localizedCaseInsensitiveCompare($1) == .orderedAscending }) {
            let servers = (grouped[folder] ?? []).sorted {
                $0.project.localizedCaseInsensitiveCompare($1.project) == .orderedAscending
            }
            let folderColor = menuColor(hex: servers.first?.folderColor, fallback: .systemGreen)
            let folderItem = NSMenuItem(
                title: "\(folder)  (\(servers.count))",
                action: nil,
                keyEquivalent: ""
            )
            applyMenuIcon(to: folderItem, title: "\(folder)  (\(servers.count))", symbol: "folder.fill", color: folderColor)
            let folderMenu = NSMenu(title: folder)
            var folderServers: [(item: NSMenuItem, server: EvoraMiniServer)] = []
            for server in servers {
                let serverItem = evoraMiniserverMenuItem(server)
                folderMenu.addItem(serverItem)
                folderServers.append((item: serverItem, server: server))
            }
            folderItem.submenu = folderMenu
            evoraMenu.addItem(folderItem)
            evoraFolderMenuItems.append((item: folderItem, folder: folder, color: folderColor, servers: folderServers))
        }
        for server in evoraServers.sorted(by: {
            $0.project.localizedCaseInsensitiveCompare($1.project) == .orderedAscending
        }) {
            let flatItem = evoraMiniserverMenuItem(server)
            flatItem.isHidden = true
            flatItem.toolTip = server.folderName
            evoraMenu.addItem(flatItem)
            evoraFlatSearchMenuItems.append((item: flatItem, folder: server.folderName, server: server))
        }
        applyEvoraSearchFilter()
    }

    @objc func refreshEvoraMenu() {
        guard !evoraRefreshInFlight else { return }
        guard evoraCredentialsLoaded else {
            evoraStatus = "Evora Smart Hub: načítám připojení…"
            rebuildEvoraMenu()
            return
        }
        guard evoraToken() != nil else {
            evoraServers = []
            evoraCameras = []
            evoraLauncherAgent = nil
            evoraHubVersion = nil
            updateBrandedHeaderSubtitle()
            evoraStatus = "Evora Smart Hub: nepřipojeno"
            rebuildEvoraMenu()
            return
        }
        evoraRefreshInFlight = true
        evoraStatus = "Evora Smart Hub: načítám…"
        rebuildEvoraMenu()
        loadEvoraTickets(forcePortalRefresh: false)
        evoraRequest(
            path: "/api/integrations/worklog/v1/miniservers"
        ) { [weak self] (result: Result<EvoraFleetResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                self.evoraRefreshInFlight = false
                self.evoraLastRefresh = Date()
                switch result {
                case .success(let response):
                    self.evoraServers = response.items
                    self.evoraCameras = response.cameras ?? []
                    self.evoraLauncherAgent = response.launcherAgent
                    self.evoraHubVersion = response.appVersion
                    self.updateBrandedHeaderSubtitle()
                    let launcher: String
                    if response.launcherAgent?.updateRequired == true {
                        launcher = "Windows Launcher vyžaduje aktualizaci"
                    } else if response.launcherAgent?.available == true {
                        launcher = response.launcherAgent?.updateAvailable == true
                            ? "Windows Launcher online · aktualizace dostupná"
                            : "Windows Launcher online"
                    } else {
                        launcher = "Windows Launcher offline"
                    }
                    self.evoraStatus = "\(response.items.count) Miniserverů · \(launcher)"
                case .failure(let error):
                    self.evoraServers = []
                    self.evoraCameras = []
                    self.evoraLauncherAgent = nil
                    self.evoraHubVersion = nil
                    self.updateBrandedHeaderSubtitle()
                    self.evoraStatus = "Chyba: \(error.localizedDescription)"
                }
                self.rebuildEvoraMenu()
            }
        }
    }

    @objc func refreshEvoraTickets() {
        loadEvoraTickets(forcePortalRefresh: true)
    }

    func loadEvoraTickets(forcePortalRefresh: Bool) {
        guard !evoraTicketsRefreshInFlight else { return }
        guard evoraToken() != nil else {
            evoraTickets = []
            evoraTicketsStatus = "Tickety: nepřipojeno"
            rebuildEvoraMenu()
            return
        }
        evoraTicketsRefreshInFlight = true
        evoraTicketsStatus = "Tickety: načítám…"
        rebuildEvoraMenu()
        evoraRequest(
            path: "/api/integrations/worklog/v1/portal-tickets\(forcePortalRefresh ? "?refresh=1" : "")"
        ) { [weak self] (result: Result<EvoraPortalTicketListResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                self.evoraTicketsRefreshInFlight = false
                switch result {
                case .success(let response):
                    self.evoraTickets = response.items
                    let open = response.items.filter { !self.evoraPortalTicketIsClosed($0.status) }.count
                    self.evoraTicketsStatus = "\(response.items.count) ticketů · \(open) otevřených"
                case .failure(let error):
                    self.evoraTicketsStatus = self.evoraTickets.isEmpty
                        ? "Tickety: \(error.localizedDescription)"
                        : "\(self.evoraTickets.count) ticketů · aktualizace selhala"
                }
                self.rebuildEvoraMenu()
            }
        }
    }

    func menuWillOpen(_ menu: NSMenu) {
        if menu === self.menu {
            applyMainMenuSearchFilter()
        } else if let cameraId = evoraCameraMenus[ObjectIdentifier(menu)] {
            startEvoraCameraPreviewStream(cameraId)
        } else if menu === evoraMenu {
            if Date().timeIntervalSince(evoraLastRefresh) > 30 {
                refreshEvoraMenu()
            } else if evoraTickets.isEmpty {
                loadEvoraTickets(forcePortalRefresh: false)
            }
        } else if menu === intranetMenu {
            if Date().timeIntervalSince1970 - intranetSnapshot.fetchedAt > 60 {
                refreshIntranet(forceAll: false)
            }
        }
    }

    func menuDidClose(_ menu: NSMenu) {
        if let cameraId = evoraCameraMenus[ObjectIdentifier(menu)] {
            stopEvoraCameraPreviewStream(cameraId)
        }
    }

    // MARK: - Icons

    func sf(_ name: String, color: NSColor? = nil) -> NSImage? {
        let baseConfig = NSImage.SymbolConfiguration(
            pointSize: 13,
            weight: .medium
        )
        let config = color.map {
            baseConfig.applying(NSImage.SymbolConfiguration(paletteColors: [$0]))
        } ?? baseConfig

        let img = NSImage(
            systemSymbolName: name,
            accessibilityDescription: nil
        )?.withSymbolConfiguration(config)

        img?.isTemplate = color == nil

        return img
    }

    func applyMenuIcon(
        to item: NSMenuItem,
        title: String,
        image: NSImage?,
        textColor: NSColor? = nil
    ) {
        item.title = title
        guard let image else { return }

        let icon = (image.copy() as? NSImage) ?? image
        icon.size = NSSize(width: 16, height: 16)

        let attachment = NSTextAttachment()
        attachment.image = icon
        attachment.bounds = NSRect(x: 0, y: -1.5, width: 16, height: 16)

        let decorated = NSMutableAttributedString(
            attributedString: NSAttributedString(attachment: attachment)
        )
        decorated.append(NSAttributedString(string: "  "))
        var attributes: [NSAttributedString.Key: Any] = [.font: NSFont.menuFont(ofSize: 0)]
        if let textColor { attributes[.foregroundColor] = textColor }
        decorated.append(NSAttributedString(string: title, attributes: attributes))

        // Some macOS versions suppress NSMenuItem.image in status-bar menus.
        // Keeping the SF Symbol in the title makes the icon deterministic while
        // preserving native highlighting, keyboard navigation and submenus.
        item.image = nil
        item.attributedTitle = decorated
    }

    func applyMenuIcon(
        to item: NSMenuItem,
        title: String,
        symbol: String?,
        color: NSColor? = nil
    ) {
        let resolvedColor = color ?? semanticMenuColor(for: symbol)
        applyMenuIcon(to: item, title: title, image: symbol.flatMap { sf($0, color: resolvedColor) })
    }

    func evoraSmartHubIcon(size: NSSize) -> NSImage {
        let image = NSImage(size: size)
        image.lockFocus()
        let clip = NSBezierPath(
            roundedRect: NSRect(origin: .zero, size: size),
            xRadius: size.width * 0.22,
            yRadius: size.height * 0.22
        )
        clip.addClip()
        evoraSmartHubLogo.draw(
            in: NSRect(origin: .zero, size: size),
            from: .zero,
            operation: .sourceOver,
            fraction: 1,
            respectFlipped: true,
            hints: [.interpolation: NSImageInterpolation.high]
        )
        image.unlockFocus()
        image.isTemplate = false
        return image
    }

    func intranetMenuLogo(size: NSSize) -> NSImage {
        let image = NSImage(size: size)
        image.lockFocus()
        NSColor(calibratedRed: 0.43, green: 0.76, blue: 0.12, alpha: 1).setFill()
        NSBezierPath(
            roundedRect: NSRect(origin: .zero, size: size),
            xRadius: size.width * 0.22,
            yRadius: size.height * 0.22
        ).fill()
        let text = "e" as NSString
        let font = NSFont.systemFont(ofSize: size.height * 0.72, weight: .bold)
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: NSColor.white
        ]
        let textSize = text.size(withAttributes: attributes)
        text.draw(
            at: NSPoint(
                x: (size.width - textSize.width) / 2,
                y: (size.height - textSize.height) / 2 + size.height * 0.03
            ),
            withAttributes: attributes
        )
        image.unlockFocus()
        image.isTemplate = false
        return image
    }

    func configureStatusButton(_ button: NSStatusBarButton) {
        button.image = evoraSmartHubIcon(size: NSSize(width: 18, height: 18))
        button.imagePosition = button.title.isEmpty ? .imageOnly : .imageLeading
        button.imageScaling = .scaleProportionallyDown
    }

    func updateStatusButtonAnimation() {
        guard let button = statusItem.button else { return }
        let isSynchronizing = intranetRefreshInFlight
            || evoraRefreshInFlight
            || evoraTicketsRefreshInFlight
        guard isSynchronizing else {
            statusPulseDimmed = false
            if button.alphaValue != 1 {
                NSAnimationContext.runAnimationGroup { context in
                    context.duration = 0.2
                    button.animator().alphaValue = 1
                }
            }
            return
        }

        statusPulseDimmed.toggle()
        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.42
            context.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
            button.animator().alphaValue = statusPulseDimmed ? 0.58 : 1
        }
    }

    func brandedHeaderItem() -> NSMenuItem {
        let item = NSMenuItem()
        let container = NSView(frame: NSRect(x: 0, y: 0, width: 320, height: 60))

        let icon = NSImageView(frame: NSRect(x: 14, y: 10, width: 40, height: 40))
        icon.image = evoraSmartHubIcon(size: NSSize(width: 40, height: 40))
        icon.imageScaling = .scaleProportionallyUpOrDown
        container.addSubview(icon)

        let title = NSTextField(labelWithString: "Evora Smart Menu")
        title.frame = NSRect(x: 66, y: 29, width: 238, height: 22)
        title.font = NSFont.systemFont(ofSize: 15, weight: .semibold)
        title.textColor = .labelColor
        container.addSubview(title)

        let hubVersion = evoraHubVersion.map { "Hub \($0)" } ?? "Hub nepřipojen"
        let subtitle = NSTextField(labelWithString: "Menu \(evoraMenuVersion) · \(hubVersion)")
        subtitle.frame = NSRect(x: 66, y: 10, width: 238, height: 17)
        subtitle.font = NSFont.systemFont(ofSize: 10.5, weight: .regular)
        subtitle.textColor = .secondaryLabelColor
        container.addSubview(subtitle)
        brandedHeaderSubtitleField = subtitle

        item.view = container
        item.isEnabled = false
        return item
    }

    func updateBrandedHeaderSubtitle() {
        let hubVersion = evoraHubVersion.map { "Hub \($0)" } ?? "Hub nepřipojen"
        brandedHeaderSubtitleField?.stringValue = "Menu \(evoraMenuVersion) · \(hubVersion)"
    }

    func intranetStatusSummaryItem() -> NSMenuItem {
        let item = NSMenuItem(title: "Intranet", action: nil, keyEquivalent: "")
        let width: CGFloat = 320
        let height: CGFloat = 54
        let container = NSView(frame: NSRect(x: 0, y: 0, width: width, height: height))

        let icon = NSImageView(frame: NSRect(x: 13, y: 11, width: 32, height: 32))
        icon.image = intranetMenuLogo(size: NSSize(width: 32, height: 32))
        icon.imageScaling = .scaleProportionallyUpOrDown
        container.addSubview(icon)

        let title = NSTextField(labelWithString: "Intranet")
        title.frame = NSRect(x: 56, y: 28, width: 250, height: 18)
        title.font = NSFont.systemFont(ofSize: 12, weight: .semibold)
        title.textColor = .labelColor
        title.lineBreakMode = .byTruncatingTail
        container.addSubview(title)

        let detail = NSTextField(labelWithString: "Načítám stav…")
        detail.frame = NSRect(x: 56, y: 10, width: 250, height: 16)
        detail.font = NSFont.monospacedDigitSystemFont(ofSize: 10, weight: .medium)
        detail.textColor = .systemBlue
        detail.lineBreakMode = .byTruncatingTail
        container.addSubview(detail)

        shiftStatusTitleField = title
        shiftStatusDetailField = detail
        item.view = container
        item.isEnabled = false
        return item
    }

    func loxoneLikeIcon() -> NSImage {
        let size = NSSize(
            width: 18,
            height: 18
        )

        let image = NSImage(size: size)

        image.lockFocus()

        let outer = NSBezierPath()
        outer.lineWidth = 1.6

        outer.move(
            to: NSPoint(x: 9, y: 1.6)
        )

        outer.line(
            to: NSPoint(x: 15.4, y: 5.1)
        )

        outer.line(
            to: NSPoint(x: 15.4, y: 12.9)
        )

        outer.line(
            to: NSPoint(x: 9, y: 16.4)
        )

        outer.line(
            to: NSPoint(x: 2.6, y: 12.9)
        )

        outer.line(
            to: NSPoint(x: 2.6, y: 5.1)
        )

        outer.close()

        NSColor.labelColor.setStroke()
        outer.stroke()

        let inner = NSBezierPath()
        inner.lineWidth = 1.7

        inner.move(
            to: NSPoint(x: 6.2, y: 5.0)
        )

        inner.line(
            to: NSPoint(x: 6.2, y: 12.8)
        )

        inner.line(
            to: NSPoint(x: 11.8, y: 12.8)
        )

        inner.stroke()

        image.unlockFocus()

        image.isTemplate = true

        return image
    }

    // MARK: - Menu items

    func semanticMenuColor(for symbol: String?) -> NSColor {
        guard let symbol else { return .systemTeal }
        let value = symbol.lowercased()
        if value.contains("stop") || value.contains("xmark") || value.contains("trash") || value.contains("power") {
            return .systemRed
        }
        if value.contains("pause") || value.contains("car") || value.contains("wrench") || value.contains("exclamation") {
            return .systemOrange
        }
        if value.contains("play") || value.contains("check") || value.contains("calendar") || value.contains("clock.badge") {
            return .systemGreen
        }
        if value.contains("gear") || value.contains("sparkles") || value.contains("key") {
            return .systemPurple
        }
        if value.contains("phone") || value.contains("person") || value.contains("iphone") || value.contains("bubble") || value.contains("ticket") {
            return .systemTeal
        }
        if value.contains("arrow.clockwise") || value.contains("arrow.down") || value.contains("doc") || value.contains("table") || value.contains("square.and.pencil") {
            return .systemBlue
        }
        if value.contains("house") || value.contains("building") || value.contains("network") || value.contains("globe") || value.contains("link") {
            return .systemCyan
        }
        return .systemIndigo
    }

    func menuColor(hex: String?, fallback: NSColor = .systemGreen) -> NSColor {
        guard let raw = hex?.trimmingCharacters(in: .whitespacesAndNewlines) else { return fallback }
        let normalized = raw.hasPrefix("#") ? String(raw.dropFirst()) : raw
        guard normalized.count == 6, let value = Int(normalized, radix: 16) else { return fallback }
        return NSColor(
            srgbRed: CGFloat((value >> 16) & 0xff) / 255,
            green: CGFloat((value >> 8) & 0xff) / 255,
            blue: CGFloat(value & 0xff) / 255,
            alpha: 1
        )
    }

    func item(
        _ title: String,
        symbol: String?,
        action: Selector,
        color: NSColor? = nil
    ) -> NSMenuItem {

        let item = NSMenuItem(
            title: title,
            action: action,
            keyEquivalent: ""
        )

        item.target = self
        applyMenuIcon(to: item, title: title, symbol: symbol, color: color ?? semanticMenuColor(for: symbol))

        return item
    }

    func linkItem(
        _ title: String,
        symbol: String?,
        url: String,
        color: NSColor? = nil
    ) -> NSMenuItem {

        let item = NSMenuItem(
            title: title,
            action: #selector(openURL(_:)),
            keyEquivalent: ""
        )

        item.target = self
        item.representedObject = url
        applyMenuIcon(to: item, title: title, symbol: symbol, color: color ?? semanticMenuColor(for: symbol))

        return item
    }

    func readOnlyItem(
        _ title: String,
        symbol: String? = nil,
        color: NSColor = .labelColor,
        weight: NSFont.Weight = .regular
    ) -> NSMenuItem {
        let menuItem = NSMenuItem()
        let width: CGFloat = 390
        let height: CGFloat = 25
        let view = NSView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        var textX: CGFloat = 13

        if let symbol, let image = sf(symbol, color: color) {
            let imageView = NSImageView(frame: NSRect(x: 13, y: 4, width: 17, height: 17))
            imageView.image = image
            imageView.contentTintColor = color
            view.addSubview(imageView)
            textX = 39
        }

        let text = NSTextField(labelWithString: title)
        text.frame = NSRect(x: textX, y: 4, width: width - textX - 12, height: 18)
        text.font = NSFont.systemFont(ofSize: NSFont.systemFontSize, weight: weight)
        text.textColor = color
        text.lineBreakMode = .byTruncatingTail
        view.addSubview(text)
        menuItem.view = view
        return menuItem
    }

    func metricItem(
        label: String,
        value: String,
        symbol: String? = nil,
        symbolColor: NSColor = .labelColor,
        valueColor: NSColor = .labelColor
    ) -> NSMenuItem {
        let menuItem = NSMenuItem()
        let width: CGFloat = 390
        let height: CGFloat = 27
        let view = NSView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        var labelX: CGFloat = 13

        if let symbol, let image = sf(symbol, color: symbolColor) {
            let imageView = NSImageView(frame: NSRect(x: 13, y: 5, width: 17, height: 17))
            imageView.image = image
            imageView.contentTintColor = symbolColor
            view.addSubview(imageView)
            labelX = 39
        }

        let valueWidth: CGFloat = 132
        let labelField = NSTextField(labelWithString: label)
        labelField.frame = NSRect(
            x: labelX,
            y: 5,
            width: width - labelX - valueWidth - 18,
            height: 18
        )
        labelField.font = NSFont.systemFont(ofSize: NSFont.systemFontSize)
        labelField.textColor = .labelColor
        labelField.lineBreakMode = .byTruncatingTail
        view.addSubview(labelField)

        let valueField = NSTextField(labelWithString: value)
        valueField.frame = NSRect(
            x: width - valueWidth - 12,
            y: 5,
            width: valueWidth,
            height: 18
        )
        valueField.alignment = .right
        valueField.font = NSFont.monospacedDigitSystemFont(
            ofSize: NSFont.systemFontSize,
            weight: .semibold
        )
        valueField.textColor = valueColor
        valueField.lineBreakMode = .byTruncatingHead
        view.addSubview(valueField)

        menuItem.view = view
        return menuItem
    }

    func statusAttributed(
        label: String,
        value: String,
        color: NSColor,
        image: NSImage? = nil,
        symbol: String? = nil
    ) -> NSAttributedString {

        let output = NSMutableAttributedString()
        let requestedImage = image ?? symbol.flatMap { sf($0) }
        if let requestedImage {
            let icon = (requestedImage.copy() as? NSImage) ?? requestedImage
            icon.size = NSSize(width: 16, height: 16)
            let attachment = NSTextAttachment()
            attachment.image = icon
            attachment.bounds = NSRect(x: 0, y: -1.5, width: 16, height: 16)
            output.append(NSAttributedString(attachment: attachment))
            output.append(NSAttributedString(string: "  "))
        }
        let labelStart = output.length
        output.append(NSAttributedString(string: "\(label)    "))

        output.addAttributes(
            [
                .foregroundColor: NSColor.labelColor,
                .font: NSFont.systemFont(
                    ofSize: NSFont.systemFontSize
                )
            ],
            range: NSRange(
                location: labelStart,
                length: output.length - labelStart
            )
        )

        let state = NSAttributedString(
            string: value,
            attributes: [
                .foregroundColor: color,
                .font: NSFont.systemFont(
                    ofSize: NSFont.systemFontSize,
                    weight: .semibold
                )
            ]
        )

        output.append(state)

        return output
    }

    // MARK: - Build menu

    func buildMenu() {
        menu = NSMenu(title: "Evora Smart Menu")
        menu.autoenablesItems = false
        menu.delegate = self
        menu.addItem(brandedHeaderItem())

        let globalSearchItem = NSMenuItem()
        let globalSearchContainer = NSView(frame: NSRect(x: 0, y: 0, width: 320, height: 40))
        let globalSearchField = MenuSearchField(frame: NSRect(x: 12, y: 6, width: 296, height: 28))
        globalSearchField.placeholderString = "Hledat v celé nabídce…"
        globalSearchField.sendsSearchStringImmediately = true
        globalSearchField.delegate = self
        globalSearchContainer.addSubview(globalSearchField)
        globalSearchItem.view = globalSearchContainer
        mainMenuSearchItem = globalSearchItem
        mainMenuSearchField = globalSearchField
        menu.addItem(globalSearchItem)

        let noSearchResults = NSMenuItem(
            title: "Žádná položka neodpovídá hledání",
            action: nil,
            keyEquivalent: ""
        )
        noSearchResults.isEnabled = false
        noSearchResults.isHidden = true
        mainMenuNoResultsItem = noSearchResults
        menu.addItem(noSearchResults)

        shiftStatusItem = intranetStatusSummaryItem()
        menu.addItem(shiftStatusItem)
        menu.addItem(.separator())

        let attendance = NSMenuItem(
            title: "Docházka",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(to: attendance, title: "Docházka", symbol: "calendar.badge.clock", color: .systemGreen)
        intranetMenu = NSMenu(title: "Docházka")
        intranetMenu.autoenablesItems = false
        intranetMenu.delegate = self
        attendance.submenu = intranetMenu
        menu.addItem(attendance)
        rebuildIntranetMenu()

        let records = NSMenuItem(
            title: "Záznam práce",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(to: records, title: "Záznam práce", symbol: "square.and.pencil", color: .systemBlue)
        let recordsMenu = NSMenu(title: "Záznam práce")
        recordsMenu.autoenablesItems = false
        recordsMenu.addItem(item("Přidat poznámku…", symbol: "square.and.pencil", action: #selector(addNote)))
        recordsMenu.addItem(item("Telefon / hovor…", symbol: "phone.fill", action: #selector(addCall)))
        recordsMenu.addItem(item("Výjezd / cesta…", symbol: "car.fill", action: #selector(addTravel)))
        recordsMenu.addItem(item("Práce mimo PC…", symbol: "wrench.and.screwdriver.fill", action: #selector(addOffPC)))
        records.submenu = recordsMenu
        menu.addItem(records)

        let reports = NSMenuItem(
            title: "Přehledy a výkazy",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(to: reports, title: "Přehledy a výkazy", symbol: "doc.text.magnifyingglass", color: .systemTeal)
        let reportsMenu = NSMenu(title: "Přehledy a výkazy")
        reportsMenu.autoenablesItems = false
        reportsMenu.addItem(item("Průběžný souhrn", symbol: "list.bullet.rectangle", action: #selector(showSummary)))
        reportsMenu.addItem(item("AI souhrn", symbol: "sparkles", action: #selector(showAISummary)))
        reportsMenu.addItem(item("Poslední aktivita", symbol: "clock.arrow.circlepath", action: #selector(showRecent)))
        reportsMenu.addItem(.separator())
        reportsMenu.addItem(item("Vytvořit výkaz", symbol: "doc.text.fill", action: #selector(makeReport)))
        reportsMenu.addItem(item("Otevřít Excel", symbol: "tablecells.fill", action: #selector(openExcel)))
        reports.submenu = reportsMenu
        menu.addItem(reports)

        let systems = NSMenuItem(
            title: "Systémy",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(to: systems, title: "Systémy", symbol: "square.grid.2x2", color: .systemOrange)
        let systemsMenu = NSMenu(title: "Systémy")
        systemsMenu.autoenablesItems = false
        evoraMenu = systemsMenu
        evoraMenu.delegate = self
        systems.submenu = systemsMenu
        menu.addItem(systems)
        rebuildEvoraMenu()

        let controls = NSMenuItem(
            title: "Nastavení Evora Smart Menu",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(to: controls, title: "Nastavení Evora Smart Menu", symbol: "gearshape.2", color: .systemPurple)
        let controlsMenu = NSMenu(title: "Nastavení Evora Smart Menu")
        controlsMenu.autoenablesItems = false

        macStatusItem = NSMenuItem(title: "Mac agent: kontroluji…", action: nil, keyEquivalent: "")
        macStatusItem.isEnabled = true
        controlsMenu.addItem(macStatusItem)
        windowsStatusItem = NSMenuItem(title: "Windows klient: kontroluji…", action: nil, keyEquivalent: "")
        windowsStatusItem.isEnabled = true
        controlsMenu.addItem(windowsStatusItem)
        trackingStatusItem = NSMenuItem(title: "Sledování: kontroluji…", action: nil, keyEquivalent: "")
        trackingStatusItem.isEnabled = true
        controlsMenu.addItem(trackingStatusItem)
        controlsMenu.addItem(.separator())

        startAgentItem = item("Spustit Mac agent", symbol: "play.circle.fill", action: #selector(startAgent))
        restartAgentItem = item("Restartovat Mac agent", symbol: "arrow.clockwise.circle.fill", action: #selector(restartAgent))
        stopAgentItem = item("Zastavit Mac agent", symbol: "stop.circle.fill", action: #selector(stopAgent))
        controlsMenu.addItem(startAgentItem)
        controlsMenu.addItem(restartAgentItem)
        controlsMenu.addItem(stopAgentItem)
        controlsMenu.addItem(.separator())
        pauseAgentItem = item("Pozastavit sledování", symbol: "pause.circle.fill", action: #selector(pauseAgent))
        resumeAgentItem = item("Pokračovat ve sledování", symbol: "play.circle.fill", action: #selector(resumeAgent))
        controlsMenu.addItem(pauseAgentItem)
        controlsMenu.addItem(resumeAgentItem)
        controls.submenu = controlsMenu
        menu.addItem(controls)

        menu.addItem(.separator())
        let quitMenuItem = item(
            "Ukončit pouze menu",
            symbol: "xmark.circle",
            action: #selector(quitMenu),
            color: .systemRed
        )
        applyMenuIcon(
            to: quitMenuItem,
            title: "Ukončit pouze menu",
            image: sf("xmark.circle", color: .systemRed),
            textColor: .systemRed
        )
        menu.addItem(quitMenuItem)
        statusItem.menu = menu
        applyMainMenuSearchFilter()
    }

    // MARK: - Refresh

    @objc func tickClock() {
        applyIntranetStatusToUI()
    }

    @objc func refreshAll() {
        if refreshInFlight {
            return
        }

        refreshInFlight = true

        DispatchQueue.global(qos: .utility).async { [weak self] in
            guard let self = self else {
                return
            }

            let q = self.quick()

            DispatchQueue.main.async { [weak self] in
                guard let self = self else {
                    return
                }

                self.refreshInFlight = false
                if let q { self.applyRefresh(q) }
                else { self.applyRefreshFailure() }
            }
        }
    }

    private func applyRefreshFailure() {
        macStatusItem.attributedTitle = statusAttributed(
            label: "Mac agent",
            value: cachedAgent ? "● POSLEDNÍ STAV ONLINE" : "● STAV NEOVĚŘEN",
            color: .systemOrange,
            symbol: "desktopcomputer"
        )
        windowsStatusItem.attributedTitle = statusAttributed(
            label: "Windows klient",
            value: cachedWindows == "NIKDY" ? "● STAV NEOVĚŘEN" : "● POSLEDNÍ STAV \(cachedWindows)",
            color: .systemOrange,
            symbol: "pc"
        )
        trackingStatusItem.attributedTitle = statusAttributed(
            label: "Sledování",
            value: "● OBNOVA STAVU SELHALA",
            color: .systemOrange,
            symbol: "exclamationmark.triangle"
        )
    }

    private func applyRefresh(_ q: [String: Any]) {



        let agent =
            (q["agent_running"] as? Bool)
            ?? false

        let windows =
            (q["windows"] as? String)
            ?? "NIKDY"

        let windowsAge =
            q["windows_last_seconds"]
            as? Double

        let trackingPaused =
            (q["paused"] as? Bool)
            ?? false

        cachedAgent = agent
        cachedWindows = windows

        // Mac agent status
        if agent {
            macStatusItem.attributedTitle =
                statusAttributed(
                    label: "Mac agent",
                    value: "● ONLINE",
                    color: .systemGreen,
                    symbol: "desktopcomputer"
                )
        } else {
            macStatusItem.attributedTitle =
                statusAttributed(
                    label: "Mac agent",
                    value: "● OFFLINE",
                    color: .systemRed,
                    symbol: "desktopcomputer"
                )
        }

        // Windows status
        if windows == "ONLINE" {

            let age =
                Int(
                    windowsAge
                    ?? 0
                )

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● ONLINE · \(age) s",
                    color: .systemGreen,
                    symbol: "pc"
                )

        } else if windows == "ZPOZDENI" {

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● ZPOŽDĚNÍ",
                    color: .systemOrange,
                    symbol: "pc"
                )

        } else if windows == "OFFLINE" {

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● OFFLINE",
                    color: .systemRed,
                    symbol: "pc"
                )

        } else {

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● BEZ DAT",
                    color: .systemOrange,
                    symbol: "pc"
                )
        }

        trackingStatusItem.attributedTitle = statusAttributed(
            label: "Sledování",
            value: agent ? (trackingPaused ? "⏸ POZASTAVENO" : "● AKTIVNÍ") : "● NEAKTIVNÍ",
            color: agent ? (trackingPaused ? .systemOrange : .systemGreen) : .systemRed,
            symbol: trackingPaused ? "pause.circle.fill" : "eye.fill"
        )

        // Agent action visibility
        startAgentItem.isHidden = agent
        restartAgentItem.isHidden = !agent
        stopAgentItem.isHidden = !agent
        pauseAgentItem.isHidden = !agent || trackingPaused
        resumeAgentItem.isHidden = !agent || !trackingPaused

        applyIntranetStatusToUI()
        reconcileTrackingWithIntranet(agent: agent, trackingPaused: trackingPaused)
    
    }

    private func reconcileTrackingWithIntranet(agent: Bool, trackingPaused: Bool) {
        guard intranetSnapshot.dataState == "current", !trackingReconciliationInFlight else { return }
        let desiredActive = ["in_building", "home_office", "offsite"]
            .contains(intranetSnapshot.currentState)
        let command: [String]?
        if desiredActive, !agent {
            command = ["spustit"]
        } else if desiredActive, trackingPaused {
            command = ["pokracovat"]
        } else if !desiredActive, agent, !trackingPaused {
            command = ["pauza"]
        } else {
            command = nil
        }
        guard let command else { return }
        trackingReconciliationInFlight = true
        DispatchQueue.global(qos: .utility).async { [weak self] in
            guard let self else { return }
            _ = self.runWork(command)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                self.trackingReconciliationInFlight = false
                self.refreshAll()
            }
        }
    }

    // MARK: - Agent control

    func ensureAgent() -> Bool {

        let q1 = quick()

        if
            (
                q1?[
                    "agent_running"
                ]
                as? Bool
            )
            == true
        {
            return true
        }

        _ = runWork(
            [
                "spustit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1.5
        )

        let q2 = quick()

        return
            (
                q2?[
                    "agent_running"
                ]
                as? Bool
            )
            == true
    }

    @objc func startAgent() {

        _ = runWork(
            [
                "spustit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        refreshAll()
    }

    @objc func restartAgent() {

        _ = runWork(
            [
                "zastavit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        _ = runWork(
            [
                "spustit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        refreshAll()
    }

    @objc func stopAgent() {

        _ = runWork(
            [
                "zastavit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        refreshAll()
    }

    // MARK: - Shift control

    func startShift(
        _ mode: String
    ) {
        executeIntranetPunch(mode == "office" ? "arrival" : "home_start")
    }

    @objc func startOffice() {
        startShift(
            "office"
        )
    }

    @objc func startHome() {
        startShift(
            "homeoffice"
        )
    }

    @objc func stopShift() {
        switch intranetSnapshot.currentState {
        case "home_office":
            executeIntranetPunch("home_end")
        case "in_building":
            executeIntranetPunch("departure")
        case "on_break", "doctor", "offsite":
            showAlert(
                "Evora Intranet",
                "Nejdřív ukončete aktuální stav „\(intranetStateLabel(intranetSnapshot.currentState))“ v nabídce Evora Intranet."
            )
        default:
            showAlert("Evora Intranet", "Pracovní doba už není aktivní.")
        }
    }

    // MARK: - Alerts

    func contextualDialogIcon(_ context: String) -> NSImage {
        let normalized = context.folding(
            options: [.caseInsensitive, .diacriticInsensitive],
            locale: Locale(identifier: "cs_CZ")
        ).lowercased()
        let problems = [
            "chyba", "chybi", "neplatn", "nepodar", "selhal", "nedokazal",
            "povinn", "vyprsel", "nejsou aktualni", "odmitnut"
        ]
        let symbol: (name: String, color: NSColor)?
        if problems.contains(where: normalized.contains) {
            symbol = ("exclamationmark.triangle.fill", .systemRed)
        } else if normalized.contains("dovolen") || normalized.contains("absence") || normalized.contains("volno") {
            symbol = ("calendar.badge.plus", .systemGreen)
        } else if normalized.contains("ticket") || normalized.contains("portal") {
            symbol = ("ticket.fill", .systemBlue)
        } else if normalized.contains("priloh") {
            symbol = ("paperclip", .systemBlue)
        } else if normalized.contains("hesl") || normalized.contains("klicenk") || normalized.contains("zabezpec") {
            symbol = ("lock.shield.fill", .systemPurple)
        } else if normalized.contains("config") {
            symbol = ("wrench.and.screwdriver.fill", .systemOrange)
        } else if normalized.contains("intranet") || normalized.contains("dochazk") || normalized.contains("prichod") || normalized.contains("odchod") {
            return intranetMenuLogo(size: NSSize(width: 64, height: 64))
        } else if normalized.contains("souhrn") || normalized.contains("vykaz") || normalized.contains("report") {
            symbol = ("doc.text.magnifyingglass", .systemTeal)
        } else if normalized.contains("worklog") || normalized.contains("zaznam") || normalized.contains("poznamk") {
            symbol = ("clock.badge.checkmark", .systemGreen)
        } else {
            symbol = nil
        }
        guard let symbol,
              let image = NSImage(
                systemSymbolName: symbol.name,
                accessibilityDescription: context
              )?.withSymbolConfiguration(
                NSImage.SymbolConfiguration(pointSize: 48, weight: .medium).applying(
                    NSImage.SymbolConfiguration(paletteColors: [symbol.color])
                )
              )
        else {
            return evoraSmartHubIcon(size: NSSize(width: 64, height: 64))
        }
        image.isTemplate = false
        return image
    }

    func makeContextualAlert(
        _ title: String,
        _ body: String = "",
        iconContext: String? = nil
    ) -> NSAlert {
        let alert = NSAlert()
        alert.messageText = title
        alert.informativeText = body
        alert.icon = contextualDialogIcon(iconContext ?? "\(title) \(body)")
        return alert
    }

    func showAlert(
        _ title: String,
        _ body: String
    ) {

        NSApp.activate(
            ignoringOtherApps: true
        )

        let alert = makeContextualAlert(title, body)

        alert.addButton(
            withTitle: "OK"
        )

        alert.runModal()
    }

    func showScrollableAlert(
        _ title: String,
        _ body: String
    ) {

        NSApp.activate(
            ignoringOtherApps: true
        )

        let alert = makeContextualAlert(title, iconContext: "souhrn výkaz report")
        alert.addButton(withTitle: "Zavřít")

        let scroll = NSScrollView(
            frame: NSRect(
                x: 0,
                y: 0,
                width: 560,
                height: 500
            )
        )

        scroll.hasVerticalScroller = true
        scroll.hasHorizontalScroller = false
        scroll.autohidesScrollers = true
        scroll.borderType = .bezelBorder

        let textView = NSTextView(
            frame: NSRect(
                x: 0,
                y: 0,
                width: 540,
                height: 500
            )
        )

        textView.isEditable = false
        textView.isSelectable = true
        textView.drawsBackground = false
        textView.isRichText = false
        textView.font = NSFont.monospacedSystemFont(
            ofSize: 12,
            weight: .regular
        )
        textView.textContainerInset = NSSize(
            width: 10,
            height: 10
        )
        textView.textContainer?.widthTracksTextView = true
        textView.textContainer?.containerSize = NSSize(
            width: 540,
            height: CGFloat.greatestFiniteMagnitude
        )
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.autoresizingMask = [.width]
        textView.string = body

        scroll.documentView = textView
        alert.accessoryView = scroll

        alert.runModal()
    }

    func inputDialog(
        _ title: String,
        command: String
    ) {

        NSApp.activate(
            ignoringOtherApps: true
        )

        let alert = makeContextualAlert(
            title,
            "Napiš stručně, co se řešilo. Délka v minutách je volitelná.",
            iconContext: "WorkLog záznam"
        )

        alert.addButton(
            withTitle: "Uložit"
        )

        alert.addButton(
            withTitle: "Zrušit"
        )

        let container =
            NSView(
                frame:
                    NSRect(
                        x: 0,
                        y: 0,
                        width: 440,
                        height: 72
                    )
            )

        let textField =
            NSTextField(
                frame:
                    NSRect(
                        x: 0,
                        y: 40,
                        width: 440,
                        height: 26
                    )
            )

        textField.placeholderString =
            "Co se řešilo?"

        let minutesField =
            NSTextField(
                frame:
                    NSRect(
                        x: 0,
                        y: 4,
                        width: 180,
                        height: 26
                    )
            )

        minutesField.placeholderString =
            "Délka v minutách"

        container.addSubview(
            textField
        )

        container.addSubview(
            minutesField
        )

        alert.accessoryView =
            container

        alert.window
            .initialFirstResponder =
            textField

        guard
            alert.runModal()
            == .alertFirstButtonReturn
        else {
            return
        }

        let body =
            textField
                .stringValue
                .trimmingCharacters(
                    in:
                        .whitespacesAndNewlines
                )

        if body.isEmpty {
            return
        }

        var args =
            [
                command,
                body
            ]

        let mins =
            minutesField
                .stringValue
                .trimmingCharacters(
                    in:
                        .whitespacesAndNewlines
                )

        if !mins.isEmpty {

            args +=
                [
                    "--minutes",
                    mins
                ]
        }

        showAlert(
            "WorkLog",
            runWork(args)
        )
    }

    // MARK: - Manual entries

    @objc func addNote() {
        inputDialog(
            "Přidat poznámku",
            command:
                "poznamka"
        )
    }

    @objc func addCall() {
        inputDialog(
            "Telefon / hovor",
            command:
                "hovor"
        )
    }

    @objc func addTravel() {
        inputDialog(
            "Výjezd / cesta",
            command:
                "vyjezd"
        )
    }

    @objc func addOffPC() {
        inputDialog(
            "Práce mimo PC",
            command:
                "mimo-pc"
        )
    }

    // MARK: - Reports

    @objc func showSummary() {
        showAlert(
            "Průběžný souhrn",
            runWork(
                [
                    "souhrn"
                ]
            )
        )
    }

    @objc func showAISummary() {
        showAlert(
            "AI souhrn",
            runWork(
                [
                    "souhrn-ai"
                ]
            )
        )
    }

    @objc func showRecent() {
        showScrollableAlert(
            "Poslední aktivita",
            runWork(
                [
                    "posledni",
                    "8"
                ]
            )
        )
    }

    @objc func makeReport() {
        showAlert(
            "Výkaz práce",
            runWork(
                [
                    "vykaz"
                ]
            )
        )
    }

    @objc func openExcel() {

        NSWorkspace.shared.open(
            URL(
                fileURLWithPath:
                    "\(runtimeRoot)/Pracovni_vykaz.xlsx"
            )
        )
    }

    // MARK: - Evora actions

    func evoraTextView(_ value: String, width: CGFloat = 560, height: CGFloat = 360) -> NSScrollView {
        let scroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        scroll.hasVerticalScroller = true
        scroll.hasHorizontalScroller = false
        scroll.autohidesScrollers = true
        scroll.borderType = .bezelBorder
        let textView = NSTextView(frame: NSRect(x: 0, y: 0, width: width - 20, height: height))
        textView.isEditable = false
        textView.isSelectable = true
        textView.drawsBackground = false
        textView.isRichText = false
        textView.font = NSFont.systemFont(ofSize: 12)
        textView.textContainerInset = NSSize(width: 10, height: 10)
        textView.textContainer?.widthTracksTextView = true
        textView.textContainer?.containerSize = NSSize(width: width - 20, height: CGFloat.greatestFiniteMagnitude)
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.autoresizingMask = [.width]
        textView.string = value
        scroll.documentView = textView
        return scroll
    }

    func evoraAttributedTextView(_ value: NSAttributedString, width: CGFloat = 560, height: CGFloat = 360) -> NSScrollView {
        let scroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        scroll.hasVerticalScroller = true
        scroll.hasHorizontalScroller = false
        scroll.autohidesScrollers = true
        scroll.scrollerStyle = .overlay
        scroll.verticalScrollElasticity = .automatic
        scroll.horizontalScrollElasticity = .none
        scroll.usesPredominantAxisScrolling = true
        scroll.borderType = .noBorder
        let textView = NSTextView(frame: NSRect(x: 0, y: 0, width: width - 20, height: height))
        textView.isEditable = false
        textView.isSelectable = true
        textView.isRichText = true
        textView.drawsBackground = true
        textView.backgroundColor = .windowBackgroundColor
        textView.textContainerInset = NSSize(width: 12, height: 12)
        textView.textContainer?.widthTracksTextView = true
        textView.textContainer?.containerSize = NSSize(width: width - 20, height: CGFloat.greatestFiniteMagnitude)
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.autoresizingMask = [.width]
        textView.textStorage?.setAttributedString(value)
        scroll.documentView = textView
        return scroll
    }

    func evoraPortalTicketText(_ ticket: EvoraPortalTicketDetail) -> String {
        var sections: [String] = [
            "#\(ticket.ticketNumber) · \(evoraPortalTicketStatus(ticket.status))",
            ticket.subject,
            "Kontakt: \(ticket.contactName.isEmpty ? "neuveden" : ticket.contactName)",
            "Založeno: \(ticket.createdTime)"
        ]
        if !ticket.attachments.isEmpty {
            sections.append("Přílohy ticketu: \(ticket.attachments.map(\.name).joined(separator: ", "))")
        }
        for thread in ticket.threads {
            let fullName = "\(thread.author.firstName) \(thread.author.lastName)"
                .trimmingCharacters(in: .whitespacesAndNewlines)
            let author = fullName.isEmpty
                ? (thread.author.isLoxone ? "LOXONE podpora" : "Evora Smart")
                : fullName
            var message = "\(thread.createdTime) · \(author)\(thread.author.isLoxone ? " · LOXONE" : "")\n\n\(thread.content)"
            if !thread.attachments.isEmpty {
                message += "\n\nPřílohy: \(thread.attachments.map(\.name).joined(separator: ", "))"
            }
            sections.append(message)
        }
        return sections.joined(separator: "\n\n────────────────────────\n\n")
    }

    func evoraPortalAttachmentKey(_ attachment: EvoraPortalTicketAttachment) -> String {
        "\(attachment.id)\n\(attachment.name)"
    }

    func evoraPortalAttachmentIsImage(_ attachment: EvoraPortalTicketAttachment) -> Bool {
        let name = attachment.name.lowercased()
        return [".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"].contains { name.hasSuffix($0) }
    }

    func loadEvoraPortalImagePreviews(
        _ attachments: [EvoraPortalTicketAttachment],
        completion: @escaping ([String: NSImage]) -> Void
    ) {
        let images = attachments.filter { $0.canDownload && evoraPortalAttachmentIsImage($0) }
        guard !images.isEmpty else {
            completion([:])
            return
        }
        let group = DispatchGroup()
        var previews: [String: NSImage] = [:]
        for attachment in images {
            group.enter()
            downloadEvoraPortalAttachment(attachment) { result in
                let image: NSImage?
                switch result {
                case .success(let file):
                    image = NSImage(contentsOf: file)
                    try? FileManager.default.removeItem(at: file.deletingLastPathComponent())
                case .failure:
                    image = nil
                }
                DispatchQueue.main.async {
                    if let image {
                        image.isTemplate = false
                        previews[self.evoraPortalAttachmentKey(attachment)] = image
                    }
                    group.leave()
                }
            }
        }
        group.notify(queue: .main) {
            completion(previews)
        }
    }

    func evoraPortalTicketAttributedText(
        _ ticket: EvoraPortalTicketDetail,
        imagePreviews: [String: NSImage] = [:]
    ) -> NSAttributedString {
        let result = NSMutableAttributedString()
        let bodyStyle = NSMutableParagraphStyle()
        bodyStyle.lineSpacing = 3
        bodyStyle.paragraphSpacing = 8
        let bubbleStyle = NSMutableParagraphStyle()
        bubbleStyle.lineSpacing = 4
        bubbleStyle.paragraphSpacing = 14
        bubbleStyle.firstLineHeadIndent = 10
        bubbleStyle.headIndent = 10
        bubbleStyle.tailIndent = -10

        func append(_ text: String, _ attributes: [NSAttributedString.Key: Any]) {
            result.append(NSAttributedString(string: text, attributes: attributes))
        }

        func appendAttachments(_ attachments: [EvoraPortalTicketAttachment]) {
            guard !attachments.isEmpty else { return }
            for attachment in attachments {
                append("📎  \(attachment.name)\n", [
                    .font: NSFont.systemFont(ofSize: 10, weight: .medium),
                    .foregroundColor: attachment.canDownload ? NSColor.systemBlue : NSColor.labelColor,
                    .paragraphStyle: bodyStyle
                ])
                if let source = imagePreviews[evoraPortalAttachmentKey(attachment)] {
                    let image = (source.copy() as? NSImage) ?? source
                    let sourceSize = image.size
                    if sourceSize.width > 0, sourceSize.height > 0 {
                        let scale = min(1, 500 / sourceSize.width, 260 / sourceSize.height)
                        image.size = NSSize(width: sourceSize.width * scale, height: sourceSize.height * scale)
                    }
                    let imageAttachment = NSTextAttachment()
                    imageAttachment.image = image
                    result.append(NSAttributedString(attachment: imageAttachment))
                    append("\n\n", [.paragraphStyle: bodyStyle])
                } else if !attachment.canDownload {
                    append("Portál poskytl pouze název; soubor přes API neposkytuje.\n\n", [
                        .font: NSFont.systemFont(ofSize: 9),
                        .foregroundColor: NSColor.secondaryLabelColor,
                        .paragraphStyle: bodyStyle
                    ])
                }
            }
        }

        append("#\(ticket.ticketNumber) · \(evoraPortalTicketStatus(ticket.status))\n", [
            .font: NSFont.boldSystemFont(ofSize: 13),
            .foregroundColor: evoraPortalTicketColor(ticket.status),
            .paragraphStyle: bodyStyle
        ])
        append("\(ticket.subject)\nKontakt: \(ticket.contactName.isEmpty ? "neuveden" : ticket.contactName) · Založeno: \(ticket.createdTime)\n\n", [
            .font: NSFont.systemFont(ofSize: 12),
            .foregroundColor: NSColor.labelColor,
            .paragraphStyle: bodyStyle
        ])
        appendAttachments(ticket.attachments)

        for thread in ticket.threads {
            let fullName = "\(thread.author.firstName) \(thread.author.lastName)"
                .trimmingCharacters(in: .whitespacesAndNewlines)
            let author = fullName.isEmpty
                ? (thread.author.isLoxone ? "LOXONE podpora" : "Evora Smart")
                : fullName
            let accent = thread.author.isLoxone ? NSColor.systemGreen : NSColor.systemTeal
            append("●  \(author)\n", [
                .font: NSFont.boldSystemFont(ofSize: 11),
                .foregroundColor: accent,
                .paragraphStyle: bodyStyle
            ])
            append("\(thread.createdTime)\n", [
                .font: NSFont.systemFont(ofSize: 9),
                .foregroundColor: NSColor.secondaryLabelColor,
                .paragraphStyle: bodyStyle
            ])
            append("\(thread.content.trimmingCharacters(in: .whitespacesAndNewlines))\n", [
                .font: NSFont.systemFont(ofSize: 12),
                .foregroundColor: NSColor.labelColor,
                .paragraphStyle: bubbleStyle
            ])
            appendAttachments(thread.attachments)
        }
        return result
    }

    func evoraPortalTicketAttachments(_ ticket: EvoraPortalTicketDetail) -> [EvoraPortalTicketAttachment] {
        var result: [EvoraPortalTicketAttachment] = []
        var seen = Set<String>()
        for attachment in ticket.attachments + ticket.threads.flatMap(\.attachments) {
            let key = "\(attachment.id)\n\(attachment.name)"
            guard seen.insert(key).inserted else { continue }
            result.append(attachment)
        }
        return result
    }

    func presentEvoraPortalAttachments(_ attachments: [EvoraPortalTicketAttachment]) {
        guard !attachments.isEmpty else {
            showAlert("Přílohy ticketu", "Portál u tohoto ticketu nevrátil žádnou skutečnou přílohu.")
            return
        }
        let downloadable = attachments.filter(\.canDownload)
        let displayOnly = attachments.filter { !$0.canDownload }
        NSApp.activate(ignoringOtherApps: true)
        let attachmentInfo: String
        if downloadable.isEmpty {
            attachmentInfo = "Portál poskytl názvy souborů bez bezpečných adres. Zobrazuji je proto jen jako přehled, nikoli jako nefunkční tlačítka."
        } else if displayOnly.isEmpty {
            attachmentInfo = "Vyberte přílohu. Evora Smart Menu ji bezpečně načte přes Evora Smart Hub a otevře v odpovídající aplikaci macOS."
        } else {
            attachmentInfo = "Dostupné přílohy lze otevřít. Soubory, u kterých Portál poskytl jen název, jsou uvedené zvlášť jako přehled."
        }
        let alert = makeContextualAlert("Přílohy ticketu", attachmentInfo, iconContext: "přílohy")

        let width: CGFloat = 520
        let listHeight = displayOnly.isEmpty
            ? CGFloat(0)
            : min(CGFloat(220), max(CGFloat(72), CGFloat(displayOnly.count * 22 + 20)))
        let downloadableHeight: CGFloat = downloadable.isEmpty ? 0 : 59
        let displayOnlyHeight: CGFloat = displayOnly.isEmpty ? 0 : listHeight + 25
        let sectionSpacing: CGFloat = downloadable.isEmpty || displayOnly.isEmpty ? 0 : 12
        let containerHeight = downloadableHeight + displayOnlyHeight + sectionSpacing
        let container = NSView(frame: NSRect(x: 0, y: 0, width: width, height: containerHeight))
        var cursor = containerHeight
        var selector: NSPopUpButton?

        if !downloadable.isEmpty {
            let heading = NSTextField(labelWithString: "Dostupné ke stažení")
            heading.font = NSFont.systemFont(ofSize: 12, weight: .semibold)
            heading.frame = NSRect(x: 0, y: cursor - 17, width: width, height: 17)
            container.addSubview(heading)
            cursor -= 25

            let popUp = NSPopUpButton(frame: NSRect(x: 0, y: cursor - 32, width: width, height: 32), pullsDown: false)
            popUp.addItems(withTitles: downloadable.map(\.name))
            container.addSubview(popUp)
            selector = popUp
            cursor -= 32
        }

        if !displayOnly.isEmpty {
            if !downloadable.isEmpty { cursor -= sectionSpacing }
            let heading = NSTextField(labelWithString: "Názvy souborů z Portálu")
            heading.font = NSFont.systemFont(ofSize: 12, weight: .semibold)
            heading.frame = NSRect(x: 0, y: cursor - 17, width: width, height: 17)
            container.addSubview(heading)
            cursor -= 25

            let list = evoraTextView(
                displayOnly.map { "• \($0.name)" }.joined(separator: "\n"),
                width: width,
                height: listHeight
            )
            list.frame = NSRect(x: 0, y: cursor - listHeight, width: width, height: listHeight)
            container.addSubview(list)
        }

        alert.accessoryView = container
        if downloadable.isEmpty {
            alert.addButton(withTitle: "Zavřít")
            _ = alert.runModal()
            return
        }
        alert.addButton(withTitle: "Otevřít vybranou")
        alert.addButton(withTitle: "Zavřít")
        guard alert.runModal() == .alertFirstButtonReturn, let selector else { return }
        let index = max(0, min(selector.indexOfSelectedItem, downloadable.count - 1))
        downloadEvoraPortalAttachment(downloadable[index]) { [weak self] result in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success(let file):
                    NSWorkspace.shared.open(file)
                case .failure(let error):
                    self.showAlert("Přílohy ticketu", error.localizedDescription)
                }
            }
        }
    }

    func presentEvoraLoadingPanel(title: String, detail: String) -> NSPanel {
        NSApp.activate(ignoringOtherApps: true)
        let panel = NSPanel(
            contentRect: NSRect(x: 0, y: 0, width: 390, height: 132),
            styleMask: [.titled, .utilityWindow],
            backing: .buffered,
            defer: false
        )
        panel.title = "Evora Smart Menu"
        panel.isReleasedWhenClosed = false
        panel.level = .floating
        panel.hidesOnDeactivate = false
        panel.animationBehavior = .utilityWindow

        let content = NSView(frame: panel.contentRect(forFrameRect: panel.frame))
        let spinner = NSProgressIndicator(frame: NSRect(x: 24, y: 43, width: 38, height: 38))
        spinner.style = .spinning
        spinner.controlSize = .large
        spinner.startAnimation(nil)
        let titleLabel = NSTextField(labelWithString: title)
        titleLabel.font = NSFont.systemFont(ofSize: 15, weight: .semibold)
        titleLabel.frame = NSRect(x: 80, y: 68, width: 282, height: 23)
        let detailLabel = NSTextField(wrappingLabelWithString: detail)
        detailLabel.font = NSFont.systemFont(ofSize: 11)
        detailLabel.textColor = .secondaryLabelColor
        detailLabel.frame = NSRect(x: 80, y: 31, width: 282, height: 35)
        content.addSubview(spinner)
        content.addSubview(titleLabel)
        content.addSubview(detailLabel)
        panel.contentView = content
        panel.center()
        panel.makeKeyAndOrderFront(nil)
        return panel
    }

    @objc func showEvoraPortalTicket(_ sender: NSMenuItem) {
        guard let id = sender.representedObject as? String else { return }
        let loadingPanel = presentEvoraLoadingPanel(
            title: "Načítám ticket…",
            detail: "Evora Smart Menu bezpečně načítá aktuální komunikaci a přílohy z Hubu."
        )
        evoraRequest(
            path: "/api/integrations/worklog/v1/portal-tickets/\(id)"
        ) { [weak self] (result: Result<EvoraPortalTicketDetailResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success(let response):
                    let attachments = self.evoraPortalTicketAttachments(response.ticket)
                    self.loadEvoraPortalImagePreviews(attachments) { previews in
                        loadingPanel.orderOut(nil)
                        loadingPanel.close()
                        self.presentEvoraPortalTicket(response.ticket, imagePreviews: previews)
                    }
                case .failure(let error):
                    loadingPanel.orderOut(nil)
                    loadingPanel.close()
                    self.showAlert("LOXONE tickety", error.localizedDescription)
                }
            }
        }
    }

    func presentEvoraPortalTicket(
        _ ticket: EvoraPortalTicketDetail,
        imagePreviews: [String: NSImage] = [:]
    ) {
        NSApp.activate(ignoringOtherApps: true)
        let attachments = evoraPortalTicketAttachments(ticket)
        let ticketInfo = attachments.isEmpty
            ? "\(evoraPortalTicketStatus(ticket.status)) · veřejná komunikace z Loxone Partner Portálu."
            : "\(evoraPortalTicketStatus(ticket.status)) · veřejná komunikace · \(attachments.count) příloh."
        let alert = makeContextualAlert(
            "#\(ticket.ticketNumber) · \(ticket.subject)",
            ticketInfo,
            iconContext: "LOXONE ticket"
        )
        alert.addButton(withTitle: "Odpovědět…")
        if !attachments.isEmpty {
            alert.addButton(withTitle: "Přílohy (\(attachments.count))…")
        }
        alert.addButton(withTitle: "Otevřít v Hubu")
        alert.addButton(withTitle: "Zavřít")
        alert.accessoryView = evoraAttributedTextView(
            evoraPortalTicketAttributedText(ticket, imagePreviews: imagePreviews),
            height: 430
        )
        let answer = alert.runModal()
        if answer == .alertFirstButtonReturn {
            presentEvoraPortalComposer(ticket: ticket)
            return
        }
        if !attachments.isEmpty, answer == .alertSecondButtonReturn {
            presentEvoraPortalAttachments(attachments)
            return
        }
        let hubResponse: NSApplication.ModalResponse = attachments.isEmpty ? .alertSecondButtonReturn : .alertThirdButtonReturn
        if answer == hubResponse, let url = URL(string: "\(evoraHubURL())?page=tickets") {
            NSWorkspace.shared.open(url)
        }
    }

    @objc func createEvoraPortalTicket() {
        presentEvoraPortalComposer(ticket: nil)
    }

    func presentEvoraPortalComposer(ticket: EvoraPortalTicketDetail?, draft: EvoraPortalDraft? = nil) {
        NSApp.activate(ignoringOtherApps: true)
        let isReply = ticket != nil
        let alert = makeContextualAlert(
            isReply ? "Odpověď do ticketu #\(ticket?.ticketNumber ?? "")" : "Nový LOXONE ticket",
            "Po pokračování se zobrazí úplný náhled. Nic se neodešle bez následného potvrzení heslem.",
            iconContext: "LOXONE ticket"
        )
        alert.addButton(withTitle: "Zkontrolovat návrh")
        alert.addButton(withTitle: "Zrušit")

        let containerHeight: CGFloat = isReply ? 255 : 300
        let container = NSView(frame: NSRect(x: 0, y: 0, width: 560, height: containerHeight))
        let subjectLabel = NSTextField(labelWithString: "Předmět")
        subjectLabel.frame = NSRect(x: 0, y: containerHeight - 20, width: 560, height: 17)
        let subjectField = NSTextField(frame: NSRect(x: 0, y: containerHeight - 52, width: 560, height: 26))
        subjectField.stringValue = draft?.subject ?? ticket?.subject ?? ""
        subjectField.isEditable = !isReply
        subjectField.isSelectable = true
        let bodyLabel = NSTextField(labelWithString: "Celá zpráva")
        bodyLabel.frame = NSRect(x: 0, y: containerHeight - 79, width: 560, height: 17)
        let bodyScroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: 560, height: containerHeight - 84))
        bodyScroll.hasVerticalScroller = true
        bodyScroll.borderType = .bezelBorder
        let bodyField = NSTextView(frame: NSRect(x: 0, y: 0, width: 540, height: containerHeight - 84))
        bodyField.isRichText = false
        bodyField.font = NSFont.systemFont(ofSize: 12)
        bodyField.textContainerInset = NSSize(width: 8, height: 8)
        bodyField.string = draft?.body ?? ""
        bodyScroll.documentView = bodyField
        container.addSubview(subjectLabel)
        container.addSubview(subjectField)
        container.addSubview(bodyLabel)
        container.addSubview(bodyScroll)
        alert.accessoryView = container
        alert.window.initialFirstResponder = isReply ? bodyField : subjectField

        guard alert.runModal() == .alertFirstButtonReturn else { return }
        let subject = subjectField.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        let body = bodyField.string.trimmingCharacters(in: .whitespacesAndNewlines)
        guard subject.count >= 3 else {
            showAlert("LOXONE tickety", "Předmět musí mít alespoň 3 znaky.")
            presentEvoraPortalComposer(ticket: ticket, draft: EvoraPortalDraft(ticketId: ticket?.id, ticketNumber: ticket?.ticketNumber, subject: subject, body: body))
            return
        }
        guard body.count >= (isReply ? 1 : 3) else {
            showAlert("LOXONE tickety", "Zpráva je příliš krátká.")
            presentEvoraPortalComposer(ticket: ticket, draft: EvoraPortalDraft(ticketId: ticket?.id, ticketNumber: ticket?.ticketNumber, subject: subject, body: body))
            return
        }
        reviewEvoraPortalDraft(
            EvoraPortalDraft(
                ticketId: ticket?.id,
                ticketNumber: ticket?.ticketNumber,
                subject: subject,
                body: body
            ),
            ticket: ticket
        )
    }

    func reviewEvoraPortalDraft(_ draft: EvoraPortalDraft, ticket: EvoraPortalTicketDetail?) {
        NSApp.activate(ignoringOtherApps: true)
        let action = draft.isReply ? "Přidat veřejnou odpověď do #\(draft.ticketNumber ?? "")" : "Vytvořit nový ticket"
        let preview = "Kam: Loxone Partner Portal\nAkce: \(action)\nPředmět: \(draft.subject)\n\nCELÝ TEXT ZPRÁVY\n\n\(draft.body)"
        let alert = makeContextualAlert(
            "Kontrola před odesláním",
            "Níže je úplný návrh. V této chvíli ještě nic nebylo odesláno.",
            iconContext: "LOXONE ticket kontrola"
        )
        alert.addButton(withTitle: "Pokračovat k heslu")
        alert.addButton(withTitle: "Zpět upravit")
        alert.addButton(withTitle: "Zrušit")
        alert.accessoryView = evoraTextView(preview, height: 380)
        let answer = alert.runModal()
        if answer == .alertFirstButtonReturn {
            confirmEvoraPortalDraft(draft)
        } else if answer == .alertSecondButtonReturn {
            presentEvoraPortalComposer(ticket: ticket, draft: draft)
        }
    }

    func confirmEvoraPortalDraft(_ draft: EvoraPortalDraft) {
        NSApp.activate(ignoringOtherApps: true)
        let alert = makeContextualAlert(
            "Potvrdit odeslání heslem",
            "Heslo slouží jen k jednorázovému potvrzení přesně zkontrolovaného návrhu.",
            iconContext: "heslo zabezpečení"
        )
        alert.addButton(withTitle: "Potvrdit a odeslat")
        alert.addButton(withTitle: "Zrušit")
        let password = NSSecureTextField(frame: NSRect(x: 0, y: 0, width: 420, height: 26))
        password.placeholderString = "Heslo do Evora Smart Hubu"
        alert.accessoryView = password
        alert.window.initialFirstResponder = password
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        guard !password.stringValue.isEmpty else {
            showAlert("LOXONE tickety", "Heslo je povinné.")
            return
        }
        let action = draft.isReply ? "portal_ticket_reply" : "portal_ticket_create"
        let payload: [String: Any] = draft.isReply
            ? ["ticketId": draft.ticketId ?? "", "content": draft.body]
            : ["subject": draft.subject, "description": draft.body]
        evoraRequest(
            path: "/api/integrations/worklog/v1/portal-tickets/confirm",
            method: "POST",
            body: ["action": action, "password": password.stringValue, "payload": payload]
        ) { [weak self] (result: Result<EvoraConfirmationResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success(let response):
                    self.sendEvoraPortalDraft(draft, confirmationId: response.confirmationId)
                case .failure(let error):
                    self.showAlert("LOXONE tickety", error.localizedDescription)
                }
            }
        }
    }

    func sendEvoraPortalDraft(_ draft: EvoraPortalDraft, confirmationId: String) {
        let path = draft.isReply
            ? "/api/integrations/worklog/v1/portal-tickets/\(draft.ticketId ?? "")/replies"
            : "/api/integrations/worklog/v1/portal-tickets"
        let body: [String: Any] = draft.isReply
            ? ["content": draft.body]
            : ["subject": draft.subject, "description": draft.body]
        evoraRequest(
            path: path,
            method: "POST",
            body: body,
            headers: ["X-Action-Confirmation": confirmationId]
        ) { [weak self] (result: Result<EvoraPortalMutationResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success:
                    self.showAlert("LOXONE tickety", draft.isReply ? "Odpověď byla odeslána." : "Ticket byl vytvořen.")
                    self.refreshEvoraTickets()
                case .failure(let error):
                    self.showAlert("LOXONE tickety", error.localizedDescription)
                }
            }
        }
    }

    @objc func configureEvoraConnection() {
        NSApp.activate(ignoringOtherApps: true)
        let alert = makeContextualAlert(
            "Evora Smart Hub",
            "Vložte adresu Hubu a osobní WorkLog token vytvořený v Nastavení Evora Smart Hubu. Token se uloží pouze do macOS Klíčenky.",
            iconContext: "Evora Smart Hub"
        )
        alert.addButton(withTitle: "Uložit")
        alert.addButton(withTitle: "Odpojit tento Mac")
        alert.addButton(withTitle: "Zrušit")

        let container = NSView(
            frame: NSRect(x: 0, y: 0, width: 480, height: 104)
        )
        let urlLabel = NSTextField(labelWithString: "Adresa Evora Smart Hubu")
        urlLabel.frame = NSRect(x: 0, y: 82, width: 480, height: 17)
        let urlField = NSTextField(
            frame: NSRect(x: 0, y: 52, width: 480, height: 26)
        )
        urlField.stringValue = evoraHubURL()
        let tokenLabel = NSTextField(labelWithString: "Osobní WorkLog token")
        tokenLabel.frame = NSRect(x: 0, y: 30, width: 480, height: 17)
        let tokenField = NSSecureTextField(
            frame: NSRect(x: 0, y: 0, width: 480, height: 26)
        )
        tokenField.placeholderString = evoraToken() == nil
            ? "esh_worklog_…"
            : "ponechte prázdné, pokud token neměníte"
        container.addSubview(urlLabel)
        container.addSubview(urlField)
        container.addSubview(tokenLabel)
        container.addSubview(tokenField)
        alert.accessoryView = container
        alert.window.initialFirstResponder = evoraToken() == nil
            ? tokenField
            : urlField

        let answer = alert.runModal()
        if answer == .alertSecondButtonReturn {
            deleteEvoraToken()
            evoraServers = []
            evoraLauncherAgent = nil
            evoraStatus = "Evora Smart Hub: nepřipojeno"
            evoraTickets = []
            evoraTicketsStatus = "Tickety: nepřipojeno"
            rebuildEvoraMenu()
            return
        }
        guard answer == .alertFirstButtonReturn else { return }
        guard let normalizedURL = validEvoraHubURL(urlField.stringValue) else {
            showAlert(
                "Evora Smart Hub",
                "Použijte platnou HTTPS adresu bez parametrů. HTTP je povolené pouze pro localhost."
            )
            return
        }
        let newToken = tokenField.stringValue.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        if evoraToken() == nil && newToken.isEmpty {
            showAlert("Evora Smart Hub", "Osobní WorkLog token je povinný.")
            return
        }
        if !newToken.isEmpty {
            guard newToken.hasPrefix("esh_worklog_") else {
                showAlert("Evora Smart Hub", "Vložený token nemá platný formát.")
                return
            }
            guard saveEvoraToken(newToken) else {
                showAlert("Evora Smart Hub", "Token se nepodařilo uložit do macOS Klíčenky.")
                return
            }
        }
        UserDefaults.standard.set(normalizedURL, forKey: evoraHubDefaultsKey)
        evoraLastRefresh = .distantPast
        refreshEvoraMenu()
    }

    func chooseEvoraConfigLaunchMode() -> String? {
        NSApp.activate(ignoringOtherApps: true)
        let alert = makeContextualAlert(
            "Otevřít Loxone Config",
            "Vyberte, zda se má Miniserver připojit v již spuštěné přesné verzi Loxone Configu, nebo v novém okně.",
            iconContext: "Loxone Config"
        )
        alert.addButton(withTitle: "Otevřít v již spuštěném Configu")
        alert.addButton(withTitle: "Otevřít v novém okně")
        alert.addButton(withTitle: "Zrušit")
        switch alert.runModal() {
        case .alertFirstButtonReturn: return "existing"
        case .alertSecondButtonReturn: return "new_window"
        default: return nil
        }
    }

    @objc func runEvoraAction(_ sender: NSMenuItem) {
        guard
            let payload = sender.representedObject as? NSDictionary,
            let serial = payload["serial"] as? String,
            let action = payload["action"] as? String
        else {
            return
        }
        var requestBody: [String: Any] = ["action": action]
        if action == "loxone_config" {
            guard let launchMode = chooseEvoraConfigLaunchMode() else { return }
            requestBody["launchMode"] = launchMode
        }
        evoraStatus = action == "loxone_app"
            ? "Připravuji Loxone App pro \(serial)…"
            : "Předávám \(serial) do Windows…"
        rebuildEvoraMenu()
        evoraRequest(
            path: "/api/integrations/worklog/v1/miniservers/\(serial)/actions",
            method: "POST",
            body: requestBody
        ) { [weak self] (result: Result<EvoraActionResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success(let response):
                    if response.action == "loxone_app" {
                        guard
                            let value = response.url,
                            let url = URL(string: value),
                            url.scheme?.lowercased() == "loxone"
                        else {
                            self.evoraStatus = "Loxone App: neplatná odpověď"
                            self.rebuildEvoraMenu()
                            self.showAlert("Evora Smart Hub", "Hub nevrátil bezpečný odkaz pro Loxone App.")
                            return
                        }
                        self.evoraStatus = "Loxone App otevřena pro \(serial)"
                        self.rebuildEvoraMenu()
                        if !NSWorkspace.shared.open(url) {
                            self.showAlert("Loxone App", "macOS nedokázal otevřít schéma loxone://. Ověřte instalaci Loxone App.")
                        }
                        return
                    }
                    guard let job = response.job else {
                        self.evoraStatus = "Config: neplatná odpověď"
                        self.rebuildEvoraMenu()
                        self.showAlert("Loxone Config", "Hub nevrátil vytvořený požadavek.")
                        return
                    }
                    self.evoraStatus = "Windows Launcher převzal požadavek…"
                    self.rebuildEvoraMenu()
                    self.pollEvoraConfigJob(job.id, attempt: 0)
                case .failure(let error):
                    self.evoraStatus = "Chyba: \(error.localizedDescription)"
                    self.rebuildEvoraMenu()
                    self.showAlert("Evora Smart Hub", error.localizedDescription)
                }
            }
        }
    }

    func pollEvoraConfigJob(_ id: String, attempt: Int) {
        guard attempt < 150 else {
            evoraStatus = "Loxone Config: vypršel čas kontroly"
            rebuildEvoraMenu()
            showAlert("Loxone Config", "Windows Launcher nepotvrdil výsledek v časovém limitu.")
            return
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { [weak self] in
            guard let self else { return }
            self.evoraRequest(
                path: "/api/integrations/worklog/v1/config-jobs/\(id)"
            ) { [weak self] (result: Result<EvoraJobResponse, Error>) in
                DispatchQueue.main.async {
                    guard let self else { return }
                    switch result {
                    case .failure(let error):
                        self.evoraStatus = "Config: \(error.localizedDescription)"
                        self.rebuildEvoraMenu()
                        self.showAlert("Loxone Config", error.localizedDescription)
                    case .success(let response):
                        let job = response.job
                        if job.state == "succeeded" {
                            self.evoraStatus = "Loxone Config \(job.requiredVersion) je otevřený"
                            self.rebuildEvoraMenu()
                        } else if ["missing_config", "failed", "expired"].contains(job.state) {
                            self.evoraStatus = "Config: \(job.message)"
                            self.rebuildEvoraMenu()
                            self.showEvoraConfigFailure(job)
                        } else {
                            self.evoraStatus = job.message
                            self.rebuildEvoraMenu()
                            self.pollEvoraConfigJob(id, attempt: attempt + 1)
                        }
                    }
                }
            }
        }
    }

    func showEvoraConfigFailure(_ job: EvoraConfigJob) {
        NSApp.activate(ignoringOtherApps: true)
        let title = job.state == "missing_config"
            ? "Požadovaný Loxone Config chybí"
            : "Loxone Config se nepodařilo otevřít"
        let alert = makeContextualAlert(title, job.message)
        if job.state == "missing_config", job.configUrl != nil {
            alert.addButton(withTitle: "Stáhnout Config \(job.requiredVersion)")
            alert.addButton(withTitle: "Zavřít")
            if alert.runModal() == .alertFirstButtonReturn,
               let value = job.configUrl,
               let url = URL(string: value) {
                NSWorkspace.shared.open(url)
            }
        } else {
            alert.addButton(withTitle: "OK")
            alert.runModal()
        }
    }

    // MARK: - Links

    @objc func openURL(
        _ sender: NSMenuItem
    ) {

        guard
            let value =
                sender
                    .representedObject
                as? String,

            let url =
                URL(
                    string:
                        value
                )

        else {
            return
        }

        NSWorkspace
            .shared
            .open(url)
    }

    // MARK: - Misc

    @objc func pauseAgent() {
        let message = runWork(["pauza"])
        refreshAll()
        showAlert("Evora Smart Menu", message)
    }

    @objc func resumeAgent() {
        let message = runWork(["pokracovat"])
        refreshAll()
        showAlert("Evora Smart Menu", message)
    }

    @objc func quitMenu() {
        NSApp.terminate(nil)
    }
}

let commandLine = CommandLine.arguments
let commandDelegate = AppDelegate()

if commandLine.count > 1, commandLine[1] == "--store-intranet-credentials" {
    guard let email = readLine()?.trimmingCharacters(in: .whitespacesAndNewlines),
          let password = readLine(),
          email.contains("@"),
          !email.contains(" "),
          !password.isEmpty
    else {
        fputs("Neplatný e-mail nebo heslo.\n", stderr)
        exit(2)
    }
    guard commandDelegate.storeIntranetCredentials(email: email, password: password) else {
        fputs("Přístup se nepodařilo uložit do macOS Klíčenky.\n", stderr)
        exit(1)
    }
    print("Přístup k Evora Intranetu byl uložen do macOS Klíčenky.")
    exit(0)
}

if commandLine.count > 1, commandLine[1] == "--clear-intranet-credentials" {
    commandDelegate.deleteIntranetCredentials()
    print("Přístup k Evora Intranetu byl z macOS Klíčenky odstraněn.")
    exit(0)
}

if commandLine.count > 1, commandLine[1] == "--self-test-intranet-history" {
    let fixedNow = ISO8601DateFormatter().date(from: "2026-08-22T15:00:00Z")!
    let events = [
        AppDelegate.IntranetAttendanceEvent(id: "a1", kind: "arrival", source: "test", ts: "2026-08-21T05:00:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "b1", kind: "break_out", source: "test", ts: "2026-08-21T10:00:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "b2", kind: "break_in", source: "test", ts: "2026-08-21T10:30:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "d1", kind: "departure", source: "test", ts: "2026-08-21T14:00:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "p1", kind: "arrival", source: "test", ts: "2026-07-15T06:00:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "p2", kind: "departure", source: "test", ts: "2026-07-15T14:00:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "old", kind: "arrival", source: "test", ts: "2026-06-30T06:00:00Z")
    ]
    let merged = commandDelegate.mergeIntranetHistory(
        existing: [events[0]],
        incoming: events,
        now: fixedNow
    )
    let currentDays = commandDelegate.intranetHistoryDays(
        monthStart: commandDelegate.intranetMonthStart(from: fixedNow),
        events: merged,
        now: fixedNow
    )
    let previousDays = commandDelegate.intranetHistoryDays(
        monthStart: commandDelegate.intranetMonthStart(offset: -1, from: fixedNow),
        events: merged,
        now: fixedNow
    )
    let overnightNow = ISO8601DateFormatter().date(from: "2026-08-23T01:00:00Z")!
    let overnightEvents = [
        AppDelegate.IntranetAttendanceEvent(id: "h1", kind: "home_start", source: "test", ts: "2026-08-22T20:04:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "h2", kind: "home_end", source: "test", ts: "2026-08-23T00:59:00Z")
    ]
    let overnightDerived = commandDelegate.deriveIntranetAttendance(events: overnightEvents, now: overnightNow)
    let overnightDays = commandDelegate.intranetHistoryDays(
        monthStart: commandDelegate.intranetMonthStart(from: overnightNow),
        events: overnightEvents,
        now: overnightNow
    )
    let breakStartedAt = fixedNow.timeIntervalSince1970
    let fullBreak = commandDelegate.intranetBreakRemainingSeconds(
        state: "on_break",
        since: breakStartedAt,
        now: fixedNow
    )
    let fiveMinuteBreak = commandDelegate.intranetBreakRemainingSeconds(
        state: "on_break",
        since: breakStartedAt,
        now: fixedNow.addingTimeInterval(5 * 60)
    )
    let expiredBreak = commandDelegate.intranetBreakRemainingSeconds(
        state: "on_break",
        since: breakStartedAt,
        now: fixedNow.addingTimeInterval(31 * 60)
    )
    let noBreak = commandDelegate.intranetBreakRemainingSeconds(
        state: "in_building",
        since: breakStartedAt,
        now: fixedNow
    )
    guard merged.count == 6,
          currentDays.count == 1,
          previousDays.count == 1,
          currentDays[0].workedSeconds == 30_600,
          previousDays[0].workedSeconds == 28_800,
          overnightDerived.state == "away",
          overnightDerived.worked == 17_700,
          overnightDays.count == 1,
          overnightDays[0].workedSeconds == 17_700,
          overnightDays[0].events.count == 2,
          fullBreak == 1_800,
          fiveMinuteBreak == 1_500,
          expiredBreak == 0,
          noBreak == nil,
          commandDelegate.formatIntranetBreakCountdown(fiveMinuteBreak ?? -1) == "25:00"
    else {
        fputs("Self-test historie docházky selhal.\n", stderr)
        exit(1)
    }
    print("Historie docházky a 30minutový odpočet přestávky jsou v pořádku.")
    exit(0)
}

if commandLine.count > 1, commandLine[1] == "--self-test-menu-structure" {
    commandDelegate.statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    defer { NSStatusBar.system.removeStatusItem(commandDelegate.statusItem) }
    commandDelegate.buildMenu()

    func visibleMenuTitle(_ item: NSMenuItem) -> String {
        let raw = item.attributedTitle?.string.isEmpty == false ? item.attributedTitle?.string ?? item.title : item.title
        return raw.replacingOccurrences(of: "\u{fffc}", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    func menuItem(in menu: NSMenu, titled title: String) -> NSMenuItem? {
        for item in menu.items {
            if visibleMenuTitle(item) == title { return item }
            if let submenu = item.submenu, let match = menuItem(in: submenu, titled: title) { return match }
        }
        return nil
    }

    func actionItemsHaveIcons(_ menu: NSMenu) -> Bool {
        for item in menu.items {
            if item.action != nil, item.view == nil, item.attributedTitle?.length ?? 0 == 0 { return false }
            if let submenu = item.submenu, !actionItemsHaveIcons(submenu) { return false }
        }
        return true
    }

    let systems = menuItem(in: commandDelegate.menu, titled: "Systémy")
    let statusLabels = commandDelegate.shiftStatusItem.view?.subviews.compactMap { ($0 as? NSTextField)?.stringValue } ?? []
    let fakeServer = AppDelegate.EvoraMiniServer(
        serial: "TEST00000001",
        project: "Testovací projekt",
        type: "Miniserver Compact",
        folderName: "Testovací složka",
        folderColor: "#D97706",
        connectionState: "online",
        currentFirmware: "16.0.0.0",
        elementsOnline: 11,
        elementsTotal: 12,
        offlineDevices: 1,
        lastCheckedAt: "2026-08-23T20:00:00.000Z",
        lastLatencyMs: 42,
        consecutiveFailures: 0,
        healthVerdict: "ok",
        healthRefreshedAt: "2026-08-23T20:00:00.000Z",
        dataState: "current",
        hasCredentials: true,
        loxoneAppAvailable: true,
        loxoneConfigAvailable: false,
        configVersion: "16.0.0.0",
        configDownloadUrl: nil,
        deviceImageUrl: nil
    )
    let fakeCamera = AppDelegate.EvoraCamera(
        id: 0,
        name: "Testovací kamera",
        online: true,
        model: "MS-C5376-PA",
        firmware: "33.8.0.3"
    )
    commandDelegate.seedEvoraMenuForSelfTest(
        servers: [fakeServer],
        cameras: [fakeCamera],
        status: "1 Miniserver · Windows Launcher offline"
    )
    let headerSubtitle = commandDelegate.seedEvoraHubVersionForSelfTest("3.0.28")
    commandDelegate.rebuildEvoraMenu()
    let folder = menuItem(in: commandDelegate.evoraMenu, titled: "Testovací složka  (1)")
    let server = menuItem(in: commandDelegate.evoraMenu, titled: "Online · Testovací projekt")
    let cameras = menuItem(in: commandDelegate.evoraMenu, titled: "Milesight  (1)")
    let camera = menuItem(in: commandDelegate.evoraMenu, titled: "Online · Testovací kamera")
    let quitItem = menuItem(in: commandDelegate.menu, titled: "Ukončit pouze menu")
    let summaryLabels = server?.submenu?.items.first?.view?.subviews.compactMap { ($0 as? NSTextField)?.stringValue } ?? []
    let flattenedSearch = commandDelegate.seedEvoraSearchForSelfTest("projekt")
    _ = commandDelegate.seedEvoraSearchForSelfTest("")
    let dialogContexts = [
        "Dovolená a absence",
        "Evora Intranet docházka",
        "LOXONE ticket",
        "přílohy",
        "heslo zabezpečení",
        "Loxone Config",
        "Evora Smart Hub"
    ]

    var failures: [String] = []
    if commandDelegate.menu.title != "Evora Smart Menu" { failures.append("název") }
    if headerSubtitle != "Menu 3.0.15 · Hub 3.0.28" { failures.append("živá verze Hubu") }
    if commandDelegate.shiftStatusItem.view?.frame.height != 54 { failures.append("výška stavu") }
    if !statusLabels.contains("Intranet") { failures.append("dvouřádkový Intranet") }
    if systems?.submenu !== commandDelegate.evoraMenu { failures.append("přímé Systémy") }
    if systems?.submenu?.items.contains(where: { visibleMenuTitle($0) == "Home Assistant odkazy" }) != true { failures.append("Home Assistant") }
    if cameras?.submenu == nil || camera?.submenu?.items.first?.view == nil { failures.append("náhled kamery") }
    if !commandDelegate.evoraCameraMenuColor().isEqual(NSColor.systemPurple) { failures.append("fialové kamery") }
    if systems?.submenu?.items.contains(where: { visibleMenuTitle($0) == "Evora Smart Hub" }) == true { failures.append("nadbytečná mezisložka") }
    if (folder?.attributedTitle?.length ?? 0) == 0 { failures.append("barevná složka") }
    if (server?.attributedTitle?.length ?? 0) == 0 { failures.append("stav Miniserveru") }
    if flattenedSearch.foldersVisible != 0 || !flattenedSearch.serverTitles.contains(where: { $0.contains("Testovací projekt") }) {
        failures.append("přímé výsledky hledání Miniserverů")
    }
    if !summaryLabels.contains("Testovací projekt") { failures.append("detail projektu") }
    if !summaryLabels.contains(where: { $0.contains("Online · FW 16.0.0.0") }) { failures.append("detail firmware") }
    if !summaryLabels.contains("Prvky 11/12 · 1 offline") { failures.append("offline prvky") }
    if !summaryLabels.contains(where: { $0.contains("Health OK") && $0.contains("42 ms") }) { failures.append("diagnostika Miniserveru") }
    if menuItem(in: commandDelegate.menu, titled: "Dovolená a absence…") == nil { failures.append("nativní absence") }
    if dialogContexts.contains(where: { commandDelegate.contextualDialogIcon($0).size.width <= 0 }) { failures.append("ikony dialogů") }
    if let attributed = quitItem?.attributedTitle,
       attributed.length > 0,
       let color = attributed.attribute(.foregroundColor, at: attributed.length - 1, effectiveRange: nil) as? NSColor {
        if !color.isEqual(NSColor.systemRed) { failures.append("červené ukončení") }
    } else {
        failures.append("červené ukončení")
    }
    if !actionItemsHaveIcons(commandDelegate.menu) { failures.append("ikony akcí") }
    if !failures.isEmpty {
        fputs("Self-test struktury Evora Smart Menu selhal: \(failures.joined(separator: ", ")).\n", stderr)
        exit(1)
    }
    print("Struktura Evora Smart Menu 3.0.15 je v pořádku.")
    exit(0)
}

if commandLine.count == 5, commandLine[1] == "--test-intranet-parsers" {
    do {
        let attendanceData = try Data(contentsOf: URL(fileURLWithPath: commandLine[2]))
        let summaryData = try Data(contentsOf: URL(fileURLWithPath: commandLine[3]))
        let rosterData = try Data(contentsOf: URL(fileURLWithPath: commandLine[4]))
        let attendance = try JSONDecoder().decode(
            AppDelegate.IntranetAttendanceResponse.self,
            from: attendanceData
        )
        guard let summaryHTML = String(data: summaryData, encoding: .utf8),
              let rosterHTML = String(data: rosterData, encoding: .utf8),
              let roster = commandDelegate.parseIntranetRoster(
                  rosterHTML,
                  ownProfileId: attendance.hrProfileId
              )
        else { throw AppDelegate.IntranetServiceError(code: "parser", message: "Parser nezpracoval vstup.") }
        let summary = commandDelegate.parseIntranetSummary(summaryHTML)
        let states = Dictionary(grouping: roster.people, by: { $0.state }).mapValues(\.count)
        var employeeIds = Set<String>()
        var eventIds = Set<String>()
        var eventKinds: [String: Int] = [:]
        var eventKeys = Set<String>()
        var eventDatesParsed = 0
        var eventDatesToday = 0
        var debugCalendar = Calendar(identifier: .gregorian)
        debugCalendar.timeZone = TimeZone(identifier: "Europe/Prague") ?? .current
        for object in commandDelegate.nextFlightObjects(from: rosterHTML) {
            guard let root = commandDelegate.findIntranetDictionary(
                in: object,
                requiredKeys: ["employees", "events", "absences", "fetchedAt"]
            ) else { continue }
            for employee in root["employees"] as? [[String: Any]] ?? [] {
                if let id = employee["id"] as? String { employeeIds.insert(id) }
            }
            for event in root["events"] as? [[String: Any]] ?? [] {
                eventKeys.formUnion(event.keys)
                if let id = event["hr_profile_id"] as? String { eventIds.insert(id) }
                if let kind = event["kind"] as? String { eventKinds[kind, default: 0] += 1 }
                if let ts = event["ts"] as? String,
                   let date = commandDelegate.parseIntranetDate(ts) {
                    eventDatesParsed += 1
                    if debugCalendar.isDateInToday(date) { eventDatesToday += 1 }
                }
            }
        }
        let result: [String: Any] = [
            "attendance_events": attendance.events.count,
            "summary_keys": summary.cards.keys.sorted(),
            "roster_people": roster.people.count,
            "roster_states": states,
            "own_state_available": roster.ownState != nil,
            "roster_event_keys": eventKeys.sorted(),
            "roster_event_kinds": eventKinds,
            "roster_employee_ids": employeeIds.count,
            "roster_event_ids": eventIds.count,
            "roster_id_overlap": employeeIds.intersection(eventIds).count,
            "roster_dates_parsed": eventDatesParsed,
            "roster_dates_today": eventDatesToday
        ]
        let output = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
        print(String(data: output, encoding: .utf8) ?? "{}")
        exit(0)
    } catch {
        fputs("Test parseru selhal.\n", stderr)
        exit(1)
    }
}

let app = NSApplication.shared
let delegate = commandDelegate
app.delegate = delegate
app.setActivationPolicy(.accessory)
app.run()
