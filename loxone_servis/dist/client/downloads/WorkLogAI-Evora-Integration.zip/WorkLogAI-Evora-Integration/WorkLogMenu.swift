import Cocoa

final class AppDelegate: NSObject, NSApplicationDelegate, NSMenuDelegate, NSSearchFieldDelegate {

    struct IntranetAttendanceEvent: Codable {
        let id: String?
        let kind: String
        let source: String?
        let ts: String
    }

    struct IntranetAttendanceResponse: Decodable {
        let hrProfileId: String
        let greeting: String
        let uvazekH: Double
        let events: [IntranetAttendanceEvent]
    }

    struct IntranetPerson: Codable {
        let name: String
        let state: String
        let since: Double?
    }

    struct IntranetHistoryDay {
        let date: Date
        let events: [(event: IntranetAttendanceEvent, date: Date)]
        let arrival: Date?
        let departure: Date?
        let workedSeconds: Int
    }

    struct IntranetSnapshot: Codable {
        var dataState: String
        var fetchedAt: Double
        var summaryFetchedAt: Double
        var rosterFetchedAt: Double
        var currentState: String
        var currentSince: Double?
        var hrProfileId: String
        var todayWorkedSeconds: Int
        var lastArrival: Double?
        var lastDeparture: Double?
        var greeting: String
        var workloadHours: Double
        var cards: [String: String]
        var people: [IntranetPerson]
        var notificationsUnread: Int
        var historyFetchedAt: Double?
        var historyEvents: [IntranetAttendanceEvent]?
        var errorCode: String?
        var errorMessage: String?

        static var empty: IntranetSnapshot {
            IntranetSnapshot(
                dataState: "not_configured",
                fetchedAt: 0,
                summaryFetchedAt: 0,
                rosterFetchedAt: 0,
                currentState: "none",
                currentSince: nil,
                hrProfileId: "",
                todayWorkedSeconds: 0,
                lastArrival: nil,
                lastDeparture: nil,
                greeting: "",
                workloadHours: 0,
                cards: [:],
                people: [],
                notificationsUnread: 0,
                historyFetchedAt: nil,
                historyEvents: [],
                errorCode: nil,
                errorMessage: nil
            )
        }
    }

    struct IntranetServiceError: LocalizedError {
        let code: String
        let message: String

        var errorDescription: String? { message }
    }

    struct EvoraMiniServer: Decodable {
        let serial: String
        let project: String
        let type: String
        let folderName: String
        let connectionState: String
        let currentFirmware: String?
        let hasCredentials: Bool
        let loxoneAppAvailable: Bool
        let loxoneConfigAvailable: Bool
        let configVersion: String?
        let configDownloadUrl: String?
        let deviceImageUrl: String?
    }

    struct EvoraLauncherAgent: Decodable {
        let name: String
        let available: Bool
        let helperVersion: String?
        let requiredHelperVersion: String?
        let latestHelperVersion: String?
        let updateRequired: Bool?
        let updateAvailable: Bool?
    }

    struct EvoraFleetResponse: Decodable {
        let launcherAgent: EvoraLauncherAgent?
        let items: [EvoraMiniServer]
    }

    struct EvoraConfigJob: Decodable {
        let id: String
        let state: String
        let message: String
        let requiredVersion: String
        let configUrl: String?
    }

    struct EvoraActionResponse: Decodable {
        let action: String
        let url: String?
        let job: EvoraConfigJob?
    }

    struct EvoraJobResponse: Decodable {
        let job: EvoraConfigJob
    }

    struct EvoraPortalTicketSummary: Decodable {
        let id: String
        let ticketNumber: String
        let subject: String
        let status: String
        let createdTime: String
        let threadCount: Int
        let contactName: String
    }

    struct EvoraPortalTicketAttachment: Decodable {
        let id: String
        let name: String
        let token: String
        let downloadable: Bool?

        var canDownload: Bool { downloadable != false && !token.isEmpty }
    }

    struct EvoraPortalTicketAuthor: Decodable {
        let type: String
        let firstName: String
        let lastName: String
        let isLoxone: Bool
    }

    struct EvoraPortalTicketThread: Decodable {
        let id: String
        let createdTime: String
        let content: String
        let author: EvoraPortalTicketAuthor
        let attachments: [EvoraPortalTicketAttachment]
    }

    struct EvoraPortalTicketDetail: Decodable {
        let id: String
        let ticketNumber: String
        let subject: String
        let status: String
        let createdTime: String
        let threadCount: Int
        let contactName: String
        let threads: [EvoraPortalTicketThread]
        let attachments: [EvoraPortalTicketAttachment]
    }

    struct EvoraPortalTicketListResponse: Decodable {
        let items: [EvoraPortalTicketSummary]
    }

    struct EvoraPortalTicketDetailResponse: Decodable {
        let ticket: EvoraPortalTicketDetail
    }

    struct EvoraConfirmationResponse: Decodable {
        let confirmationId: String
        let expiresAt: String
    }

    struct EvoraPortalMutationResponse: Decodable {
        let ok: Bool
        let ticketId: String?
        let ticketNumber: String?
    }

    struct EvoraPortalDraft {
        let ticketId: String?
        let ticketNumber: String?
        let subject: String
        let body: String

        var isReply: Bool { ticketId != nil }
    }

    struct EvoraErrorResponse: Decodable {
        let error: String
        let code: String?
    }

    struct EvoraServiceError: LocalizedError {
        let message: String

        var errorDescription: String? {
            message
        }
    }

    var statusItem: NSStatusItem!
    private var clockTimer: Timer?
    private var refreshTimer: Timer?
    private var intranetTimer: Timer?

    var menu: NSMenu!
    var macStatusItem: NSMenuItem!
    var windowsStatusItem: NSMenuItem!
    var shiftStatusItem: NSMenuItem!

    var startAgentItem: NSMenuItem!
    var restartAgentItem: NSMenuItem!
    var stopAgentItem: NSMenuItem!
    var intranetOfficeItem: NSMenuItem!
    var intranetHomeItem: NSMenuItem!
    var intranetEndItem: NSMenuItem!
    var evoraMenu: NSMenu!
    var evoraStatusItem: NSMenuItem!
    var intranetMenu: NSMenu!

    private var evoraRefreshInFlight = false
    private var evoraTicketsRefreshInFlight = false
    private var evoraLastRefresh = Date.distantPast
    private var evoraServers: [EvoraMiniServer] = []
    private var evoraLauncherAgent: EvoraLauncherAgent?
    private var evoraTickets: [EvoraPortalTicketSummary] = []
    private var evoraTicketsStatus = "Tickety: načítám…"
    private var evoraStatus = "Kontroluji připojení…"
    private var evoraSearchQuery = ""
    private weak var evoraSearchField: NSSearchField?
    private var evoraFolderMenuItems: [(item: NSMenuItem, folder: String, servers: [(item: NSMenuItem, server: EvoraMiniServer)])] = []
    private weak var evoraNoResultsItem: NSMenuItem?
    private let evoraKeychainAlias = "evora-token"
    private var evoraTokenCache: String?
    private var evoraCredentialsLoaded = false
    private let evoraHubDefaultsKey = "EvoraSmartHubURL"
    private let defaultEvoraHubURL = "https://homeassistant-work.skunk-atria.ts.net:8443/api/loxone-servis"
    private lazy var evoraSession: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 30
        return URLSession(configuration: configuration)
    }()

    private var intranetSnapshot = IntranetSnapshot.empty
    private var intranetCredentialCache: [String: String] = [:]
    private var intranetCredentialsLoaded = false
    private var intranetRefreshInFlight = false
    private var intranetAccessToken = ""
    private var intranetRefreshToken = ""
    private var intranetCookieHeader = ""
    private var intranetTokenExpiresAt = Date.distantPast
    private var intranetRetryAfter = Date.distantPast
    private var intranetFailureCount = 0
    private let intranetBaseURL = "https://intranet.evora.cz"
    private let intranetSupabaseURL = "https://wknmzrjafskktgmkifux.supabase.co"
    private let intranetSupabaseKey = "sb_publishable_G7YKpiRaxEgGvuDxW6eemg_IG30Bw2F"
    private let intranetCookieName = "sb-wknmzrjafskktgmkifux-auth-token"
    private let intranetEmailAccount = "intranet-email"
    private let intranetPasswordAccount = "intranet-password"
    private lazy var intranetSession: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.timeoutIntervalForRequest = 25
        configuration.timeoutIntervalForResource = 40
        return URLSession(configuration: configuration)
    }()

    let home = FileManager.default.homeDirectoryForCurrentUser.path

    var runtimeRoot: String {
        "\(home)/Library/Application Support/WorkLogAI"
    }

    var workPath: String {
        "\(runtimeRoot)/bin/work"
    }

    var keychainHelperPath: String {
        "\(runtimeRoot)/bin/worklog-keychain-helper"
    }

    var intranetSnapshotPath: String {
        "\(runtimeRoot)/intranet_state.json"
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        statusItem = NSStatusBar.system.statusItem(
            withLength: NSStatusItem.variableLength
        )

        if let button = statusItem.button {
            button.toolTip = "WorkLog AI"
        }

        buildMenu()
        loadIntranetSnapshot()
        rebuildIntranetMenu()
        loadIntranetCredentialsAsync()
        loadEvoraTokenAsync()
        refreshAll()

        clockTimer = Timer(
            timeInterval: 1.0,
            target: self,
            selector: #selector(tickClock),
            userInfo: nil,
            repeats: true
        )

        if let clockTimer {
            RunLoop.main.add(clockTimer, forMode: .common)
        }

        refreshTimer = Timer(
            timeInterval: 5.0,
            target: self,
            selector: #selector(refreshAll),
            userInfo: nil,
            repeats: true
        )

        if let refreshTimer {
            RunLoop.main.add(refreshTimer, forMode: .common)
        }

        intranetTimer = Timer(
            timeInterval: 60.0,
            target: self,
            selector: #selector(refreshIntranetTimerFired),
            userInfo: nil,
            repeats: true
        )

        if let intranetTimer {
            RunLoop.main.add(intranetTimer, forMode: .common)
        }
    }

    private var refreshInFlight = false
    private var cachedAgent = false
    private var cachedWindows = "NIKDY"

    // MARK: - Work CLI

    func runWork(_ args: [String]) -> String {
        let process = Process()
        let pipe = Pipe()

        process.executableURL = URL(fileURLWithPath: workPath)
        process.arguments = args
        process.standardOutput = pipe
        process.standardError = pipe

        do {
            try process.run()
            process.waitUntilExit()

            let data = pipe.fileHandleForReading.readDataToEndOfFile()

            return String(
                data: data,
                encoding: .utf8
            ) ?? ""

        } catch {
            return "CHYBA: \(error.localizedDescription)"
        }
    }

    func quick() -> [String: Any] {
        let out = runWork(["rychle"])

        guard
            let data = out.data(using: .utf8),
            let json = try? JSONSerialization.jsonObject(
                with: data
            ) as? [String: Any]
        else {
            return [:]
        }

        return json
    }

    // MARK: - Evora Intranet

    func runKeychainHelper(
        _ command: String,
        alias: String,
        input: String? = nil
    ) -> (success: Bool, output: String) {
        let process = Process()
        let outputPipe = Pipe()
        let inputPipe = Pipe()
        process.executableURL = URL(fileURLWithPath: keychainHelperPath)
        process.arguments = [command, alias]
        process.standardOutput = outputPipe
        process.standardError = FileHandle.nullDevice
        if input != nil { process.standardInput = inputPipe }
        do {
            try process.run()
            if let input {
                inputPipe.fileHandleForWriting.write(Data(input.utf8))
                inputPipe.fileHandleForWriting.closeFile()
            }
            process.waitUntilExit()
            let data = outputPipe.fileHandleForReading.readDataToEndOfFile()
            let value = String(data: data, encoding: .utf8) ?? ""
            return (process.terminationStatus == 0, value)
        } catch {
            return (false, "")
        }
    }

    func readKeychainValue(alias: String) -> String? {
        let result = runKeychainHelper("read", alias: alias)
        return result.success && !result.output.isEmpty ? result.output : nil
    }

    func intranetCredential(_ account: String) -> String? {
        intranetCredentialCache[account]
    }

    func loadIntranetCredentialsAsync() {
        DispatchQueue.global(qos: .utility).async { [weak self] in
            guard let self else { return }
            let email = self.readKeychainValue(alias: self.intranetEmailAccount)
            let password = self.readKeychainValue(alias: self.intranetPasswordAccount)
            DispatchQueue.main.async {
                self.intranetCredentialCache.removeAll()
                if let email { self.intranetCredentialCache[self.intranetEmailAccount] = email }
                if let password { self.intranetCredentialCache[self.intranetPasswordAccount] = password }
                self.intranetCredentialsLoaded = true
                self.rebuildIntranetMenu()
                self.refreshIntranet(forceAll: true)
            }
        }
    }

    @discardableResult
    func saveIntranetCredential(_ value: String, account: String) -> Bool {
        let saved = runKeychainHelper("store", alias: account, input: value).success
        if saved {
            intranetCredentialCache[account] = value
            intranetCredentialsLoaded = true
        }
        return saved
    }

    @discardableResult
    func storeIntranetCredentials(email: String, password: String) -> Bool {
        guard saveIntranetCredential(email, account: intranetEmailAccount),
              saveIntranetCredential(password, account: intranetPasswordAccount)
        else {
            deleteIntranetCredentials()
            return false
        }
        return true
    }

    func deleteIntranetCredentials() {
        for account in [intranetEmailAccount, intranetPasswordAccount] {
            _ = runKeychainHelper("delete", alias: account)
        }
        intranetCredentialCache.removeAll()
        intranetCredentialsLoaded = true
        intranetAccessToken = ""
        intranetRefreshToken = ""
        intranetCookieHeader = ""
        intranetTokenExpiresAt = .distantPast
        intranetRetryAfter = .distantPast
        intranetFailureCount = 0
    }

    func hasIntranetCredentials() -> Bool {
        intranetCredential(intranetEmailAccount) != nil
            && intranetCredential(intranetPasswordAccount) != nil
    }

    func intranetBase64URL(_ data: Data) -> String {
        data.base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }

    func intranetCookieHeader(for sessionObject: [String: Any]) throws -> String {
        let compact = try JSONSerialization.data(withJSONObject: sessionObject)
        let value = "base64-\(intranetBase64URL(compact))"
        let characters = Array(value)
        let chunkSize = 3_180
        guard characters.count > chunkSize else {
            return "\(intranetCookieName)=\(value)"
        }
        var parts: [String] = []
        var offset = 0
        var index = 0
        while offset < characters.count {
            let end = min(offset + chunkSize, characters.count)
            parts.append("\(intranetCookieName).\(index)=\(String(characters[offset..<end]))")
            offset = end
            index += 1
        }
        return parts.joined(separator: "; ")
    }

    func applyIntranetSessionObject(_ object: [String: Any]) throws {
        guard
            let token = object["access_token"] as? String,
            !token.isEmpty
        else {
            throw IntranetServiceError(
                code: "internal_error",
                message: "Přihlášení neobsahuje přístupovou relaci."
            )
        }
        let expiresAt: Double
        if let value = object["expires_at"] as? Double {
            expiresAt = value
        } else if let value = object["expires_at"] as? Int {
            expiresAt = Double(value)
        } else {
            let expiresIn = (object["expires_in"] as? Double)
                ?? Double(object["expires_in"] as? Int ?? 3_600)
            expiresAt = Date().timeIntervalSince1970 + expiresIn
        }
        intranetAccessToken = token
        if let refreshToken = object["refresh_token"] as? String,
           !refreshToken.isEmpty {
            intranetRefreshToken = refreshToken
        }
        intranetCookieHeader = try intranetCookieHeader(for: object)
        intranetTokenExpiresAt = Date(timeIntervalSince1970: expiresAt)
    }

    func authenticateIntranet(
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        guard
            let email = intranetCredential(intranetEmailAccount),
            let password = intranetCredential(intranetPasswordAccount)
        else {
            completion(.failure(IntranetServiceError(
                code: "not_configured",
                message: "Připojení k Evora Intranetu není nastavené."
            )))
            return
        }
        guard let url = URL(string: "\(intranetSupabaseURL)/auth/v1/token?grant_type=password") else {
            completion(.failure(IntranetServiceError(code: "internal_error", message: "Neplatná adresa přihlášení.")))
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue(intranetSupabaseKey, forHTTPHeaderField: "apikey")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.httpBody = try? JSONSerialization.data(withJSONObject: [
            "email": email,
            "password": password
        ])
        intranetSession.dataTask(with: request) { [weak self] data, response, error in
            guard let self else { return }
            if error != nil {
                completion(.failure(IntranetServiceError(
                    code: "unavailable",
                    message: "Evora Intranet není dostupný."
                )))
                return
            }
            guard let http = response as? HTTPURLResponse else {
                completion(.failure(IntranetServiceError(code: "internal_error", message: "Přihlášení nevrátilo platnou odpověď.")))
                return
            }
            guard (200..<300).contains(http.statusCode), let data else {
                let code = [400, 401, 403].contains(http.statusCode) ? "auth_denied" : "unavailable"
                let message = code == "auth_denied"
                    ? "Evora Intranet odmítl e-mail nebo heslo."
                    : "Přihlášení k Evora Intranetu se nezdařilo."
                completion(.failure(IntranetServiceError(code: code, message: message)))
                return
            }
            do {
                guard let object = try JSONSerialization.jsonObject(with: data) as? [String: Any]
                else {
                    throw IntranetServiceError(code: "internal_error", message: "Přihlašovací relaci nelze zpracovat.")
                }
                try self.applyIntranetSessionObject(object)
                completion(.success(()))
            } catch let serviceError as IntranetServiceError {
                completion(.failure(serviceError))
            } catch {
                completion(.failure(IntranetServiceError(code: "internal_error", message: "Přihlašovací relaci nelze zpracovat.")))
            }
        }.resume()
    }

    func refreshIntranetSession(
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        guard !intranetRefreshToken.isEmpty else {
            authenticateIntranet(completion: completion)
            return
        }
        guard let url = URL(string: "\(intranetSupabaseURL)/auth/v1/token?grant_type=refresh_token") else {
            completion(.failure(IntranetServiceError(code: "internal_error", message: "Neplatná adresa obnovení přihlášení.")))
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue(intranetSupabaseKey, forHTTPHeaderField: "apikey")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.httpBody = try? JSONSerialization.data(withJSONObject: [
            "refresh_token": intranetRefreshToken
        ])
        intranetSession.dataTask(with: request) { [weak self] data, response, error in
            guard let self else { return }
            if error != nil {
                completion(.failure(IntranetServiceError(code: "unavailable", message: "Evora Intranet není dostupný.")))
                return
            }
            guard let http = response as? HTTPURLResponse else {
                completion(.failure(IntranetServiceError(code: "internal_error", message: "Obnovení přihlášení nevrátilo platnou odpověď.")))
                return
            }
            guard (200..<300).contains(http.statusCode), let data else {
                if [400, 401, 403].contains(http.statusCode) {
                    self.intranetRefreshToken = ""
                    self.authenticateIntranet(completion: completion)
                } else {
                    completion(.failure(IntranetServiceError(code: "unavailable", message: "Přihlášení se nepodařilo obnovit.")))
                }
                return
            }
            do {
                guard let object = try JSONSerialization.jsonObject(with: data) as? [String: Any]
                else {
                    throw IntranetServiceError(code: "internal_error", message: "Obnovenou relaci nelze zpracovat.")
                }
                try self.applyIntranetSessionObject(object)
                completion(.success(()))
            } catch let serviceError as IntranetServiceError {
                completion(.failure(serviceError))
            } catch {
                completion(.failure(IntranetServiceError(code: "internal_error", message: "Obnovenou relaci nelze zpracovat.")))
            }
        }.resume()
    }

    func ensureIntranetSession(
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        if !intranetCookieHeader.isEmpty,
           intranetTokenExpiresAt.timeIntervalSinceNow > 45 {
            completion(.success(()))
            return
        }
        refreshIntranetSession(completion: completion)
    }

    func intranetRequest(
        path: String,
        method: String = "GET",
        body: [String: Any]? = nil,
        retryAuthentication: Bool = true,
        completion: @escaping (Result<Data, Error>) -> Void
    ) {
        ensureIntranetSession { [weak self] sessionResult in
            guard let self else { return }
            switch sessionResult {
            case .failure(let error):
                completion(.failure(error))
            case .success:
                guard let url = URL(string: "\(self.intranetBaseURL)\(path)") else {
                    completion(.failure(IntranetServiceError(code: "internal_error", message: "Neplatná adresa Evora Intranetu.")))
                    return
                }
                var request = URLRequest(url: url)
                request.httpMethod = method
                request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
                request.setValue(self.intranetCookieHeader, forHTTPHeaderField: "Cookie")
                request.setValue("application/json, text/html", forHTTPHeaderField: "Accept")
                if let body {
                    request.httpBody = try? JSONSerialization.data(withJSONObject: body)
                    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                }
                self.intranetSession.dataTask(with: request) { data, response, error in
                    if error != nil {
                        completion(.failure(IntranetServiceError(code: "unavailable", message: "Evora Intranet není dostupný.")))
                        return
                    }
                    guard let http = response as? HTTPURLResponse else {
                        completion(.failure(IntranetServiceError(code: "internal_error", message: "Evora Intranet nevrátil platnou odpověď.")))
                        return
                    }
                    let redirectedToLogin = http.url?.path == "/login"
                    if (http.statusCode == 401 || redirectedToLogin), retryAuthentication {
                        self.intranetAccessToken = ""
                        self.intranetCookieHeader = ""
                        self.intranetTokenExpiresAt = .distantPast
                        self.intranetRequest(
                            path: path,
                            method: method,
                            body: body,
                            retryAuthentication: false,
                            completion: completion
                        )
                        return
                    }
                    if http.statusCode == 403 {
                        completion(.failure(IntranetServiceError(code: "permission_denied", message: "Účet nemá k této části Evora Intranetu oprávnění.")))
                        return
                    }
                    guard (200..<300).contains(http.statusCode), !redirectedToLogin else {
                        completion(.failure(IntranetServiceError(
                            code: redirectedToLogin ? "auth_denied" : "source_unavailable",
                            message: redirectedToLogin
                                ? "Přihlášení k Evora Intranetu už neplatí."
                                : "Evora Intranet požadovaná data neposkytl."
                        )))
                        return
                    }
                    completion(.success(data ?? Data()))
                }.resume()
            }
        }
    }

    func parseIntranetDate(_ value: String) -> Date? {
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = fractional.date(from: value) { return date }
        return ISO8601DateFormatter().date(from: value)
    }

    func intranetStateLabel(_ state: String) -> String {
        switch state {
        case "in_building": return "V práci"
        case "home_office": return "Home office"
        case "on_break": return "Na přestávce"
        case "doctor": return "U lékaře"
        case "offsite": return "Služebně mimo"
        case "vacation": return "Dovolená"
        case "sick": return "Omluvená absence"
        case "away": return "Po pracovní době"
        default: return "Bez záznamu"
        }
    }

    func intranetDataStateLabel(_ state: String) -> String {
        switch state {
        case "loading": return "Načítám"
        case "current": return "Aktuální"
        case "stale": return "Zastaralá data"
        case "auth_denied": return "Přihlášení odmítnuto"
        case "permission_denied": return "Bez oprávnění"
        case "not_configured": return "Není nastaven přístup"
        case "source_unavailable": return "Zdroj údaj neposkytuje"
        case "unavailable": return "Intranet neodpovídá"
        default: return "Interní chyba WorkLogAI"
        }
    }

    func deriveIntranetAttendance(
        events: [IntranetAttendanceEvent],
        now: Date = Date()
    ) -> (state: String, since: Double?, worked: Int, arrival: Double?, departure: Double?) {
        var calendar = Calendar(identifier: .gregorian)
        calendar.timeZone = TimeZone(identifier: "Europe/Prague") ?? .current
        let parsed = events.compactMap { event -> (IntranetAttendanceEvent, Date)? in
            guard let date = parseIntranetDate(event.ts), date <= now else { return nil }
            return (event, date)
        }.sorted { $0.1 < $1.1 }

        var baseState = "none"
        var baseSince: Date?
        var temporaryState: String?
        var temporarySince: Date?
        var activeStart: Date?
        var worked: TimeInterval = 0
        var lastArrival: Date?
        var lastDeparture: Date?

        for (event, date) in parsed where calendar.isDate(date, inSameDayAs: now) {
            switch event.kind {
            case "arrival":
                baseState = "in_building"
                baseSince = date
                temporaryState = nil
                temporarySince = nil
                if activeStart == nil { activeStart = date }
                lastArrival = date
            case "home_start":
                baseState = "home_office"
                baseSince = date
                temporaryState = nil
                temporarySince = nil
                if activeStart == nil { activeStart = date }
                lastArrival = date
            case "break_out":
                if let start = activeStart { worked += max(0, date.timeIntervalSince(start)) }
                activeStart = nil
                temporaryState = "on_break"
                temporarySince = date
            case "doctor_out":
                if let start = activeStart { worked += max(0, date.timeIntervalSince(start)) }
                activeStart = nil
                temporaryState = "doctor"
                temporarySince = date
            case "offsite_out":
                temporaryState = "offsite"
                temporarySince = date
                if activeStart == nil { activeStart = date }
            case "break_in", "doctor_in":
                temporaryState = nil
                temporarySince = nil
                if baseState == "none" {
                    baseState = "in_building"
                    baseSince = date
                }
                if activeStart == nil { activeStart = date }
            case "offsite_in":
                temporaryState = nil
                temporarySince = nil
                if baseState == "none" {
                    baseState = "in_building"
                    baseSince = date
                }
                if activeStart == nil { activeStart = date }
            case "departure", "home_end":
                if let start = activeStart { worked += max(0, date.timeIntervalSince(start)) }
                activeStart = nil
                temporaryState = nil
                temporarySince = nil
                baseState = "away"
                baseSince = date
                lastDeparture = date
            default:
                break
            }
        }
        if let start = activeStart {
            worked += max(0, now.timeIntervalSince(start))
        }
        return (
            temporaryState ?? baseState,
            (temporarySince ?? baseSince)?.timeIntervalSince1970,
            max(0, Int(worked)),
            lastArrival?.timeIntervalSince1970,
            lastDeparture?.timeIntervalSince1970
        )
    }

    func intranetCalendar() -> Calendar {
        var calendar = Calendar(identifier: .gregorian)
        calendar.locale = Locale(identifier: "cs_CZ")
        calendar.timeZone = TimeZone(identifier: "Europe/Prague") ?? .current
        return calendar
    }

    func intranetMonthStart(offset: Int = 0, from date: Date = Date()) -> Date {
        let calendar = intranetCalendar()
        let components = calendar.dateComponents([.year, .month], from: date)
        let start = calendar.date(from: components) ?? calendar.startOfDay(for: date)
        return calendar.date(byAdding: .month, value: offset, to: start) ?? start
    }

    func intranetMonthKey(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "cs_CZ")
        formatter.timeZone = intranetCalendar().timeZone
        formatter.dateFormat = "yyyy-MM"
        return formatter.string(from: date)
    }

    func intranetMonthTitle(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "cs_CZ")
        formatter.timeZone = intranetCalendar().timeZone
        formatter.dateFormat = "LLLL yyyy"
        return formatter.string(from: date).prefix(1).uppercased()
            + formatter.string(from: date).dropFirst()
    }

    func intranetDayTitle(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "cs_CZ")
        formatter.timeZone = intranetCalendar().timeZone
        formatter.dateFormat = "EEE d. M."
        return formatter.string(from: date)
    }

    func mergeIntranetHistory(
        existing: [IntranetAttendanceEvent],
        incoming: [IntranetAttendanceEvent],
        now: Date = Date()
    ) -> [IntranetAttendanceEvent] {
        var merged: [String: IntranetAttendanceEvent] = [:]
        for event in existing + incoming {
            let key = "\(event.kind)|\(event.ts)"
            merged[key] = IntranetAttendanceEvent(
                id: nil,
                kind: event.kind,
                source: nil,
                ts: event.ts
            )
        }
        let start = intranetMonthStart(offset: -1, from: now)
        let end = intranetMonthStart(offset: 1, from: now)
        return merged.values.filter { event in
            guard let date = parseIntranetDate(event.ts) else { return false }
            return date >= start && date < end
        }.sorted {
            (parseIntranetDate($0.ts) ?? .distantPast)
                < (parseIntranetDate($1.ts) ?? .distantPast)
        }
    }

    func collectIntranetHistoryEvents(
        from value: Any,
        ownProfileId: String,
        output: inout [IntranetAttendanceEvent]
    ) {
        if let dictionary = value as? [String: Any] {
            if let kind = dictionary["kind"] as? String,
               let ts = dictionary["ts"] as? String,
               parseIntranetDate(ts) != nil {
                let profileId = dictionary["hr_profile_id"] as? String
                if profileId == nil || ownProfileId.isEmpty || profileId == ownProfileId {
                    output.append(IntranetAttendanceEvent(
                        id: dictionary["id"] as? String,
                        kind: kind,
                        source: dictionary["source"] as? String,
                        ts: ts
                    ))
                }
            }
            for child in dictionary.values {
                collectIntranetHistoryEvents(
                    from: child,
                    ownProfileId: ownProfileId,
                    output: &output
                )
            }
        } else if let array = value as? [Any] {
            for child in array {
                collectIntranetHistoryEvents(
                    from: child,
                    ownProfileId: ownProfileId,
                    output: &output
                )
            }
        }
    }

    func parseIntranetHistory(
        _ html: String,
        ownProfileId: String
    ) -> [IntranetAttendanceEvent] {
        var events: [IntranetAttendanceEvent] = []
        for object in nextFlightObjects(from: html) {
            collectIntranetHistoryEvents(
                from: object,
                ownProfileId: ownProfileId,
                output: &events
            )
        }
        return mergeIntranetHistory(existing: [], incoming: events)
    }

    func intranetHistoryDays(
        monthStart: Date,
        events: [IntranetAttendanceEvent],
        now: Date = Date()
    ) -> [IntranetHistoryDay] {
        let calendar = intranetCalendar()
        let monthEnd = calendar.date(byAdding: .month, value: 1, to: monthStart)
            ?? monthStart.addingTimeInterval(32 * 86_400)
        let parsed = events.compactMap { event -> (IntranetAttendanceEvent, Date)? in
            guard let date = parseIntranetDate(event.ts),
                  date >= monthStart,
                  date < monthEnd,
                  date <= now
            else { return nil }
            return (event, date)
        }
        let grouped = Dictionary(grouping: parsed) { calendar.startOfDay(for: $0.1) }

        return grouped.keys.sorted(by: >).map { day in
            let dayEvents = (grouped[day] ?? []).sorted { $0.1 < $1.1 }
            var activeStart: Date?
            var worked: TimeInterval = 0
            var arrival: Date?
            var departure: Date?

            for (event, date) in dayEvents {
                switch event.kind {
                case "arrival", "home_start":
                    if arrival == nil { arrival = date }
                    if activeStart == nil { activeStart = date }
                case "break_out", "doctor_out":
                    if let start = activeStart {
                        worked += max(0, date.timeIntervalSince(start))
                    }
                    activeStart = nil
                case "break_in", "doctor_in", "offsite_in":
                    if activeStart == nil { activeStart = date }
                case "offsite_out":
                    if activeStart == nil { activeStart = date }
                case "departure", "home_end":
                    if let start = activeStart {
                        worked += max(0, date.timeIntervalSince(start))
                    }
                    activeStart = nil
                    departure = date
                default:
                    break
                }
            }
            if calendar.isDate(day, inSameDayAs: now), let start = activeStart {
                worked += max(0, now.timeIntervalSince(start))
            }
            return IntranetHistoryDay(
                date: day,
                events: dayEvents.map { (event: $0.0, date: $0.1) },
                arrival: arrival,
                departure: departure,
                workedSeconds: max(0, Int(worked))
            )
        }
    }

    func nextFlightObjects(from html: String) -> [Any] {
        guard let regex = try? NSRegularExpression(
            pattern: #"self\.__next_f\.push\((\[.*?\])\)</script>"#,
            options: [.dotMatchesLineSeparators]
        ) else { return [] }
        let ns = html as NSString
        var payload = ""
        for match in regex.matches(in: html, range: NSRange(location: 0, length: ns.length)) {
            guard match.numberOfRanges > 1,
                  let range = Range(match.range(at: 1), in: html),
                  let data = String(html[range]).data(using: .utf8),
                  let array = try? JSONSerialization.jsonObject(with: data) as? [Any],
                  array.count > 1,
                  (array[0] as? Int) == 1,
                  let part = array[1] as? String
            else { continue }
            payload += part
        }
        var objects: [Any] = []
        for line in payload.split(separator: "\n", omittingEmptySubsequences: true) {
            guard let colon = line.firstIndex(of: ":") else { continue }
            let raw = line[line.index(after: colon)...]
            guard let data = String(raw).data(using: .utf8),
                  let object = try? JSONSerialization.jsonObject(with: data)
            else { continue }
            objects.append(object)
        }
        return objects
    }

    func findIntranetDictionary(
        in value: Any,
        requiredKeys: Set<String>
    ) -> [String: Any]? {
        if let dictionary = value as? [String: Any] {
            if requiredKeys.isSubset(of: Set(dictionary.keys)) { return dictionary }
            for child in dictionary.values {
                if let found = findIntranetDictionary(in: child, requiredKeys: requiredKeys) {
                    return found
                }
            }
        } else if let array = value as? [Any] {
            for child in array {
                if let found = findIntranetDictionary(in: child, requiredKeys: requiredKeys) {
                    return found
                }
            }
        }
        return nil
    }

    func cleanIntranetHTML(_ value: String) -> String {
        var text = value.replacingOccurrences(
            of: #"<!--.*?-->"#,
            with: "",
            options: .regularExpression
        )
        text = text.replacingOccurrences(
            of: #"<[^>]+>"#,
            with: "",
            options: .regularExpression
        )
        guard let data = ("<span>\(text)</span>").data(using: .utf8),
              let attributed = try? NSAttributedString(
                data: data,
                options: [.documentType: NSAttributedString.DocumentType.html,
                          .characterEncoding: String.Encoding.utf8.rawValue],
                documentAttributes: nil
              )
        else { return text.trimmingCharacters(in: .whitespacesAndNewlines) }
        return attributed.string.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    func intranetCardValue(label: String, html: String) -> String? {
        let escaped = NSRegularExpression.escapedPattern(for: label)
        let pattern = #"<div class="text-xs text-muted">"# + escaped
            + #"</div>\s*<div class="text-lg[^"]*">(.*?)</div>"#
        guard let regex = try? NSRegularExpression(
            pattern: pattern,
            options: [.dotMatchesLineSeparators]
        ) else { return nil }
        let ns = html as NSString
        guard let match = regex.firstMatch(
            in: html,
            range: NSRange(location: 0, length: ns.length)
        ), match.numberOfRanges > 1,
        let range = Range(match.range(at: 1), in: html)
        else { return nil }
        let value = cleanIntranetHTML(String(html[range]))
        return value.isEmpty ? nil : value
    }

    func parseIntranetSummary(_ html: String) -> (cards: [String: String], workload: Double) {
        let labels: [(String, String)] = [
            ("workload", "Úvazek"),
            ("worked_month", "Odpracováno (měsíc)"),
            ("balance_month", "Saldo (měsíc)"),
            ("overtime_ordered", "Přesčas (nařízený)"),
            ("vacation_remaining", "Dovolená – zbývá"),
            ("sickday_remaining", "Sickday – zbývá")
        ]
        var cards: [String: String] = [:]
        for (key, label) in labels {
            if let value = intranetCardValue(label: label, html: html) {
                cards[key] = value
            }
        }
        let normalized = (cards["workload"] ?? "")
            .replacingOccurrences(of: ",", with: ".")
        let workload = normalized.range(of: #"[0-9]+(?:\.[0-9]+)?"#, options: .regularExpression)
            .flatMap { Double(normalized[$0]) } ?? 0
        return (cards, workload)
    }

    func parseIntranetRoster(
        _ html: String,
        ownProfileId: String,
        now: Date = Date()
    ) -> (people: [IntranetPerson], ownState: String?)? {
        var root: [String: Any]?
        for object in nextFlightObjects(from: html) where root == nil {
            root = findIntranetDictionary(
                in: object,
                requiredKeys: ["employees", "events", "absences", "fetchedAt"]
            )
        }
        guard let root,
              let employees = root["employees"] as? [[String: Any]],
              let rawEvents = root["events"] as? [[String: Any]]
        else { return nil }
        let rawAbsences = root["absences"] as? [[String: Any]] ?? []
        var eventsByPerson: [String: [IntranetAttendanceEvent]] = [:]
        for value in rawEvents {
            guard let personId = value["hr_profile_id"] as? String,
                  let kind = value["kind"] as? String,
                  let ts = value["ts"] as? String
            else { continue }
            let date = parseIntranetDate(ts)
            if let date, now.timeIntervalSince(date) > 86_400 { continue }
            eventsByPerson[personId, default: []].append(IntranetAttendanceEvent(
                id: value["id"] as? String,
                kind: kind,
                source: value["source"] as? String,
                ts: ts
            ))
        }
        var absencesByPerson: [String: String] = [:]
        for value in rawAbsences {
            guard let personId = value["hr_profile_id"] as? String,
                  let type = value["type"] as? String,
                  let status = value["status"] as? String,
                  ["approved", "auto_approved", "announced"].contains(status)
            else { continue }
            if type == "vacation" {
                absencesByPerson[personId] = "vacation"
            } else if type == "sick" || type == "sickday" {
                absencesByPerson[personId] = "sick"
            } else if type == "home_office" {
                absencesByPerson[personId] = "home_office"
            }
        }
        let activeStates: Set<String> = ["in_building", "home_office", "on_break", "doctor", "offsite"]
        let people = employees.compactMap { employee -> IntranetPerson? in
            guard let id = employee["id"] as? String,
                  let name = employee["name"] as? String,
                  !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            else { return nil }
            let derived = deriveIntranetAttendance(events: eventsByPerson[id] ?? [], now: now)
            let state = activeStates.contains(derived.state)
                ? derived.state
                : (absencesByPerson[id] ?? derived.state)
            return IntranetPerson(name: name, state: state, since: derived.since)
        }.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        let ownState: String?
        if ownProfileId.isEmpty {
            ownState = nil
        } else {
            let ownEvents = eventsByPerson[ownProfileId] ?? []
            let ownDerived = deriveIntranetAttendance(events: ownEvents, now: now)
            ownState = activeStates.contains(ownDerived.state)
                ? ownDerived.state
                : (absencesByPerson[ownProfileId] ?? ownDerived.state)
        }
        return (people, ownState)
    }

    func loadIntranetSnapshot() {
        let url = URL(fileURLWithPath: intranetSnapshotPath)
        guard let data = try? Data(contentsOf: url),
              var snapshot = try? JSONDecoder().decode(IntranetSnapshot.self, from: data)
        else { return }
        if snapshot.fetchedAt > 0,
           Date().timeIntervalSince1970 - snapshot.fetchedAt > 150 {
            snapshot.dataState = "stale"
        }
        intranetSnapshot = snapshot
    }

    func saveIntranetSnapshot() {
        let url = URL(fileURLWithPath: intranetSnapshotPath)
        do {
            try FileManager.default.createDirectory(
                at: url.deletingLastPathComponent(),
                withIntermediateDirectories: true
            )
            let data = try JSONEncoder().encode(intranetSnapshot)
            try data.write(to: url, options: .atomic)
            try FileManager.default.setAttributes(
                [.posixPermissions: 0o600],
                ofItemAtPath: url.path
            )
        } catch {
            // Cache neobsahuje přihlašovací údaje; selhání zápisu se ukáže
            // jako interní chyba při příští obnově, ne do systémového logu.
        }
    }

    func applyIntranetError(_ error: Error) {
        let serviceError = error as? IntranetServiceError
        let code = serviceError?.code ?? "internal_error"
        let now = Date().timeIntervalSince1970
        intranetFailureCount += 1
        let retryDelay: TimeInterval
        switch code {
        case "auth_denied", "permission_denied":
            retryDelay = 15 * 60
        case "unavailable":
            retryDelay = min(15 * 60, 60 * pow(2, Double(min(intranetFailureCount - 1, 4))))
        default:
            retryDelay = 5 * 60
        }
        intranetRetryAfter = Date(timeIntervalSinceNow: retryDelay)
        intranetSnapshot.dataState = code
        intranetSnapshot.errorCode = code
        intranetSnapshot.errorMessage = serviceError?.message ?? "Interní chyba WorkLogAI."
        if intranetSnapshot.fetchedAt == 0 || now - intranetSnapshot.fetchedAt > 300 {
            _ = runWork(["intranet-sync", "off"])
        }
        saveIntranetSnapshot()
        rebuildIntranetMenu()
        applyIntranetStatusToUI()
    }

    func syncWorkLogCollectionFromIntranet() {
        let age = Date().timeIntervalSince1970 - intranetSnapshot.fetchedAt
        let desired: String
        if intranetSnapshot.dataState != "current" || age > 300 {
            desired = "off"
        } else if intranetSnapshot.currentState == "in_building" {
            desired = "office"
        } else if intranetSnapshot.currentState == "home_office" {
            desired = "homeoffice"
        } else {
            desired = "off"
        }
        _ = runWork(["intranet-sync", desired])
    }

    func parseIntranetUnreadNotifications(_ data: Data) -> Int? {
        guard let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
        else { return nil }
        if let value = object["unread"] as? Int { return max(0, value) }
        if let value = object["unread"] as? NSNumber { return max(0, value.intValue) }
        return nil
    }

    @objc func refreshIntranetTimerFired() {
        refreshIntranet(forceAll: false)
    }

    @objc func refreshIntranetNow() {
        refreshIntranet(forceAll: true)
    }

    func refreshIntranet(forceAll: Bool) {
        guard !intranetRefreshInFlight else { return }
        guard intranetCredentialsLoaded else { return }
        guard forceAll || Date() >= intranetRetryAfter else {
            if intranetSnapshot.fetchedAt > 0,
               Date().timeIntervalSince1970 - intranetSnapshot.fetchedAt > 150,
               intranetSnapshot.dataState == "current" {
                intranetSnapshot.dataState = "stale"
                saveIntranetSnapshot()
                rebuildIntranetMenu()
                applyIntranetStatusToUI()
            }
            return
        }
        guard hasIntranetCredentials() else {
            intranetSnapshot = .empty
            saveIntranetSnapshot()
            _ = runWork(["intranet-sync", "off"])
            rebuildIntranetMenu()
            applyIntranetStatusToUI()
            return
        }
        intranetRefreshInFlight = true
        if intranetSnapshot.fetchedAt == 0 {
            intranetSnapshot.dataState = "loading"
            rebuildIntranetMenu()
        }
        intranetRequest(path: "/api/attendance/me", method: "POST") { [weak self] result in
            guard let self else { return }
            switch result {
            case .failure(let error):
                DispatchQueue.main.async {
                    self.intranetRefreshInFlight = false
                    self.applyIntranetError(error)
                }
            case .success(let data):
                do {
                    let response = try JSONDecoder().decode(IntranetAttendanceResponse.self, from: data)
                    let now = Date()
                    let derived = self.deriveIntranetAttendance(events: response.events, now: now)
                    var updated = self.intranetSnapshot
                    updated.dataState = "current"
                    updated.fetchedAt = now.timeIntervalSince1970
                    updated.currentState = derived.state
                    updated.currentSince = derived.since
                    updated.hrProfileId = response.hrProfileId
                    updated.todayWorkedSeconds = derived.worked
                    updated.lastArrival = derived.arrival
                    updated.lastDeparture = derived.departure
                    updated.greeting = response.greeting
                    updated.workloadHours = response.uvazekH
                    updated.errorCode = nil
                    updated.errorMessage = nil

                    let summaryDue = forceAll || now.timeIntervalSince1970 - updated.summaryFetchedAt > 600
                    let rosterDue = forceAll || now.timeIntervalSince1970 - updated.rosterFetchedAt > 300
                    let historyDue = forceAll
                        || now.timeIntervalSince1970 - (updated.historyFetchedAt ?? 0) > 600
                    updated.historyEvents = self.mergeIntranetHistory(
                        existing: updated.historyEvents ?? [],
                        incoming: response.events,
                        now: now
                    )
                    if !response.events.isEmpty {
                        updated.historyFetchedAt = now.timeIntervalSince1970
                    }

                    let finish: (IntranetSnapshot) -> Void = { finalSnapshot in
                        DispatchQueue.main.async {
                            self.intranetSnapshot = finalSnapshot
                            self.intranetRefreshInFlight = false
                            self.intranetFailureCount = 0
                            self.intranetRetryAfter = .distantPast
                            self.saveIntranetSnapshot()
                            self.syncWorkLogCollectionFromIntranet()
                            self.rebuildIntranetMenu()
                            self.applyIntranetStatusToUI()
                        }
                    }

                    let loadNotifications: (IntranetSnapshot) -> Void = { snapshotAfterRoster in
                        self.intranetRequest(path: "/api/notifications") { notificationsResult in
                            var finalSnapshot = snapshotAfterRoster
                            if case .success(let notificationsData) = notificationsResult,
                               let unread = self.parseIntranetUnreadNotifications(notificationsData) {
                                finalSnapshot.notificationsUnread = unread
                            }
                            finish(finalSnapshot)
                        }
                    }

                    let loadRoster: (IntranetSnapshot) -> Void = { snapshotAfterSummary in
                        guard rosterDue else { finish(snapshotAfterSummary); return }
                        self.intranetRequest(path: "/nastenka") { rosterResult in
                            var finalSnapshot = snapshotAfterSummary
                            if case .success(let rosterData) = rosterResult,
                               let html = String(data: rosterData, encoding: .utf8),
                               let roster = self.parseIntranetRoster(
                                   html,
                                   ownProfileId: finalSnapshot.hrProfileId,
                                   now: now
                               ) {
                                finalSnapshot.people = roster.people
                                if ["vacation", "sick", "home_office"].contains(roster.ownState),
                                   !["in_building", "home_office", "on_break", "doctor", "offsite"].contains(finalSnapshot.currentState),
                                   let ownState = roster.ownState {
                                    finalSnapshot.currentState = ownState
                                    finalSnapshot.currentSince = nil
                                }
                                finalSnapshot.rosterFetchedAt = now.timeIntervalSince1970
                            }
                            loadNotifications(finalSnapshot)
                        }
                    }

                    let loadAttendanceHistory: (IntranetSnapshot) -> Void = { snapshotAfterSummary in
                        guard historyDue else {
                            loadRoster(snapshotAfterSummary)
                            return
                        }
                        let currentMonth = self.intranetMonthKey(
                            self.intranetMonthStart(from: now)
                        )
                        let previousMonth = self.intranetMonthKey(
                            self.intranetMonthStart(offset: -1, from: now)
                        )
                        self.intranetRequest(path: "/dochazka?month=\(currentMonth)") { currentResult in
                            var withCurrent = snapshotAfterSummary
                            if case .success(let currentData) = currentResult,
                               let html = String(data: currentData, encoding: .utf8) {
                                let events = self.parseIntranetHistory(
                                    html,
                                    ownProfileId: withCurrent.hrProfileId
                                )
                                withCurrent.historyEvents = self.mergeIntranetHistory(
                                    existing: withCurrent.historyEvents ?? [],
                                    incoming: events,
                                    now: now
                                )
                                withCurrent.historyFetchedAt = now.timeIntervalSince1970
                            }
                            self.intranetRequest(path: "/dochazka?month=\(previousMonth)") { previousResult in
                                var withPrevious = withCurrent
                                if case .success(let previousData) = previousResult,
                                   let html = String(data: previousData, encoding: .utf8) {
                                    let events = self.parseIntranetHistory(
                                        html,
                                        ownProfileId: withPrevious.hrProfileId
                                    )
                                    withPrevious.historyEvents = self.mergeIntranetHistory(
                                        existing: withPrevious.historyEvents ?? [],
                                        incoming: events,
                                        now: now
                                    )
                                    withPrevious.historyFetchedAt = now.timeIntervalSince1970
                                }
                                loadRoster(withPrevious)
                            }
                        }
                    }

                    guard summaryDue else {
                        loadAttendanceHistory(updated)
                        return
                    }
                    self.intranetRequest(path: "/moje") { summaryResult in
                        var withSummary = updated
                        if case .success(let summaryData) = summaryResult,
                           let html = String(data: summaryData, encoding: .utf8) {
                            let parsed = self.parseIntranetSummary(html)
                            if !parsed.cards.isEmpty {
                                withSummary.cards = parsed.cards
                                if parsed.workload > 0 { withSummary.workloadHours = parsed.workload }
                                withSummary.summaryFetchedAt = now.timeIntervalSince1970
                            }
                        }
                        loadAttendanceHistory(withSummary)
                    }
                } catch {
                    DispatchQueue.main.async {
                        self.intranetRefreshInFlight = false
                        self.applyIntranetError(IntranetServiceError(
                            code: "internal_error",
                            message: "Docházková data Evora Intranetu mají neočekávaný formát."
                        ))
                    }
                }
            }
        }
    }

    func formatIntranetDuration(_ seconds: Int) -> String {
        let roundedMinutes = max(0, Int((Double(seconds) / 60.0).rounded()))
        let hours = roundedMinutes / 60
        let minutes = roundedMinutes % 60
        if hours == 0 { return "\(minutes) min" }
        if minutes == 0 { return "\(hours) h" }
        return "\(hours) h \(minutes) min"
    }

    func formatIntranetLiveClock(_ seconds: Int) -> String {
        let safeSeconds = max(0, seconds)
        let hours = safeSeconds / 3600
        let minutes = (safeSeconds % 3600) / 60
        let secondsPart = safeSeconds % 60
        return String(format: "%02d:%02d:%02d", hours, minutes, secondsPart)
    }

    func formatIntranetTime(_ timestamp: Double?) -> String {
        guard let timestamp else { return "—" }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "cs_CZ")
        formatter.timeZone = TimeZone(identifier: "Europe/Prague")
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: Date(timeIntervalSince1970: timestamp))
    }

    func displayedIntranetWorkedSeconds() -> Int {
        var seconds = intranetSnapshot.todayWorkedSeconds
        let activeWorkStates: Set<String> = ["in_building", "home_office", "offsite"]
        if intranetSnapshot.dataState == "current",
           activeWorkStates.contains(intranetSnapshot.currentState),
           intranetSnapshot.fetchedAt > 0 {
            seconds += max(0, Int(Date().timeIntervalSince1970 - intranetSnapshot.fetchedAt))
        }
        return seconds
    }

    func applyIntranetStatusToUI() {
        guard shiftStatusItem != nil else { return }
        let state = intranetSnapshot.dataState
        let ready = state == "current" && !intranetSnapshot.hrProfileId.isEmpty
        let canStart = ["none", "away"].contains(intranetSnapshot.currentState)
        intranetOfficeItem?.isEnabled = ready && canStart
        intranetHomeItem?.isEnabled = ready && canStart
        intranetEndItem?.isEnabled = ready
            && ["in_building", "home_office"].contains(intranetSnapshot.currentState)
        if state == "current" || state == "stale" {
            let stateLabel = intranetStateLabel(intranetSnapshot.currentState)
            let duration = formatIntranetLiveClock(displayedIntranetWorkedSeconds())
            let color: NSColor
            switch intranetSnapshot.currentState {
            case "in_building", "home_office", "offsite": color = .systemGreen
            case "on_break", "doctor": color = .systemOrange
            case "vacation", "sick": color = .systemBlue
            default: color = .secondaryLabelColor
            }
            let stale = state == "stale" ? " · ZASTARALÉ" : ""
            shiftStatusItem.attributedTitle = statusAttributed(
                label: "Evora Intranet",
                value: "\(stateLabel) · dnes \(duration)\(stale)",
                color: state == "stale" ? .systemOrange : color
            )
            if let button = statusItem.button {
                let symbol: String
                switch intranetSnapshot.currentState {
                case "in_building": symbol = "building.2.fill"
                case "home_office": symbol = "house.fill"
                case "offsite": symbol = "car.fill"
                case "on_break": symbol = "cup.and.saucer.fill"
                default: symbol = "clock.fill"
                }
                button.image = NSImage(systemSymbolName: symbol, accessibilityDescription: nil)
                button.imagePosition = .imageLeading
                button.title = ["in_building", "home_office", "offsite"].contains(intranetSnapshot.currentState)
                    ? " \(duration)"
                    : ""
            }
        } else {
            let statusColor: NSColor
            switch state {
            case "loading": statusColor = .systemBlue
            case "stale", "unavailable", "source_unavailable": statusColor = .systemOrange
            case "not_configured": statusColor = .secondaryLabelColor
            default: statusColor = .systemRed
            }
            shiftStatusItem.attributedTitle = statusAttributed(
                label: "Evora Intranet",
                value: intranetDataStateLabel(state),
                color: statusColor
            )
            if let button = statusItem.button {
                button.title = ""
                button.image = loxoneLikeIcon()
            }
        }
    }

    func intranetPunchLabel(_ kind: String) -> String {
        switch kind {
        case "arrival": return "Příchod"
        case "departure": return "Odchod"
        case "home_start": return "Začít Home office"
        case "home_end": return "Ukončit Home office"
        case "break_out": return "Začít přestávku"
        case "break_in": return "Ukončit přestávku"
        case "doctor_out": return "Odchod k lékaři"
        case "doctor_in": return "Návrat od lékaře"
        case "offsite_out": return "Začít služební cestu"
        case "offsite_in": return "Ukončit služební cestu"
        default: return kind
        }
    }

    func intranetAvailablePunches() -> [String] {
        switch intranetSnapshot.currentState {
        case "in_building": return ["departure", "break_out", "doctor_out", "offsite_out"]
        case "home_office": return ["home_end", "break_out", "doctor_out"]
        case "on_break": return ["break_in"]
        case "doctor": return ["doctor_in"]
        case "offsite": return ["offsite_in"]
        case "vacation", "sick": return []
        default: return ["arrival", "home_start", "doctor_out", "offsite_out"]
        }
    }

    func intranetPunchMenuItem(_ kind: String) -> NSMenuItem {
        let symbol: String
        switch kind {
        case "arrival": symbol = "building.2"
        case "departure", "home_end": symbol = "rectangle.portrait.and.arrow.right"
        case "home_start": symbol = "house"
        case "break_out", "break_in": symbol = "cup.and.saucer"
        case "doctor_out", "doctor_in": symbol = "cross.case"
        default: symbol = "car"
        }
        let entry = item(
            intranetPunchLabel(kind),
            symbol: symbol,
            action: #selector(performIntranetPunch(_:))
        )
        entry.representedObject = kind
        entry.isEnabled = intranetSnapshot.dataState == "current"
            && !intranetSnapshot.hrProfileId.isEmpty
        return entry
    }

    func intranetHistoryMenuItem(now: Date = Date()) -> NSMenuItem {
        let parent = NSMenuItem(
            title: "Historie docházky",
            action: nil,
            keyEquivalent: ""
        )
        parent.image = sf("calendar")
        let historyMenu = NSMenu(title: "Historie docházky")
        historyMenu.autoenablesItems = false
        let allEvents = intranetSnapshot.historyEvents ?? []

        for offset in [0, -1] {
            let monthStart = intranetMonthStart(offset: offset, from: now)
            let monthItem = NSMenuItem(
                title: intranetMonthTitle(monthStart),
                action: nil,
                keyEquivalent: ""
            )
            monthItem.image = sf(offset == 0 ? "calendar.badge.clock" : "calendar")
            let monthMenu = NSMenu(title: intranetMonthTitle(monthStart))
            monthMenu.autoenablesItems = false
            let days = intranetHistoryDays(
                monthStart: monthStart,
                events: allEvents,
                now: now
            )

            if days.isEmpty {
                monthMenu.addItem(readOnlyItem(
                    "Zdroj zatím neposkytl záznamy pro tento měsíc",
                    symbol: "info.circle",
                    color: .labelColor
                ))
            } else {
                for day in days {
                    let summary = day.workedSeconds > 0
                        ? formatIntranetDuration(day.workedSeconds)
                        : "bez vypočteného času"
                    let dayItem = NSMenuItem(
                        title: "\(intranetDayTitle(day.date)) · \(summary)",
                        action: nil,
                        keyEquivalent: ""
                    )
                    let dayMenu = NSMenu(title: intranetDayTitle(day.date))
                    dayMenu.autoenablesItems = false
                    dayMenu.addItem(metricItem(
                        label: "Příchod",
                        value: formatIntranetTime(day.arrival?.timeIntervalSince1970),
                        symbol: "rectangle.portrait.and.arrow.right",
                        valueColor: .labelColor
                    ))

                    var breakStart: Date?
                    var breakIntervals: [String] = []
                    for entry in day.events {
                        if entry.event.kind == "break_out" {
                            breakStart = entry.date
                        } else if entry.event.kind == "break_in", let start = breakStart {
                            breakIntervals.append(
                                "\(formatIntranetTime(start.timeIntervalSince1970))–\(formatIntranetTime(entry.date.timeIntervalSince1970))"
                            )
                            breakStart = nil
                        }
                    }
                    if let start = breakStart {
                        breakIntervals.append("od \(formatIntranetTime(start.timeIntervalSince1970))")
                    }
                    dayMenu.addItem(metricItem(
                        label: "Pauza",
                        value: breakIntervals.isEmpty ? "bez pauzy" : breakIntervals.joined(separator: ", "),
                        symbol: "cup.and.saucer",
                        valueColor: .labelColor
                    ))
                    dayMenu.addItem(metricItem(
                        label: "Odchod",
                        value: formatIntranetTime(day.departure?.timeIntervalSince1970),
                        symbol: "rectangle.portrait.and.arrow.forward",
                        valueColor: .labelColor
                    ))
                    dayMenu.addItem(.separator())
                    dayMenu.addItem(metricItem(
                        label: "Odpracováno",
                        value: formatIntranetDuration(day.workedSeconds),
                        symbol: "clock",
                        valueColor: .labelColor
                    ))
                    dayItem.submenu = dayMenu
                    monthMenu.addItem(dayItem)
                }
            }
            monthItem.submenu = monthMenu
            historyMenu.addItem(monthItem)
        }

        if let fetchedAt = intranetSnapshot.historyFetchedAt, fetchedAt > 0 {
            historyMenu.addItem(.separator())
            historyMenu.addItem(readOnlyItem(
                "Aktualizováno \(formatIntranetTime(fetchedAt))",
                symbol: "checkmark.circle",
                color: .labelColor
            ))
        }
        parent.submenu = historyMenu
        return parent
    }

    func rebuildIntranetMenu() {
        guard intranetMenu != nil else { return }
        intranetMenu.removeAllItems()

        let statusTitle: String
        if intranetSnapshot.dataState == "current" || intranetSnapshot.dataState == "stale" {
            statusTitle = "\(intranetStateLabel(intranetSnapshot.currentState)) · dnes \(formatIntranetLiveClock(displayedIntranetWorkedSeconds()))"
        } else {
            statusTitle = intranetDataStateLabel(intranetSnapshot.dataState)
        }
        intranetMenu.addItem(readOnlyItem(
            statusTitle,
            symbol: "clock",
            color: .labelColor,
            weight: .semibold
        ))

        if intranetSnapshot.fetchedAt > 0 {
            intranetMenu.addItem(readOnlyItem(
                "Poslední úspěšná obnova: \(formatIntranetTime(intranetSnapshot.fetchedAt))",
                symbol: "checkmark.circle",
                color: .labelColor
            ))
        }

        if intranetSnapshot.dataState != "current",
           let message = intranetSnapshot.errorMessage {
            intranetMenu.addItem(readOnlyItem(
                "Poslední obnova selhala · \(message)",
                symbol: "exclamationmark.triangle",
                color: .systemRed,
                weight: .semibold
            ))
        }

        if intranetSnapshot.notificationsUnread > 0 {
            intranetMenu.addItem(metricItem(
                label: "Nepřečtená upozornění",
                value: String(intranetSnapshot.notificationsUnread),
                symbol: "bell",
                valueColor: .labelColor
            ))
        }

        intranetMenu.addItem(.separator())
        if !intranetSnapshot.cards.isEmpty {
            let cardRows: [(String, String)] = [
                ("worked_month", "Odpracováno za měsíc"),
                ("balance_month", "Saldo za měsíc"),
                ("overtime_ordered", "Nařízený přesčas"),
                ("vacation_remaining", "Zbývající dovolená"),
                ("sickday_remaining", "Zbývající sick days")
            ]
            for (key, label) in cardRows {
                let value = intranetSnapshot.cards[key] ?? "Zdroj údaj neposkytuje"
                intranetMenu.addItem(metricItem(
                    label: label,
                    value: value,
                    valueColor: .labelColor
                ))
            }
        }
        intranetMenu.addItem(intranetHistoryMenuItem())

        intranetMenu.addItem(.separator())
        let available = intranetAvailablePunches()
        if let primary = available.first {
            intranetMenu.addItem(intranetPunchMenuItem(primary))
        }
        if available.count > 1 {
            let more = NSMenuItem(title: "Další docházkové akce", action: nil, keyEquivalent: "")
            let submenu = NSMenu(title: "Další docházkové akce")
            for kind in available.dropFirst() {
                submenu.addItem(intranetPunchMenuItem(kind))
            }
            more.submenu = submenu
            intranetMenu.addItem(more)
        }

        if !intranetSnapshot.people.isEmpty {
            let roster = NSMenuItem(title: "Kdo je kde", action: nil, keyEquivalent: "")
            let rosterMenu = NSMenu(title: "Kdo je kde")
            let groups = [
                "in_building", "home_office", "offsite", "on_break",
                "vacation", "sick", "doctor", "away", "none"
            ]
            for state in groups {
                let people = intranetSnapshot.people.filter { $0.state == state }
                guard !people.isEmpty else { continue }
                let group = NSMenuItem(
                    title: "\(intranetStateLabel(state)) (\(people.count))",
                    action: nil,
                    keyEquivalent: ""
                )
                let peopleMenu = NSMenu(title: intranetStateLabel(state))
                peopleMenu.autoenablesItems = false
                for person in people {
                    let suffix = person.since.map { " · od \(formatIntranetTime($0))" } ?? ""
                    peopleMenu.addItem(readOnlyItem(
                        "\(person.name)\(suffix)",
                        color: .labelColor
                    ))
                }
                group.submenu = peopleMenu
                rosterMenu.addItem(group)
            }
            roster.submenu = rosterMenu
            intranetMenu.addItem(roster)
        }

        intranetMenu.addItem(.separator())
        intranetMenu.addItem(item(
            intranetRefreshInFlight ? "Aktualizuji…" : "Aktualizovat nyní",
            symbol: "arrow.clockwise",
            action: #selector(refreshIntranetNow)
        ))
        intranetMenu.items.last?.isEnabled = !intranetRefreshInFlight && hasIntranetCredentials()
        intranetMenu.addItem(linkItem(
            "Otevřít Evora Intranet",
            symbol: "globe",
            url: "https://intranet.evora.cz/moje"
        ))
        intranetMenu.addItem(item(
            hasIntranetCredentials() ? "Nastavit připojení…" : "Připojit Evora Intranet…",
            symbol: "key",
            action: #selector(configureIntranetConnection)
        ))
    }

    @objc func configureIntranetConnection() {
        NSApp.activate(ignoringOtherApps: true)
        let alert = NSAlert()
        alert.messageText = "Evora Intranet"
        alert.informativeText = "Přihlášení se uloží pouze do macOS Klíčenky. WorkLogAI neukládá heslo, přístupový token ani GPS do svých souborů."
        alert.addButton(withTitle: "Uložit a připojit")
        alert.addButton(withTitle: hasIntranetCredentials() ? "Odpojit" : "Zrušit")
        if hasIntranetCredentials() { alert.addButton(withTitle: "Zrušit") }

        let container = NSView(frame: NSRect(x: 0, y: 0, width: 380, height: 112))
        let emailLabel = NSTextField(labelWithString: "Firemní e-mail")
        emailLabel.frame = NSRect(x: 0, y: 90, width: 380, height: 18)
        let email = NSTextField(frame: NSRect(x: 0, y: 60, width: 380, height: 26))
        email.stringValue = intranetCredential(intranetEmailAccount) ?? ""
        email.placeholderString = "jmeno@evorasmart.cz"
        let passwordLabel = NSTextField(labelWithString: "Heslo")
        passwordLabel.frame = NSRect(x: 0, y: 36, width: 380, height: 18)
        let password = NSSecureTextField(frame: NSRect(x: 0, y: 4, width: 380, height: 26))
        password.placeholderString = hasIntranetCredentials() ? "Ponechte prázdné pro zachování" : "Heslo"
        container.addSubview(emailLabel)
        container.addSubview(email)
        container.addSubview(passwordLabel)
        container.addSubview(password)
        alert.accessoryView = container

        let response = alert.runModal()
        if response == .alertSecondButtonReturn {
            if hasIntranetCredentials() {
                deleteIntranetCredentials()
                intranetSnapshot = .empty
                saveIntranetSnapshot()
                _ = runWork(["intranet-sync", "off"])
                rebuildIntranetMenu()
                applyIntranetStatusToUI()
            }
            return
        }
        guard response == .alertFirstButtonReturn else { return }
        let emailValue = email.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        let passwordValue = password.stringValue
        guard emailValue.contains("@"), !emailValue.contains(" ") else {
            showAlert("Evora Intranet", "Zadejte platný firemní e-mail.")
            return
        }
        guard !passwordValue.isEmpty || intranetCredential(intranetPasswordAccount) != nil else {
            showAlert("Evora Intranet", "Heslo je povinné.")
            return
        }
        let passwordToStore = passwordValue.isEmpty
            ? (intranetCredential(intranetPasswordAccount) ?? "")
            : passwordValue
        guard storeIntranetCredentials(email: emailValue, password: passwordToStore) else {
            showAlert("Evora Intranet", "Přístup se nepodařilo bezpečně uložit do macOS Klíčenky.")
            return
        }
        intranetAccessToken = ""
        intranetRefreshToken = ""
        intranetCookieHeader = ""
        intranetTokenExpiresAt = .distantPast
        intranetRetryAfter = .distantPast
        intranetFailureCount = 0
        intranetSnapshot.dataState = "loading"
        rebuildIntranetMenu()
        refreshIntranet(forceAll: true)
    }

    @objc func performIntranetPunch(_ sender: NSMenuItem) {
        guard let kind = sender.representedObject as? String else { return }
        executeIntranetPunch(kind)
    }

    func executeIntranetPunch(_ kind: String) {
        guard intranetSnapshot.dataState == "current",
              !intranetSnapshot.hrProfileId.isEmpty
        else {
            showAlert("Evora Intranet", "Docházková data nejsou aktuální. Nejdřív je obnovte.")
            return
        }
        guard intranetAvailablePunches().contains(kind) else {
            showAlert(
                "Evora Intranet",
                "Akce „\(intranetPunchLabel(kind))“ neodpovídá aktuálnímu stavu „\(intranetStateLabel(intranetSnapshot.currentState))“. Nejdřív obnovte data."
            )
            return
        }
        NSApp.activate(ignoringOtherApps: true)
        let confirmation = NSAlert()
        confirmation.messageText = intranetPunchLabel(kind)
        confirmation.informativeText = "Tato akce se zapíše do Evora Intranetu jako oficiální docházka. GPS se z WorkLogAI neodesílá."
        confirmation.addButton(withTitle: "Ano, zapsat")
        confirmation.addButton(withTitle: "Zrušit")
        guard confirmation.runModal() == .alertFirstButtonReturn else { return }

        let body: [String: Any] = [
            "action": "save",
            "hr_profile_id": intranetSnapshot.hrProfileId,
            "kind": kind,
            "ts": ISO8601DateFormatter().string(from: Date()),
            "source": "web",
            "lat": NSNull(),
            "lng": NSNull(),
            "gps_accuracy": NSNull(),
            "location": NSNull(),
            "client_ref": UUID().uuidString.lowercased()
        ]
        intranetRequest(path: "/api/attendance/events", method: "POST", body: body) { [weak self] result in
            guard let self else { return }
            if case .success = result,
               ["arrival", "home_start"].contains(kind) {
                _ = self.runWork(["spustit"])
            }
            DispatchQueue.main.async {
                switch result {
                case .success:
                    self.refreshIntranet(forceAll: false)
                case .failure(let error):
                    self.showAlert("Evora Intranet", error.localizedDescription)
                }
            }
        }
    }

    // MARK: - Evora Smart Hub

    func evoraToken() -> String? {
        evoraTokenCache
    }

    func loadEvoraTokenAsync() {
        DispatchQueue.global(qos: .utility).async { [weak self] in
            guard let self else { return }
            let token = self.readKeychainValue(alias: self.evoraKeychainAlias)
            DispatchQueue.main.async {
                self.evoraTokenCache = token
                self.evoraCredentialsLoaded = true
                self.rebuildEvoraMenu()
                self.refreshEvoraMenu()
            }
        }
    }

    @discardableResult
    func saveEvoraToken(_ token: String) -> Bool {
        let saved = runKeychainHelper("store", alias: evoraKeychainAlias, input: token).success
        if saved {
            evoraTokenCache = token
            evoraCredentialsLoaded = true
        }
        return saved
    }

    func deleteEvoraToken() {
        _ = runKeychainHelper("delete", alias: evoraKeychainAlias)
        evoraTokenCache = nil
        evoraCredentialsLoaded = true
    }

    func evoraHubURL() -> String {
        let configured = UserDefaults.standard.string(forKey: evoraHubDefaultsKey)
            ?? defaultEvoraHubURL
        return configured.trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
    }

    func validEvoraHubURL(_ value: String) -> String? {
        let normalized = value.trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard
            let url = URL(string: normalized),
            let scheme = url.scheme?.lowercased(),
            let host = url.host,
            !host.isEmpty,
            url.query == nil,
            url.fragment == nil,
            scheme == "https" || (scheme == "http" && ["127.0.0.1", "localhost"].contains(host.lowercased()))
        else {
            return nil
        }
        return normalized
    }

    func evoraEndpoint(_ path: String) -> URL? {
        let suffix = path.hasPrefix("/") ? path : "/\(path)"
        return URL(string: "\(evoraHubURL())\(suffix)")
    }

    func evoraRequest<T: Decodable>(
        path: String,
        method: String = "GET",
        body: [String: Any]? = nil,
        headers: [String: String] = [:],
        completion: @escaping (Result<T, Error>) -> Void
    ) {
        guard let token = evoraToken() else {
            completion(.failure(EvoraServiceError(message: "Nejdřív nastavte osobní token z Evora Smart Hubu.")))
            return
        }
        guard let url = evoraEndpoint(path) else {
            completion(.failure(EvoraServiceError(message: "Adresa Evora Smart Hubu není platná.")))
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        for (name, value) in headers {
            request.setValue(value, forHTTPHeaderField: name)
        }
        if let body {
            request.httpBody = try? JSONSerialization.data(withJSONObject: body)
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        evoraSession.dataTask(with: request) { data, response, error in
            if let error {
                completion(.failure(EvoraServiceError(message: "Evora Smart Hub není dostupný: \(error.localizedDescription)")))
                return
            }
            guard let http = response as? HTTPURLResponse else {
                completion(.failure(EvoraServiceError(message: "Evora Smart Hub nevrátil platnou odpověď.")))
                return
            }
            let payload = data ?? Data()
            guard (200..<300).contains(http.statusCode) else {
                let message = (try? JSONDecoder().decode(EvoraErrorResponse.self, from: payload).error)
                    ?? "Požadavek na Evora Smart Hub selhal (HTTP \(http.statusCode))."
                completion(.failure(EvoraServiceError(message: message)))
                return
            }
            do {
                completion(.success(try JSONDecoder().decode(T.self, from: payload)))
            } catch {
                completion(.failure(EvoraServiceError(message: "Evora Smart Hub vrátil nečitelná data.")))
            }
        }.resume()
    }

    func downloadEvoraPortalAttachment(
        _ attachment: EvoraPortalTicketAttachment,
        completion: @escaping (Result<URL, Error>) -> Void
    ) {
        guard attachment.canDownload else {
            completion(.failure(EvoraServiceError(message: "Portál poskytl pouze název této přílohy, ne bezpečný odkaz ke stažení.")))
            return
        }
        guard let token = evoraToken(),
              let url = evoraEndpoint("/api/integrations/worklog/v1/portal-tickets/attachments/download") else {
            completion(.failure(EvoraServiceError(message: "Připojení k Evora Smart Hubu není nastavené.")))
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/octet-stream", forHTTPHeaderField: "Accept")
        request.httpBody = try? JSONSerialization.data(withJSONObject: ["token": attachment.token])
        evoraSession.dataTask(with: request) { data, response, error in
            if let error {
                completion(.failure(EvoraServiceError(message: "Přílohu se nepodařilo načíst: \(error.localizedDescription)")))
                return
            }
            guard let http = response as? HTTPURLResponse else {
                completion(.failure(EvoraServiceError(message: "Hub nevrátil platnou odpověď přílohy.")))
                return
            }
            let payload = data ?? Data()
            guard (200..<300).contains(http.statusCode) else {
                let message = (try? JSONDecoder().decode(EvoraErrorResponse.self, from: payload).error)
                    ?? "Přílohu se nepodařilo načíst (HTTP \(http.statusCode))."
                completion(.failure(EvoraServiceError(message: message)))
                return
            }
            let safeName = attachment.name
                .replacingOccurrences(of: "[^\\p{L}\\p{N} ._()-]", with: "_", options: .regularExpression)
                .prefix(180)
            let directory = FileManager.default.temporaryDirectory
                .appendingPathComponent("WorkLogAI-Evora-Attachments", isDirectory: true)
                .appendingPathComponent(UUID().uuidString, isDirectory: true)
            do {
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
                let target = directory.appendingPathComponent(safeName.isEmpty ? "priloha" : String(safeName))
                try payload.write(to: target, options: .atomic)
                completion(.success(target))
            } catch {
                completion(.failure(EvoraServiceError(message: "Staženou přílohu se nepodařilo bezpečně uložit.")))
            }
        }.resume()
    }

    func evoraConnectionLabel(_ state: String) -> String {
        switch state {
        case "online": return "Odpovídá"
        case "no_access": return "Odpovídá · bez přístupu"
        case "unavailable", "error": return "Neodpovídá"
        default: return "Neověřeno"
        }
    }

    func evoraServerMatchesSearch(_ server: EvoraMiniServer, folder: String, query: String) -> Bool {
        let normalized = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.isEmpty else { return true }
        let haystack = "\(server.project) \(server.serial) \(server.type) \(folder)"
        return haystack.range(of: normalized, options: [.caseInsensitive, .diacriticInsensitive]) != nil
    }

    func applyEvoraSearchFilter() {
        let query = evoraSearchQuery
        var visibleTotal = 0
        for folderEntry in evoraFolderMenuItems {
            var visibleInFolder = 0
            for serverEntry in folderEntry.servers {
                let matches = evoraServerMatchesSearch(serverEntry.server, folder: folderEntry.folder, query: query)
                serverEntry.item.isHidden = !matches
                if matches { visibleInFolder += 1 }
            }
            folderEntry.item.isHidden = visibleInFolder == 0
            folderEntry.item.title = "📁  \(folderEntry.folder)  (\(visibleInFolder))"
            visibleTotal += visibleInFolder
        }
        evoraNoResultsItem?.isHidden = query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || visibleTotal > 0
    }

    func controlTextDidChange(_ notification: Notification) {
        guard let field = notification.object as? NSSearchField, field === evoraSearchField else { return }
        evoraSearchQuery = field.stringValue
        applyEvoraSearchFilter()
    }

    func evoraPortalTicketIsClosed(_ status: String) -> Bool {
        let normalized = status.lowercased()
        return normalized.contains("closed")
            || normalized.contains("resolved")
            || normalized.contains("solved")
            || normalized.contains("uzavřen")
    }

    func evoraPortalTicketStatus(_ status: String) -> String {
        let normalized = status.lowercased()
        if normalized == "open" || normalized == "opened" { return "Otevřený" }
        if evoraPortalTicketIsClosed(status) { return "Uzavřený" }
        if normalized.contains("waiting") || normalized.contains("pending") { return "Čeká" }
        return status.isEmpty ? "Neznámý" : status
    }

    func evoraTicketsMenuItem() -> NSMenuItem {
        let parent = NSMenuItem(
            title: "LOXONE tickety  (\(evoraTickets.count))",
            action: nil,
            keyEquivalent: ""
        )
        parent.image = sf("ticket")
        let submenu = NSMenu(title: "LOXONE tickety")
        let status = NSMenuItem(title: evoraTicketsStatus, action: nil, keyEquivalent: "")
        status.isEnabled = false
        submenu.addItem(status)
        submenu.addItem(.separator())
        submenu.addItem(item("Nový ticket…", symbol: "plus.bubble", action: #selector(createEvoraPortalTicket)))
        submenu.addItem(item("Aktualizovat změny", symbol: "arrow.clockwise", action: #selector(refreshEvoraTickets)))
        submenu.addItem(linkItem("Otevřít centrum v Evora Smart Hubu", symbol: "rectangle.portrait.and.arrow.right", url: "\(evoraHubURL())?page=tickets"))
        submenu.addItem(.separator())
        if evoraTickets.isEmpty {
            let empty = NSMenuItem(
                title: evoraTicketsRefreshInFlight ? "Načítám tickety…" : "Žádné tickety nejsou dostupné.",
                action: nil,
                keyEquivalent: ""
            )
            empty.isEnabled = false
            submenu.addItem(empty)
        } else {
            for ticket in evoraTickets {
                let marker = evoraPortalTicketIsClosed(ticket.status) ? "⚪️" : "🟢"
                let ticketItem = item(
                    "\(marker)  #\(ticket.ticketNumber) · \(ticket.subject)",
                    symbol: "bubble.left.and.bubble.right",
                    action: #selector(showEvoraPortalTicket(_:))
                )
                ticketItem.representedObject = ticket.id
                ticketItem.toolTip = "\(evoraPortalTicketStatus(ticket.status)) · \(ticket.contactName)"
                submenu.addItem(ticketItem)
            }
        }
        parent.submenu = submenu
        return parent
    }

    func rebuildEvoraMenu() {
        guard evoraMenu != nil else { return }
        evoraMenu.removeAllItems()
        evoraFolderMenuItems.removeAll()
        evoraNoResultsItem = nil

        evoraStatusItem = NSMenuItem(
            title: evoraStatus,
            action: nil,
            keyEquivalent: ""
        )
        evoraStatusItem.isEnabled = false
        evoraMenu.addItem(evoraStatusItem)
        evoraMenu.addItem(.separator())
        let searchItem = NSMenuItem()
        let searchContainer = NSView(frame: NSRect(x: 0, y: 0, width: 310, height: 38))
        let searchField = NSSearchField(frame: NSRect(x: 10, y: 5, width: 290, height: 28))
        searchField.placeholderString = "Hledat Miniserver…"
        searchField.stringValue = evoraSearchQuery
        searchField.sendsSearchStringImmediately = true
        searchField.delegate = self
        searchContainer.addSubview(searchField)
        searchItem.view = searchContainer
        evoraSearchField = searchField
        evoraMenu.addItem(searchItem)
        evoraMenu.addItem(.separator())
        evoraMenu.addItem(
            linkItem(
                "Otevřít Evora Smart Hub",
                symbol: "network",
                url: evoraHubURL()
            )
        )
        evoraMenu.addItem(
            item(
                "Obnovit Miniservery",
                symbol: "arrow.clockwise",
                action: #selector(refreshEvoraMenu)
            )
        )
        evoraMenu.addItem(
            item(
                "Nastavit připojení…",
                symbol: "key",
                action: #selector(configureEvoraConnection)
            )
        )
        evoraMenu.addItem(.separator())
        evoraMenu.addItem(evoraTicketsMenuItem())

        guard !evoraServers.isEmpty else {
            evoraMenu.addItem(.separator())
            let empty = NSMenuItem(
                title: !evoraCredentialsLoaded
                    ? "Načítám zabezpečené připojení…"
                    : evoraToken() == nil
                    ? "Vložte osobní token z Nastavení Hubu."
                    : "Žádné Miniservery nejsou dostupné.",
                action: nil,
                keyEquivalent: ""
            )
            empty.isEnabled = false
            evoraMenu.addItem(empty)
            return
        }

        evoraMenu.addItem(.separator())
        let noResultsItem = NSMenuItem(title: "Žádný Miniserver neodpovídá hledání", action: nil, keyEquivalent: "")
        noResultsItem.isEnabled = false
        noResultsItem.isHidden = true
        evoraNoResultsItem = noResultsItem
        evoraMenu.addItem(noResultsItem)
        let grouped = Dictionary(grouping: evoraServers, by: { $0.folderName })
        for folder in grouped.keys.sorted(by: { $0.localizedCaseInsensitiveCompare($1) == .orderedAscending }) {
            let servers = (grouped[folder] ?? []).sorted {
                $0.project.localizedCaseInsensitiveCompare($1.project) == .orderedAscending
            }
            let folderItem = NSMenuItem(
                title: "📁  \(folder)  (\(servers.count))",
                action: nil,
                keyEquivalent: ""
            )
            let folderMenu = NSMenu(title: folder)
            var folderServers: [(item: NSMenuItem, server: EvoraMiniServer)] = []
            for server in servers {
                let statusMarker = server.connectionState == "online" ? "🟢" : "⚪️"
                let serverItem = NSMenuItem(
                    title: "\(statusMarker)  \(server.project)",
                    action: nil,
                    keyEquivalent: ""
                )
                let serverMenu = NSMenu(title: server.project)
                let identity = NSMenuItem(
                    title: "\(server.serial) · \(server.type)",
                    action: nil,
                    keyEquivalent: ""
                )
                identity.isEnabled = false
                serverMenu.addItem(identity)
                let status = NSMenuItem(
                    title: "\(evoraConnectionLabel(server.connectionState)) · FW \(server.currentFirmware ?? "neznámý")",
                    action: nil,
                    keyEquivalent: ""
                )
                status.isEnabled = false
                serverMenu.addItem(status)
                serverMenu.addItem(.separator())

                let appAction = item(
                    "Otevřít v Loxone App",
                    symbol: "iphone",
                    action: #selector(runEvoraAction(_:))
                )
                appAction.representedObject = [
                    "serial": server.serial,
                    "action": "loxone_app"
                ] as NSDictionary
                appAction.isEnabled = server.loxoneAppAvailable
                serverMenu.addItem(appAction)

                let configTitle: String
                if evoraLauncherAgent?.updateRequired == true {
                    configTitle = "Otevřít v Loxone Config · aktualizujte Launcher"
                } else if server.loxoneConfigAvailable {
                    configTitle = "Otevřít v Loxone Config"
                } else {
                    configTitle = "Otevřít v Loxone Config · Launcher offline"
                }
                let configAction = item(
                    configTitle,
                    symbol: "doc.badge.gearshape",
                    action: #selector(runEvoraAction(_:))
                )
                configAction.representedObject = [
                    "serial": server.serial,
                    "action": "loxone_config"
                ] as NSDictionary
                configAction.isEnabled = server.loxoneConfigAvailable
                serverMenu.addItem(configAction)

                if let download = server.configDownloadUrl {
                    serverMenu.addItem(.separator())
                    serverMenu.addItem(
                        linkItem(
                            "Stáhnout Loxone Config \(server.configVersion ?? "")",
                            symbol: "arrow.down.circle",
                            url: download
                        )
                    )
                }
                serverItem.submenu = serverMenu
                folderMenu.addItem(serverItem)
                folderServers.append((item: serverItem, server: server))
            }
            folderItem.submenu = folderMenu
            evoraMenu.addItem(folderItem)
            evoraFolderMenuItems.append((item: folderItem, folder: folder, servers: folderServers))
        }
        applyEvoraSearchFilter()
    }

    @objc func refreshEvoraMenu() {
        guard !evoraRefreshInFlight else { return }
        guard evoraCredentialsLoaded else {
            evoraStatus = "Evora Smart Hub: načítám připojení…"
            rebuildEvoraMenu()
            return
        }
        guard evoraToken() != nil else {
            evoraServers = []
            evoraLauncherAgent = nil
            evoraStatus = "Evora Smart Hub: nepřipojeno"
            rebuildEvoraMenu()
            return
        }
        evoraRefreshInFlight = true
        evoraStatus = "Evora Smart Hub: načítám…"
        rebuildEvoraMenu()
        loadEvoraTickets(forcePortalRefresh: false)
        evoraRequest(
            path: "/api/integrations/worklog/v1/miniservers"
        ) { [weak self] (result: Result<EvoraFleetResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                self.evoraRefreshInFlight = false
                self.evoraLastRefresh = Date()
                switch result {
                case .success(let response):
                    self.evoraServers = response.items
                    self.evoraLauncherAgent = response.launcherAgent
                    let launcher: String
                    if response.launcherAgent?.updateRequired == true {
                        launcher = "Windows Launcher vyžaduje aktualizaci"
                    } else if response.launcherAgent?.available == true {
                        launcher = response.launcherAgent?.updateAvailable == true
                            ? "Windows Launcher online · aktualizace dostupná"
                            : "Windows Launcher online"
                    } else {
                        launcher = "Windows Launcher offline"
                    }
                    self.evoraStatus = "\(response.items.count) Miniserverů · \(launcher)"
                case .failure(let error):
                    self.evoraServers = []
                    self.evoraLauncherAgent = nil
                    self.evoraStatus = "Chyba: \(error.localizedDescription)"
                }
                self.rebuildEvoraMenu()
            }
        }
    }

    @objc func refreshEvoraTickets() {
        loadEvoraTickets(forcePortalRefresh: true)
    }

    func loadEvoraTickets(forcePortalRefresh: Bool) {
        guard !evoraTicketsRefreshInFlight else { return }
        guard evoraToken() != nil else {
            evoraTickets = []
            evoraTicketsStatus = "Tickety: nepřipojeno"
            rebuildEvoraMenu()
            return
        }
        evoraTicketsRefreshInFlight = true
        evoraTicketsStatus = "Tickety: načítám…"
        rebuildEvoraMenu()
        evoraRequest(
            path: "/api/integrations/worklog/v1/portal-tickets\(forcePortalRefresh ? "?refresh=1" : "")"
        ) { [weak self] (result: Result<EvoraPortalTicketListResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                self.evoraTicketsRefreshInFlight = false
                switch result {
                case .success(let response):
                    self.evoraTickets = response.items
                    let open = response.items.filter { !self.evoraPortalTicketIsClosed($0.status) }.count
                    self.evoraTicketsStatus = "\(response.items.count) ticketů · \(open) otevřených"
                case .failure(let error):
                    self.evoraTicketsStatus = self.evoraTickets.isEmpty
                        ? "Tickety: \(error.localizedDescription)"
                        : "\(self.evoraTickets.count) ticketů · aktualizace selhala"
                }
                self.rebuildEvoraMenu()
            }
        }
    }

    func menuWillOpen(_ menu: NSMenu) {
        if menu === evoraMenu {
            if Date().timeIntervalSince(evoraLastRefresh) > 30 {
                refreshEvoraMenu()
            } else if evoraTickets.isEmpty {
                loadEvoraTickets(forcePortalRefresh: false)
            }
        } else if menu === intranetMenu {
            if Date().timeIntervalSince1970 - intranetSnapshot.fetchedAt > 60 {
                refreshIntranet(forceAll: false)
            }
        }
    }

    // MARK: - Icons

    func sf(_ name: String) -> NSImage? {
        let config = NSImage.SymbolConfiguration(
            pointSize: 13,
            weight: .medium
        )

        let img = NSImage(
            systemSymbolName: name,
            accessibilityDescription: nil
        )?.withSymbolConfiguration(config)

        img?.isTemplate = true

        return img
    }

    func loxoneLikeIcon() -> NSImage {
        let size = NSSize(
            width: 18,
            height: 18
        )

        let image = NSImage(size: size)

        image.lockFocus()

        let outer = NSBezierPath()
        outer.lineWidth = 1.6

        outer.move(
            to: NSPoint(x: 9, y: 1.6)
        )

        outer.line(
            to: NSPoint(x: 15.4, y: 5.1)
        )

        outer.line(
            to: NSPoint(x: 15.4, y: 12.9)
        )

        outer.line(
            to: NSPoint(x: 9, y: 16.4)
        )

        outer.line(
            to: NSPoint(x: 2.6, y: 12.9)
        )

        outer.line(
            to: NSPoint(x: 2.6, y: 5.1)
        )

        outer.close()

        NSColor.labelColor.setStroke()
        outer.stroke()

        let inner = NSBezierPath()
        inner.lineWidth = 1.7

        inner.move(
            to: NSPoint(x: 6.2, y: 5.0)
        )

        inner.line(
            to: NSPoint(x: 6.2, y: 12.8)
        )

        inner.line(
            to: NSPoint(x: 11.8, y: 12.8)
        )

        inner.stroke()

        image.unlockFocus()

        image.isTemplate = true

        return image
    }

    // MARK: - Menu items

    func item(
        _ title: String,
        symbol: String?,
        action: Selector
    ) -> NSMenuItem {

        let item = NSMenuItem(
            title: title,
            action: action,
            keyEquivalent: ""
        )

        item.target = self
        if let symbol { item.image = sf(symbol) }

        return item
    }

    func linkItem(
        _ title: String,
        symbol: String?,
        url: String
    ) -> NSMenuItem {

        let item = NSMenuItem(
            title: title,
            action: #selector(openURL(_:)),
            keyEquivalent: ""
        )

        item.target = self
        item.representedObject = url
        if let symbol { item.image = sf(symbol) }

        return item
    }

    func readOnlyItem(
        _ title: String,
        symbol: String? = nil,
        color: NSColor = .labelColor,
        weight: NSFont.Weight = .regular
    ) -> NSMenuItem {
        let menuItem = NSMenuItem()
        let width: CGFloat = 390
        let height: CGFloat = 25
        let view = NSView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        var textX: CGFloat = 13

        if let symbol, let image = sf(symbol) {
            let imageView = NSImageView(frame: NSRect(x: 13, y: 4, width: 17, height: 17))
            imageView.image = image
            imageView.contentTintColor = color
            view.addSubview(imageView)
            textX = 39
        }

        let text = NSTextField(labelWithString: title)
        text.frame = NSRect(x: textX, y: 4, width: width - textX - 12, height: 18)
        text.font = NSFont.systemFont(ofSize: NSFont.systemFontSize, weight: weight)
        text.textColor = color
        text.lineBreakMode = .byTruncatingTail
        view.addSubview(text)
        menuItem.view = view
        return menuItem
    }

    func metricItem(
        label: String,
        value: String,
        symbol: String? = nil,
        valueColor: NSColor = .labelColor
    ) -> NSMenuItem {
        let menuItem = NSMenuItem()
        let width: CGFloat = 390
        let height: CGFloat = 27
        let view = NSView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        var labelX: CGFloat = 13

        if let symbol, let image = sf(symbol) {
            let imageView = NSImageView(frame: NSRect(x: 13, y: 5, width: 17, height: 17))
            imageView.image = image
            imageView.contentTintColor = .labelColor
            view.addSubview(imageView)
            labelX = 39
        }

        let valueWidth: CGFloat = 132
        let labelField = NSTextField(labelWithString: label)
        labelField.frame = NSRect(
            x: labelX,
            y: 5,
            width: width - labelX - valueWidth - 18,
            height: 18
        )
        labelField.font = NSFont.systemFont(ofSize: NSFont.systemFontSize)
        labelField.textColor = .labelColor
        labelField.lineBreakMode = .byTruncatingTail
        view.addSubview(labelField)

        let valueField = NSTextField(labelWithString: value)
        valueField.frame = NSRect(
            x: width - valueWidth - 12,
            y: 5,
            width: valueWidth,
            height: 18
        )
        valueField.alignment = .right
        valueField.font = NSFont.monospacedDigitSystemFont(
            ofSize: NSFont.systemFontSize,
            weight: .semibold
        )
        valueField.textColor = valueColor
        valueField.lineBreakMode = .byTruncatingHead
        view.addSubview(valueField)

        menuItem.view = view
        return menuItem
    }

    func statusAttributed(
        label: String,
        value: String,
        color: NSColor
    ) -> NSAttributedString {

        let output = NSMutableAttributedString(
            string: "\(label)    "
        )

        output.addAttributes(
            [
                .foregroundColor: NSColor.labelColor,
                .font: NSFont.systemFont(
                    ofSize: NSFont.systemFontSize
                )
            ],
            range: NSRange(
                location: 0,
                length: output.length
            )
        )

        let state = NSAttributedString(
            string: value,
            attributes: [
                .foregroundColor: color,
                .font: NSFont.systemFont(
                    ofSize: NSFont.systemFontSize,
                    weight: .semibold
                )
            ]
        )

        output.append(state)

        return output
    }

    // MARK: - Build menu

    func buildMenu() {
        menu = NSMenu(title: "WorkLogAI")
        menu.autoenablesItems = false

        let header = NSMenuItem(
            title: "WorkLogAI 5.8.2",
            action: nil,
            keyEquivalent: ""
        )
        header.isEnabled = false
        menu.addItem(header)

        shiftStatusItem = NSMenuItem(
            title: "Pracovní čas: neaktivní",
            action: nil,
            keyEquivalent: ""
        )
        shiftStatusItem.isEnabled = false
        menu.addItem(shiftStatusItem)
        menu.addItem(.separator())

        let attendance = NSMenuItem(
            title: "Docházka",
            action: nil,
            keyEquivalent: ""
        )
        attendance.image = sf("calendar.badge.clock")
        intranetMenu = NSMenu(title: "Docházka")
        intranetMenu.autoenablesItems = false
        intranetMenu.delegate = self
        attendance.submenu = intranetMenu
        menu.addItem(attendance)
        rebuildIntranetMenu()

        let records = NSMenuItem(
            title: "Záznam práce",
            action: nil,
            keyEquivalent: ""
        )
        records.image = sf("square.and.pencil")
        let recordsMenu = NSMenu(title: "Záznam práce")
        recordsMenu.autoenablesItems = false
        recordsMenu.addItem(item("Přidat poznámku…", symbol: "square.and.pencil", action: #selector(addNote)))
        recordsMenu.addItem(item("Telefon / hovor…", symbol: "phone.fill", action: #selector(addCall)))
        recordsMenu.addItem(item("Výjezd / cesta…", symbol: "car.fill", action: #selector(addTravel)))
        recordsMenu.addItem(item("Práce mimo PC…", symbol: "wrench.and.screwdriver.fill", action: #selector(addOffPC)))
        records.submenu = recordsMenu
        menu.addItem(records)

        let reports = NSMenuItem(
            title: "Přehledy a výkazy",
            action: nil,
            keyEquivalent: ""
        )
        reports.image = sf("doc.text.magnifyingglass")
        let reportsMenu = NSMenu(title: "Přehledy a výkazy")
        reportsMenu.autoenablesItems = false
        reportsMenu.addItem(item("Průběžný souhrn", symbol: "list.bullet.rectangle", action: #selector(showSummary)))
        reportsMenu.addItem(item("AI souhrn", symbol: "sparkles", action: #selector(showAISummary)))
        reportsMenu.addItem(item("Poslední aktivita", symbol: "clock.arrow.circlepath", action: #selector(showRecent)))
        reportsMenu.addItem(.separator())
        reportsMenu.addItem(item("Vytvořit výkaz", symbol: "doc.text.fill", action: #selector(makeReport)))
        reportsMenu.addItem(item("Otevřít Excel", symbol: "tablecells.fill", action: #selector(openExcel)))
        reports.submenu = reportsMenu
        menu.addItem(reports)

        let systems = NSMenuItem(
            title: "Systémy",
            action: nil,
            keyEquivalent: ""
        )
        systems.image = sf("square.grid.2x2")
        let systemsMenu = NSMenu(title: "Systémy")
        systemsMenu.autoenablesItems = false

        let ha = NSMenuItem(
            title: "Home Assistant odkazy",
            action: nil,
            keyEquivalent: ""
        )
        let haMenu = NSMenu(title: "Home Assistant odkazy")
        haMenu.autoenablesItems = false
        haMenu.addItem(linkItem("Herškovič", symbol: "person.crop.circle", url: "https://homeassistant-herskovic.skunk-atria.ts.net"))
        haMenu.addItem(linkItem("Vágner", symbol: "person.crop.circle", url: "https://homeassistant-vagner.skunk-atria.ts.net"))
        haMenu.addItem(linkItem("Evora", symbol: "building.2.fill", url: "https://homeassistant-work.skunk-atria.ts.net"))
        haMenu.addItem(linkItem("Domov", symbol: "house.fill", url: "https://homeassistant.skunk-atria.ts.net"))
        ha.submenu = haMenu
        ha.image = sf("house.fill")
        systemsMenu.addItem(ha)

        let evora = NSMenuItem(
            title: "Evora Smart Hub",
            action: nil,
            keyEquivalent: ""
        )
        evora.image = loxoneLikeIcon()
        evoraMenu = NSMenu(title: "Evora Smart Hub")
        evoraMenu.delegate = self
        evora.submenu = evoraMenu
        systemsMenu.addItem(evora)
        rebuildEvoraMenu()
        systems.submenu = systemsMenu
        menu.addItem(systems)

        let controls = NSMenuItem(
            title: "Ovládání WorkLogAI",
            action: nil,
            keyEquivalent: ""
        )
        controls.image = sf("gearshape.2")
        let controlsMenu = NSMenu(title: "Ovládání WorkLogAI")
        controlsMenu.autoenablesItems = false

        macStatusItem = NSMenuItem(title: "Mac agent: kontroluji…", action: nil, keyEquivalent: "")
        macStatusItem.isEnabled = false
        controlsMenu.addItem(macStatusItem)
        windowsStatusItem = NSMenuItem(title: "Windows klient: kontroluji…", action: nil, keyEquivalent: "")
        windowsStatusItem.isEnabled = false
        controlsMenu.addItem(windowsStatusItem)
        controlsMenu.addItem(.separator())

        startAgentItem = item("Spustit Mac agent", symbol: "play.circle.fill", action: #selector(startAgent))
        restartAgentItem = item("Restartovat Mac agent", symbol: "arrow.clockwise.circle.fill", action: #selector(restartAgent))
        stopAgentItem = item("Zastavit Mac agent", symbol: "stop.circle.fill", action: #selector(stopAgent))
        controlsMenu.addItem(startAgentItem)
        controlsMenu.addItem(restartAgentItem)
        controlsMenu.addItem(stopAgentItem)
        controlsMenu.addItem(.separator())
        controlsMenu.addItem(item("Pozastavit sledování", symbol: "pause.circle.fill", action: #selector(pauseAgent)))
        controlsMenu.addItem(item("Pokračovat ve sledování", symbol: "play.circle.fill", action: #selector(resumeAgent)))
        controls.submenu = controlsMenu
        menu.addItem(controls)

        menu.addItem(.separator())
        menu.addItem(item("Ukončit pouze menu", symbol: "xmark.circle", action: #selector(quitMenu)))
        statusItem.menu = menu
    }

    // MARK: - Refresh

    @objc func tickClock() {
        applyIntranetStatusToUI()
    }

    @objc func refreshAll() {
        if refreshInFlight {
            return
        }

        refreshInFlight = true

        DispatchQueue.global(qos: .utility).async { [weak self] in
            guard let self = self else {
                return
            }

            let q = self.quick()

            DispatchQueue.main.async { [weak self] in
                guard let self = self else {
                    return
                }

                self.refreshInFlight = false
                self.applyRefresh(q)
            }
        }
    }

    private func applyRefresh(_ q: [String: Any]) {



        let agent =
            (q["agent_running"] as? Bool)
            ?? false

        let windows =
            (q["windows"] as? String)
            ?? "NIKDY"

        let windowsAge =
            q["windows_last_seconds"]
            as? Double

        cachedAgent = agent
        cachedWindows = windows

        // Mac agent status
        if agent {
            macStatusItem.attributedTitle =
                statusAttributed(
                    label: "Mac agent",
                    value: "● ONLINE",
                    color: .systemGreen
                )
        } else {
            macStatusItem.attributedTitle =
                statusAttributed(
                    label: "Mac agent",
                    value: "● OFFLINE",
                    color: .systemRed
                )
        }

        // Windows status
        if windows == "ONLINE" {

            let age =
                Int(
                    windowsAge
                    ?? 0
                )

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● ONLINE · \(age) s",
                    color: .systemGreen
                )

        } else if windows == "ZPOZDENI" {

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● ZPOŽDĚNÍ",
                    color: .systemOrange
                )

        } else if windows == "OFFLINE" {

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● OFFLINE",
                    color: .systemRed
                )

        } else {

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● BEZ DAT",
                    color: .secondaryLabelColor
                )
        }

        // Agent action visibility
        startAgentItem.isHidden = agent
        restartAgentItem.isHidden = !agent
        stopAgentItem.isHidden = !agent

        applyIntranetStatusToUI()
    
    }

    // MARK: - Agent control

    func ensureAgent() -> Bool {

        let q1 = quick()

        if
            (
                q1[
                    "agent_running"
                ]
                as? Bool
            )
            == true
        {
            return true
        }

        _ = runWork(
            [
                "spustit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1.5
        )

        let q2 = quick()

        return
            (
                q2[
                    "agent_running"
                ]
                as? Bool
            )
            == true
    }

    @objc func startAgent() {

        _ = runWork(
            [
                "spustit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        refreshAll()
    }

    @objc func restartAgent() {

        _ = runWork(
            [
                "zastavit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        _ = runWork(
            [
                "spustit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        refreshAll()
    }

    @objc func stopAgent() {

        _ = runWork(
            [
                "zastavit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        refreshAll()
    }

    // MARK: - Shift control

    func startShift(
        _ mode: String
    ) {
        executeIntranetPunch(mode == "office" ? "arrival" : "home_start")
    }

    @objc func startOffice() {
        startShift(
            "office"
        )
    }

    @objc func startHome() {
        startShift(
            "homeoffice"
        )
    }

    @objc func stopShift() {
        switch intranetSnapshot.currentState {
        case "home_office":
            executeIntranetPunch("home_end")
        case "in_building":
            executeIntranetPunch("departure")
        case "on_break", "doctor", "offsite":
            showAlert(
                "Evora Intranet",
                "Nejdřív ukončete aktuální stav „\(intranetStateLabel(intranetSnapshot.currentState))“ v nabídce Evora Intranet."
            )
        default:
            showAlert("Evora Intranet", "Pracovní doba už není aktivní.")
        }
    }

    // MARK: - Alerts

    func showAlert(
        _ title: String,
        _ body: String
    ) {

        NSApp.activate(
            ignoringOtherApps: true
        )

        let alert =
            NSAlert()

        alert.messageText =
            title

        alert.informativeText =
            body

        alert.addButton(
            withTitle: "OK"
        )

        alert.runModal()
    }

    func showScrollableAlert(
        _ title: String,
        _ body: String
    ) {

        NSApp.activate(
            ignoringOtherApps: true
        )

        let alert = NSAlert()
        alert.messageText = title
        alert.addButton(withTitle: "Zavřít")

        let scroll = NSScrollView(
            frame: NSRect(
                x: 0,
                y: 0,
                width: 560,
                height: 500
            )
        )

        scroll.hasVerticalScroller = true
        scroll.hasHorizontalScroller = false
        scroll.autohidesScrollers = true
        scroll.borderType = .bezelBorder

        let textView = NSTextView(
            frame: NSRect(
                x: 0,
                y: 0,
                width: 540,
                height: 500
            )
        )

        textView.isEditable = false
        textView.isSelectable = true
        textView.drawsBackground = false
        textView.isRichText = false
        textView.font = NSFont.monospacedSystemFont(
            ofSize: 12,
            weight: .regular
        )
        textView.textContainerInset = NSSize(
            width: 10,
            height: 10
        )
        textView.textContainer?.widthTracksTextView = true
        textView.textContainer?.containerSize = NSSize(
            width: 540,
            height: CGFloat.greatestFiniteMagnitude
        )
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.autoresizingMask = [.width]
        textView.string = body

        scroll.documentView = textView
        alert.accessoryView = scroll

        alert.runModal()
    }

    func inputDialog(
        _ title: String,
        command: String
    ) {

        NSApp.activate(
            ignoringOtherApps: true
        )

        let alert =
            NSAlert()

        alert.messageText =
            title

        alert.informativeText =
            "Napiš stručně, co se řešilo. Délka v minutách je volitelná."

        alert.addButton(
            withTitle: "Uložit"
        )

        alert.addButton(
            withTitle: "Zrušit"
        )

        let container =
            NSView(
                frame:
                    NSRect(
                        x: 0,
                        y: 0,
                        width: 440,
                        height: 72
                    )
            )

        let textField =
            NSTextField(
                frame:
                    NSRect(
                        x: 0,
                        y: 40,
                        width: 440,
                        height: 26
                    )
            )

        textField.placeholderString =
            "Co se řešilo?"

        let minutesField =
            NSTextField(
                frame:
                    NSRect(
                        x: 0,
                        y: 4,
                        width: 180,
                        height: 26
                    )
            )

        minutesField.placeholderString =
            "Délka v minutách"

        container.addSubview(
            textField
        )

        container.addSubview(
            minutesField
        )

        alert.accessoryView =
            container

        alert.window
            .initialFirstResponder =
            textField

        guard
            alert.runModal()
            == .alertFirstButtonReturn
        else {
            return
        }

        let body =
            textField
                .stringValue
                .trimmingCharacters(
                    in:
                        .whitespacesAndNewlines
                )

        if body.isEmpty {
            return
        }

        var args =
            [
                command,
                body
            ]

        let mins =
            minutesField
                .stringValue
                .trimmingCharacters(
                    in:
                        .whitespacesAndNewlines
                )

        if !mins.isEmpty {

            args +=
                [
                    "--minutes",
                    mins
                ]
        }

        showAlert(
            "WorkLog",
            runWork(args)
        )
    }

    // MARK: - Manual entries

    @objc func addNote() {
        inputDialog(
            "Přidat poznámku",
            command:
                "poznamka"
        )
    }

    @objc func addCall() {
        inputDialog(
            "Telefon / hovor",
            command:
                "hovor"
        )
    }

    @objc func addTravel() {
        inputDialog(
            "Výjezd / cesta",
            command:
                "vyjezd"
        )
    }

    @objc func addOffPC() {
        inputDialog(
            "Práce mimo PC",
            command:
                "mimo-pc"
        )
    }

    // MARK: - Reports

    @objc func showSummary() {
        showAlert(
            "Průběžný souhrn",
            runWork(
                [
                    "souhrn"
                ]
            )
        )
    }

    @objc func showAISummary() {
        showAlert(
            "AI souhrn",
            runWork(
                [
                    "souhrn-ai"
                ]
            )
        )
    }

    @objc func showRecent() {
        showScrollableAlert(
            "Poslední aktivita",
            runWork(
                [
                    "posledni",
                    "8"
                ]
            )
        )
    }

    @objc func makeReport() {
        showAlert(
            "Výkaz práce",
            runWork(
                [
                    "vykaz"
                ]
            )
        )
    }

    @objc func openExcel() {

        NSWorkspace.shared.open(
            URL(
                fileURLWithPath:
                    "\(runtimeRoot)/Pracovni_vykaz.xlsx"
            )
        )
    }

    // MARK: - Evora actions

    func evoraTextView(_ value: String, width: CGFloat = 560, height: CGFloat = 360) -> NSScrollView {
        let scroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        scroll.hasVerticalScroller = true
        scroll.hasHorizontalScroller = false
        scroll.autohidesScrollers = true
        scroll.borderType = .bezelBorder
        let textView = NSTextView(frame: NSRect(x: 0, y: 0, width: width - 20, height: height))
        textView.isEditable = false
        textView.isSelectable = true
        textView.drawsBackground = false
        textView.isRichText = false
        textView.font = NSFont.systemFont(ofSize: 12)
        textView.textContainerInset = NSSize(width: 10, height: 10)
        textView.textContainer?.widthTracksTextView = true
        textView.textContainer?.containerSize = NSSize(width: width - 20, height: CGFloat.greatestFiniteMagnitude)
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.autoresizingMask = [.width]
        textView.string = value
        scroll.documentView = textView
        return scroll
    }

    func evoraAttributedTextView(_ value: NSAttributedString, width: CGFloat = 560, height: CGFloat = 360) -> NSScrollView {
        let scroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        scroll.hasVerticalScroller = true
        scroll.hasHorizontalScroller = false
        scroll.autohidesScrollers = true
        scroll.borderType = .noBorder
        let textView = NSTextView(frame: NSRect(x: 0, y: 0, width: width - 20, height: height))
        textView.isEditable = false
        textView.isSelectable = true
        textView.isRichText = true
        textView.drawsBackground = true
        textView.backgroundColor = .windowBackgroundColor
        textView.textContainerInset = NSSize(width: 12, height: 12)
        textView.textContainer?.widthTracksTextView = true
        textView.textContainer?.containerSize = NSSize(width: width - 20, height: CGFloat.greatestFiniteMagnitude)
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.autoresizingMask = [.width]
        textView.textStorage?.setAttributedString(value)
        scroll.documentView = textView
        return scroll
    }

    func evoraPortalTicketText(_ ticket: EvoraPortalTicketDetail) -> String {
        var sections: [String] = [
            "#\(ticket.ticketNumber) · \(evoraPortalTicketStatus(ticket.status))",
            ticket.subject,
            "Kontakt: \(ticket.contactName.isEmpty ? "neuveden" : ticket.contactName)",
            "Založeno: \(ticket.createdTime)"
        ]
        if !ticket.attachments.isEmpty {
            sections.append("Přílohy ticketu: \(ticket.attachments.map(\.name).joined(separator: ", "))")
        }
        for thread in ticket.threads {
            let fullName = "\(thread.author.firstName) \(thread.author.lastName)"
                .trimmingCharacters(in: .whitespacesAndNewlines)
            let author = fullName.isEmpty
                ? (thread.author.isLoxone ? "LOXONE podpora" : "Evora Smart")
                : fullName
            var message = "\(thread.createdTime) · \(author)\(thread.author.isLoxone ? " · LOXONE" : "")\n\n\(thread.content)"
            if !thread.attachments.isEmpty {
                message += "\n\nPřílohy: \(thread.attachments.map(\.name).joined(separator: ", "))"
            }
            sections.append(message)
        }
        return sections.joined(separator: "\n\n────────────────────────\n\n")
    }

    func evoraPortalTicketAttributedText(_ ticket: EvoraPortalTicketDetail) -> NSAttributedString {
        let result = NSMutableAttributedString()
        let bodyStyle = NSMutableParagraphStyle()
        bodyStyle.lineSpacing = 3
        bodyStyle.paragraphSpacing = 8
        let bubbleStyle = NSMutableParagraphStyle()
        bubbleStyle.lineSpacing = 4
        bubbleStyle.paragraphSpacing = 14
        bubbleStyle.firstLineHeadIndent = 10
        bubbleStyle.headIndent = 10
        bubbleStyle.tailIndent = -10

        func append(_ text: String, _ attributes: [NSAttributedString.Key: Any]) {
            result.append(NSAttributedString(string: text, attributes: attributes))
        }

        append("#\(ticket.ticketNumber) · \(evoraPortalTicketStatus(ticket.status))\n", [
            .font: NSFont.boldSystemFont(ofSize: 13),
            .foregroundColor: NSColor.systemGreen,
            .paragraphStyle: bodyStyle
        ])
        append("\(ticket.subject)\nKontakt: \(ticket.contactName.isEmpty ? "neuveden" : ticket.contactName) · Založeno: \(ticket.createdTime)\n\n", [
            .font: NSFont.systemFont(ofSize: 12),
            .foregroundColor: NSColor.labelColor,
            .paragraphStyle: bodyStyle
        ])

        for thread in ticket.threads {
            let fullName = "\(thread.author.firstName) \(thread.author.lastName)"
                .trimmingCharacters(in: .whitespacesAndNewlines)
            let author = fullName.isEmpty
                ? (thread.author.isLoxone ? "LOXONE podpora" : "Evora Smart")
                : fullName
            let accent = thread.author.isLoxone ? NSColor.systemGreen : NSColor.systemTeal
            append("●  \(author)\n", [
                .font: NSFont.boldSystemFont(ofSize: 11),
                .foregroundColor: accent,
                .paragraphStyle: bodyStyle
            ])
            append("\(thread.createdTime)\n", [
                .font: NSFont.systemFont(ofSize: 9),
                .foregroundColor: NSColor.secondaryLabelColor,
                .paragraphStyle: bodyStyle
            ])
            append("\(thread.content.trimmingCharacters(in: .whitespacesAndNewlines))\n", [
                .font: NSFont.systemFont(ofSize: 12),
                .foregroundColor: NSColor.labelColor,
                .backgroundColor: thread.author.isLoxone ? NSColor.systemGreen.withAlphaComponent(0.08) : NSColor.systemTeal.withAlphaComponent(0.08),
                .paragraphStyle: bubbleStyle
            ])
            if !thread.attachments.isEmpty {
                append("📎  \(thread.attachments.map(\.name).joined(separator: ", "))\n\n", [
                    .font: NSFont.systemFont(ofSize: 10),
                    .foregroundColor: NSColor.systemBlue,
                    .paragraphStyle: bodyStyle
                ])
            }
        }
        return result
    }

    func evoraPortalTicketAttachments(_ ticket: EvoraPortalTicketDetail) -> [EvoraPortalTicketAttachment] {
        var result: [EvoraPortalTicketAttachment] = []
        var seen = Set<String>()
        for attachment in ticket.attachments + ticket.threads.flatMap(\.attachments) {
            let key = "\(attachment.id)\n\(attachment.name)"
            guard seen.insert(key).inserted else { continue }
            result.append(attachment)
        }
        return result
    }

    func presentEvoraPortalAttachments(_ attachments: [EvoraPortalTicketAttachment]) {
        guard !attachments.isEmpty else {
            showAlert("Přílohy ticketu", "Portál u tohoto ticketu nevrátil žádnou skutečnou přílohu.")
            return
        }
        let downloadable = attachments.filter(\.canDownload)
        let displayOnly = attachments.filter { !$0.canDownload }
        NSApp.activate(ignoringOtherApps: true)
        let alert = NSAlert()
        alert.messageText = "Přílohy ticketu"
        if downloadable.isEmpty {
            alert.informativeText = "Portál poskytl názvy souborů bez bezpečných adres. Zobrazuji je proto jen jako přehled, nikoli jako nefunkční tlačítka."
        } else if displayOnly.isEmpty {
            alert.informativeText = "Vyberte přílohu. WorkFlowAI ji bezpečně načte přes Evora Smart Hub a otevře v odpovídající aplikaci macOS."
        } else {
            alert.informativeText = "Dostupné přílohy lze otevřít. Soubory, u kterých Portál poskytl jen název, jsou uvedené zvlášť jako přehled."
        }

        let width: CGFloat = 520
        let listHeight = displayOnly.isEmpty
            ? CGFloat(0)
            : min(CGFloat(220), max(CGFloat(72), CGFloat(displayOnly.count * 22 + 20)))
        let downloadableHeight: CGFloat = downloadable.isEmpty ? 0 : 59
        let displayOnlyHeight: CGFloat = displayOnly.isEmpty ? 0 : listHeight + 25
        let sectionSpacing: CGFloat = downloadable.isEmpty || displayOnly.isEmpty ? 0 : 12
        let containerHeight = downloadableHeight + displayOnlyHeight + sectionSpacing
        let container = NSView(frame: NSRect(x: 0, y: 0, width: width, height: containerHeight))
        var cursor = containerHeight
        var selector: NSPopUpButton?

        if !downloadable.isEmpty {
            let heading = NSTextField(labelWithString: "Dostupné ke stažení")
            heading.font = NSFont.systemFont(ofSize: 12, weight: .semibold)
            heading.frame = NSRect(x: 0, y: cursor - 17, width: width, height: 17)
            container.addSubview(heading)
            cursor -= 25

            let popUp = NSPopUpButton(frame: NSRect(x: 0, y: cursor - 32, width: width, height: 32), pullsDown: false)
            popUp.addItems(withTitles: downloadable.map(\.name))
            container.addSubview(popUp)
            selector = popUp
            cursor -= 32
        }

        if !displayOnly.isEmpty {
            if !downloadable.isEmpty { cursor -= sectionSpacing }
            let heading = NSTextField(labelWithString: "Názvy souborů z Portálu")
            heading.font = NSFont.systemFont(ofSize: 12, weight: .semibold)
            heading.frame = NSRect(x: 0, y: cursor - 17, width: width, height: 17)
            container.addSubview(heading)
            cursor -= 25

            let list = evoraTextView(
                displayOnly.map { "• \($0.name)" }.joined(separator: "\n"),
                width: width,
                height: listHeight
            )
            list.frame = NSRect(x: 0, y: cursor - listHeight, width: width, height: listHeight)
            container.addSubview(list)
        }

        alert.accessoryView = container
        if downloadable.isEmpty {
            alert.addButton(withTitle: "Zavřít")
            _ = alert.runModal()
            return
        }
        alert.addButton(withTitle: "Otevřít vybranou")
        alert.addButton(withTitle: "Zavřít")
        guard alert.runModal() == .alertFirstButtonReturn, let selector else { return }
        let index = max(0, min(selector.indexOfSelectedItem, downloadable.count - 1))
        downloadEvoraPortalAttachment(downloadable[index]) { [weak self] result in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success(let file):
                    NSWorkspace.shared.open(file)
                case .failure(let error):
                    self.showAlert("Přílohy ticketu", error.localizedDescription)
                }
            }
        }
    }

    @objc func showEvoraPortalTicket(_ sender: NSMenuItem) {
        guard let id = sender.representedObject as? String else { return }
        evoraRequest(
            path: "/api/integrations/worklog/v1/portal-tickets/\(id)"
        ) { [weak self] (result: Result<EvoraPortalTicketDetailResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success(let response):
                    self.presentEvoraPortalTicket(response.ticket)
                case .failure(let error):
                    self.showAlert("LOXONE tickety", error.localizedDescription)
                }
            }
        }
    }

    func presentEvoraPortalTicket(_ ticket: EvoraPortalTicketDetail) {
        NSApp.activate(ignoringOtherApps: true)
        let attachments = evoraPortalTicketAttachments(ticket)
        let alert = NSAlert()
        alert.messageText = "#\(ticket.ticketNumber) · \(ticket.subject)"
        alert.informativeText = attachments.isEmpty
            ? "\(evoraPortalTicketStatus(ticket.status)) · veřejná komunikace z Loxone Partner Portálu."
            : "\(evoraPortalTicketStatus(ticket.status)) · veřejná komunikace · \(attachments.count) příloh."
        alert.addButton(withTitle: "Odpovědět…")
        if !attachments.isEmpty {
            alert.addButton(withTitle: "Přílohy (\(attachments.count))…")
        }
        alert.addButton(withTitle: "Otevřít v Hubu")
        alert.addButton(withTitle: "Zavřít")
        alert.accessoryView = evoraAttributedTextView(evoraPortalTicketAttributedText(ticket), height: 430)
        let answer = alert.runModal()
        if answer == .alertFirstButtonReturn {
            presentEvoraPortalComposer(ticket: ticket)
            return
        }
        if !attachments.isEmpty, answer == .alertSecondButtonReturn {
            presentEvoraPortalAttachments(attachments)
            return
        }
        let hubResponse: NSApplication.ModalResponse = attachments.isEmpty ? .alertSecondButtonReturn : .alertThirdButtonReturn
        if answer == hubResponse, let url = URL(string: "\(evoraHubURL())?page=tickets") {
            NSWorkspace.shared.open(url)
        }
    }

    @objc func createEvoraPortalTicket() {
        presentEvoraPortalComposer(ticket: nil)
    }

    func presentEvoraPortalComposer(ticket: EvoraPortalTicketDetail?, draft: EvoraPortalDraft? = nil) {
        NSApp.activate(ignoringOtherApps: true)
        let isReply = ticket != nil
        let alert = NSAlert()
        alert.messageText = isReply ? "Odpověď do ticketu #\(ticket?.ticketNumber ?? "")" : "Nový LOXONE ticket"
        alert.informativeText = "Po pokračování se zobrazí úplný náhled. Nic se neodešle bez následného potvrzení heslem."
        alert.addButton(withTitle: "Zkontrolovat návrh")
        alert.addButton(withTitle: "Zrušit")

        let containerHeight: CGFloat = isReply ? 255 : 300
        let container = NSView(frame: NSRect(x: 0, y: 0, width: 560, height: containerHeight))
        let subjectLabel = NSTextField(labelWithString: "Předmět")
        subjectLabel.frame = NSRect(x: 0, y: containerHeight - 20, width: 560, height: 17)
        let subjectField = NSTextField(frame: NSRect(x: 0, y: containerHeight - 52, width: 560, height: 26))
        subjectField.stringValue = draft?.subject ?? ticket?.subject ?? ""
        subjectField.isEditable = !isReply
        subjectField.isSelectable = true
        let bodyLabel = NSTextField(labelWithString: "Celá zpráva")
        bodyLabel.frame = NSRect(x: 0, y: containerHeight - 79, width: 560, height: 17)
        let bodyScroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: 560, height: containerHeight - 84))
        bodyScroll.hasVerticalScroller = true
        bodyScroll.borderType = .bezelBorder
        let bodyField = NSTextView(frame: NSRect(x: 0, y: 0, width: 540, height: containerHeight - 84))
        bodyField.isRichText = false
        bodyField.font = NSFont.systemFont(ofSize: 12)
        bodyField.textContainerInset = NSSize(width: 8, height: 8)
        bodyField.string = draft?.body ?? ""
        bodyScroll.documentView = bodyField
        container.addSubview(subjectLabel)
        container.addSubview(subjectField)
        container.addSubview(bodyLabel)
        container.addSubview(bodyScroll)
        alert.accessoryView = container
        alert.window.initialFirstResponder = isReply ? bodyField : subjectField

        guard alert.runModal() == .alertFirstButtonReturn else { return }
        let subject = subjectField.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        let body = bodyField.string.trimmingCharacters(in: .whitespacesAndNewlines)
        guard subject.count >= 3 else {
            showAlert("LOXONE tickety", "Předmět musí mít alespoň 3 znaky.")
            presentEvoraPortalComposer(ticket: ticket, draft: EvoraPortalDraft(ticketId: ticket?.id, ticketNumber: ticket?.ticketNumber, subject: subject, body: body))
            return
        }
        guard body.count >= (isReply ? 1 : 3) else {
            showAlert("LOXONE tickety", "Zpráva je příliš krátká.")
            presentEvoraPortalComposer(ticket: ticket, draft: EvoraPortalDraft(ticketId: ticket?.id, ticketNumber: ticket?.ticketNumber, subject: subject, body: body))
            return
        }
        reviewEvoraPortalDraft(
            EvoraPortalDraft(
                ticketId: ticket?.id,
                ticketNumber: ticket?.ticketNumber,
                subject: subject,
                body: body
            ),
            ticket: ticket
        )
    }

    func reviewEvoraPortalDraft(_ draft: EvoraPortalDraft, ticket: EvoraPortalTicketDetail?) {
        NSApp.activate(ignoringOtherApps: true)
        let action = draft.isReply ? "Přidat veřejnou odpověď do #\(draft.ticketNumber ?? "")" : "Vytvořit nový ticket"
        let preview = "Kam: Loxone Partner Portal\nAkce: \(action)\nPředmět: \(draft.subject)\n\nCELÝ TEXT ZPRÁVY\n\n\(draft.body)"
        let alert = NSAlert()
        alert.messageText = "Kontrola před odesláním"
        alert.informativeText = "Níže je úplný návrh. V této chvíli ještě nic nebylo odesláno."
        alert.addButton(withTitle: "Pokračovat k heslu")
        alert.addButton(withTitle: "Zpět upravit")
        alert.addButton(withTitle: "Zrušit")
        alert.accessoryView = evoraTextView(preview, height: 380)
        let answer = alert.runModal()
        if answer == .alertFirstButtonReturn {
            confirmEvoraPortalDraft(draft)
        } else if answer == .alertSecondButtonReturn {
            presentEvoraPortalComposer(ticket: ticket, draft: draft)
        }
    }

    func confirmEvoraPortalDraft(_ draft: EvoraPortalDraft) {
        NSApp.activate(ignoringOtherApps: true)
        let alert = NSAlert()
        alert.messageText = "Potvrdit odeslání heslem"
        alert.informativeText = "Heslo slouží jen k jednorázovému potvrzení přesně zkontrolovaného návrhu."
        alert.addButton(withTitle: "Potvrdit a odeslat")
        alert.addButton(withTitle: "Zrušit")
        let password = NSSecureTextField(frame: NSRect(x: 0, y: 0, width: 420, height: 26))
        password.placeholderString = "Heslo do Evora Smart Hubu"
        alert.accessoryView = password
        alert.window.initialFirstResponder = password
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        guard !password.stringValue.isEmpty else {
            showAlert("LOXONE tickety", "Heslo je povinné.")
            return
        }
        let action = draft.isReply ? "portal_ticket_reply" : "portal_ticket_create"
        let payload: [String: Any] = draft.isReply
            ? ["ticketId": draft.ticketId ?? "", "content": draft.body]
            : ["subject": draft.subject, "description": draft.body]
        evoraRequest(
            path: "/api/integrations/worklog/v1/portal-tickets/confirm",
            method: "POST",
            body: ["action": action, "password": password.stringValue, "payload": payload]
        ) { [weak self] (result: Result<EvoraConfirmationResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success(let response):
                    self.sendEvoraPortalDraft(draft, confirmationId: response.confirmationId)
                case .failure(let error):
                    self.showAlert("LOXONE tickety", error.localizedDescription)
                }
            }
        }
    }

    func sendEvoraPortalDraft(_ draft: EvoraPortalDraft, confirmationId: String) {
        let path = draft.isReply
            ? "/api/integrations/worklog/v1/portal-tickets/\(draft.ticketId ?? "")/replies"
            : "/api/integrations/worklog/v1/portal-tickets"
        let body: [String: Any] = draft.isReply
            ? ["content": draft.body]
            : ["subject": draft.subject, "description": draft.body]
        evoraRequest(
            path: path,
            method: "POST",
            body: body,
            headers: ["X-Action-Confirmation": confirmationId]
        ) { [weak self] (result: Result<EvoraPortalMutationResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success:
                    self.showAlert("LOXONE tickety", draft.isReply ? "Odpověď byla odeslána." : "Ticket byl vytvořen.")
                    self.refreshEvoraTickets()
                case .failure(let error):
                    self.showAlert("LOXONE tickety", error.localizedDescription)
                }
            }
        }
    }

    @objc func configureEvoraConnection() {
        NSApp.activate(ignoringOtherApps: true)
        let alert = NSAlert()
        alert.messageText = "Evora Smart Hub"
        alert.informativeText = "Vložte adresu Hubu a osobní WorkLog token vytvořený v Nastavení Evora Smart Hubu. Token se uloží pouze do macOS Klíčenky."
        alert.addButton(withTitle: "Uložit")
        alert.addButton(withTitle: "Odpojit tento Mac")
        alert.addButton(withTitle: "Zrušit")

        let container = NSView(
            frame: NSRect(x: 0, y: 0, width: 480, height: 104)
        )
        let urlLabel = NSTextField(labelWithString: "Adresa Evora Smart Hubu")
        urlLabel.frame = NSRect(x: 0, y: 82, width: 480, height: 17)
        let urlField = NSTextField(
            frame: NSRect(x: 0, y: 52, width: 480, height: 26)
        )
        urlField.stringValue = evoraHubURL()
        let tokenLabel = NSTextField(labelWithString: "Osobní WorkLog token")
        tokenLabel.frame = NSRect(x: 0, y: 30, width: 480, height: 17)
        let tokenField = NSSecureTextField(
            frame: NSRect(x: 0, y: 0, width: 480, height: 26)
        )
        tokenField.placeholderString = evoraToken() == nil
            ? "esh_worklog_…"
            : "ponechte prázdné, pokud token neměníte"
        container.addSubview(urlLabel)
        container.addSubview(urlField)
        container.addSubview(tokenLabel)
        container.addSubview(tokenField)
        alert.accessoryView = container
        alert.window.initialFirstResponder = evoraToken() == nil
            ? tokenField
            : urlField

        let answer = alert.runModal()
        if answer == .alertSecondButtonReturn {
            deleteEvoraToken()
            evoraServers = []
            evoraLauncherAgent = nil
            evoraStatus = "Evora Smart Hub: nepřipojeno"
            evoraTickets = []
            evoraTicketsStatus = "Tickety: nepřipojeno"
            rebuildEvoraMenu()
            return
        }
        guard answer == .alertFirstButtonReturn else { return }
        guard let normalizedURL = validEvoraHubURL(urlField.stringValue) else {
            showAlert(
                "Evora Smart Hub",
                "Použijte platnou HTTPS adresu bez parametrů. HTTP je povolené pouze pro localhost."
            )
            return
        }
        let newToken = tokenField.stringValue.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        if evoraToken() == nil && newToken.isEmpty {
            showAlert("Evora Smart Hub", "Osobní WorkLog token je povinný.")
            return
        }
        if !newToken.isEmpty {
            guard newToken.hasPrefix("esh_worklog_") else {
                showAlert("Evora Smart Hub", "Vložený token nemá platný formát.")
                return
            }
            guard saveEvoraToken(newToken) else {
                showAlert("Evora Smart Hub", "Token se nepodařilo uložit do macOS Klíčenky.")
                return
            }
        }
        UserDefaults.standard.set(normalizedURL, forKey: evoraHubDefaultsKey)
        evoraLastRefresh = .distantPast
        refreshEvoraMenu()
    }

    @objc func runEvoraAction(_ sender: NSMenuItem) {
        guard
            let payload = sender.representedObject as? NSDictionary,
            let serial = payload["serial"] as? String,
            let action = payload["action"] as? String
        else {
            return
        }
        evoraStatus = action == "loxone_app"
            ? "Připravuji Loxone App pro \(serial)…"
            : "Předávám \(serial) do Windows…"
        rebuildEvoraMenu()
        evoraRequest(
            path: "/api/integrations/worklog/v1/miniservers/\(serial)/actions",
            method: "POST",
            body: ["action": action]
        ) { [weak self] (result: Result<EvoraActionResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success(let response):
                    if response.action == "loxone_app" {
                        guard
                            let value = response.url,
                            let url = URL(string: value),
                            url.scheme?.lowercased() == "loxone"
                        else {
                            self.evoraStatus = "Loxone App: neplatná odpověď"
                            self.rebuildEvoraMenu()
                            self.showAlert("Evora Smart Hub", "Hub nevrátil bezpečný odkaz pro Loxone App.")
                            return
                        }
                        self.evoraStatus = "Loxone App otevřena pro \(serial)"
                        self.rebuildEvoraMenu()
                        if !NSWorkspace.shared.open(url) {
                            self.showAlert("Loxone App", "macOS nedokázal otevřít schéma loxone://. Ověřte instalaci Loxone App.")
                        }
                        return
                    }
                    guard let job = response.job else {
                        self.evoraStatus = "Config: neplatná odpověď"
                        self.rebuildEvoraMenu()
                        self.showAlert("Loxone Config", "Hub nevrátil vytvořený požadavek.")
                        return
                    }
                    self.evoraStatus = "Windows Launcher převzal požadavek…"
                    self.rebuildEvoraMenu()
                    self.pollEvoraConfigJob(job.id, attempt: 0)
                case .failure(let error):
                    self.evoraStatus = "Chyba: \(error.localizedDescription)"
                    self.rebuildEvoraMenu()
                    self.showAlert("Evora Smart Hub", error.localizedDescription)
                }
            }
        }
    }

    func pollEvoraConfigJob(_ id: String, attempt: Int) {
        guard attempt < 150 else {
            evoraStatus = "Loxone Config: vypršel čas kontroly"
            rebuildEvoraMenu()
            showAlert("Loxone Config", "Windows Launcher nepotvrdil výsledek v časovém limitu.")
            return
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { [weak self] in
            guard let self else { return }
            self.evoraRequest(
                path: "/api/integrations/worklog/v1/config-jobs/\(id)"
            ) { [weak self] (result: Result<EvoraJobResponse, Error>) in
                DispatchQueue.main.async {
                    guard let self else { return }
                    switch result {
                    case .failure(let error):
                        self.evoraStatus = "Config: \(error.localizedDescription)"
                        self.rebuildEvoraMenu()
                        self.showAlert("Loxone Config", error.localizedDescription)
                    case .success(let response):
                        let job = response.job
                        if job.state == "succeeded" {
                            self.evoraStatus = "Loxone Config \(job.requiredVersion) je otevřený"
                            self.rebuildEvoraMenu()
                        } else if ["missing_config", "failed", "expired"].contains(job.state) {
                            self.evoraStatus = "Config: \(job.message)"
                            self.rebuildEvoraMenu()
                            self.showEvoraConfigFailure(job)
                        } else {
                            self.evoraStatus = job.message
                            self.rebuildEvoraMenu()
                            self.pollEvoraConfigJob(id, attempt: attempt + 1)
                        }
                    }
                }
            }
        }
    }

    func showEvoraConfigFailure(_ job: EvoraConfigJob) {
        NSApp.activate(ignoringOtherApps: true)
        let alert = NSAlert()
        alert.messageText = job.state == "missing_config"
            ? "Požadovaný Loxone Config chybí"
            : "Loxone Config se nepodařilo otevřít"
        alert.informativeText = job.message
        if job.state == "missing_config", job.configUrl != nil {
            alert.addButton(withTitle: "Stáhnout Config \(job.requiredVersion)")
            alert.addButton(withTitle: "Zavřít")
            if alert.runModal() == .alertFirstButtonReturn,
               let value = job.configUrl,
               let url = URL(string: value) {
                NSWorkspace.shared.open(url)
            }
        } else {
            alert.addButton(withTitle: "OK")
            alert.runModal()
        }
    }

    // MARK: - Links

    @objc func openURL(
        _ sender: NSMenuItem
    ) {

        guard
            let value =
                sender
                    .representedObject
                as? String,

            let url =
                URL(
                    string:
                        value
                )

        else {
            return
        }

        NSWorkspace
            .shared
            .open(url)
    }

    // MARK: - Misc

    @objc func pauseAgent() {
        showAlert(
            "WorkLog",
            runWork(
                [
                    "pauza"
                ]
            )
        )
    }

    @objc func resumeAgent() {
        showAlert(
            "WorkLog",
            runWork(
                [
                    "pokracovat"
                ]
            )
        )
    }

    @objc func quitMenu() {
        NSApp.terminate(nil)
    }
}

let commandLine = CommandLine.arguments
let commandDelegate = AppDelegate()

if commandLine.count > 1, commandLine[1] == "--store-intranet-credentials" {
    guard let email = readLine()?.trimmingCharacters(in: .whitespacesAndNewlines),
          let password = readLine(),
          email.contains("@"),
          !email.contains(" "),
          !password.isEmpty
    else {
        fputs("Neplatný e-mail nebo heslo.\n", stderr)
        exit(2)
    }
    guard commandDelegate.storeIntranetCredentials(email: email, password: password) else {
        fputs("Přístup se nepodařilo uložit do macOS Klíčenky.\n", stderr)
        exit(1)
    }
    print("Přístup k Evora Intranetu byl uložen do macOS Klíčenky.")
    exit(0)
}

if commandLine.count > 1, commandLine[1] == "--clear-intranet-credentials" {
    commandDelegate.deleteIntranetCredentials()
    print("Přístup k Evora Intranetu byl z macOS Klíčenky odstraněn.")
    exit(0)
}

if commandLine.count > 1, commandLine[1] == "--self-test-intranet-history" {
    let fixedNow = ISO8601DateFormatter().date(from: "2026-08-22T15:00:00Z")!
    let events = [
        AppDelegate.IntranetAttendanceEvent(id: "a1", kind: "arrival", source: "test", ts: "2026-08-21T05:00:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "b1", kind: "break_out", source: "test", ts: "2026-08-21T10:00:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "b2", kind: "break_in", source: "test", ts: "2026-08-21T10:30:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "d1", kind: "departure", source: "test", ts: "2026-08-21T14:00:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "p1", kind: "arrival", source: "test", ts: "2026-07-15T06:00:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "p2", kind: "departure", source: "test", ts: "2026-07-15T14:00:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "old", kind: "arrival", source: "test", ts: "2026-06-30T06:00:00Z")
    ]
    let merged = commandDelegate.mergeIntranetHistory(
        existing: [events[0]],
        incoming: events,
        now: fixedNow
    )
    let currentDays = commandDelegate.intranetHistoryDays(
        monthStart: commandDelegate.intranetMonthStart(from: fixedNow),
        events: merged,
        now: fixedNow
    )
    let previousDays = commandDelegate.intranetHistoryDays(
        monthStart: commandDelegate.intranetMonthStart(offset: -1, from: fixedNow),
        events: merged,
        now: fixedNow
    )
    guard merged.count == 6,
          currentDays.count == 1,
          previousDays.count == 1,
          currentDays[0].workedSeconds == 30_600,
          previousDays[0].workedSeconds == 28_800
    else {
        fputs("Self-test historie docházky selhal.\n", stderr)
        exit(1)
    }
    print("Historie docházky: aktuální i předchozí měsíc jsou v pořádku.")
    exit(0)
}

if commandLine.count == 5, commandLine[1] == "--test-intranet-parsers" {
    do {
        let attendanceData = try Data(contentsOf: URL(fileURLWithPath: commandLine[2]))
        let summaryData = try Data(contentsOf: URL(fileURLWithPath: commandLine[3]))
        let rosterData = try Data(contentsOf: URL(fileURLWithPath: commandLine[4]))
        let attendance = try JSONDecoder().decode(
            AppDelegate.IntranetAttendanceResponse.self,
            from: attendanceData
        )
        guard let summaryHTML = String(data: summaryData, encoding: .utf8),
              let rosterHTML = String(data: rosterData, encoding: .utf8),
              let roster = commandDelegate.parseIntranetRoster(
                  rosterHTML,
                  ownProfileId: attendance.hrProfileId
              )
        else { throw AppDelegate.IntranetServiceError(code: "parser", message: "Parser nezpracoval vstup.") }
        let summary = commandDelegate.parseIntranetSummary(summaryHTML)
        let states = Dictionary(grouping: roster.people, by: { $0.state }).mapValues(\.count)
        var employeeIds = Set<String>()
        var eventIds = Set<String>()
        var eventKinds: [String: Int] = [:]
        var eventKeys = Set<String>()
        var eventDatesParsed = 0
        var eventDatesToday = 0
        var debugCalendar = Calendar(identifier: .gregorian)
        debugCalendar.timeZone = TimeZone(identifier: "Europe/Prague") ?? .current
        for object in commandDelegate.nextFlightObjects(from: rosterHTML) {
            guard let root = commandDelegate.findIntranetDictionary(
                in: object,
                requiredKeys: ["employees", "events", "absences", "fetchedAt"]
            ) else { continue }
            for employee in root["employees"] as? [[String: Any]] ?? [] {
                if let id = employee["id"] as? String { employeeIds.insert(id) }
            }
            for event in root["events"] as? [[String: Any]] ?? [] {
                eventKeys.formUnion(event.keys)
                if let id = event["hr_profile_id"] as? String { eventIds.insert(id) }
                if let kind = event["kind"] as? String { eventKinds[kind, default: 0] += 1 }
                if let ts = event["ts"] as? String,
                   let date = commandDelegate.parseIntranetDate(ts) {
                    eventDatesParsed += 1
                    if debugCalendar.isDateInToday(date) { eventDatesToday += 1 }
                }
            }
        }
        let result: [String: Any] = [
            "attendance_events": attendance.events.count,
            "summary_keys": summary.cards.keys.sorted(),
            "roster_people": roster.people.count,
            "roster_states": states,
            "own_state_available": roster.ownState != nil,
            "roster_event_keys": eventKeys.sorted(),
            "roster_event_kinds": eventKinds,
            "roster_employee_ids": employeeIds.count,
            "roster_event_ids": eventIds.count,
            "roster_id_overlap": employeeIds.intersection(eventIds).count,
            "roster_dates_parsed": eventDatesParsed,
            "roster_dates_today": eventDatesToday
        ]
        let output = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
        print(String(data: output, encoding: .utf8) ?? "{}")
        exit(0)
    } catch {
        fputs("Test parseru selhal.\n", stderr)
        exit(1)
    }
}

let app = NSApplication.shared
let delegate = commandDelegate
app.delegate = delegate
app.setActivationPolicy(.accessory)
app.run()
