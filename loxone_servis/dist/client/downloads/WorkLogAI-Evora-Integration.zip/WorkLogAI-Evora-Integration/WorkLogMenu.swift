import Cocoa
import AVFoundation
import Darwin
import Network

func evoraResolvedCGColor(_ color: NSColor, appearance: NSAppearance) -> CGColor {
    var resolved = color.cgColor
    appearance.performAsCurrentDrawingAppearance {
        resolved = color.cgColor
    }
    return resolved
}

func evoraMenuUsesDarkAppearance(_ view: NSView) -> Bool {
    if let forced = ProcessInfo.processInfo.environment["EVORA_MENU_PREVIEW_APPEARANCE"] {
        if forced == "dark" { return true }
        if forced == "light" { return false }
    }
    if UserDefaults.standard.string(forKey: "AppleInterfaceStyle")?.lowercased() == "dark" {
        return true
    }
    let appearance = view.window?.effectiveAppearance ?? view.effectiveAppearance
    return appearance.bestMatch(from: [.darkAqua, .aqua]) == .darkAqua
}

func evoraMenuSurfaceColor(_ view: NSView, elevated: Bool = false) -> NSColor {
    if evoraMenuUsesDarkAppearance(view) {
        return NSColor(srgbRed: elevated ? 0.145 : 0.115, green: elevated ? 0.145 : 0.115, blue: elevated ? 0.155 : 0.125, alpha: 0.98)
    }
    return NSColor(srgbRed: elevated ? 0.985 : 0.965, green: elevated ? 0.985 : 0.965, blue: elevated ? 0.99 : 0.975, alpha: 0.98)
}

func evoraMenuBorderColor(_ view: NSView) -> NSColor {
    evoraMenuUsesDarkAppearance(view)
        ? NSColor.white.withAlphaComponent(0.18)
        : NSColor.black.withAlphaComponent(0.16)
}

func evoraMenuPrimaryTextColor(_ view: NSView) -> NSColor {
    evoraMenuUsesDarkAppearance(view)
        ? NSColor.white.withAlphaComponent(0.96)
        : NSColor.black.withAlphaComponent(0.86)
}

func evoraMenuSecondaryTextColor(_ view: NSView) -> NSColor {
    evoraMenuUsesDarkAppearance(view)
        ? NSColor.white.withAlphaComponent(0.66)
        : NSColor.black.withAlphaComponent(0.56)
}

func evoraClearClassicHoverAnimation(layer: CALayer?) {
    guard let layer else { return }
    // Jednotlivé řádky nesmějí držet nekonečnou animaci. NSMenu při
    // opuštění a opětovném vstupu myši doručuje tracking události dávkově a
    // více pulzujících vrstev pak může zůstat vizuálně aktivních současně.
    // Statický border a shadow v updateAppearance poskytují jasný hover bez
    // blikání a bez stavu, který by přežil přechod na jinou stránku.
    layer.removeAnimation(forKey: "evora.classic.hoverPulse")
}

final class ClassicMenuAdaptiveView: NSView {
    var appearanceHandler: ((ClassicMenuAdaptiveView) -> Void)?

    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        refreshAppearance()
    }

    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        refreshAppearance()
    }

    override func viewWillDraw() {
        refreshAppearance()
        super.viewWillDraw()
    }

    func refreshAppearance() {
        appearanceHandler?(self)
    }
}

final class MenuSearchField: NSSearchField {
    override var acceptsFirstResponder: Bool { true }

    func ensureKeyboardFocus(selection requestedSelection: NSRange? = nil) {
        guard let window else { return }
        let textLength = stringValue.utf16.count
        let existingSelection = currentEditor()?.selectedRange
        let selection = requestedSelection ?? existingSelection ?? NSRange(location: textLength, length: 0)
        let safeLocation = min(max(0, selection.location), textLength)
        let safeLength = min(max(0, selection.length), textLength - safeLocation)
        NSApp.activate(ignoringOtherApps: true)
        if window.firstResponder !== self {
            _ = window.makeFirstResponder(self)
        }
        if let editor = currentEditor() {
            if window.firstResponder !== editor {
                _ = window.makeFirstResponder(editor)
            }
            editor.selectedRange = NSRange(location: safeLocation, length: safeLength)
        }
    }

    override func mouseDown(with event: NSEvent) {
        ensureKeyboardFocus()
        super.mouseDown(with: event)
        // NSMenu can reclaim the first responder at the end of its click
        // tracking cycle. Restore the field editor on the next AppKit turn so
        // typing after a deliberate click continues in this search field.
        DispatchQueue.main.async { [weak self] in
            self?.ensureKeyboardFocus()
        }
    }

    override func becomeFirstResponder() -> Bool {
        let accepted = super.becomeFirstResponder()
        if accepted {
            DispatchQueue.main.async { [weak self] in
                guard let self, let editor = self.currentEditor() else { return }
                _ = self.window?.makeFirstResponder(editor)
            }
        }
        return accepted
    }
}

final class ModernMenuFlippedView: NSView {
    override var isFlipped: Bool { true }
}

class ModernMenuActionButton: NSButton {
    var pressChanged: ((Bool) -> Void)?

    override func mouseDown(with event: NSEvent) {
        pressChanged?(true)
        super.mouseDown(with: event)
        pressChanged?(false)
    }
}

final class ClassicMenuClosureButton: ModernMenuActionButton {
    var handler: (() -> Void)?

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        target = self
        action = #selector(runHandler)
    }

    required init?(coder: NSCoder) {
        nil
    }

    @objc private func runHandler() {
        handler?()
    }
}

class ClassicMenuHoverSurfaceView: NSView {
    private(set) var pointerIsInside = false

    override func viewWillMove(toWindow newWindow: NSWindow?) {
        if newWindow == nil {
            setPointerInside(false)
        }
        super.viewWillMove(toWindow: newWindow)
    }

    func pointerStateDidChange() {}

    func setPointerInside(_ inside: Bool) {
        guard pointerIsInside != inside else { return }
        pointerIsInside = inside
        pointerStateDidChange()
    }
}

final class EvoraPayloadButton: NSButton {
    var payload: NSDictionary?

    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        refreshCardAppearance()
    }

    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        refreshCardAppearance()
    }

    override func viewWillDraw() {
        refreshCardAppearance()
        super.viewWillDraw()
    }

    func refreshCardAppearance() {
        guard let layer else { return }
        layer.backgroundColor = evoraMenuSurfaceColor(self, elevated: true).cgColor
        layer.borderColor = evoraMenuBorderColor(self).cgColor
    }

    override func mouseDown(with event: NSEvent) {
        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.08
            animator().alphaValue = 0.68
        }
        super.mouseDown(with: event)
        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.16
            context.timingFunction = CAMediaTimingFunction(name: .easeOut)
            animator().alphaValue = 1
        }
    }
}

final class ModernMenuRowView: ClassicMenuHoverSurfaceView {
    override var isFlipped: Bool { true }

    private let iconTile = NSView()
    private let iconView = NSImageView()
    private let titleField = NSTextField(labelWithString: "")
    private let detailField = NSTextField(labelWithString: "")
    private let arrowField = NSTextField(labelWithString: "")
    private let actionButton = ModernMenuActionButton()
    private var activation: (() -> Void)?
    private var selected = false
    private var showsBaseBackground = false
    private var configuredTintColor: NSColor?
    private var hasConfiguredImage = false
    private var configuredEnabled = true

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        wantsLayer = true
        // Stejný povrch, rámeček a zaoblení jako karty na kořenové stránce.
        // Podnabídky se liší jen rozvržením obsahu, ne vizuálním systémem.
        layer?.cornerRadius = 14
        layer?.cornerCurve = .continuous
        layer?.borderWidth = 0.5
        layer?.shadowColor = NSColor.black.cgColor
        layer?.shadowOpacity = 0.045
        layer?.shadowRadius = 5
        layer?.shadowOffset = NSSize(width: 0, height: -1)
        iconTile.wantsLayer = true
        iconTile.layer?.cornerRadius = 10
        iconTile.layer?.cornerCurve = .continuous
        iconView.imageScaling = .scaleProportionallyDown
        titleField.font = .systemFont(ofSize: 12.5, weight: .semibold)
        titleField.lineBreakMode = .byTruncatingTail
        detailField.font = .systemFont(ofSize: 11, weight: .regular)
        detailField.textColor = .secondaryLabelColor
        detailField.lineBreakMode = .byTruncatingTail
        arrowField.font = .systemFont(ofSize: 17, weight: .medium)
        arrowField.textColor = .tertiaryLabelColor
        arrowField.alignment = .center
        actionButton.isBordered = false
        actionButton.title = ""
        actionButton.target = self
        actionButton.action = #selector(activateRow)
        actionButton.focusRingType = .none
        actionButton.pressChanged = { [weak self] pressed in
            self?.setPressed(pressed)
        }
        addSubview(iconTile)
        addSubview(iconView)
        addSubview(titleField)
        addSubview(detailField)
        addSubview(arrowField)
        addSubview(actionButton)
    }

    required init?(coder: NSCoder) {
        nil
    }

    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        updateBackground()
    }

    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        updateBackground()
    }

    override func viewWillDraw() {
        updateBackground()
        super.viewWillDraw()
    }

    override func pointerStateDidChange() {
        updateBackground()
    }

    override func layout() {
        super.layout()
        let hasDetail = !detailField.stringValue.isEmpty
        let reservedTrailingWidth: CGFloat = arrowField.stringValue.isEmpty ? 66 : 96
        let tileSize: CGFloat = 30
        let tileY = (bounds.height - tileSize) / 2
        iconTile.frame = NSRect(x: 12, y: tileY, width: tileSize, height: tileSize)
        iconView.frame = NSRect(x: 18, y: tileY + 6, width: 18, height: 18)
        titleField.frame = NSRect(
            x: 53,
            y: hasDetail ? 4 : (bounds.height - 19) / 2,
            width: max(80, bounds.width - reservedTrailingWidth),
            height: 19
        )
        detailField.frame = NSRect(x: 53, y: 24, width: max(80, bounds.width - reservedTrailingWidth), height: 15)
        arrowField.frame = NSRect(x: bounds.width - 33, y: (bounds.height - 22) / 2, width: 18, height: 22)
        actionButton.frame = bounds
    }

    func configure(
        title: String,
        detail: String,
        image: NSImage?,
        tintColor: NSColor? = nil,
        enabled: Bool,
        selected: Bool = false,
        showsBaseBackground: Bool = false,
        hasChildren: Bool,
        activation: (() -> Void)?
    ) {
        titleField.stringValue = title
        detailField.stringValue = detail
        iconView.image = image
        iconView.contentTintColor = image?.isTemplate == true ? tintColor : nil
        configuredTintColor = tintColor
        hasConfiguredImage = image != nil
        configuredEnabled = enabled
        arrowField.stringValue = hasChildren ? "›" : ""
        actionButton.isEnabled = enabled && activation != nil
        self.activation = activation
        self.selected = selected
        self.showsBaseBackground = showsBaseBackground
        updateBackground()
    }

    func updateText(_ title: String, detail: String, tintColor: NSColor?) {
        titleField.stringValue = title
        detailField.stringValue = detail
        configuredTintColor = tintColor
        iconView.contentTintColor = iconView.image?.isTemplate == true ? tintColor : nil
        detailField.textColor = tintColor ?? .secondaryLabelColor
        updateBackground()
        needsLayout = true
    }

    private func updateBackground() {
        let hoverActive = pointerIsInside && configuredEnabled && activation != nil
        let accent = configuredTintColor ?? NSColor.systemBlue
        let background: NSColor
        if hoverActive {
            background = accent.withAlphaComponent(evoraMenuUsesDarkAppearance(self) ? 0.16 : 0.09)
        } else if selected {
            background = evoraMenuSurfaceColor(self, elevated: true)
        } else if showsBaseBackground {
            background = evoraMenuSurfaceColor(self)
        } else {
            background = .clear
        }
        layer?.backgroundColor = background.cgColor
        layer?.borderWidth = hoverActive ? 1.2 : (showsBaseBackground || selected ? 0.5 : 0)
        layer?.borderColor = hoverActive
            ? accent.withAlphaComponent(0.72).cgColor
            : evoraMenuBorderColor(self).cgColor
        let tileColor = configuredTintColor ?? evoraMenuSecondaryTextColor(self)
        iconTile.layer?.backgroundColor = tileColor.withAlphaComponent(hasConfiguredImage ? 0.15 : 0).cgColor
        titleField.textColor = configuredEnabled
            ? evoraMenuPrimaryTextColor(self)
            : evoraMenuSecondaryTextColor(self).withAlphaComponent(0.52)
        detailField.textColor = configuredEnabled
            ? (configuredTintColor ?? evoraMenuSecondaryTextColor(self))
            : evoraMenuSecondaryTextColor(self).withAlphaComponent(0.52)
        arrowField.textColor = configuredEnabled
            ? evoraMenuSecondaryTextColor(self)
            : evoraMenuSecondaryTextColor(self).withAlphaComponent(0.45)
        iconView.alphaValue = configuredEnabled ? 1 : 0.45
        layer?.shadowColor = hoverActive ? accent.cgColor : NSColor.black.cgColor
        layer?.shadowOpacity = hoverActive ? 0.16 : (selected ? 0.09 : (showsBaseBackground ? 0.045 : 0))
        layer?.shadowRadius = hoverActive ? 10 : (selected ? 8 : (showsBaseBackground ? 5 : 0))
        layer?.shadowOffset = NSSize(width: 0, height: -1)
        evoraClearClassicHoverAnimation(layer: layer)
    }

    private func setPressed(_ pressed: Bool) {
        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.12
            animator().alphaValue = pressed ? 0.72 : 1
        }
    }

    @objc private func activateRow() {
        activation?()
    }
}

final class ClassicMenuGridCardView: ClassicMenuHoverSurfaceView {
    override var isFlipped: Bool { true }

    private let iconTile = NSView()
    private let iconView = NSImageView()
    private let titleField = NSTextField(labelWithString: "")
    private let arrowField = NSTextField(labelWithString: "")
    private let actionButton = ModernMenuActionButton()
    private var activation: (() -> Void)?
    private var tintColor: NSColor = .secondaryLabelColor
    private var enabled = true

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        wantsLayer = true
        layer?.cornerRadius = 14
        layer?.cornerCurve = .continuous
        layer?.borderWidth = 0.5
        layer?.shadowColor = NSColor.black.cgColor
        layer?.shadowOpacity = 0.045
        layer?.shadowRadius = 5
        layer?.shadowOffset = NSSize(width: 0, height: -1)

        iconTile.wantsLayer = true
        iconTile.layer?.cornerRadius = 10
        iconTile.layer?.cornerCurve = .continuous
        iconView.imageScaling = .scaleProportionallyDown

        titleField.font = .systemFont(ofSize: 11, weight: .semibold)
        titleField.lineBreakMode = .byTruncatingTail
        titleField.maximumNumberOfLines = 1

        arrowField.stringValue = "›"
        arrowField.font = .systemFont(ofSize: 16, weight: .medium)
        arrowField.textColor = .tertiaryLabelColor
        arrowField.alignment = .center

        actionButton.isBordered = false
        actionButton.title = ""
        actionButton.target = self
        actionButton.action = #selector(activateCard)
        actionButton.focusRingType = .none
        actionButton.pressChanged = { [weak self] pressed in
            self?.setPressed(pressed)
        }

        [iconTile, iconView, titleField, arrowField, actionButton].forEach { addSubview($0) }
        updateAppearance()
    }

    required init?(coder: NSCoder) {
        nil
    }

    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        updateAppearance()
    }

    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        updateAppearance()
    }

    override func viewWillDraw() {
        updateAppearance()
        super.viewWillDraw()
    }

    override func pointerStateDidChange() {
        updateAppearance()
    }

    override func layout() {
        super.layout()
        let tileSize: CGFloat = 30
        let tileY = (bounds.height - tileSize) / 2
        iconTile.frame = NSRect(x: 11, y: tileY, width: tileSize, height: tileSize)
        iconView.frame = NSRect(x: 17, y: tileY + 6, width: 18, height: 18)
        arrowField.frame = NSRect(x: bounds.width - 27, y: (bounds.height - 21) / 2, width: 16, height: 21)
        titleField.frame = NSRect(x: 50, y: (bounds.height - 19) / 2, width: max(70, bounds.width - 81), height: 19)
        actionButton.frame = bounds
    }

    func configure(
        title: String,
        image: NSImage?,
        tintColor: NSColor?,
        enabled: Bool,
        hasChildren: Bool,
        activation: (() -> Void)?
    ) {
        titleField.stringValue = title
        iconView.image = image
        self.tintColor = tintColor ?? .secondaryLabelColor
        iconView.contentTintColor = image?.isTemplate == true ? self.tintColor : nil
        arrowField.stringValue = hasChildren ? "›" : ""
        actionButton.isEnabled = enabled && activation != nil
        self.enabled = enabled
        self.activation = activation
        updateAppearance()
        needsLayout = true
    }

    private func updateAppearance() {
        guard let layer else { return }
        let hoverActive = pointerIsInside && enabled && activation != nil
        layer.backgroundColor = hoverActive
            ? tintColor.withAlphaComponent(evoraMenuUsesDarkAppearance(self) ? 0.16 : 0.09).cgColor
            : evoraMenuSurfaceColor(self).cgColor
        layer.borderWidth = hoverActive ? 1.2 : 0.5
        layer.borderColor = hoverActive
            ? tintColor.withAlphaComponent(0.72).cgColor
            : evoraMenuBorderColor(self).cgColor
        iconTile.layer?.backgroundColor = tintColor.withAlphaComponent(0.16).cgColor
        titleField.textColor = enabled
            ? evoraMenuPrimaryTextColor(self)
            : evoraMenuSecondaryTextColor(self).withAlphaComponent(0.52)
        arrowField.textColor = enabled
            ? evoraMenuSecondaryTextColor(self)
            : evoraMenuSecondaryTextColor(self).withAlphaComponent(0.45)
        iconView.alphaValue = enabled ? 1 : 0.45
        layer.shadowColor = hoverActive ? tintColor.cgColor : NSColor.black.cgColor
        layer.shadowOpacity = hoverActive ? 0.16 : 0.045
        layer.shadowRadius = hoverActive ? 10 : 5
        evoraClearClassicHoverAnimation(layer: layer)
    }

    private func setPressed(_ pressed: Bool) {
        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.12
            animator().alphaValue = pressed ? 0.70 : 1
        }
    }

    @objc private func activateCard() {
        activation?()
    }
}

final class ClassicMenuActionCardView: ClassicMenuHoverSurfaceView {
    override var isFlipped: Bool { true }

    private let iconTile = NSView()
    private let iconView = NSImageView()
    private let titleField = NSTextField(labelWithString: "")
    private let actionButton = ModernMenuActionButton()
    private var activation: (() -> Void)?
    private var tintColor: NSColor = .secondaryLabelColor
    private var enabled = true

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        wantsLayer = true
        layer?.cornerRadius = 12
        layer?.cornerCurve = .continuous
        layer?.borderWidth = 0.5
        layer?.shadowOffset = NSSize(width: 0, height: -1)

        iconTile.wantsLayer = true
        iconTile.layer?.cornerRadius = 9
        iconTile.layer?.cornerCurve = .continuous
        iconView.imageScaling = .scaleProportionallyDown

        titleField.font = .systemFont(ofSize: 10.5, weight: .semibold)
        titleField.lineBreakMode = .byTruncatingTail
        titleField.maximumNumberOfLines = 1

        actionButton.isBordered = false
        actionButton.title = ""
        actionButton.target = self
        actionButton.action = #selector(activateCard)
        actionButton.focusRingType = .none
        actionButton.pressChanged = { [weak self] pressed in
            self?.setPressed(pressed)
        }
        [iconTile, iconView, titleField, actionButton].forEach { addSubview($0) }
        updateAppearance()
    }

    required init?(coder: NSCoder) {
        nil
    }

    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        updateAppearance()
    }

    override func viewDidChangeEffectiveAppearance() {
        super.viewDidChangeEffectiveAppearance()
        updateAppearance()
    }

    override func viewWillDraw() {
        updateAppearance()
        super.viewWillDraw()
    }

    override func pointerStateDidChange() {
        updateAppearance()
    }

    override func layout() {
        super.layout()
        let tileSize: CGFloat = 28
        let tileY = (bounds.height - tileSize) / 2
        iconTile.frame = NSRect(x: 9, y: tileY, width: tileSize, height: tileSize)
        iconView.frame = NSRect(x: 15, y: tileY + 6, width: 16, height: 16)
        titleField.frame = NSRect(
            x: 45,
            y: (bounds.height - 18) / 2,
            width: max(64, bounds.width - 54),
            height: 18
        )
        actionButton.frame = bounds
    }

    func configure(
        title: String,
        image: NSImage?,
        tintColor: NSColor,
        enabled: Bool,
        activation: (() -> Void)?
    ) {
        titleField.stringValue = title
        iconView.image = image
        iconView.contentTintColor = image?.isTemplate == true ? tintColor : nil
        self.tintColor = tintColor
        self.enabled = enabled
        self.activation = activation
        actionButton.isEnabled = enabled && activation != nil
        updateAppearance()
        needsLayout = true
    }

    private func updateAppearance() {
        guard let layer else { return }
        let hoverActive = pointerIsInside && enabled && activation != nil
        layer.backgroundColor = hoverActive
            ? tintColor.withAlphaComponent(evoraMenuUsesDarkAppearance(self) ? 0.16 : 0.09).cgColor
            : evoraMenuSurfaceColor(self).cgColor
        layer.borderWidth = hoverActive ? 1.2 : 0.5
        layer.borderColor = hoverActive
            ? tintColor.withAlphaComponent(0.72).cgColor
            : evoraMenuBorderColor(self).cgColor
        layer.shadowColor = hoverActive ? tintColor.cgColor : NSColor.black.cgColor
        layer.shadowOpacity = hoverActive ? 0.16 : 0.045
        layer.shadowRadius = hoverActive ? 10 : 5
        iconTile.layer?.backgroundColor = tintColor.withAlphaComponent(0.16).cgColor
        titleField.textColor = enabled
            ? evoraMenuPrimaryTextColor(self)
            : evoraMenuSecondaryTextColor(self).withAlphaComponent(0.52)
        iconView.alphaValue = enabled ? 1 : 0.45
        evoraClearClassicHoverAnimation(layer: layer)
    }

    private func setPressed(_ pressed: Bool) {
        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.12
            animator().alphaValue = pressed ? 0.70 : 1
        }
    }

    @objc private func activateCard() {
        activation?()
    }
}

final class ClassicMenuNavigatorView: NSView {
    private enum Transition: Equatable {
        case none
        case forward
        case backward
    }

    private struct Page {
        let title: String
        let menu: NSMenu
        let isTransient: Bool
    }

    private weak var owner: AppDelegate?
    private let rootMenu: NSMenu
    private let backgroundView = NSVisualEffectView()
    private let scrollView = NSScrollView()
    private let documentView = ModernMenuFlippedView()
    private var panelTrackingArea: NSTrackingArea?
    private var pages: [Page]
    private var customViewSizes: [ObjectIdentifier: NSSize] = [:]
    private var openingAnimationGeneration = 0
    private let panelWidth: CGFloat = 440
    private let maximumPanelHeight: CGFloat = 620
    private let minimumPanelHeight: CGFloat = 210
    private let contentInset: CGFloat = 12
    private let cardGap: CGFloat = 8

    var currentMenu: NSMenu { pages.last?.menu ?? rootMenu }
    var pathTitles: [String] { pages.map(\.title) }

    init(owner: AppDelegate, rootMenu: NSMenu) {
        self.owner = owner
        self.rootMenu = rootMenu
        self.pages = [Page(title: "Evora Smart Menu", menu: rootMenu, isTransient: false)]
        super.init(frame: NSRect(x: 0, y: 0, width: panelWidth, height: maximumPanelHeight))
        wantsLayer = true
        layer?.backgroundColor = NSColor.clear.cgColor

        backgroundView.frame = bounds
        backgroundView.autoresizingMask = [.width, .height]
        backgroundView.material = .popover
        backgroundView.blendingMode = .withinWindow
        backgroundView.state = .active
        addSubview(backgroundView)

        scrollView.frame = bounds
        scrollView.autoresizingMask = [.width, .height]
        scrollView.drawsBackground = false
        scrollView.hasVerticalScroller = false
        scrollView.hasHorizontalScroller = false
        scrollView.autohidesScrollers = true
        scrollView.verticalScrollElasticity = .automatic
        scrollView.horizontalScrollElasticity = .none
        scrollView.scrollerStyle = .overlay
        scrollView.documentView = documentView
        addSubview(scrollView)
        renderCurrentPage(preserveScroll: false, transition: .none)
    }

    required init?(coder: NSCoder) {
        nil
    }

    override func viewDidMoveToWindow() {
        super.viewDidMoveToWindow()
        window?.acceptsMouseMovedEvents = true
        resetHoverSurfaces()
    }

    override func updateTrackingAreas() {
        super.updateTrackingAreas()
        if let panelTrackingArea {
            removeTrackingArea(panelTrackingArea)
        }
        let tracking = NSTrackingArea(
            rect: bounds,
            options: [.mouseEnteredAndExited, .mouseMoved, .activeAlways],
            owner: self,
            userInfo: nil
        )
        addTrackingArea(tracking)
        panelTrackingArea = tracking
    }

    override func mouseEntered(with event: NSEvent) {
        updateHoverSurfaces(at: event.locationInWindow)
    }

    override func mouseMoved(with event: NSEvent) {
        updateHoverSurfaces(at: event.locationInWindow)
    }

    override func mouseExited(with event: NSEvent) {
        resetHoverSurfaces()
    }

    override func viewWillMove(toWindow newWindow: NSWindow?) {
        if newWindow == nil {
            resetHoverSurfaces()
        }
        super.viewWillMove(toWindow: newWindow)
    }

    func playOpeningAnimation() {
        openingAnimationGeneration += 1
        let generation = openingAnimationGeneration
        guard !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion else {
            layer?.removeAnimation(forKey: "evora-menu-open")
            return
        }
        DispatchQueue.main.async { [weak self] in
            guard let self,
                  generation == self.openingAnimationGeneration,
                  self.window?.isVisible == true,
                  let layer = self.layer
            else { return }
            layer.removeAnimation(forKey: "evora-menu-open")

            var startTransform = CATransform3DMakeScale(0.945, 0.945, 1)
            startTransform = CATransform3DTranslate(startTransform, 7, 6, 0)
            let transform = CABasicAnimation(keyPath: "transform")
            transform.fromValue = NSValue(caTransform3D: startTransform)
            transform.toValue = NSValue(caTransform3D: CATransform3DIdentity)

            let opacity = CABasicAnimation(keyPath: "opacity")
            opacity.fromValue = 0.38
            opacity.toValue = 1

            let group = CAAnimationGroup()
            group.animations = [transform, opacity]
            group.duration = 0.24
            group.timingFunction = CAMediaTimingFunction(controlPoints: 0.16, 1, 0.3, 1)
            group.isRemovedOnCompletion = true
            layer.add(group, forKey: "evora-menu-open")
        }
    }

    private func hoverSurfaces(in root: NSView) -> [ClassicMenuHoverSurfaceView] {
        var result = [ClassicMenuHoverSurfaceView]()
        if let surface = root as? ClassicMenuHoverSurfaceView {
            result.append(surface)
        }
        for child in root.subviews {
            result.append(contentsOf: hoverSurfaces(in: child))
        }
        return result
    }

    private func updateHoverSurfaces(at windowPoint: NSPoint) {
        for surface in hoverSurfaces(in: documentView) {
            let point = surface.convert(windowPoint, from: nil)
            let inside = surface.window === window
                && !surface.isHidden
                && surface.alphaValue > 0
                && surface.bounds.contains(point)
                && surface.visibleRect.contains(point)
            surface.setPointerInside(inside)
        }
    }

    private func resetHoverSurfaces() {
        hoverSurfaces(in: documentView).forEach { $0.setPointerInside(false) }
    }

    func resetToRoot() {
        pages = [Page(title: "Evora Smart Menu", menu: rootMenu, isTransient: false)]
        owner?.classicNavigatorDidShow(rootMenu)
        renderCurrentPage(preserveScroll: false, transition: .none)
    }

    func refreshCurrentPage(preserveScroll: Bool = true) {
        renderCurrentPage(preserveScroll: preserveScroll, transition: .none)
    }

    func modelDidChange() {
        while pages.count > 1,
              pages.last?.isTransient != true,
              !menuIsReachable(pages.last!.menu, from: rootMenu, visited: []) {
            pages.removeLast()
        }
        owner?.classicNavigatorDidShow(currentMenu)
        renderCurrentPage(preserveScroll: true, transition: .none)
    }

    func isShowing(_ menu: NSMenu) -> Bool {
        currentMenu === menu
    }

    @discardableResult
    func navigateForSelfTest(_ titles: [String]) -> Bool {
        resetToRoot()
        for requested in titles {
            guard let item = currentMenu.items.first(where: {
                !$0.isHidden && owner?.modernPanelVisibleTitle($0) == requested
            }), let submenu = item.submenu else {
                return false
            }
            show(submenu, title: requested, isTransient: false)
        }
        return true
    }

    func visibleLabelsForSelfTest() -> [String] {
        currentMenu.items
            .filter { !$0.isHidden && !$0.isSeparatorItem }
            .flatMap { owner?.searchDetailLabels([$0]) ?? [] }
    }

    @objc private func goBack() {
        guard pages.count > 1 else { return }
        pages.removeLast()
        owner?.classicNavigatorDidShow(currentMenu)
        renderCurrentPage(preserveScroll: false, transition: .backward)
    }

    private func show(_ submenu: NSMenu, title: String, isTransient: Bool = false) {
        owner?.classicNavigatorPrepare(submenu)
        pages.append(Page(title: title, menu: submenu, isTransient: isTransient))
        owner?.classicNavigatorDidShow(submenu)
        renderCurrentPage(preserveScroll: false, transition: .forward)
    }

    func showTransientPage(_ menu: NSMenu, title: String) {
        show(menu, title: title, isTransient: true)
    }

    @discardableResult
    func replaceTransientPage(
        expected currentMenu: NSMenu,
        with replacement: NSMenu,
        title: String
    ) -> Bool {
        guard pages.count > 1,
              pages.last?.isTransient == true,
              pages.last?.menu === currentMenu
        else { return false }
        owner?.classicNavigatorPrepare(replacement)
        pages[pages.count - 1] = Page(title: title, menu: replacement, isTransient: true)
        owner?.classicNavigatorDidShow(replacement)
        renderCurrentPage(preserveScroll: false, transition: .none)
        return true
    }

    private func renderCurrentPage(preserveScroll: Bool, transition: Transition) {
        let previousOffset = scrollView.contentView.bounds.origin
        let previousSearchSelection = visibleSearchField(in: documentView)?.currentEditor()?.selectedRange
        resetHoverSurfaces()
        documentView.subviews.forEach { $0.removeFromSuperview() }

        var y: CGFloat = contentInset
        if pages.count > 1 {
            let header = navigationHeader(title: pages.last?.title ?? "")
            header.frame.origin = NSPoint(x: contentInset, y: y)
            documentView.addSubview(header)
            y += header.frame.height + cardGap
        }

        var pendingRootGridItem: NSMenuItem?
        func flushRootGrid(second: NSMenuItem? = nil) {
            guard let first = pendingRootGridItem else { return }
            let cardWidth = (panelWidth - 2 * contentInset - cardGap) / 2
            if let left = navigationGridCard(for: first, width: cardWidth) {
                left.frame.origin = NSPoint(x: contentInset, y: y)
                documentView.addSubview(left)
            }
            if let second, let right = navigationGridCard(for: second, width: cardWidth) {
                right.frame.origin = NSPoint(x: contentInset + cardWidth + cardGap, y: y)
                documentView.addSubview(right)
            }
            y += 64
            pendingRootGridItem = nil
        }

        for item in currentMenu.items where !item.isHidden {
            if currentMenu === rootMenu, isRootGridItem(item) {
                if pendingRootGridItem == nil {
                    pendingRootGridItem = item
                } else {
                    flushRootGrid(second: item)
                }
                continue
            }
            flushRootGrid()

            if item.isSeparatorItem {
                let separator = NSBox(frame: NSRect(
                    x: contentInset + 12,
                    y: y + 4,
                    width: panelWidth - 2 * (contentInset + 12),
                    height: 1
                ))
                separator.boxType = .separator
                documentView.addSubview(separator)
                y += 13
                continue
            }

            if let customView = item.view {
                let wrapper = wrappedCustomView(customView)
                wrapper.frame.origin = NSPoint(
                    x: (panelWidth - wrapper.frame.width) / 2,
                    y: y
                )
                documentView.addSubview(wrapper)
                y += wrapper.frame.height + 6
                continue
            }

            guard let row = navigationRow(for: item) else { continue }
            row.frame.origin = NSPoint(x: contentInset, y: y)
            documentView.addSubview(row)
            y += row.frame.height + 6
        }
        flushRootGrid()

        let naturalHeight = ceil(y + contentInset)
        let viewportHeight = min(maximumPanelHeight, max(minimumPanelHeight, naturalHeight))
        let contentHeight = max(naturalHeight, viewportHeight)
        if abs(frame.height - viewportHeight) > 0.5 {
            frame.size.height = viewportHeight
            backgroundView.frame = bounds
            scrollView.frame = bounds
        }
        scrollView.hasVerticalScroller = contentHeight > viewportHeight + 0.5
        documentView.frame = NSRect(x: 0, y: 0, width: panelWidth, height: contentHeight)
        documentView.needsLayout = true
        documentView.layoutSubtreeIfNeeded()

        if preserveScroll {
            let maximumY = max(0, contentHeight - scrollView.contentView.bounds.height)
            scrollView.contentView.scroll(to: NSPoint(x: 0, y: min(previousOffset.y, maximumY)))
        } else {
            scrollView.contentView.scroll(to: .zero)
        }
        scrollView.reflectScrolledClipView(scrollView.contentView)

        // NSClipView owns the document origin. Animating that origin could be
        // interrupted by menu tracking and leave a long page shifted by 18
        // points. A short opacity transition keeps the native feel without
        // changing scroll geometry.
        documentView.frame.origin.x = 0
        if transition != .none,
           window?.isVisible == true,
           !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion {
            documentView.alphaValue = 0.72
            NSAnimationContext.runAnimationGroup { context in
                context.duration = 0.14
                context.timingFunction = CAMediaTimingFunction(name: .easeOut)
                documentView.animator().alphaValue = 1
            }
        } else {
            documentView.alphaValue = 1
        }
        focusVisibleSearchField(selection: previousSearchSelection)
        owner?.classicNavigatorLayoutDidFinish()
    }

    private func wrappedCustomView(_ customView: NSView) -> NSView {
        // NSMenu si i u view dočasně zobrazeného jinde drží vlastní layout a
        // průběžně mu vrací origin na nulu. Samostatný wrapper proto nese
        // pozici v našem flipped dokumentu, zatímco původní view zůstává v
        // přirozeném AppKit souřadném systému a zachová si funkční ovládací
        // prvky (hledání, kamera i tlačítka detailu Miniserveru).
        let identifier = ObjectIdentifier(customView)
        let measured = customViewSizes[identifier] ?? customView.frame.size
        let size = NSSize(
            width: max(
                1,
                min(
                    panelWidth - 2 * contentInset,
                    measured.width > 0 ? measured.width : panelWidth - 2 * contentInset
                )
            ),
            height: max(1, measured.height)
        )
        customViewSizes[identifier] = size

        customView.removeFromSuperview()
        let wrapper = NSView(frame: NSRect(origin: .zero, size: size))
        wrapper.autoresizesSubviews = true
        customView.frame = wrapper.bounds
        customView.autoresizingMask = [.width, .height]
        wrapper.addSubview(customView)
        customView.layoutSubtreeIfNeeded()
        return wrapper
    }

    private func navigationHeader(title: String) -> NSView {
        let container = ClassicMenuAdaptiveView(frame: NSRect(
            x: 0,
            y: 0,
            width: panelWidth - 2 * contentInset,
            height: 44
        ))
        container.wantsLayer = true
        container.layer?.cornerRadius = 13
        container.layer?.cornerCurve = .continuous
        container.layer?.borderWidth = 0.5
        container.layer?.shadowColor = NSColor.black.cgColor
        container.layer?.shadowOpacity = 0.045
        container.layer?.shadowRadius = 5
        container.layer?.shadowOffset = NSSize(width: 0, height: -1)

        let back = NSButton(
            image: NSImage(systemSymbolName: "chevron.left", accessibilityDescription: "Zpět") ?? NSImage(),
            target: self,
            action: #selector(goBack)
        )
        back.frame = NSRect(x: 7, y: 7, width: 30, height: 30)
        back.isBordered = false
        back.focusRingType = .none
        back.contentTintColor = .systemBlue
        back.toolTip = "Zpět"
        back.wantsLayer = true
        back.layer?.cornerRadius = 9
        back.layer?.cornerCurve = .continuous
        container.addSubview(back)

        let label = NSTextField(labelWithString: title)
        label.frame = NSRect(x: 44, y: 10, width: container.frame.width - 88, height: 24)
        label.font = .systemFont(ofSize: 15, weight: .semibold)
        label.alignment = .center
        label.lineBreakMode = .byTruncatingTail
        container.addSubview(label)
        container.appearanceHandler = { [weak back, weak label] view in
            view.layer?.backgroundColor = evoraMenuSurfaceColor(view, elevated: true).cgColor
            view.layer?.borderColor = evoraMenuBorderColor(view).cgColor
            back?.layer?.backgroundColor = NSColor.systemBlue.withAlphaComponent(
                evoraMenuUsesDarkAppearance(view) ? 0.18 : 0.09
            ).cgColor
            label?.textColor = evoraMenuPrimaryTextColor(view)
        }
        container.refreshAppearance()
        return container
    }

    private func navigationRow(for item: NSMenuItem) -> NSView? {
        guard let owner else { return nil }
        let text = owner.modernPanelText(item)
        let title = text.0.isEmpty ? owner.modernPanelVisibleTitle(item) : text.0
        guard !title.isEmpty else { return nil }
        let detail = text.1.isEmpty ? (item.toolTip ?? "") : text.1
        let submenu = item.submenu
        let canRun = submenu != nil || item.action != nil
        let row = ModernMenuRowView(frame: NSRect(
            x: 0,
            y: 0,
            width: panelWidth - 2 * contentInset,
            height: 46
        ))
        row.configure(
            title: title,
            detail: owner.compactMenuText(detail, limit: 90),
            image: owner.modernPanelImage(item),
            tintColor: owner.modernPanelColor(item),
            enabled: item.isEnabled && canRun,
            showsBaseBackground: true,
            hasChildren: submenu != nil
        ) { [weak self, weak item] in
            guard let self, let item else { return }
            if let submenu = item.submenu {
                self.show(
                    submenu,
                    title: title,
                    isTransient: self.pages.last?.isTransient == true
                )
            } else {
                self.owner?.classicNavigatorPerform(item)
            }
        }
        return row
    }

    private func isRootGridItem(_ item: NSMenuItem) -> Bool {
        guard item.submenu != nil, let owner else { return false }
        let title = owner.modernPanelVisibleTitle(item)
        return [
            "Docházka",
            "Záznam práce",
            "Přehledy a výkazy",
            "Úkoly a poznámky",
            "Systémy",
            "Nastavení",
            "Nastavení Evora Smart Menu",
        ].contains(title)
    }

    private func navigationGridCard(for item: NSMenuItem, width: CGFloat) -> NSView? {
        guard let owner else { return nil }
        let visibleTitle = owner.modernPanelVisibleTitle(item)
        let title = visibleTitle == "Nastavení Evora Smart Menu" ? "Nastavení" : visibleTitle
        guard !title.isEmpty else { return nil }
        let submenu = item.submenu
        let canRun = submenu != nil || item.action != nil
        let card = ClassicMenuGridCardView(frame: NSRect(x: 0, y: 0, width: width, height: 58))
        card.configure(
            title: title,
            image: owner.modernPanelImage(item),
            tintColor: owner.modernPanelColor(item),
            enabled: item.isEnabled && canRun,
            hasChildren: submenu != nil
        ) { [weak self, weak item] in
            guard let self, let item else { return }
            if let submenu = item.submenu {
                self.show(
                    submenu,
                    title: title,
                    isTransient: self.pages.last?.isTransient == true
                )
            } else {
                self.owner?.classicNavigatorPerform(item)
            }
        }
        return card
    }

    private func visibleSearchField(in view: NSView) -> MenuSearchField? {
        if let field = view as? MenuSearchField { return field }
        for child in view.subviews {
            if let field = visibleSearchField(in: child) { return field }
        }
        return nil
    }

    private func focusVisibleSearchField(selection: NSRange? = nil) {
        guard let field = visibleSearchField(in: documentView) else { return }
        let expectedValue = field.stringValue
        let desiredSelection = selection
            ?? NSRange(location: field.stringValue.utf16.count, length: 0)
        DispatchQueue.main.async { [weak field] in
            guard let field, field.stringValue == expectedValue else { return }
            field.ensureKeyboardFocus(selection: desiredSelection)
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) { [weak field] in
            guard let field, field.stringValue == expectedValue else { return }
            field.ensureKeyboardFocus(selection: desiredSelection)
        }
    }

    private func menuIsReachable(_ target: NSMenu, from source: NSMenu, visited: Set<ObjectIdentifier>) -> Bool {
        if source === target { return true }
        let identifier = ObjectIdentifier(source)
        guard !visited.contains(identifier) else { return false }
        var nextVisited = visited
        nextVisited.insert(identifier)
        for item in source.items {
            if let submenu = item.submenu,
               menuIsReachable(target, from: submenu, visited: nextVisited) {
                return true
            }
        }
        return false
    }
}

final class ModernMenuPanelController: NSObject, NSWindowDelegate, NSSearchFieldDelegate {
    private typealias DetailAction = (title: String, image: NSImage?, color: NSColor?, handler: () -> Void)
    private weak var owner: AppDelegate?
    private let panel: NSPanel
    private let searchField = NSSearchField()
    private let sidebar = ModernMenuFlippedView()
    private let navigationTitle = NSTextField(labelWithString: "")
    private let headerSubtitle = NSTextField(labelWithString: "")
    private let profileCard = NSVisualEffectView()
    private let profileImageView = NSImageView()
    private let profileNameField = NSTextField(labelWithString: "")
    private let profileDetailField = NSTextField(labelWithString: "")
    private let profileMetricsField = NSTextField(labelWithString: "")
    private let backButton = NSButton()
    private let contentScroll = NSScrollView()
    private let contentDocument = ModernMenuFlippedView()
    private var rootItems: [NSMenuItem] = []
    private var navigation: [(title: String, menu: NSMenu)] = []
    private var selectedRootTitle = "Docházka"
    private var displayedItems: [NSMenuItem] = []
    private var displayedRows: [ObjectIdentifier: ModernMenuRowView] = [:]
    private var displayedTitle = "Systémy"
    private var searchRevision = 0
    private var searchWorkItem: DispatchWorkItem?
    private var isShowingCustomContent = false
    private var customDetail: (title: String, detail: String, content: NSAttributedString, actions: [DetailAction])?
    private let sidebarWidth: CGFloat = 252
    private let maximumSearchFieldWidth: CGFloat = 520

    var isVisible: Bool { panel.isVisible }

    init(owner: AppDelegate) {
        self.owner = owner
        panel = NSPanel(
            contentRect: NSRect(x: 0, y: 0, width: 960, height: 650),
            styleMask: [.titled, .closable, .resizable, .fullSizeContentView],
            backing: .buffered,
            defer: false
        )
        super.init()
        buildPanel()
    }

    private func buildPanel() {
        panel.title = "Evora Smart Menu"
        panel.titleVisibility = .hidden
        panel.titlebarAppearsTransparent = true
        panel.isReleasedWhenClosed = false
        panel.isMovableByWindowBackground = true
        panel.hidesOnDeactivate = false
        panel.level = .floating
        panel.collectionBehavior = [.moveToActiveSpace]
        panel.minSize = NSSize(width: 860, height: 580)
        panel.delegate = self
        panel.standardWindowButton(.miniaturizeButton)?.isHidden = true
        panel.standardWindowButton(.zoomButton)?.isHidden = true

        let root = ModernMenuFlippedView(frame: panel.contentView?.bounds ?? .zero)
        root.autoresizingMask = [.width, .height]
        root.wantsLayer = true
        root.layer?.backgroundColor = NSColor.underPageBackgroundColor.cgColor
        panel.contentView = root

        let header = NSVisualEffectView(frame: NSRect(x: 0, y: 0, width: 960, height: 84))
        header.material = .headerView
        header.blendingMode = .withinWindow
        header.state = .active
        header.autoresizingMask = [.width]
        let logo = NSImageView(frame: NSRect(x: 30, y: 28, width: 38, height: 38))
        logo.image = owner?.modernPanelBrandImage(size: NSSize(width: 38, height: 38))
        logo.imageScaling = .scaleProportionallyDown
        let title = NSTextField(labelWithString: "Evora Smart Menu")
        title.frame = NSRect(x: 82, y: 26, width: 350, height: 24)
        title.font = .systemFont(ofSize: 18, weight: .semibold)
        headerSubtitle.stringValue = owner?.modernPanelVersionText() ?? ""
        headerSubtitle.frame = NSRect(x: 83, y: 50, width: 500, height: 17)
        headerSubtitle.font = .systemFont(ofSize: 10.5, weight: .regular)
        headerSubtitle.textColor = .secondaryLabelColor
        header.addSubview(logo)
        header.addSubview(title)
        header.addSubview(headerSubtitle)

        profileCard.frame = NSRect(x: 588, y: 11, width: 344, height: 62)
        profileCard.autoresizingMask = [.minXMargin]
        profileCard.material = .contentBackground
        profileCard.blendingMode = .withinWindow
        profileCard.state = .active
        profileCard.wantsLayer = true
        profileCard.layer?.cornerRadius = 18
        profileCard.layer?.cornerCurve = .continuous
        profileCard.layer?.borderWidth = 1
        profileCard.layer?.borderColor = NSColor.separatorColor.withAlphaComponent(0.30).cgColor
        profileCard.layer?.shadowColor = NSColor.black.cgColor
        profileCard.layer?.shadowOpacity = 0.04
        profileCard.layer?.shadowRadius = 7
        profileCard.layer?.shadowOffset = NSSize(width: 0, height: -1)
        profileImageView.frame = NSRect(x: 10, y: 7, width: 48, height: 48)
        profileImageView.imageScaling = .scaleProportionallyUpOrDown
        profileImageView.wantsLayer = true
        profileImageView.layer?.cornerRadius = 24
        profileImageView.layer?.cornerCurve = .continuous
        profileImageView.layer?.masksToBounds = true
        profileImageView.layer?.borderWidth = 1
        profileImageView.layer?.borderColor = NSColor.separatorColor.withAlphaComponent(0.45).cgColor
        profileNameField.frame = NSRect(x: 70, y: 38, width: 260, height: 18)
        profileNameField.alignment = .left
        profileNameField.font = .systemFont(ofSize: 13, weight: .semibold)
        profileNameField.lineBreakMode = .byTruncatingTail
        profileDetailField.frame = NSRect(x: 70, y: 21, width: 260, height: 16)
        profileDetailField.alignment = .left
        profileDetailField.font = .monospacedDigitSystemFont(ofSize: 10.5, weight: .medium)
        profileDetailField.lineBreakMode = .byTruncatingTail
        profileMetricsField.frame = NSRect(x: 70, y: 5, width: 260, height: 15)
        profileMetricsField.alignment = .left
        profileMetricsField.font = .monospacedDigitSystemFont(ofSize: 9.5, weight: .regular)
        profileMetricsField.textColor = .secondaryLabelColor
        profileMetricsField.lineBreakMode = .byTruncatingTail
        profileCard.addSubview(profileImageView)
        profileCard.addSubview(profileNameField)
        profileCard.addSubview(profileDetailField)
        profileCard.addSubview(profileMetricsField)
        header.addSubview(profileCard)
        root.addSubview(header)

        let sidebarEffect = NSVisualEffectView(frame: NSRect(x: 0, y: 84, width: 252, height: 566))
        sidebarEffect.material = .sidebar
        sidebarEffect.blendingMode = .behindWindow
        sidebarEffect.state = .active
        sidebarEffect.autoresizingMask = [.height]
        sidebar.frame = sidebarEffect.bounds
        sidebar.autoresizingMask = [.width, .height]
        sidebarEffect.addSubview(sidebar)
        root.addSubview(sidebarEffect)

        searchField.frame = NSRect(x: 0, y: 106, width: maximumSearchFieldWidth, height: 34)
        searchField.placeholderString = "Hledat Miniserver nebo funkci…"
        searchField.sendsSearchStringImmediately = true
        searchField.delegate = self
        searchField.font = .systemFont(ofSize: 13, weight: .regular)
        searchField.isBezeled = true
        searchField.bezelStyle = .roundedBezel
        searchField.drawsBackground = true
        searchField.focusRingType = .none
        root.addSubview(searchField)
        layoutSearchField()

        backButton.frame = NSRect(x: 278, y: 157, width: 34, height: 30)
        backButton.bezelStyle = .texturedRounded
        backButton.image = NSImage(systemSymbolName: "chevron.left", accessibilityDescription: "Zpět")
        backButton.imagePosition = .imageOnly
        backButton.target = self
        backButton.action = #selector(goBack)
        root.addSubview(backButton)

        navigationTitle.frame = NSRect(x: 322, y: 155, width: 598, height: 30)
        navigationTitle.autoresizingMask = [.width]
        navigationTitle.font = .systemFont(ofSize: 24, weight: .semibold)
        navigationTitle.lineBreakMode = .byTruncatingTail
        root.addSubview(navigationTitle)

        contentScroll.frame = NSRect(x: 266, y: 202, width: 684, height: 436)
        contentScroll.autoresizingMask = [.width, .height]
        contentScroll.hasVerticalScroller = true
        contentScroll.autohidesScrollers = true
        contentScroll.scrollerStyle = .overlay
        contentScroll.drawsBackground = false
        contentScroll.borderType = .noBorder
        contentDocument.wantsLayer = true
        contentDocument.layer?.backgroundColor = NSColor.underPageBackgroundColor.cgColor
        contentScroll.documentView = contentDocument
        root.addSubview(contentScroll)
    }

    func show() {
        reloadData()
        searchField.stringValue = ""
        renderSelectedRoot()
        NSApp.activate(ignoringOtherApps: true)
        panel.center()
        panel.makeKeyAndOrderFront(nil)
        owner?.modernPanelDidShow()
        refreshLiveContent()
        DispatchQueue.main.async { [weak self] in
            guard let self else { return }
            self.scrollContentToTop()
            _ = self.panel.makeFirstResponder(self.searchField)
        }
    }

    func toggle() {
        if panel.isVisible {
            panel.orderOut(nil)
            owner?.modernPanelDidClose()
        } else {
            show()
        }
    }

    func closeForExternalAction() {
        guard panel.isVisible else { return }
        panel.orderOut(nil)
        owner?.modernPanelDidClose()
    }

    func reloadData() {
        headerSubtitle.stringValue = owner?.modernPanelVersionText() ?? ""
        updateProfileHeader()
        rootItems = owner?.modernPanelRootItems() ?? []
        if !rootItems.contains(where: { owner?.modernPanelVisibleTitle($0) == selectedRootTitle }) {
            selectedRootTitle = rootItems.first.map { owner?.modernPanelVisibleTitle($0) ?? "" } ?? ""
        }
        rebuildSidebar()
        if panel.isVisible && searchField.stringValue.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            renderSelectedRoot()
        }
    }

    private func rebuildSidebar() {
        sidebar.subviews.forEach { $0.removeFromSuperview() }
        var y: CGFloat = 22
        for item in rootItems {
            let title = owner?.modernPanelVisibleTitle(item) ?? item.title
            let displayTitle = title == "Nastavení Evora Smart Menu" ? "Nastavení" : title
            let row = ModernMenuRowView(frame: NSRect(x: 14, y: y, width: 224, height: 56))
            row.autoresizingMask = [.width]
            row.configure(
                title: displayTitle,
                detail: "",
                image: item.image ?? owner?.modernPanelImage(item),
                tintColor: owner?.modernPanelColor(item),
                enabled: item.isEnabled || item.submenu != nil,
                selected: title == selectedRootTitle,
                hasChildren: false,
                activation: { [weak self] in self?.selectRoot(title) }
            )
            sidebar.addSubview(row)
            y += 64
        }
    }

    private func selectRoot(_ title: String) {
        selectedRootTitle = title
        searchField.stringValue = ""
        rebuildSidebar()
        renderSelectedRoot()
    }

    private func renderSelectedRoot() {
        guard let item = rootItems.first(where: { owner?.modernPanelVisibleTitle($0) == selectedRootTitle }),
              let submenu = item.submenu
        else {
            render(items: [], title: selectedRootTitle)
            return
        }
        owner?.modernPanelPrepare(submenu)
        navigation = [(selectedRootTitle, submenu)]
        render(items: submenu.items, title: selectedRootTitle)
    }

    func controlTextDidChange(_ notification: Notification) {
        let query = searchField.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        searchWorkItem?.cancel()
        searchRevision += 1
        let revision = searchRevision
        if query.isEmpty {
            renderSelectedRoot()
            return
        }
        let work = DispatchWorkItem { [weak self] in
            guard let self,
                  revision == self.searchRevision,
                  self.searchField.stringValue.trimmingCharacters(in: .whitespacesAndNewlines) == query
            else { return }
            self.navigation.removeAll()
            self.render(items: self.owner?.modernPanelSearchItems(query) ?? [], title: "Výsledky · \(query)")
            DispatchQueue.main.async { [weak self] in
                guard let self else { return }
                let responder: NSResponder = self.searchField.currentEditor() ?? self.searchField
                _ = self.panel.makeFirstResponder(responder)
            }
        }
        searchWorkItem = work
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05, execute: work)
    }

    private func layoutSearchField() {
        guard let contentView = panel.contentView else { return }
        let availableWidth = max(360, contentView.bounds.width - sidebarWidth - 56)
        let fieldWidth = min(maximumSearchFieldWidth, availableWidth)
        let contentWidth = max(0, contentView.bounds.width - sidebarWidth)
        searchField.frame.origin.x = sidebarWidth + max(28, (contentWidth - fieldWidth) / 2)
        searchField.frame.size.width = fieldWidth
    }

    private func open(_ item: NSMenuItem) {
        if let submenu = item.submenu {
            owner?.modernPanelPrepare(submenu)
            let title = owner?.modernPanelVisibleTitle(item) ?? item.title
            navigation.append((title, submenu))
            render(items: submenu.items, title: title)
            return
        }
        guard item.isEnabled, item.action != nil else { return }
        let closesPanel = owner?.modernPanelShouldClose(after: item) ?? false
        if closesPanel {
            panel.orderOut(nil)
            owner?.modernPanelDidClose()
        }
        DispatchQueue.main.async { [weak self] in
            self?.owner?.modernPanelPerform(item)
        }
    }

    private func render(items: [NSMenuItem], title: String) {
        displayedItems = items
        displayedTitle = title
        displayedRows.removeAll()
        isShowingCustomContent = false
        customDetail = nil
        navigationTitle.stringValue = title
        backButton.isHidden = navigation.count < 2
        contentDocument.subviews.forEach { $0.removeFromSuperview() }
        let width = max(430, contentScroll.contentSize.width)
        let twoColumnTitles = [
            "Docházka",
            "Přehledy a výkazy",
            "Záznam práce",
            "Úkoly a poznámky",
            "Nastavení",
        ]
        let containsMiniserverSummary = items.contains { item in
            guard let payload = item.representedObject as? NSDictionary else { return false }
            return payload["modernEmbedded"] as? String == "miniserverSummary"
        }
        let usesTwoColumns = width >= 620 && (
            twoColumnTitles.contains(title)
                || title.hasPrefix("Plánované dovolené a absence")
                || containsMiniserverSummary
        )
        let columnGap: CGFloat = 10
        let columnWidth = usesTwoColumns ? (width - 26) / 2 : width - 16
        var y: CGFloat = 4
        var rendered = 0
        var column = 0

        func flushPartialRow() {
            if usesTwoColumns && column == 1 {
                y += 68
                column = 0
            }
        }

        for item in items where !item.isHidden {
            if item.isSeparatorItem {
                flushPartialRow()
                y += 10
                continue
            }
            if let embedded = owner?.modernPanelEmbeddedView(item, width: width - 16) {
                flushPartialRow()
                embedded.frame.origin = NSPoint(x: 8, y: y)
                contentDocument.addSubview(embedded)
                y += embedded.frame.height + 10
                rendered += 1
                continue
            }
            let text = owner?.modernPanelText(item) ?? (item.title, "")
            guard !text.0.isEmpty else { continue }
            let hasChildren = item.submenu != nil
            let enabled = item.isEnabled || hasChildren
            let forceFullWidth = (item.representedObject as? NSDictionary)?["modernFullWidth"] as? Bool == true
            if usesTwoColumns && forceFullWidth { flushPartialRow() }
            let itemUsesFullWidth = !usesTwoColumns || forceFullWidth
            let rowX = itemUsesFullWidth
                ? 8
                : 8 + CGFloat(column) * (columnWidth + columnGap)
            let rowWidth = itemUsesFullWidth ? width - 16 : columnWidth
            let row = ModernMenuRowView(frame: NSRect(x: rowX, y: y, width: rowWidth, height: 58))
            if itemUsesFullWidth { row.autoresizingMask = [.width] }
            row.configure(
                title: text.0,
                detail: text.1,
                image: item.image ?? owner?.modernPanelImage(item),
                tintColor: owner?.modernPanelColor(item),
                enabled: enabled,
                showsBaseBackground: true,
                hasChildren: hasChildren,
                activation: { [weak self, weak item] in
                    guard let item else { return }
                    self?.open(item)
                }
            )
            contentDocument.addSubview(row)
            displayedRows[ObjectIdentifier(item)] = row
            if usesTwoColumns {
                if forceFullWidth {
                    column = 0
                    y += 68
                } else if column == 0 {
                    column = 1
                } else {
                    column = 0
                    y += 68
                }
            } else {
                y += 68
            }
            rendered += 1
        }
        flushPartialRow()
        if rendered == 0 {
            let empty = NSTextField(labelWithString: "Nic jsme nenašli.")
            empty.frame = NSRect(x: 22, y: 28, width: width - 44, height: 24)
            empty.font = .systemFont(ofSize: 13, weight: .medium)
            empty.textColor = .secondaryLabelColor
            contentDocument.addSubview(empty)
            y = 70
        }
        contentDocument.frame = NSRect(x: 0, y: 0, width: width, height: max(contentScroll.contentSize.height, y + 12))
        scrollContentToTop()
    }

    private func scrollContentToTop() {
        contentScroll.contentView.setBoundsOrigin(.zero)
        contentScroll.reflectScrolledClipView(contentScroll.contentView)
    }

    @objc private func goBack() {
        if isShowingCustomContent, let current = navigation.last {
            owner?.modernPanelPrepare(current.menu)
            render(items: current.menu.items, title: current.title)
            return
        }
        guard navigation.count > 1 else { return }
        navigation.removeLast()
        guard let previous = navigation.last else { return }
        owner?.modernPanelPrepare(previous.menu)
        render(items: previous.menu.items, title: previous.title)
    }

    func windowDidResize(_ notification: Notification) {
        layoutSearchField()
        if let customDetail {
            showAttributedDetail(
                title: customDetail.title,
                detail: customDetail.detail,
                content: customDetail.content,
                actions: customDetail.actions
            )
        } else {
            render(items: displayedItems, title: displayedTitle)
        }
    }

    func windowWillClose(_ notification: Notification) {
        owner?.modernPanelDidClose()
    }

    private func updateProfileHeader() {
        profileNameField.stringValue = owner?.modernPanelProfileName() ?? "Evora Smart Hub"
        profileImageView.image = owner?.modernPanelProfileImage(size: NSSize(width: 48, height: 48))
        let detail = owner?.modernPanelProfileDetail() ?? "Docházka není dostupná"
        profileMetricsField.stringValue = owner?.modernPanelProfileMetrics() ?? ""
        let color = owner?.modernPanelProfileColor() ?? .secondaryLabelColor
        profileCard.layer?.borderColor = color.withAlphaComponent(0.22).cgColor
        profileCard.layer?.shadowColor = color.cgColor
        let output = NSMutableAttributedString(
            string: "● ",
            attributes: [.foregroundColor: color]
        )
        output.append(NSAttributedString(
            string: detail,
            attributes: [.foregroundColor: color]
        ))
        profileDetailField.attributedStringValue = output
    }

    func refreshLiveContent() {
        guard panel.isVisible else { return }
        owner?.modernPanelUpdateLiveItems()
        updateProfileHeader()
        for item in displayedItems {
            guard let row = displayedRows[ObjectIdentifier(item)] else { continue }
            let text = owner?.modernPanelText(item) ?? (item.title, "")
            row.updateText(text.0, detail: text.1, tintColor: owner?.modernPanelColor(item))
        }
    }

    func showInlineNotice(title: String, body: String, color: NSColor = .systemBlue) {
        let content = NSMutableAttributedString(
            string: "●  ",
            attributes: [
                .font: NSFont.systemFont(ofSize: 13, weight: .bold),
                .foregroundColor: color,
            ]
        )
        content.append(NSAttributedString(
            string: body,
            attributes: [
                .font: NSFont.systemFont(ofSize: 13),
                .foregroundColor: NSColor.labelColor,
            ]
        ))
        showAttributedDetail(title: title, detail: "Evora Smart Menu", content: content, actions: [])
    }

    func showAttributedDetail(
        title: String,
        detail: String,
        content: NSAttributedString,
        actions: [(title: String, image: NSImage?, color: NSColor?, handler: () -> Void)]
    ) {
        customDetail = (title, detail, content, actions)
        displayedItems = []
        displayedRows.removeAll()
        displayedTitle = title
        isShowingCustomContent = true
        navigationTitle.stringValue = title
        backButton.isHidden = navigation.isEmpty
        contentDocument.subviews.forEach { $0.removeFromSuperview() }
        let width = max(430, contentScroll.contentSize.width)
        var y: CGFloat = 8

        let detailField = NSTextField(labelWithString: detail)
        detailField.frame = NSRect(x: 18, y: y, width: width - 36, height: 20)
        detailField.font = .systemFont(ofSize: 11.5, weight: .medium)
        detailField.textColor = .secondaryLabelColor
        detailField.lineBreakMode = .byTruncatingTail
        contentDocument.addSubview(detailField)
        y += 30

        let textHeight = max(220, contentScroll.contentSize.height - CGFloat(actions.count * 68) - 58)
        let scroll = NSScrollView(frame: NSRect(x: 8, y: y, width: width - 16, height: textHeight))
        scroll.hasVerticalScroller = true
        scroll.autohidesScrollers = true
        scroll.scrollerStyle = .overlay
        scroll.drawsBackground = true
        scroll.backgroundColor = .controlBackgroundColor
        scroll.borderType = .noBorder
        scroll.wantsLayer = true
        scroll.layer?.cornerRadius = 15
        scroll.layer?.cornerCurve = .continuous
        let textView = NSTextView(frame: NSRect(x: 0, y: 0, width: width - 36, height: textHeight))
        textView.isEditable = false
        textView.isSelectable = true
        textView.drawsBackground = false
        textView.textContainerInset = NSSize(width: 14, height: 14)
        textView.textContainer?.widthTracksTextView = true
        textView.textStorage?.setAttributedString(content)
        scroll.documentView = textView
        contentDocument.addSubview(scroll)
        y += textHeight + 12

        for action in actions {
            let row = ModernMenuRowView(frame: NSRect(x: 8, y: y, width: width - 16, height: 58))
            row.configure(
                title: action.title,
                detail: "",
                image: action.image,
                tintColor: action.color,
                enabled: true,
                showsBaseBackground: true,
                hasChildren: false,
                activation: action.handler
            )
            contentDocument.addSubview(row)
            y += 68
        }
        contentDocument.frame = NSRect(x: 0, y: 0, width: width, height: max(contentScroll.contentSize.height, y + 12))
        scrollContentToTop()
    }

    func renderPreview(rootTitle: String, query: String, to url: URL) -> Bool {
        reloadData()
        selectedRootTitle = rootTitle
        searchField.stringValue = query
        rebuildSidebar()
        if query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            renderSelectedRoot()
        } else {
            navigation.removeAll()
            render(
                items: owner?.modernPanelSearchItems(query) ?? [],
                title: "Výsledky · \(query)"
            )
        }
        panel.contentView?.layoutSubtreeIfNeeded()
        panel.displayIfNeeded()
        guard
            let view = panel.contentView,
            let bitmap = view.bitmapImageRepForCachingDisplay(in: view.bounds)
        else {
            return false
        }
        view.cacheDisplay(in: view.bounds, to: bitmap)
        guard let png = bitmap.representation(using: .png, properties: [:]) else {
            return false
        }
        do {
            try png.write(to: url, options: .atomic)
            return true
        } catch {
            return false
        }
    }
}

final class EvoraCameraPlayerView: NSView {
    private let playerLayer = AVPlayerLayer()
    private let snapshotView = NSImageView()
    private var readinessObservation: NSKeyValueObservation?
    var onFirstVideoFrame: (() -> Void)?

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        wantsLayer = true
        layer?.backgroundColor = NSColor.black.cgColor
        layer?.borderColor = NSColor.separatorColor.cgColor
        layer?.borderWidth = 1
        playerLayer.videoGravity = .resizeAspect
        layer?.addSublayer(playerLayer)
        snapshotView.imageScaling = .scaleProportionallyUpOrDown
        snapshotView.animates = false
        addSubview(snapshotView)
    }

    required init?(coder: NSCoder) {
        nil
    }

    override func layout() {
        super.layout()
        playerLayer.frame = bounds
        snapshotView.frame = bounds
    }

    func show(_ player: AVPlayer?) {
        readinessObservation?.invalidate()
        readinessObservation = nil
        playerLayer.player = player
        guard player != nil else { return }
        readinessObservation = playerLayer.observe(
            \.isReadyForDisplay,
            options: [.initial, .new]
        ) { [weak self] layer, _ in
            guard layer.isReadyForDisplay else { return }
            DispatchQueue.main.async { [weak self] in
                self?.onFirstVideoFrame?()
            }
        }
    }

    func showSnapshot(_ image: NSImage) {
        snapshotView.image = image
        snapshotView.isHidden = false
    }

    func showPlaybackReady() {
        snapshotView.isHidden = true
    }

    deinit {
        readinessObservation?.invalidate()
    }
}

final class EvoraAuthenticatedHLSResourceLoader: NSObject, AVAssetResourceLoaderDelegate {
    private let authorizationToken: String
    private let upstreamScheme: String
    private let session: URLSession
    private let stateQueue = DispatchQueue(label: "cz.evora.smart-menu.camera-loader.state")
    private var tasks: [ObjectIdentifier: URLSessionDataTask] = [:]

    init(authorizationToken: String, upstreamScheme: String) {
        self.authorizationToken = authorizationToken
        self.upstreamScheme = upstreamScheme
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.timeoutIntervalForRequest = 12
        configuration.timeoutIntervalForResource = 20
        session = URLSession(configuration: configuration)
        super.init()
    }

    private func upstreamURL(_ protectedURL: URL) -> URL? {
        guard protectedURL.scheme == "evora-hls",
              var components = URLComponents(url: protectedURL, resolvingAgainstBaseURL: false)
        else { return nil }
        components.scheme = upstreamScheme
        return components.url
    }

    private func uniformType(for response: HTTPURLResponse, url: URL) -> String {
        switch response.mimeType?.lowercased() {
        case "application/vnd.apple.mpegurl", "application/x-mpegurl":
            return "public.m3u-playlist"
        case "video/mp2t":
            return "public.mpeg-2-transport-stream"
        case "video/mp4":
            return "public.mpeg-4"
        default:
            if url.pathExtension.lowercased() == "m3u8" { return "public.m3u-playlist" }
            if url.pathExtension.lowercased() == "ts" { return "public.mpeg-2-transport-stream" }
            return "public.data"
        }
    }

    func resourceLoader(
        _ resourceLoader: AVAssetResourceLoader,
        shouldWaitForLoadingOfRequestedResource loadingRequest: AVAssetResourceLoadingRequest
    ) -> Bool {
        guard let protectedURL = loadingRequest.request.url,
              let url = upstreamURL(protectedURL)
        else { return false }

        var request = URLRequest(url: url)
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue("Bearer \(authorizationToken)", forHTTPHeaderField: "Authorization")
        request.setValue("application/vnd.apple.mpegurl, video/mp2t, video/mp4, */*", forHTTPHeaderField: "Accept")
        if let dataRequest = loadingRequest.dataRequest {
            let start = max(dataRequest.currentOffset, dataRequest.requestedOffset)
            if start > 0 || !dataRequest.requestsAllDataToEndOfResource {
                let end = dataRequest.requestsAllDataToEndOfResource
                    ? ""
                    : String(start + Int64(max(1, dataRequest.requestedLength)) - 1)
                request.setValue("bytes=\(start)-\(end)", forHTTPHeaderField: "Range")
            }
        }

        let identifier = ObjectIdentifier(loadingRequest)
        let task = session.dataTask(with: request) { [weak self, weak loadingRequest] data, response, error in
            guard let self, let loadingRequest else { return }
            defer { self.stateQueue.async { self.tasks.removeValue(forKey: identifier) } }
            if let error {
                loadingRequest.finishLoading(with: error)
                return
            }
            guard let http = response as? HTTPURLResponse,
                  (200..<300).contains(http.statusCode),
                  let data
            else {
                loadingRequest.finishLoading(with: NSError(
                    domain: "cz.evora.smart-menu.camera",
                    code: (response as? HTTPURLResponse)?.statusCode ?? -1,
                    userInfo: [NSLocalizedDescriptionKey: "Autorizovaný video segment není dostupný."]
                ))
                return
            }
            if let information = loadingRequest.contentInformationRequest {
                information.contentType = self.uniformType(for: http, url: url)
                information.contentLength = max(0, http.expectedContentLength)
                information.isByteRangeAccessSupported = http.statusCode == 206
                    || http.value(forHTTPHeaderField: "Accept-Ranges")?.lowercased() == "bytes"
            }
            loadingRequest.dataRequest?.respond(with: data)
            loadingRequest.finishLoading()
        }
        stateQueue.sync { tasks[identifier] = task }
        task.resume()
        return true
    }

    func resourceLoader(
        _ resourceLoader: AVAssetResourceLoader,
        didCancel loadingRequest: AVAssetResourceLoadingRequest
    ) {
        let identifier = ObjectIdentifier(loadingRequest)
        let task = stateQueue.sync { tasks.removeValue(forKey: identifier) }
        task?.cancel()
    }

    func cancelAll() {
        let active = stateQueue.sync { () -> [URLSessionDataTask] in
            let current = Array(tasks.values)
            tasks.removeAll()
            return current
        }
        active.forEach { $0.cancel() }
        session.invalidateAndCancel()
    }
}

final class EvoraAuthenticatedHLSLoopbackProxy {
    private let upstreamMasterURL: URL
    private let authorizationToken: String
    private let routeKey = UUID().uuidString.replacingOccurrences(of: "-", with: "").lowercased()
    private let queue = DispatchQueue(label: "cz.evora.smart-menu.camera-loopback", qos: .userInitiated)
    private let session: URLSession
    private var listener: NWListener?

    init(upstreamMasterURL: URL, authorizationToken: String) {
        self.upstreamMasterURL = upstreamMasterURL
        self.authorizationToken = authorizationToken
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.timeoutIntervalForRequest = 15
        configuration.timeoutIntervalForResource = 24
        session = URLSession(configuration: configuration)
    }

    func start() -> URL? {
        guard listener == nil else { return localMasterURL() }
        let parameters = NWParameters.tcp
        parameters.requiredLocalEndpoint = .hostPort(
            host: NWEndpoint.Host("127.0.0.1"),
            port: .any
        )
        guard let listener = try? NWListener(using: parameters) else { return nil }
        self.listener = listener
        let ready = DispatchSemaphore(value: 0)
        let stateLock = NSLock()
        var didFinishStartup = false
        func finishStartup() {
            stateLock.lock()
            defer { stateLock.unlock() }
            guard !didFinishStartup else { return }
            didFinishStartup = true
            ready.signal()
        }
        listener.stateUpdateHandler = { state in
            switch state {
            case .ready, .failed, .cancelled:
                finishStartup()
            default:
                break
            }
        }
        listener.newConnectionHandler = { [weak self] connection in
            self?.accept(connection)
        }
        listener.start(queue: queue)
        guard ready.wait(timeout: .now() + 3) == .success,
              listener.state == .ready
        else {
            stop()
            return nil
        }
        return localMasterURL()
    }

    private func localMasterURL() -> URL? {
        guard let port = listener?.port else { return nil }
        var components = URLComponents()
        components.scheme = "http"
        components.host = "127.0.0.1"
        components.port = Int(port.rawValue)
        components.path = "/\(routeKey)/index.m3u8"
        components.query = upstreamMasterURL.query
        return components.url
    }

    private func accept(_ connection: NWConnection) {
        connection.start(queue: queue)
        receiveRequest(connection, buffer: Data())
    }

    private func receiveRequest(_ connection: NWConnection, buffer: Data) {
        connection.receive(minimumIncompleteLength: 1, maximumLength: 16_384) { [weak self] data, _, isComplete, error in
            guard let self else {
                connection.cancel()
                return
            }
            var next = buffer
            if let data { next.append(data) }
            if next.count > 32_768 {
                self.send(connection, status: 413, mime: "text/plain", body: Data())
                return
            }
            let delimiter = Data("\r\n\r\n".utf8)
            if next.range(of: delimiter) != nil {
                self.handle(connection, requestData: next)
                return
            }
            if isComplete || error != nil {
                self.send(connection, status: 400, mime: "text/plain", body: Data())
                return
            }
            self.receiveRequest(connection, buffer: next)
        }
    }

    private func upstreamURL(for requestTarget: String) -> URL? {
        guard let local = URLComponents(string: "http://127.0.0.1\(requestTarget)"),
              local.path.hasPrefix("/\(routeKey)/")
        else { return nil }
        let resource = String(local.path.dropFirst(routeKey.count + 2))
        guard ["index.m3u8", "playlist.m3u8", "init.mp4", "segment.m4s", "segment.ts"].contains(resource)
        else { return nil }
        if resource == "index.m3u8" { return upstreamMasterURL }
        var components = URLComponents(url: upstreamMasterURL, resolvingAgainstBaseURL: false)
        var directory = upstreamMasterURL.deletingLastPathComponent()
        directory.appendPathComponent(resource)
        components?.path = directory.path
        components?.query = local.query
        return components?.url
    }

    private func handle(_ connection: NWConnection, requestData: Data) {
        guard let header = String(data: requestData, encoding: .utf8) else {
            send(connection, status: 400, mime: "text/plain", body: Data())
            return
        }
        let lines = header.components(separatedBy: "\r\n")
        let first = lines.first?.split(separator: " ").map(String.init) ?? []
        guard first.count >= 2,
              ["GET", "HEAD"].contains(first[0]),
              let url = upstreamURL(for: first[1])
        else {
            send(connection, status: 404, mime: "text/plain", body: Data())
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = first[0]
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue("Bearer \(authorizationToken)", forHTTPHeaderField: "Authorization")
        request.setValue("application/vnd.apple.mpegurl, video/mp2t, video/mp4, */*", forHTTPHeaderField: "Accept")
        if let range = lines.first(where: { $0.lowercased().hasPrefix("range:") })?.split(separator: ":", maxSplits: 1).last {
            request.setValue(range.trimmingCharacters(in: .whitespacesAndNewlines), forHTTPHeaderField: "Range")
        }
        session.dataTask(with: request) { [weak self] data, response, _ in
            guard let self else {
                connection.cancel()
                return
            }
            guard let response = response as? HTTPURLResponse else {
                self.send(connection, status: 502, mime: "text/plain", body: Data())
                return
            }
            self.send(
                connection,
                status: response.statusCode,
                mime: response.mimeType ?? "application/octet-stream",
                body: first[0] == "HEAD" ? Data() : (data ?? Data()),
                contentRange: response.value(forHTTPHeaderField: "Content-Range"),
                acceptsRanges: response.value(forHTTPHeaderField: "Accept-Ranges")
            )
        }.resume()
    }

    private func send(
        _ connection: NWConnection,
        status: Int,
        mime: String,
        body: Data,
        contentRange: String? = nil,
        acceptsRanges: String? = nil
    ) {
        var header = "HTTP/1.1 \(status) \(HTTPURLResponse.localizedString(forStatusCode: status))\r\n"
        header += "Content-Type: \(mime)\r\n"
        header += "Content-Length: \(body.count)\r\n"
        header += "Cache-Control: private, no-store, max-age=0\r\n"
        if let contentRange { header += "Content-Range: \(contentRange)\r\n" }
        if let acceptsRanges { header += "Accept-Ranges: \(acceptsRanges)\r\n" }
        header += "Connection: close\r\n\r\n"
        var payload = Data(header.utf8)
        payload.append(body)
        connection.send(content: payload, completion: .contentProcessed { _ in
            connection.cancel()
        })
    }

    func stop() {
        listener?.cancel()
        listener = nil
        session.invalidateAndCancel()
    }

    deinit {
        stop()
    }
}

final class EvoraCameraHLSPlayer: NSObject {
    private weak var playerView: EvoraCameraPlayerView?
    private let onConnecting: () -> Void
    private let onReady: () -> Void
    private let onFailure: (String) -> Void
    private var endpoint: URL?
    private var authorizationToken = ""
    private var player: AVPlayer?
    private var loopbackProxy: EvoraAuthenticatedHLSLoopbackProxy?
    private var videoOutput: AVPlayerItemVideoOutput?
    private var itemObservation: NSKeyValueObservation?
    private var timeControlObservation: NSKeyValueObservation?
    private var notificationObservers: [NSObjectProtocol] = []
    private var startupWorkItem: DispatchWorkItem?
    private var reconnectWorkItem: DispatchWorkItem?
    private var frameProbeWorkItem: DispatchWorkItem?
    private var stopped = false
    private var playedInAttempt = false
    private var consecutiveFailures = 0
    private let failuresBeforeMessage = 1
    private(set) var isReady = false
    private(set) var diagnosticItemStatus = "unknown"
    private(set) var diagnosticTimeControlStatus = "unknown"
    private(set) var diagnosticErrorDomain = "none"
    private(set) var diagnosticErrorCode = 0

    init(
        playerView: EvoraCameraPlayerView,
        onConnecting: @escaping () -> Void,
        onReady: @escaping () -> Void,
        onFailure: @escaping (String) -> Void
    ) {
        self.playerView = playerView
        self.onConnecting = onConnecting
        self.onReady = onReady
        self.onFailure = onFailure
        super.init()
        configurePlayerView(playerView)
    }

    private func configurePlayerView(_ view: EvoraCameraPlayerView) {
        view.onFirstVideoFrame = { [weak self] in
            self?.handleFirstVideoFrame()
        }
    }

    func start(url: URL, token: String) {
        guard player == nil, endpoint == nil else { return }
        stopped = false
        endpoint = url
        authorizationToken = token
        consecutiveFailures = 0
        beginPlayback()
    }

    func attach(to view: EvoraCameraPlayerView) {
        playerView = view
        configurePlayerView(view)
        view.show(player)
        if isReady { view.showPlaybackReady() }
    }

    func stop() {
        stopped = true
        reconnectWorkItem?.cancel()
        reconnectWorkItem = nil
        startupWorkItem?.cancel()
        startupWorkItem = nil
        frameProbeWorkItem?.cancel()
        frameProbeWorkItem = nil
        tearDownPlayer(clearView: true)
        endpoint = nil
        authorizationToken = ""
        isReady = false
    }

    private func tearDownPlayer(clearView: Bool) {
        itemObservation?.invalidate()
        itemObservation = nil
        timeControlObservation?.invalidate()
        timeControlObservation = nil
        frameProbeWorkItem?.cancel()
        frameProbeWorkItem = nil
        videoOutput = nil
        notificationObservers.forEach(NotificationCenter.default.removeObserver)
        notificationObservers.removeAll()
        player?.pause()
        player = nil
        loopbackProxy?.stop()
        loopbackProxy = nil
        if clearView { playerView?.show(nil) }
    }

    private func beginPlayback() {
        guard !stopped, player == nil, let endpoint else { return }
        reconnectWorkItem = nil
        playedInAttempt = false
        onConnecting()
        let proxy = EvoraAuthenticatedHLSLoopbackProxy(
            upstreamMasterURL: endpoint,
            authorizationToken: authorizationToken
        )
        guard let localURL = proxy.start() else {
            scheduleReconnect("Místní přehrávač živého videa se nepodařilo spustit")
            return
        }
        loopbackProxy = proxy
        let asset = AVURLAsset(url: localURL)
        let item = AVPlayerItem(asset: asset)
        let output = AVPlayerItemVideoOutput(pixelBufferAttributes: CVPixelBufferAttributes(
            pixelFormatTypes: [CVPixelFormatType(rawValue: kCVPixelFormatType_32BGRA)]
        ))
        item.add(output)
        videoOutput = output
        item.preferredForwardBufferDuration = 0.5
        let player = AVPlayer(playerItem: item)
        player.automaticallyWaitsToMinimizeStalling = false
        self.player = player
        playerView?.show(player)

        itemObservation = item.observe(\.status, options: [.initial, .new]) { [weak self] item, _ in
            guard let self, !self.stopped else { return }
            switch item.status {
            case .unknown:
                self.diagnosticItemStatus = "unknown"
            case .readyToPlay:
                self.diagnosticItemStatus = "ready"
            case .failed:
                self.diagnosticItemStatus = "failed"
                let error = item.error as NSError?
                self.diagnosticErrorDomain = error?.domain ?? "none"
                self.diagnosticErrorCode = error?.code ?? 0
            @unknown default:
                self.diagnosticItemStatus = "other"
            }
            if item.status == .failed {
                self.scheduleReconnect("Živý přenos teď není dostupný")
            }
        }
        timeControlObservation = player.observe(\.timeControlStatus, options: [.initial, .new]) { [weak self] player, _ in
            guard let self, !self.stopped else { return }
            switch player.timeControlStatus {
            case .paused: self.diagnosticTimeControlStatus = "paused"
            case .waitingToPlayAtSpecifiedRate: self.diagnosticTimeControlStatus = "waiting"
            case .playing: self.diagnosticTimeControlStatus = "playing"
            @unknown default: self.diagnosticTimeControlStatus = "other"
            }
        }
        notificationObservers = [
            NotificationCenter.default.addObserver(
                forName: AVPlayerItem.failedToPlayToEndTimeNotification,
                object: item,
                queue: .main
            ) { [weak self] _ in self?.scheduleReconnect("Živý přenos byl přerušen") },
            NotificationCenter.default.addObserver(
                forName: AVPlayerItem.didPlayToEndTimeNotification,
                object: item,
                queue: .main
            ) { [weak self] _ in self?.scheduleReconnect("Živý přenos byl ukončen") },
        ]
        let startup = DispatchWorkItem { [weak self] in
            self?.scheduleReconnect("Živý přenos se nepodařilo načíst")
        }
        startupWorkItem?.cancel()
        startupWorkItem = startup
        DispatchQueue.main.asyncAfter(deadline: .now() + 8, execute: startup)
        player.play()
        scheduleFrameProbe()
    }

    private func scheduleFrameProbe() {
        guard !stopped, !isReady, frameProbeWorkItem == nil else { return }
        let probe = DispatchWorkItem { [weak self] in
            guard let self, !self.stopped else { return }
            self.frameProbeWorkItem = nil
            guard let output = self.videoOutput else { return }
            let itemTime = output.itemTime(forHostTime: CACurrentMediaTime())
            if output.hasNewPixelBuffer(forItemTime: itemTime),
               output.pixelBufferAndDisplayTime(forItemTime: itemTime).pixelBuffer != nil {
                self.handleFirstVideoFrame()
                return
            }
            self.scheduleFrameProbe()
        }
        frameProbeWorkItem = probe
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.05, execute: probe)
    }

    private func handleFirstVideoFrame() {
        guard !stopped, !isReady else { return }
        playedInAttempt = true
        consecutiveFailures = 0
        isReady = true
        startupWorkItem?.cancel()
        startupWorkItem = nil
        frameProbeWorkItem?.cancel()
        frameProbeWorkItem = nil
        playerView?.showPlaybackReady()
        onReady()
    }

    private func scheduleReconnect(_ message: String) {
        guard !stopped, reconnectWorkItem == nil else { return }
        startupWorkItem?.cancel()
        startupWorkItem = nil
        tearDownPlayer(clearView: true)
        consecutiveFailures = playedInAttempt ? 0 : consecutiveFailures + 1
        isReady = false
        playedInAttempt = false
        if consecutiveFailures >= failuresBeforeMessage {
            DispatchQueue.main.async { [weak self] in self?.onFailure(message) }
        }
        let delay = min(10.0, max(1.0, pow(2.0, Double(max(0, min(consecutiveFailures, 4) - 1)))))
        let reconnect = DispatchWorkItem { [weak self] in
            guard let self, !self.stopped else { return }
            self.reconnectWorkItem = nil
            self.beginPlayback()
        }
        reconnectWorkItem = reconnect
        DispatchQueue.main.asyncAfter(deadline: .now() + delay, execute: reconnect)
    }
}

final class AppDelegate: NSObject, NSApplicationDelegate, NSMenuDelegate, NSSearchFieldDelegate {

    struct IntranetAttendanceEvent: Codable {
        let id: String?
        let kind: String
        let source: String?
        let ts: String
    }

    struct IntranetAttendanceResponse: Decodable {
        let hrProfileId: String
        let greeting: String
        let uvazekH: Double
        let events: [IntranetAttendanceEvent]
    }

    struct IntranetPerson: Codable {
        let name: String
        let state: String
        let since: Double?
        var phone: String? = nil
    }

    struct IntranetLeave: Codable {
        let id: String
        let type: String
        let dateFrom: String
        let dateTo: String
        let portion: Double
        let note: String?
        let status: String
        let hours: Double?
        let createdAt: String?
    }

    struct IntranetHistoryDay {
        let date: Date
        let events: [(event: IntranetAttendanceEvent, date: Date)]
        let arrival: Date?
        let departure: Date?
        let workedSeconds: Int
    }

    struct IntranetAttendanceSession {
        let date: Date
        let startedAt: Date
        var endedAt: Date?
        var events: [(event: IntranetAttendanceEvent, date: Date)]
        var arrival: Date?
        var departure: Date?
        var worked: TimeInterval
        var activeStart: Date?
        var baseState: String
        var baseSince: Date?
        var temporaryState: String?
        var temporarySince: Date?
    }

    struct IntranetSnapshot: Codable {
        var dataState: String
        var fetchedAt: Double
        var summaryFetchedAt: Double
        var rosterFetchedAt: Double
        var currentState: String
        var currentSince: Double?
        var hrProfileId: String
        var todayWorkedSeconds: Int
        var lastArrival: Double?
        var lastDeparture: Double?
        var greeting: String
        var workloadHours: Double
        var cards: [String: String]
        var people: [IntranetPerson]
        var leavesFetchedAt: Double?
        var leaves: [IntranetLeave]?
        var notificationsUnread: Int
        var historyFetchedAt: Double?
        var historyEvents: [IntranetAttendanceEvent]?
        var errorCode: String?
        var errorMessage: String?

        static var empty: IntranetSnapshot {
            IntranetSnapshot(
                dataState: "not_configured",
                fetchedAt: 0,
                summaryFetchedAt: 0,
                rosterFetchedAt: 0,
                currentState: "none",
                currentSince: nil,
                hrProfileId: "",
                todayWorkedSeconds: 0,
                lastArrival: nil,
                lastDeparture: nil,
                greeting: "",
                workloadHours: 0,
                cards: [:],
                people: [],
                leavesFetchedAt: nil,
                leaves: [],
                notificationsUnread: 0,
                historyFetchedAt: nil,
                historyEvents: [],
                errorCode: nil,
                errorMessage: nil
            )
        }
    }

    struct IntranetServiceError: LocalizedError {
        let code: String
        let message: String

        var errorDescription: String? { message }
    }

    struct EvoraMiniServer: Decodable {
        let serial: String
        let project: String
        let type: String
        let folderName: String
        let folderColor: String?
        let connectionState: String
        let currentFirmware: String?
        let elementsOnline: Int?
        let elementsTotal: Int?
        let offlineDevices: Int?
        let lastCheckedAt: String?
        let lastLatencyMs: Double?
        let consecutiveFailures: Int?
        let healthVerdict: String?
        let healthRefreshedAt: String?
        let dataState: String?
        let hasCredentials: Bool
        let loxoneAppAvailable: Bool
        let loxoneConfigAvailable: Bool
        let configVersion: String?
        let configDownloadUrl: String?
        let deviceImageUrl: String?
    }

    struct EvoraCamera: Decodable {
        let id: Int
        let name: String
        let online: Bool
        let model: String?
        let firmware: String?
    }

    struct EvoraNvrSummary: Decodable {
        let configured: Bool
        let name: String
        let vendor: String?
        let model: String?
        let firmware: String?
        let connectionState: String
        let lastCheckedAt: String?
        let lastSuccessAt: String?
        let lastError: String?
        let onlineCount: Int
        let offlineCount: Int
        let cameras: [EvoraCamera]
    }

    struct EvoraGateStatus: Decodable {
        let configured: Bool
        let available: Bool
        let project: String?
    }

    struct EvoraTaskSummary: Decodable {
        let id: String
        let publicId: String
        let title: String
        let status: String
        let priority: String
        let assigneeName: String?
        let project: String?
        let dueAt: String?
        let source: String
        let updatedAt: String
    }

    struct EvoraPersonalNote: Codable {
        let id: String
        var title: String
        var body: String
        let createdAt: Double
        var updatedAt: Double
    }

    struct EvoraLauncherAgent: Decodable {
        let name: String
        let available: Bool
        let helperVersion: String?
        let requiredHelperVersion: String?
        let latestHelperVersion: String?
        let updateRequired: Bool?
        let updateAvailable: Bool?
    }

    struct EvoraFleetResponse: Decodable {
        struct Capabilities: Decodable {
            let miniserverWebInterface: Bool?
            let miniserverPasswordCopy: Bool?
        }

        struct User: Decodable {
            let id: String?
            let email: String
            let displayName: String?
            let role: String?
            let hasAvatar: Bool?
            let avatarUpdatedAt: String?
        }

        let appVersion: String?
        let capabilities: Capabilities?
        let user: User?
        let launcherAgent: EvoraLauncherAgent?
        let gate: EvoraGateStatus?
        let nvr: EvoraNvrSummary?
        let cameras: [EvoraCamera]?
        let tasks: [EvoraTaskSummary]?
        let items: [EvoraMiniServer]
    }

    struct EvoraConfigJob: Decodable {
        let id: String
        let state: String
        let message: String
        let errorCode: String?
        let requiredVersion: String
        let configUrl: String?
    }

    struct EvoraActionResponse: Decodable {
        let action: String
        let url: String?
        let password: String?
        let job: EvoraConfigJob?
    }

    struct EvoraGateCommandResponse: Decodable {
        let ok: Bool
        let command: String
    }

    struct EvoraJobResponse: Decodable {
        let job: EvoraConfigJob
    }

    struct EvoraPortalTicketSummary: Decodable {
        let id: String
        let ticketNumber: String
        let subject: String
        let status: String
        let createdTime: String
        let threadCount: Int
        let contactName: String
    }

    struct EvoraPortalTicketAttachment: Decodable {
        let id: String
        let name: String
        let token: String
        let downloadable: Bool?

        var canDownload: Bool { downloadable != false && !token.isEmpty }
    }

    struct EvoraPortalTicketAuthor: Decodable {
        let type: String
        let firstName: String
        let lastName: String
        let isLoxone: Bool
    }

    struct EvoraPortalTicketThread: Decodable {
        let id: String
        let createdTime: String
        let content: String
        let author: EvoraPortalTicketAuthor
        let attachments: [EvoraPortalTicketAttachment]
    }

    struct EvoraPortalTicketDetail: Decodable {
        let id: String
        let ticketNumber: String
        let subject: String
        let status: String
        let createdTime: String
        let threadCount: Int
        let contactName: String
        let threads: [EvoraPortalTicketThread]
        let attachments: [EvoraPortalTicketAttachment]
    }

    struct EvoraPortalTicketListResponse: Decodable {
        let items: [EvoraPortalTicketSummary]
    }

    struct EvoraPortalTicketDetailResponse: Decodable {
        let ticket: EvoraPortalTicketDetail
    }

    struct EvoraConfirmationResponse: Decodable {
        let confirmationId: String
        let expiresAt: String
    }

    struct EvoraPortalMutationResponse: Decodable {
        let ok: Bool
        let ticketId: String?
        let ticketNumber: String?
    }

    struct EvoraPortalDraft {
        let ticketId: String?
        let ticketNumber: String?
        let subject: String
        let body: String

        var isReply: Bool { ticketId != nil }
    }

    struct EvoraErrorResponse: Decodable {
        let error: String
        let code: String?
    }

    struct EvoraServiceError: LocalizedError {
        let message: String

        var errorDescription: String? {
            message
        }
    }

    var statusItem: NSStatusItem!
    private var modernMenuPanel: ModernMenuPanelController?
    private var classicPresentationMenu: NSMenu?
    private var classicMenuNavigator: ClassicMenuNavigatorView?
    private let classicMenuScreenEdgeInset: CGFloat = 8
    private var classicMenuFrameObservers: [NSObjectProtocol] = []
    private var classicMenuPositionCorrectionInProgress = false
    private var clockTimer: Timer?
    private var refreshTimer: Timer?
    private var intranetTimer: Timer?
    private var evoraTimer: Timer?
    private var statusPulseDimmed = false

    var menu: NSMenu!
    var macStatusItem: NSMenuItem!
    var windowsStatusItem: NSMenuItem!
    var trackingStatusItem: NSMenuItem!
    var shiftStatusItem: NSMenuItem!
    private weak var shiftStatusTitleField: NSTextField?
    private weak var shiftStatusDetailField: NSTextField?
    private weak var shiftStatusMetricsField: NSTextField?
    private weak var shiftStatusImageView: NSImageView?
    private weak var shiftStatusContainer: ClassicMenuAdaptiveView?
    private weak var brandedHeaderSubtitleField: NSTextField?

    var startAgentItem: NSMenuItem!
    var restartAgentItem: NSMenuItem!
    var stopAgentItem: NSMenuItem!
    var pauseAgentItem: NSMenuItem!
    var resumeAgentItem: NSMenuItem!
    var intranetOfficeItem: NSMenuItem!
    var intranetHomeItem: NSMenuItem!
    var intranetEndItem: NSMenuItem!
    var evoraMenu: NSMenu!
    var evoraMiniserversMenu: NSMenu!
    var evoraStatusItem: NSMenuItem!
    var intranetMenu: NSMenu!
    var tasksNotesMenu: NSMenu!

    private var mainMenuSearchQuery = ""
    private var mainMenuSearchWorkItem: DispatchWorkItem?
    private var mainMenuSearchRevision = 0
    private let classicSearchMinimumLength = 2
    private let classicSearchDebounce: TimeInterval = 0.35
    private var evoraRebuildDeferred = false
    private weak var mainMenuSearchField: MenuSearchField?
    private weak var mainMenuSearchItem: NSMenuItem?
    private weak var mainMenuNoResultsItem: NSMenuItem?
    private var mainMenuOriginalHidden: [ObjectIdentifier: Bool] = [:]
    private var mainMenuEvoraSearchItems: [(item: NSMenuItem, folder: String, server: EvoraMiniServer)] = []
    private var mainMenuEvoraUniqueSearchItems: [NSMenuItem] = []

    private var evoraRefreshInFlight = false
    private var evoraTicketsRefreshInFlight = false
    private var evoraMenuTracking = false
    private var evoraLastRefresh = Date.distantPast
    private var evoraServers: [EvoraMiniServer] = []
    private var evoraCameras: [EvoraCamera] = []
    private var evoraNvr: EvoraNvrSummary?
    private var evoraGate: EvoraGateStatus?
    private var evoraCameraMenus: [ObjectIdentifier: Int] = [:]
    private var evoraCameraPreviewViews: [Int: EvoraCameraPlayerView] = [:]
    private var evoraCameraPreviewLabels: [Int: NSTextField] = [:]
    private var evoraCameraStateLabels: [Int: NSTextField] = [:]
    private var evoraCameraPreviewStreams: [Int: EvoraCameraHLSPlayer] = [:]
    private var evoraCameraPreviewStartItems: [Int: DispatchWorkItem] = [:]
    private var evoraCameraSnapshotCache: [Int: NSImage] = [:]
    private var evoraCameraSnapshotRequests: Set<Int> = []
    private weak var evoraGateFeedbackField: NSTextField?
    private var evoraGateControlButtons: [NSButton] = []
    private var evoraLauncherAgent: EvoraLauncherAgent?
    private var evoraCapabilities: EvoraFleetResponse.Capabilities?
    private var evoraUser: EvoraFleetResponse.User?
    private var evoraProfileImage: NSImage?
    private var evoraProfileImageVersion = ""
    private var evoraProfileImageRequestInFlight = false
    private var evoraHubVersion: String?
    private var evoraTickets: [EvoraPortalTicketSummary] = []
    private var evoraTasks: [EvoraTaskSummary] = []
    private var personalNotes: [EvoraPersonalNote] = []
    private var personalNotesLoaded = false
    private weak var evoraTicketsSubmenu: NSMenu?
    private var evoraTicketsStatus = "Tickety: načítám…"
    private var evoraStatus = "Kontroluji připojení…"
    private var evoraSearchQuery = ""
    private var evoraSearchWorkItem: DispatchWorkItem?
    private var evoraSearchRevision = 0
    private weak var evoraSearchField: MenuSearchField?
    private var evoraFolderMenuItems: [(item: NSMenuItem, folder: String, color: NSColor, servers: [EvoraMiniServer])] = []
    private var evoraLazyFolderServers: [ObjectIdentifier: [EvoraMiniServer]] = [:]
    private var evoraFlatSearchMenuItems: [(item: NSMenuItem, folder: String, server: EvoraMiniServer)] = []
    private var evoraUniqueSearchItems: [NSMenuItem] = []
    private var evoraDeviceImageCache: [String: NSImage] = [:]
    private var evoraDeviceImageRequests: Set<String> = []
    private weak var evoraNoResultsItem: NSMenuItem?
    private let evoraKeychainAlias = "evora-token"
    private let evoraMenuVersion = "3.0.22"
    private var evoraTokenCache: String?
    private var evoraCredentialsLoaded = false
    private let evoraHubDefaultsKey = "EvoraSmartHubURL"
    private let defaultEvoraHubURL = "https://homeassistant-work.skunk-atria.ts.net:8443/api/loxone-servis"
    private lazy var evoraSession: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 30
        return URLSession(configuration: configuration)
    }()

    private var intranetSnapshot = IntranetSnapshot.empty
    private var intranetCredentialCache: [String: String] = [:]
    private var intranetCredentialsLoaded = false
    private var intranetRefreshInFlight = false
    private var intranetAccessToken = ""
    private var intranetRefreshToken = ""
    private var intranetCookieHeader = ""
    private var intranetTokenExpiresAt = Date.distantPast
    private var intranetRetryAfter = Date.distantPast
    private var intranetFailureCount = 0
    private var trackingReconciliationInFlight = false
    private let intranetBaseURL = "https://intranet.evora.cz"
    private let intranetSupabaseURL = "https://wknmzrjafskktgmkifux.supabase.co"
    private let intranetSupabaseKey = "sb_publishable_G7YKpiRaxEgGvuDxW6eemg_IG30Bw2F"
    private let intranetCookieName = "sb-wknmzrjafskktgmkifux-auth-token"
    private let intranetEmailAccount = "intranet-email"
    private let intranetPasswordAccount = "intranet-password"
    private lazy var intranetSession: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.httpCookieStorage = nil
        configuration.httpShouldSetCookies = false
        configuration.timeoutIntervalForRequest = 25
        configuration.timeoutIntervalForResource = 40
        return URLSession(configuration: configuration)
    }()

    let home = FileManager.default.homeDirectoryForCurrentUser.path

    var runtimeRoot: String {
        "\(home)/Library/Application Support/WorkLogAI"
    }

    var workPath: String {
        "\(runtimeRoot)/bin/work"
    }

    var keychainHelperPath: String {
        "\(runtimeRoot)/bin/worklog-keychain-helper"
    }

    private lazy var evoraSmartHubLogo: NSImage = {
        let path = "\(runtimeRoot)/app/evora-hub-mark.png"
        let image = NSImage(contentsOfFile: path) ?? loxoneLikeIcon()
        image.isTemplate = false
        return image
    }()

    private lazy var bundledProfilePhoto: NSImage? = {
        let path = "\(runtimeRoot)/app/profile-photo.jpeg"
        guard let image = NSImage(contentsOfFile: path) else { return nil }
        image.isTemplate = false
        return image
    }()

    private lazy var milesightMenuLogo: NSImage = {
        let encoded = "iVBORw0KGgoAAAANSUhEUgAAARgAAABLCAYAAACr45hhAAAACXBIWXMAAAsTAAALEwEAmpwYAAAGtmlUWHRYTUw6Y29tLmFkb2JlLnhtcAAAAAAAPD94cGFja2V0IGJlZ2luPSLvu78iIGlkPSJXNU0wTXBDZWhpSHpyZVN6TlRjemtjOWQiPz4gPHg6eG1wbWV0YSB4bWxuczp4PSJhZG9iZTpuczptZXRhLyIgeDp4bXB0az0iQWRvYmUgWE1QIENvcmUgNS42LWMxNDggNzkuMTY0MDM2LCAyMDE5LzA4LzEzLTAxOjA2OjU3ICAgICAgICAiPiA8cmRmOlJERiB4bWxuczpyZGY9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkvMDIvMjItcmRmLXN5bnRheC1ucyMiPiA8cmRmOkRlc2NyaXB0aW9uIHJkZjphYm91dD0iIiB4bWxuczp4bXA9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC8iIHhtbG5zOnhtcE1NPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvbW0vIiB4bWxuczpzdFJlZj0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL3NUeXBlL1Jlc291cmNlUmVmIyIgeG1sbnM6c3RFdnQ9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZUV2ZW50IyIgeG1sbnM6ZGM9Imh0dHA6Ly9wdXJsLm9yZy9kYy9lbGVtZW50cy8xLjEvIiB4bWxuczpwaG90b3Nob3A9Imh0dHA6Ly9ucy5hZG9iZS5jb20vcGhvdG9zaG9wLzEuMC8iIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChXaW5kb3dzKSIgeG1wOkNyZWF0ZURhdGU9IjIwMjAtMTAtMjNUMTA6MTA6NTUrMDg6MDAiIHhtcDpNb2RpZnlEYXRlPSIyMDIxLTEwLTI2VDEzOjI0OjQ0KzA4OjAwIiB4bXA6TWV0YWRhdGFEYXRlPSIyMDIxLTEwLTI2VDEzOjI0OjQ0KzA4OjAwIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOmM3MDQzNWY4LWE0MDktMzk0OS04YTIwLWI3NzU1NzBmOTYzZiIgeG1wTU06RG9jdW1lbnRJRD0ieG1wLmRpZDpGRENBMDlDQ0Y1NjAxMUU5QjVDOUMxMjI4NDY3MzA1MiIgeG1wTU06T3JpZ2luYWxEb2N1bWVudElEPSJ4bXAuZGlkOkZEQ0EwOUNDRjU2MDExRTlCNUM5QzEyMjg0NjczMDUyIiBkYzpmb3JtYXQ9ImltYWdlL3BuZyIgcGhvdG9zaG9wOkNvbG9yTW9kZT0iMyIgcGhvdG9zaG9wOklDQ1Byb2ZpbGU9InNSR0IgSUVDNjE5NjYtMi4xIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RkRDQTA5QzlGNTYwMTFFOUI1QzlDMTIyODQ2NzMwNTIiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6RkRDQTA5Q0FGNTYwMTFFOUI1QzlDMTIyODQ2NzMwNTIiLz4gPHhtcE1NOkhpc3Rvcnk+IDxyZGY6U2VxPiA8cmRmOmxpIHN0RXZ0OmFjdGlvbj0ic2F2ZWQiIHN0RXZ0Omluc3RhbmNlSUQ9InhtcC5paWQ6NzhlNDI5NmUtMjkwZi0yMzQxLWI5MTktZGQxMzNlMjc1ZTQ4IiBzdEV2dDp3aGVuPSIyMDIwLTEwLTIzVDExOjAwOjQzKzA4OjAwIiBzdEV2dDpzb2Z0d2FyZUFnZW50PSJBZG9iZSBQaG90b3Nob3AgQ0MgMjAxOSAoV2luZG93cykiIHN0RXZ0OmNoYW5nZWQ9Ii8iLz4gPHJkZjpsaSBzdEV2dDphY3Rpb249InNhdmVkIiBzdEV2dDppbnN0YW5jZUlEPSJ4bXAuaWlkOmM3MDQzNWY4LWE0MDktMzk0OS04YTIwLWI3NzU1NzBmOTYzZiIgc3RFdnQ6d2hlbj0iMjAyMS0xMC0yNlQxMzoyNDo0NCswODowMCIgc3RFdnQ6c29mdHdhcmVBZ2VudD0iQWRvYmUgUGhvdG9zaG9wIDIxLjAgKFdpbmRvd3MpIiBzdEV2dDpjaGFuZ2VkPSIvIi8+IDwvcmRmOlNlcT4gPC94bXBNTTpIaXN0b3J5PiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/Pkj8VOsAABlZSURBVHic7Z15uBxFtcB/FwIEBiEIEQUeCMMqW1gExIMEkNEgDxGfD+UK856K4Cgiojx4iOKKuMGHOi48lwsOiqDmsUgcZVGOIhAgLGERLrIGkS0kTDYg8Y/qSyYzVV3VNX23pH/fd7/kdk91152uPnXqbNW3bNkyhujr66MgnUq9tRlwLbB15CXuBA5q1kpP5dergoKxQ7tMWW0U+zHuqNRbWwN/JF643ATsVwiXglWFQsAEUqm3tgeuA7aKvMS1QKVZKz2fW6cKCsY4E0a7A+OBSr21M3ANsFHkJX4HHNGslRbk16uCgrFPocF4qNRbewN/Il64XA4cVgiXglWRQsCkUKm3pgJNYFLkJS4C3tWslZbk1aeCgvFEIWAcVOqtg4HfAutFXuJ84JhmrfRyfr0qKBhfFALGQqXeOgy4Elg78hLnAccVwqVgVacw8nZQqbf6gZ8S/92c3ayVTs2vRwUF45dCg2mjUm99CLiAeOFyWiFcCgqWU2gwCZV662PAt3u4xInNWum8vPpTULAyEC1gKvXWmsBtwBsyNFsM/Apjn3gh9t55U6m3TgXOimy+FPhIs1b6YY5dKihYKYheIiWu1w8Cy3yfbWMt4CjgB7H3zZtKvfUVehMuxxTCpaDATpSAKVcbbwdo1kp/JW5ZcVSl3jo05t55Uam3+ir11jnAaZGXeBET49LIsVsFBSsVmQVMudooAxeWq40Nk0OnA49E3LteqbdiY0x6olJvrQ58D/hE5CUWYqJzL8utUwUFKyExGsxemLD5cwASW8pxEdf5N+CrEe16IhEuFxDXZ4B5wKHNWmlGfr0qKFg56ctaD6ZcbZzD8pl/2uBA/wyASr11AXB0xvsvA/Zv1krXZ2wXRWKYvhg4PPIS8zAZ0TeGfFhEVgNuwNie2vl/Vf2cp+01wKs7Dquqfiy0s6siSQT21y2nqs1a6faR7k8sIrI98AvLqVNVdUQnNxGZDPzecurLqnpJ58F2mRLjRdqr7f8/KFcbOw4O9L8AnARMI1tSYB9wfqXemtKslRZF9CWYSr21DnAppo8xPA0c2KyV7gQoVxt7A4sHB/pnpbTZnhW/ryF+lHYjEdkUOMBy6rdhXV2lOQDYtePYUmBwFPrSC0L33wHw95HuCGYM2/ryqK9hpiVSudqYAOzedmhz4MsAzVrpGeDjWa6XsB1wRkS7YCr11quAK4gXLo9jNK0h4XIAMAP/oLUJF4CbPe32dhy/ydOuAN5oOXbPWAqLCMT2dzwP/G2kO4J9PL6ICVNJJasNZmdgYsexE8rVxj4AzVrp55gcnqycUqm3bBKyZyr11vrAH7BrBCE8BExt1kp3A5Srjbdh/sY5gwP98z1tbQLmJfwPxiWYgpZmqyqVems17N/dePzebH/HzaqaJSwkL2x9uV1VF/saZhUwthv1AT8qVxtDdoaPAL4Xr5MJwI8SA2xuVOqtyZgSl64X1scgpsTlAwDlauMwTH2XtQnTJmz3nRXwYGyz1+Oq+kTAPVdltsWe/e7TGMcUIrI2ZjLvZLQ0WNt4DOpLHgIGTDTvaQDNWulRICYfZw+MHScX2opzx2pGdwH7NmulxwDK1UY/8GtgjeR86qwoIhMd904d7Ilh2PZAx+MsPNKsLJrf7oBtsh1xASMiW9PtbAjuS1YB47INAJxWrjZ2Sv7/fUAzXhvgC5V6qxzRbgUq9dbmmPq5O0Ze4iaMQfefAOVq41iMa7v9oftmxSnYjei+wb4d8CrL8XE1C48StvG5CLOTw3jCJShHQ4PpqS/BXqRytbEusEPKR9YE/q9cbezbrJWWVuqtY4FZdLto01gb41U6qFkrRa01k8r/1wGbxrQH/gIcMlScu1xtnICp79LOIuAOz3WeAv7bcvwqT7vCwBvPdLoF8dxmrfTSKPSlF2xj4LFRWiLbBMx84L6Qxlnc1Hvg13j2BmrAd5q10r2VeutLwBcz3AOMMfYDeFy5NpLi3L8HNs7aNuFaTBDdAoByteFKgpw1OND/YtqFVHWQONeo7YEuo9BgvDRrJVusxnhkLC2RbePxJlVdGtI4yxIpbXnUzqS2/59NnHr6zUq99bosDSr11p6Yyv+xwuVyYFqbcDkLdxLkcGoTVjerqmY1nBeMQ0RkI+xb44z4BCMiE4DdeulLFgFjG/g2Xrl5s1Z6EaONBEm7NtYHvhv64Uq99SbgauIr/18M/EezVlpcrjb6ytXGuaQbqodFwIjIWhjbzYjcr2BM4nrPRmMM7Ep3WApk6MtwaDArSLdmrTQTODfDfYZ4V6XeOsL3oUq9dSBGuMQmTl4A9DdrpSXlamN1jIH6RE+b4XrYu2FfthYCZtXBtUSeOdIdIQdhFyRgytXGazHJiT4eGBzof9Zy/AziQpzrlXprkutkUpz7CuKLc38f+K9mrfRyIlwuAD7safMc8EDk/Xy4Hmhhf1l1sE3ko7VEtgm7Oar6eOgFQjWY0OWRVbIldg3fi2tjY+CbthOVeus9mNyiWOFyNlBr81btgymG5eOmwYH+4Yqm3MdybBEwbpL0CnpmLBl4bcIukzYd6kUKXR45v4hmrfSHSr31E+yu2zQ+UKm3LmrWSlcPHajUW0djKv/HVuQ7s1krfb7jWGi0r1ebEJH7gckdhy9T1WM8TW2Da5aqpnqsPH2ZBOyL8QJuC2yJsVVNxCwr52PSF+ZgtMybgd+paq45L20JnDthAjM3BUrAuhgb3dKkL09iXPyDwL2YDPKHPNc+EBME2cl7VDXKs5QEmB2AGRdbAZtgJrP1MKVf5yV9/CvwK1WdbbnGbzHffTs3qurbHPfcCrsdseulTqJ9pwJvwsR7bY4Zc2sl/ZsPPIyZnGYAfw71/CTXfxUmWbeTQ0RkbkrT+bStdkIFTOjL55NuJwOHkN3T8+NKvTUNM+BOAr6RsX07pzRrJVs6f+jf6Ivg3QLY2nLqHk+7DYBtLKcy218S6/+7gWOB/Ul/zhsk/26FyeA9OrmGAqepakzAZHs/3gt8FLt2ZmOnjt9/CRzpabMPxjHQyazAewKv9Pf9mFALn9b+WozAngZ8XkSuBk5S1TuTa60O7IcRoO3cm3JNb3KsiOyBsRG+G1jH08edgHcA/wv8TUROVtUrPG2G2BP7BL5m8uNihTw7rwZQrjb6CFsivYTngTZrpeeAmHommwOzgSX0JlxqDuECEV4yB7EZ1Ll4D0TkEMx39QvgIOILuwtwvYicJSL+QkHd/XgjZrBdSLhwsRFif7Jp2H9X1adCbyIi+2NCKn5C+Fho5yDgFhE5Pvl9e7qFC6RPULb7LgLuEJEtRWQ6xth7NH7h0sm2wOUi8qnAz8fm760wXkMG3zaE7c18++BAv7emS7NWurRSb00nruhTbDLkUowx90LbyXK1sREQkqLwyOBA/5Oez8QGyvUkYERkTZIdJUM+n4FTMd/f6aENROQozBJ2Dc9HQwixP1iDwUIunmganyOfkiFrAN9LNKGFjs+kjQObIJ6F0QLr2AVWVr4uIjeo6p89n4sRshAhYHoy8Dr4KGZ9a1Nr8+ZFjBu6q/JWG3n+jbbBfp+qPu9pZxtcQR4rEVkHuAwzi9p4AuNtuwFTfmJu8rMM2BCzpHsr8D6MXaST00TkUlX11v8QkSMwWkundrww6cN1mDDzxzC2AjDjcBLGLrMFJhZoH0xe1q2e+22GWa50EmIrG/Icphn3n8Pk1d2Psbu8iNEeNsOEFeyMqSjQzrnY3crPqur9jr64gtq2S/roYhHGZrUQs3SZjP0ZtnMq8O+ez4TaXTtZYUIIETChNwoWMM1aaU6l3jqF4d++ZCHw3oDi3LnYmJIBu0fWdgnWlHhf/Y8k+/rn2IXLo8ApwCWq6ton+yHgFuBiETkT45nrFHZ9mKXtBz192QS78X06cJyq/jOtPR0vpYhsrKotTxvX+AzRfL6LW7jcBHwBuCrNOJrY3D6J+X6G/u7VHf1KE3o7YfeIbtDx+wvAJZjv9CZV/YelTzsAJ2BKp9h4q4hMUFVrjpaIvBYjQDuZQXoO0iJVfaz9QIiAycvA28n5mBlzasZ2oSzE5BVdE/DZvP7GHbDPHj7BtDl2w3eI/eEzwGGW41cBR2aJn1DVx0XkHZiqaRt2nH57wCVOpzsT/BaMNydzwqGq+pajYBfML+Mp6iUix2JfTi4FPg2cE1LcSVUfBk4UkSsxL31a2ESa0AsZg98HPuuzLanqPUBNRB7GXlh/Ikbre8xyDtxC+wxVzRTwl2rkLVcba2BX2zqZT7p1vIsk/uTDGBUvb+YBBwUKFwh7uEvxR1O6jJk+wRQ1C4vILsBnLaeuAw6PCc5S1Wexq+SbiIjTBpDYgN5vOfW5GOGSAdt3d1ea5pNoHedYTi3FCOVvZa0cp6pN/NvgpI2DtGX6fOCdqvqRLIZrzFJtnuNcmj3T9j4sJiIey+dFmkK6S2qImwcH+rPmG9Gsle4HzszazsPTGOFyQ8iHy9XGUFyIj7sHB/p96rptkCzB/2BiI3jPo3ugPA8cpapLPG3TcE0WaZ6L3ehO11iCKVc6LCTLwz0tp3wC/WvYNc3PquqlPXTpx6QXwk7rl2tyWggcrKqZ9+BKKid2xeckpAkqVyXGzPFYPgGTl+s2jW/iMeRl4ElMoagsalwu8S8p15oV8LLb2j2StkQQkamYGJdOvppD3RBXf12eEbDXChoMqdvaAztg96w4x6OIvAF4j+XUHfS4T1eiqbl2fnjQpX2ISAn3Hu81Ve0lktemPT6qqgscfXGFpUTlw/kEzHDZX14hKQb0Icy6uRceB2So8n8GchGisXVUE8OwbRb2DapPWI7Nx7gze+U1lmMve5ZckyzHNkq0jOEipkTmx+j2+oCxL/Q6BsGt/aWNH1etpStU9ac99mcTy7G0d2Rb7N7dKCGXl4DpKVeiWSvdRm8BdIOY+rkxSYihQWA+Ieqqo+r7blyG4bRZ+HWAbW/vC1XVtebOwustx2KKZ00GvjSMQsY2PhfgWBYkdqL3Wk49jHGh58Fcx/G0ceCywX2yl44kmtGWllNpBvDYQFErTi9SudpYD3suQidzBgf6g7MrUzgTE/5sC7NPYzbw9qHi3FlI9nkKMWKH1HV1DZLYPZDSBuQ7sQuz6Z57ASAi62Eml4nJTx/LZ60SJr+lk7s9l7XGd2CKwR8mIj/DGJ9n5mj0tWmft6ZoIofQ7fYF48bPbEN0MMlxPKuB92FXzEwGpmBXIv6a0sY2Hufifr6ppLmp34hdlewkl1olzVppUaXe+hBmEIZyO3Bws1bKYllvZ0fCQq5vHRzo970UNskfslGWbXAtxbh3XRzuOP4VERlKhZiU/LsOxlA/AX8AVhp/8pz/PSYo0DZB7Mjy6oALROQGzHO+DpP8l9l4mCxJbbs2pL08/+k4npf2AiatpZOXSbczRkcie4jRRmzjcWbsfkxpqutwRPCm0qyV/gj8MMN99+9BuEC+Nibb9xWyUZatD3e73KxJxKc4rrUn5qXbFRMRuwVmmbI+vQkX8Gxbmxiy34WxhaWxDiYo8IvA9cCTIjIgIlk3xpuCfYK0vjyJ8dIWjDiPuB0wXNjscHeoqtVALiIbY55TJ8MlYJzOg2QJOSXPvqQJmGE38Do4BVM6II1rMa5oX/i9j7wieF11VH3t1gZ2sZxKWx7tSe/CIit3qaq3iryq3oV5wb6BsYWEsAFwDHCNiNyYZAuHkHU7jR2xG6//kpNxd4iskdyuiTyPGjBZvUFTsIelRL/jaUukkBSB3KvdN2ul5yv11keB3zg+chWmfm7oAE4jLyEaO0hiNthy3etJTN7MYswSa8jYuwDjdn6Z5TtutjA5NS9hQs9J/n0pOT6kPc1P2j2U/mcsR1WfAz4tIp/HLOUOxURrh5To2AtQETlUVa8O+GwnT6XUjnFpSL6lXzBJPRebjSftedres6X0GLohIhtiT+CNGVv5CphytbEpdvdWJ/cNDvTn4bVYgWatNL1Sb11Cd7zCdODIZq3USxAZAOVqo0TYxmzPDA70+zwosXsZxWxq5TJK75eDUTA3VPUF4GfJDyKyHfBmzPKugnvfqonABSKypSd+yLp3c8rnd3ccz7PWbYzb3PZSzw7IwfIRIyxs47inLYtdGsxoLY/a+Tgmw3doRrgIOKZZK+Wlzu5GWPmHEA3N9n09ZktEC2i3ELNtrYttHW1i3MgjRrLEug8T7YqI7I0pnPQ+y8c3wdhLrJvUicirsRuT015km20E8i1HanupXyC92JhtDOSxPHJpRmnOg9z74rLBjEj8SxrNWukfmC1P7sPUz81TuEC+WeKxdVRt7W7zuHFttp57cnSzjgiqeqOqHoWpumfDls07RIzmZxPMSwIyvLNgG1MzXc9GRLbBvqTKw+xg+47uSTRLW1/Wx/4d9dQXlwYzEikCXpq10nQCYzsiyMvA66qj6ov8dRW58gmmzixnAJ+mNJb5MfB1uuNH0rKSY9R/237fz6V8PhMp9VxiMqjzmLht105z4e+FPSylp1VKlwZTrjZWI0zALCFjzdMxRl7LwNhBEmtQs1n5o4uCjzbJ7G5z4T6S0symKTyQZIJ3kRQ+txFbTtSGK6YqbaLJFIkcioi4EnjT+jLFcdxbZCwN2xJpO8I2MbvNtz/zWKVcbUzGHg7fyUODA/2+OJuYQDmIU/PBnoj4ek+bMUtSAsK2TXCaW9wacxRx+w3TSlBkxPU8fVpDJ74lci99SRtbNofHY4lXMBqbgMlt+44xTJ5GbFsu070BtVhsfXhaVR/0tLMth3ZJapyMR2xbeDyFI2lQRF6PPZ4l7VnNw55VDPkVPLM9zydcm5SJyBrYtYbhin/xpbvYBExa6YkgehEwaZJ5rJOX/SVm3Z3WhxChbXOr9gHnxlT/H02S/p5kOfXLlAjozLNzsgxzedk+ndP3ltUD0/O+zynYJr1bPZpR5z5e4C7bEUyhwaTjExSuOqo+weRaI4cMrisdxw8Hfp4Yj8c8yUv9JUxsTDsvkb6XuW12fgm/reBax/G3AF/LkvEtIruLyNfafi/RvZ8TjHBQW9IX16Tnu+4ky7FdRGStXvqzgpGrXG2shT2BrJO5RGZXjhFCjNjeuq7Ep7bHBuaB2e/oy9gr6R8JHCoiFwFNzG5+3iCpZFBOxsSf7Apspaqf8bT5CuY7uhFjlHw4xFWe2DymYUoR2Gbas1Q1reyG7btz5vq08VPgeMe5TwFvFpFvYfnO2nY53Bc4AiOUzmv7yO7YJ+u05+laIsfs4d6Oy9jsG1s27WYD4NfJs56tqnOT+kXrY5I6n0tqEjvptKJPIWwvm+Hcn3lYKVcbZeyu3k5mR5bIDNlLOnr2UtUFInIicLHjIyVMbMmxACLyDGbbkhZmW9E+VsywXpfuAkNp22QMcTwrxnAsEpFHMDaiJzDfQwuTTrIuRoBtgal/49IWLgM6t/R9hZRdG7zatKreKCK/wSRk2ngTplo/IrKE5Z4tVxZ6+7OyCT1fGs1YyqAGeBD7e3FI8oNIV47tQZhaOk46BUyxPFpOrIE3xAtgG5APqurTAfdEVX+ZLLNCSjxuSJhAbce3xLMFiE3EBGrZgrVC+A5wsifx8A3Ezc5DfBgj4Hx1jnzbo3be0zZh3Osq/pVoRLYSo8MlYJ7xaIVghGuWzdaC8hA7Z5KeN7kfB+Rl4HXVUY01DGcS2qp6NmapMRwpArHJnTFch8mjOiGgdrGr+mDQeEwE+H6Y5WMvXMeKG+LZ3pu073BPhiGoLaUvIWPr22R7r0M8pV0CZkxE8A4zeWkwrjqqvnaxa+QuVHUGZjZ+NyZXqxe34pOYzOJv41/iPQ1cjlGPs6ZvLEruczqwk6oeoKqh9VhcuT7BW+ao6tOq+jZMVcAZhHtK5mCWjm9J+rwMXtmkzBYiEFMis1cDryuBN2TpvQg4EGN4D0luDOpr5xKpjr+K3eLBgf7xHJp+Acla24MvmvI57C5WX5mBhY520wP61EWyHPt18jOUCLgNJnhtEsvtLe1lGBZhYkPmYYTFQ8kAC71nk0QLSDSyTTGxKa9OftZK7jshuUcLeBYz6z/aQ95Uk+7Snf+MqeeSbANyWRKPshPGwD0Z812tjalGuBhTQGvQFc+Ce7ve61NuP5PuMbBQVZ8J7L6LicDJluPWpNFOkp0GzgDOEJFNMQmlr0uuux7mOS7A2NmCoo37li1bbqvt6xtXYRQFBaOOiPwK41lq5wlg09gyk+OddpkynFtKFBSs1IjIa7Dv7nDJqipcOikETEFBPJ/E7m06f6Q7MlYplkgFBREkFfpux9ib2pmhqtNGoUtjhmKJVFDQAyKyDibQsVO4LAX+Z+R7NHYpBExBQQaS2jJXYk+p+Yaq3jGyPRrbFAKmYKVGREp5bV0rIgdjXMxTLaf/gnHxFrRR2GAKVmqSnS6PxySuzsQUArsFuD8kfibRWA4FjsO94d3dwFRV7WUTwJWGFWRKIWAKVmZEROkuCQEm8PBBTFWAOZjAyRdYHlS2GWZTPFvd5HZuAw5VVd9mgasMhYApWCVIooznkV5AvBd+ApyQwx5GKxXtMiXPoscFBWONnRke4XIncEqSC1aQQmHkLViZeQY4C5Oc2+u+UQsx+V7TgF0L4RJGsUQqWCVIjLX7Jj9DtpWNkp/2ifZFTALoHIx9ZjbGQ3RDQNW8AlZcIv0Lil3doJVdHgwAAAAASUVORK5CYII="
        guard let data = Data(base64Encoded: encoded),
              let source = NSImage(data: data)
        else { return sf("video.fill", color: evoraCameraMenuColor()) ?? NSImage() }
        let image = NSImage(size: NSSize(width: 16, height: 16))
        image.lockFocus()
        source.draw(
            in: NSRect(x: 0, y: 0, width: 16, height: 16),
            from: NSRect(x: 0, y: 0, width: 75, height: 75),
            operation: .sourceOver,
            fraction: 1,
            respectFlipped: true,
            hints: [.interpolation: NSImageInterpolation.high]
        )
        image.unlockFocus()
        image.isTemplate = false
        return image
    }()

    var intranetSnapshotPath: String {
        "\(runtimeRoot)/intranet_state.json"
    }

    var personalNotesPath: String {
        "\(runtimeRoot)/user-data/personal-notes.json"
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        statusItem = NSStatusBar.system.statusItem(
            withLength: NSStatusItem.variableLength
        )

        if let button = statusItem.button {
            button.toolTip = "Evora Smart Menu"
            button.font = NSFont.monospacedDigitSystemFont(
                ofSize: NSFont.systemFontSize,
                weight: .semibold
            )
        }

        buildMenu()
        loadIntranetSnapshot()
        rebuildIntranetMenu()
        loadIntranetCredentialsAsync()
        loadPersonalNotesAsync()
        loadEvoraTokenAsync()
        refreshAll()

        clockTimer = Timer(
            timeInterval: 1.0,
            target: self,
            selector: #selector(tickClock),
            userInfo: nil,
            repeats: true
        )

        if let clockTimer {
            RunLoop.main.add(clockTimer, forMode: .common)
        }

        refreshTimer = Timer(
            timeInterval: 5.0,
            target: self,
            selector: #selector(refreshAll),
            userInfo: nil,
            repeats: true
        )

        if let refreshTimer {
            RunLoop.main.add(refreshTimer, forMode: .common)
        }

        intranetTimer = Timer(
            timeInterval: 60.0,
            target: self,
            selector: #selector(refreshIntranetTimerFired),
            userInfo: nil,
            repeats: true
        )

        if let intranetTimer {
            RunLoop.main.add(intranetTimer, forMode: .common)
        }

        // Keep the fleet snapshot warm independently of menu tracking. Opening
        // Systémy only renders the last snapshot and never starts a network read.
        evoraTimer = Timer(
            timeInterval: 60.0,
            target: self,
            selector: #selector(refreshEvoraMenu),
            userInfo: nil,
            repeats: true
        )

        if let evoraTimer {
            RunLoop.main.add(evoraTimer, forMode: .common)
        }
    }

    func applicationWillTerminate(_ notification: Notification) {
        stopAllEvoraCameraPreviews()
    }

    private var refreshInFlight = false
    private var cachedAgent = false
    private var cachedWindows = "NIKDY"

    // MARK: - Work CLI

    private func runBoundedProcess(
        executable: String,
        arguments: [String],
        input: String? = nil,
        timeout: TimeInterval,
        mergeStandardError: Bool
    ) -> (status: Int32, output: String, timedOut: Bool)? {
        let process = Process()
        let outputPipe = Pipe()
        let inputPipe = Pipe()
        let stateLock = NSLock()
        var didTimeOut = false

        process.executableURL = URL(fileURLWithPath: executable)
        process.arguments = arguments
        process.standardOutput = outputPipe
        process.standardError = mergeStandardError ? outputPipe : FileHandle.nullDevice
        if input != nil { process.standardInput = inputPipe }

        do {
            try process.run()
            if let input {
                inputPipe.fileHandleForWriting.write(Data(input.utf8))
                inputPipe.fileHandleForWriting.closeFile()
            }
            let timeoutWork = DispatchWorkItem {
                guard process.isRunning else { return }
                stateLock.lock()
                didTimeOut = true
                stateLock.unlock()
                process.terminate()
                DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + 0.5) {
                    if process.isRunning { Darwin.kill(process.processIdentifier, SIGKILL) }
                }
            }
            DispatchQueue.global(qos: .utility).asyncAfter(deadline: .now() + timeout, execute: timeoutWork)

            // Drain the pipe while the process runs. Waiting first can deadlock
            // when a verbose child fills the pipe buffer.
            let data = outputPipe.fileHandleForReading.readDataToEndOfFile()
            process.waitUntilExit()
            timeoutWork.cancel()
            stateLock.lock()
            let timedOut = didTimeOut
            stateLock.unlock()
            return (
                process.terminationStatus,
                String(data: data, encoding: .utf8) ?? "",
                timedOut
            )
        } catch {
            return nil
        }
    }

    func runWork(_ args: [String]) -> String {
        guard let result = runBoundedProcess(
            executable: workPath,
            arguments: args,
            timeout: 30,
            mergeStandardError: true
        ) else { return "CHYBA: příkaz se nepodařilo spustit" }
        return result.timedOut ? "CHYBA: příkaz překročil časový limit" : result.output
    }

    func quick() -> [String: Any]? {
        let out = runWork(["rychle"])

        guard
            let data = out.data(using: .utf8),
            let json = try? JSONSerialization.jsonObject(
                with: data
            ) as? [String: Any]
        else {
            return nil
        }

        return json
    }

    // MARK: - Evora Intranet

    func runKeychainHelper(
        _ command: String,
        alias: String,
        input: String? = nil
    ) -> (success: Bool, output: String) {
        guard let result = runBoundedProcess(
            executable: keychainHelperPath,
            arguments: [command, alias],
            input: input,
            timeout: 10,
            mergeStandardError: false
        ) else { return (false, "") }
        return (!result.timedOut && result.status == 0, result.output)
    }

    func readKeychainValue(alias: String) -> String? {
        let result = runKeychainHelper("read", alias: alias)
        return result.success && !result.output.isEmpty ? result.output : nil
    }

    func intranetCredential(_ account: String) -> String? {
        intranetCredentialCache[account]
    }

    func loadIntranetCredentialsAsync() {
        DispatchQueue.global(qos: .utility).async { [weak self] in
            guard let self else { return }
            let email = self.readKeychainValue(alias: self.intranetEmailAccount)
            let password = self.readKeychainValue(alias: self.intranetPasswordAccount)
            DispatchQueue.main.async {
                self.intranetCredentialCache.removeAll()
                if let email { self.intranetCredentialCache[self.intranetEmailAccount] = email }
                if let password { self.intranetCredentialCache[self.intranetPasswordAccount] = password }
                self.intranetCredentialsLoaded = true
                self.rebuildIntranetMenu()
                self.refreshIntranet(forceAll: true)
            }
        }
    }

    @discardableResult
    func saveIntranetCredential(_ value: String, account: String) -> Bool {
        let saved = runKeychainHelper("store", alias: account, input: value).success
        if saved {
            intranetCredentialCache[account] = value
            intranetCredentialsLoaded = true
        }
        return saved
    }

    @discardableResult
    func storeIntranetCredentials(email: String, password: String) -> Bool {
        guard saveIntranetCredential(email, account: intranetEmailAccount),
              saveIntranetCredential(password, account: intranetPasswordAccount)
        else {
            deleteIntranetCredentials()
            return false
        }
        return true
    }

    func deleteIntranetCredentials() {
        for account in [intranetEmailAccount, intranetPasswordAccount] {
            _ = runKeychainHelper("delete", alias: account)
        }
        intranetCredentialCache.removeAll()
        intranetCredentialsLoaded = true
        intranetAccessToken = ""
        intranetRefreshToken = ""
        intranetCookieHeader = ""
        intranetTokenExpiresAt = .distantPast
        intranetRetryAfter = .distantPast
        intranetFailureCount = 0
    }

    func hasIntranetCredentials() -> Bool {
        intranetCredential(intranetEmailAccount) != nil
            && intranetCredential(intranetPasswordAccount) != nil
    }

    func loadPersonalNotesAsync() {
        DispatchQueue.global(qos: .utility).async { [weak self] in
            guard let self else { return }
            let url = URL(fileURLWithPath: self.personalNotesPath)
            var notes: [EvoraPersonalNote] = []
            if let data = try? Data(contentsOf: url) {
                do {
                    notes = try JSONDecoder().decode([EvoraPersonalNote].self, from: data)
                } catch {
                    let formatter = DateFormatter()
                    formatter.locale = Locale(identifier: "en_US_POSIX")
                    formatter.dateFormat = "yyyyMMdd-HHmmss"
                    let backup = url.deletingPathExtension()
                        .appendingPathExtension("corrupt-\(formatter.string(from: Date())).json")
                    try? FileManager.default.copyItem(at: url, to: backup)
                }
            }
            DispatchQueue.main.async {
                self.personalNotes = notes.sorted { $0.updatedAt > $1.updatedAt }
                self.personalNotesLoaded = true
                self.rebuildTasksNotesMenu()
            }
        }
    }

    @discardableResult
    func savePersonalNotes() -> Bool {
        let url = URL(fileURLWithPath: personalNotesPath)
        do {
            let directory = url.deletingLastPathComponent()
            try FileManager.default.createDirectory(
                at: directory,
                withIntermediateDirectories: true,
                attributes: [.posixPermissions: 0o700]
            )
            let encoder = JSONEncoder()
            encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
            let data = try encoder.encode(personalNotes)
            try data.write(to: url, options: .atomic)
            try FileManager.default.setAttributes(
                [.posixPermissions: 0o600],
                ofItemAtPath: url.path
            )
            return true
        } catch {
            return false
        }
    }

    func intranetBase64URL(_ data: Data) -> String {
        data.base64EncodedString()
            .replacingOccurrences(of: "+", with: "-")
            .replacingOccurrences(of: "/", with: "_")
            .replacingOccurrences(of: "=", with: "")
    }

    func intranetCookieHeader(for sessionObject: [String: Any]) throws -> String {
        let compact = try JSONSerialization.data(withJSONObject: sessionObject)
        let value = "base64-\(intranetBase64URL(compact))"
        let characters = Array(value)
        let chunkSize = 3_180
        guard characters.count > chunkSize else {
            return "\(intranetCookieName)=\(value)"
        }
        var parts: [String] = []
        var offset = 0
        var index = 0
        while offset < characters.count {
            let end = min(offset + chunkSize, characters.count)
            parts.append("\(intranetCookieName).\(index)=\(String(characters[offset..<end]))")
            offset = end
            index += 1
        }
        return parts.joined(separator: "; ")
    }

    func applyIntranetSessionObject(_ object: [String: Any]) throws {
        guard
            let token = object["access_token"] as? String,
            !token.isEmpty
        else {
            throw IntranetServiceError(
                code: "internal_error",
                message: "Přihlášení neobsahuje přístupovou relaci."
            )
        }
        let expiresAt: Double
        if let value = object["expires_at"] as? Double {
            expiresAt = value
        } else if let value = object["expires_at"] as? Int {
            expiresAt = Double(value)
        } else {
            let expiresIn = (object["expires_in"] as? Double)
                ?? Double(object["expires_in"] as? Int ?? 3_600)
            expiresAt = Date().timeIntervalSince1970 + expiresIn
        }
        intranetAccessToken = token
        if let refreshToken = object["refresh_token"] as? String,
           !refreshToken.isEmpty {
            intranetRefreshToken = refreshToken
        }
        intranetCookieHeader = try intranetCookieHeader(for: object)
        intranetTokenExpiresAt = Date(timeIntervalSince1970: expiresAt)
    }

    func authenticateIntranet(
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        guard
            let email = intranetCredential(intranetEmailAccount),
            let password = intranetCredential(intranetPasswordAccount)
        else {
            completion(.failure(IntranetServiceError(
                code: "not_configured",
                message: "Připojení k Evora Intranetu není nastavené."
            )))
            return
        }
        guard let url = URL(string: "\(intranetSupabaseURL)/auth/v1/token?grant_type=password") else {
            completion(.failure(IntranetServiceError(code: "internal_error", message: "Neplatná adresa přihlášení.")))
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue(intranetSupabaseKey, forHTTPHeaderField: "apikey")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.httpBody = try? JSONSerialization.data(withJSONObject: [
            "email": email,
            "password": password
        ])
        intranetSession.dataTask(with: request) { [weak self] data, response, error in
            guard let self else { return }
            if error != nil {
                completion(.failure(IntranetServiceError(
                    code: "unavailable",
                    message: "Evora Intranet není dostupný."
                )))
                return
            }
            guard let http = response as? HTTPURLResponse else {
                completion(.failure(IntranetServiceError(code: "internal_error", message: "Přihlášení nevrátilo platnou odpověď.")))
                return
            }
            guard (200..<300).contains(http.statusCode), let data else {
                let code = [400, 401, 403].contains(http.statusCode) ? "auth_denied" : "unavailable"
                let message = code == "auth_denied"
                    ? "Evora Intranet odmítl e-mail nebo heslo."
                    : "Přihlášení k Evora Intranetu se nezdařilo."
                completion(.failure(IntranetServiceError(code: code, message: message)))
                return
            }
            do {
                guard let object = try JSONSerialization.jsonObject(with: data) as? [String: Any]
                else {
                    throw IntranetServiceError(code: "internal_error", message: "Přihlašovací relaci nelze zpracovat.")
                }
                try self.applyIntranetSessionObject(object)
                completion(.success(()))
            } catch let serviceError as IntranetServiceError {
                completion(.failure(serviceError))
            } catch {
                completion(.failure(IntranetServiceError(code: "internal_error", message: "Přihlašovací relaci nelze zpracovat.")))
            }
        }.resume()
    }

    func refreshIntranetSession(
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        guard !intranetRefreshToken.isEmpty else {
            authenticateIntranet(completion: completion)
            return
        }
        guard let url = URL(string: "\(intranetSupabaseURL)/auth/v1/token?grant_type=refresh_token") else {
            completion(.failure(IntranetServiceError(code: "internal_error", message: "Neplatná adresa obnovení přihlášení.")))
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue(intranetSupabaseKey, forHTTPHeaderField: "apikey")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        request.httpBody = try? JSONSerialization.data(withJSONObject: [
            "refresh_token": intranetRefreshToken
        ])
        intranetSession.dataTask(with: request) { [weak self] data, response, error in
            guard let self else { return }
            if error != nil {
                completion(.failure(IntranetServiceError(code: "unavailable", message: "Evora Intranet není dostupný.")))
                return
            }
            guard let http = response as? HTTPURLResponse else {
                completion(.failure(IntranetServiceError(code: "internal_error", message: "Obnovení přihlášení nevrátilo platnou odpověď.")))
                return
            }
            guard (200..<300).contains(http.statusCode), let data else {
                if [400, 401, 403].contains(http.statusCode) {
                    self.intranetRefreshToken = ""
                    self.authenticateIntranet(completion: completion)
                } else {
                    completion(.failure(IntranetServiceError(code: "unavailable", message: "Přihlášení se nepodařilo obnovit.")))
                }
                return
            }
            do {
                guard let object = try JSONSerialization.jsonObject(with: data) as? [String: Any]
                else {
                    throw IntranetServiceError(code: "internal_error", message: "Obnovenou relaci nelze zpracovat.")
                }
                try self.applyIntranetSessionObject(object)
                completion(.success(()))
            } catch let serviceError as IntranetServiceError {
                completion(.failure(serviceError))
            } catch {
                completion(.failure(IntranetServiceError(code: "internal_error", message: "Obnovenou relaci nelze zpracovat.")))
            }
        }.resume()
    }

    func ensureIntranetSession(
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        if !intranetCookieHeader.isEmpty,
           intranetTokenExpiresAt.timeIntervalSinceNow > 45 {
            completion(.success(()))
            return
        }
        refreshIntranetSession(completion: completion)
    }

    func intranetRequest(
        path: String,
        method: String = "GET",
        body: [String: Any]? = nil,
        retryAuthentication: Bool = true,
        completion: @escaping (Result<Data, Error>) -> Void
    ) {
        ensureIntranetSession { [weak self] sessionResult in
            guard let self else { return }
            switch sessionResult {
            case .failure(let error):
                completion(.failure(error))
            case .success:
                guard let url = URL(string: "\(self.intranetBaseURL)\(path)") else {
                    completion(.failure(IntranetServiceError(code: "internal_error", message: "Neplatná adresa Evora Intranetu.")))
                    return
                }
                var request = URLRequest(url: url)
                request.httpMethod = method
                request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
                request.setValue(self.intranetCookieHeader, forHTTPHeaderField: "Cookie")
                request.setValue("application/json, text/html", forHTTPHeaderField: "Accept")
                if let body {
                    request.httpBody = try? JSONSerialization.data(withJSONObject: body)
                    request.setValue("application/json", forHTTPHeaderField: "Content-Type")
                }
                self.intranetSession.dataTask(with: request) { data, response, error in
                    if error != nil {
                        completion(.failure(IntranetServiceError(code: "unavailable", message: "Evora Intranet není dostupný.")))
                        return
                    }
                    guard let http = response as? HTTPURLResponse else {
                        completion(.failure(IntranetServiceError(code: "internal_error", message: "Evora Intranet nevrátil platnou odpověď.")))
                        return
                    }
                    let redirectedToLogin = http.url?.path == "/login"
                    if (http.statusCode == 401 || redirectedToLogin), retryAuthentication {
                        self.intranetAccessToken = ""
                        self.intranetCookieHeader = ""
                        self.intranetTokenExpiresAt = .distantPast
                        self.intranetRequest(
                            path: path,
                            method: method,
                            body: body,
                            retryAuthentication: false,
                            completion: completion
                        )
                        return
                    }
                    if http.statusCode == 403 {
                        completion(.failure(IntranetServiceError(code: "permission_denied", message: "Účet nemá k této části Evora Intranetu oprávnění.")))
                        return
                    }
                    guard (200..<300).contains(http.statusCode), !redirectedToLogin else {
                        completion(.failure(IntranetServiceError(
                            code: redirectedToLogin ? "auth_denied" : "source_unavailable",
                            message: redirectedToLogin
                                ? "Přihlášení k Evora Intranetu už neplatí."
                                : "Evora Intranet požadovaná data neposkytl."
                        )))
                        return
                    }
                    completion(.success(data ?? Data()))
                }.resume()
            }
        }
    }

    func parseIntranetDate(_ value: String) -> Date? {
        let fractional = ISO8601DateFormatter()
        fractional.formatOptions = [.withInternetDateTime, .withFractionalSeconds]
        if let date = fractional.date(from: value) { return date }
        return ISO8601DateFormatter().date(from: value)
    }

    func intranetStateLabel(_ state: String) -> String {
        switch state {
        case "in_building": return "V práci"
        case "home_office": return "Home office"
        case "on_break": return "Na přestávce"
        case "doctor": return "U lékaře"
        case "offsite": return "Služebně mimo"
        case "vacation": return "Dovolená"
        case "sick": return "Omluvená absence"
        case "away", "none": return "Po pracovní době"
        default: return "Stav neověřen"
        }
    }

    func intranetLeaveTypeLabel(_ type: String) -> String {
        switch type {
        case "vacation": return "Dovolená"
        case "sickday": return "Sick day"
        case "sick": return "Nemoc"
        case "doctor": return "Lékař"
        default: return "Absence"
        }
    }

    func intranetLeaveStatus(_ status: String) -> (label: String, color: NSColor) {
        switch status.lowercased() {
        case "approved", "auto_approved": return ("Schváleno", .systemGreen)
        case "pending", "announced": return ("Čeká na schválení", .systemOrange)
        case "rejected": return ("Zamítnuto", .systemRed)
        case "cancelled", "canceled": return ("Zrušeno", .secondaryLabelColor)
        default: return (status.isEmpty ? "Stav neuveden" : status, .secondaryLabelColor)
        }
    }

    func formatIntranetLeaveRange(_ leave: IntranetLeave) -> String {
        let input = DateFormatter()
        input.locale = Locale(identifier: "en_US_POSIX")
        input.timeZone = TimeZone(identifier: "Europe/Prague")
        input.dateFormat = "yyyy-MM-dd"
        guard let from = input.date(from: leave.dateFrom), let to = input.date(from: leave.dateTo) else {
            return leave.dateFrom == leave.dateTo ? leave.dateFrom : "\(leave.dateFrom)–\(leave.dateTo)"
        }
        let output = DateFormatter()
        output.locale = Locale(identifier: "cs_CZ")
        output.timeZone = input.timeZone
        output.dateFormat = "d. M. yyyy"
        if Calendar.current.isDate(from, inSameDayAs: to) {
            return output.string(from: from)
        }
        return "\(output.string(from: from)) – \(output.string(from: to))"
    }

    func intranetDataStateLabel(_ state: String) -> String {
        switch state {
        case "loading": return "Načítám"
        case "current": return "Aktuální"
        case "stale": return "Zastaralá data"
        case "auth_denied": return "Přihlášení odmítnuto"
        case "permission_denied": return "Bez oprávnění"
        case "not_configured": return "Není nastaven přístup"
        case "source_unavailable": return "Zdroj údaj neposkytuje"
        case "unavailable": return "Intranet neodpovídá"
        default: return "Interní chyba Evora Smart Menu"
        }
    }

    func deriveIntranetAttendance(
        events: [IntranetAttendanceEvent],
        now: Date = Date()
    ) -> (state: String, since: Double?, worked: Int, arrival: Double?, departure: Double?) {
        guard let latest = intranetAttendanceSessions(events: events, now: now).last else {
            return ("none", nil, 0, nil, nil)
        }
        let calendar = intranetCalendar()
        let belongsToToday = calendar.isDate(latest.date, inSameDayAs: now)
            || (latest.endedAt.map { calendar.isDate($0, inSameDayAs: now) } ?? false)
        let isOpen = latest.departure == nil
        if (!isOpen && !belongsToToday) || (isOpen && now.timeIntervalSince(latest.startedAt) > 36 * 60 * 60) {
            return ("none", nil, 0, nil, nil)
        }
        var worked = latest.worked
        if let activeStart = latest.activeStart {
            worked += max(0, now.timeIntervalSince(activeStart))
        }
        return (
            latest.temporaryState ?? latest.baseState,
            (latest.temporarySince ?? latest.baseSince)?.timeIntervalSince1970,
            max(0, Int(worked)),
            latest.arrival?.timeIntervalSince1970,
            latest.departure?.timeIntervalSince1970
        )
    }

    func intranetAttendanceSessions(
        events: [IntranetAttendanceEvent],
        now: Date = Date()
    ) -> [IntranetAttendanceSession] {
        let calendar = intranetCalendar()
        let parsed = events.compactMap { event -> (IntranetAttendanceEvent, Date)? in
            guard let date = parseIntranetDate(event.ts), date <= now else { return nil }
            return (event, date)
        }.sorted { $0.1 < $1.1 }
        var sessions: [IntranetAttendanceSession] = []
        var session: IntranetAttendanceSession?

        func makeSession(_ date: Date) -> IntranetAttendanceSession {
            IntranetAttendanceSession(
                date: calendar.startOfDay(for: date),
                startedAt: date,
                endedAt: nil,
                events: [],
                arrival: nil,
                departure: nil,
                worked: 0,
                activeStart: nil,
                baseState: "none",
                baseSince: nil,
                temporaryState: nil,
                temporarySince: nil
            )
        }

        for (event, date) in parsed {
            if var current = session,
               date.timeIntervalSince(current.startedAt) > 36 * 60 * 60 {
                current.activeStart = nil
                current.baseState = "away"
                current.baseSince = current.events.last?.date ?? current.startedAt
                sessions.append(current)
                session = nil
            }
            if session == nil { session = makeSession(date) }
            guard var current = session else { continue }
            current.events.append((event: event, date: date))
            switch event.kind {
            case "arrival", "home_start":
                current.baseState = event.kind == "arrival" ? "in_building" : "home_office"
                current.baseSince = date
                current.temporaryState = nil
                current.temporarySince = nil
                if current.activeStart == nil { current.activeStart = date }
                if current.arrival == nil { current.arrival = date }
            case "break_out", "doctor_out":
                if let start = current.activeStart { current.worked += max(0, date.timeIntervalSince(start)) }
                current.activeStart = nil
                current.temporaryState = event.kind == "break_out" ? "on_break" : "doctor"
                current.temporarySince = date
            case "offsite_out":
                current.temporaryState = "offsite"
                current.temporarySince = date
                if current.activeStart == nil { current.activeStart = date }
            case "break_in", "doctor_in", "offsite_in":
                current.temporaryState = nil
                current.temporarySince = nil
                if current.baseState == "none" {
                    current.baseState = "in_building"
                    current.baseSince = date
                }
                if current.activeStart == nil { current.activeStart = date }
            case "departure", "home_end":
                if let start = current.activeStart { current.worked += max(0, date.timeIntervalSince(start)) }
                current.activeStart = nil
                current.temporaryState = nil
                current.temporarySince = nil
                current.baseState = "away"
                current.baseSince = date
                current.departure = date
                current.endedAt = date
                sessions.append(current)
                session = nil
                continue
            default:
                break
            }
            session = current
        }
        if let session { sessions.append(session) }
        return sessions
    }

    func intranetCalendar() -> Calendar {
        var calendar = Calendar(identifier: .gregorian)
        calendar.locale = Locale(identifier: "cs_CZ")
        calendar.timeZone = TimeZone(identifier: "Europe/Prague") ?? .current
        return calendar
    }

    func intranetMonthStart(offset: Int = 0, from date: Date = Date()) -> Date {
        let calendar = intranetCalendar()
        let components = calendar.dateComponents([.year, .month], from: date)
        let start = calendar.date(from: components) ?? calendar.startOfDay(for: date)
        return calendar.date(byAdding: .month, value: offset, to: start) ?? start
    }

    func intranetMonthKey(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "cs_CZ")
        formatter.timeZone = intranetCalendar().timeZone
        formatter.dateFormat = "yyyy-MM"
        return formatter.string(from: date)
    }

    func intranetMonthTitle(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "cs_CZ")
        formatter.timeZone = intranetCalendar().timeZone
        formatter.dateFormat = "LLLL yyyy"
        return formatter.string(from: date).prefix(1).uppercased()
            + formatter.string(from: date).dropFirst()
    }

    func intranetDayTitle(_ date: Date) -> String {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "cs_CZ")
        formatter.timeZone = intranetCalendar().timeZone
        formatter.dateFormat = "EEE d. M."
        return formatter.string(from: date)
    }

    func mergeIntranetHistory(
        existing: [IntranetAttendanceEvent],
        incoming: [IntranetAttendanceEvent],
        now: Date = Date()
    ) -> [IntranetAttendanceEvent] {
        var merged: [String: IntranetAttendanceEvent] = [:]
        for event in existing + incoming {
            let key = "\(event.kind)|\(event.ts)"
            merged[key] = IntranetAttendanceEvent(
                id: nil,
                kind: event.kind,
                source: nil,
                ts: event.ts
            )
        }
        let start = intranetMonthStart(offset: -1, from: now)
        let end = intranetMonthStart(offset: 1, from: now)
        return merged.values.filter { event in
            guard let date = parseIntranetDate(event.ts) else { return false }
            return date >= start && date < end
        }.sorted {
            (parseIntranetDate($0.ts) ?? .distantPast)
                < (parseIntranetDate($1.ts) ?? .distantPast)
        }
    }

    func collectIntranetHistoryEvents(
        from value: Any,
        ownProfileId: String,
        output: inout [IntranetAttendanceEvent]
    ) {
        if let dictionary = value as? [String: Any] {
            if let kind = dictionary["kind"] as? String,
               let ts = dictionary["ts"] as? String,
               parseIntranetDate(ts) != nil {
                let profileId = dictionary["hr_profile_id"] as? String
                if profileId == nil || ownProfileId.isEmpty || profileId == ownProfileId {
                    output.append(IntranetAttendanceEvent(
                        id: dictionary["id"] as? String,
                        kind: kind,
                        source: dictionary["source"] as? String,
                        ts: ts
                    ))
                }
            }
            for child in dictionary.values {
                collectIntranetHistoryEvents(
                    from: child,
                    ownProfileId: ownProfileId,
                    output: &output
                )
            }
        } else if let array = value as? [Any] {
            for child in array {
                collectIntranetHistoryEvents(
                    from: child,
                    ownProfileId: ownProfileId,
                    output: &output
                )
            }
        }
    }

    func parseIntranetHistory(
        _ html: String,
        ownProfileId: String
    ) -> [IntranetAttendanceEvent] {
        var events: [IntranetAttendanceEvent] = []
        for object in nextFlightObjects(from: html) {
            collectIntranetHistoryEvents(
                from: object,
                ownProfileId: ownProfileId,
                output: &events
            )
        }
        return mergeIntranetHistory(existing: [], incoming: events)
    }

    func intranetHistoryDays(
        monthStart: Date,
        events: [IntranetAttendanceEvent],
        now: Date = Date()
    ) -> [IntranetHistoryDay] {
        let calendar = intranetCalendar()
        let monthEnd = calendar.date(byAdding: .month, value: 1, to: monthStart)
            ?? monthStart.addingTimeInterval(32 * 86_400)
        return intranetAttendanceSessions(events: events, now: now)
            .filter { $0.date >= monthStart && $0.date < monthEnd }
            .sorted { $0.date > $1.date }
            .map { session in
            var worked = session.worked
            if let start = session.activeStart {
                worked += max(0, now.timeIntervalSince(start))
            }
            return IntranetHistoryDay(
                date: session.date,
                events: session.events,
                arrival: session.arrival,
                departure: session.departure,
                workedSeconds: max(0, Int(worked))
            )
        }
    }

    func nextFlightObjects(from html: String) -> [Any] {
        guard let regex = try? NSRegularExpression(
            pattern: #"self\.__next_f\.push\((\[.*?\])\)</script>"#,
            options: [.dotMatchesLineSeparators]
        ) else { return [] }
        let ns = html as NSString
        var payload = ""
        for match in regex.matches(in: html, range: NSRange(location: 0, length: ns.length)) {
            guard match.numberOfRanges > 1,
                  let range = Range(match.range(at: 1), in: html),
                  let data = String(html[range]).data(using: .utf8),
                  let array = try? JSONSerialization.jsonObject(with: data) as? [Any],
                  array.count > 1,
                  (array[0] as? Int) == 1,
                  let part = array[1] as? String
            else { continue }
            payload += part
        }
        var objects: [Any] = []
        for line in payload.split(separator: "\n", omittingEmptySubsequences: true) {
            guard let colon = line.firstIndex(of: ":") else { continue }
            let raw = line[line.index(after: colon)...]
            guard let data = String(raw).data(using: .utf8),
                  let object = try? JSONSerialization.jsonObject(with: data)
            else { continue }
            objects.append(object)
        }
        return objects
    }

    func findIntranetDictionary(
        in value: Any,
        requiredKeys: Set<String>
    ) -> [String: Any]? {
        if let dictionary = value as? [String: Any] {
            if requiredKeys.isSubset(of: Set(dictionary.keys)) { return dictionary }
            for child in dictionary.values {
                if let found = findIntranetDictionary(in: child, requiredKeys: requiredKeys) {
                    return found
                }
            }
        } else if let array = value as? [Any] {
            for child in array {
                if let found = findIntranetDictionary(in: child, requiredKeys: requiredKeys) {
                    return found
                }
            }
        }
        return nil
    }

    func parseIntranetLeaves(_ html: String) -> (leaves: [IntranetLeave], vacationDays: Double?)? {
        var root: [String: Any]?
        for object in nextFlightObjects(from: html) where root == nil {
            root = findIntranetDictionary(
                in: object,
                requiredKeys: ["hrProfileId", "uvazekH", "vacDays", "leaves"]
            )
        }
        guard let root, let rawLeaves = root["leaves"] as? [Any] else { return nil }
        let supportedTypes: Set<String> = ["vacation", "sick", "sickday", "doctor"]
        let datePattern = #"^\d{4}-\d{2}-\d{2}$"#
        let leaves = rawLeaves.compactMap { raw -> IntranetLeave? in
            guard
                let object = raw as? [String: Any],
                let id = object["id"] as? String,
                let type = object["type"] as? String,
                supportedTypes.contains(type),
                let dateFrom = object["date_from"] as? String,
                dateFrom.range(of: datePattern, options: .regularExpression) != nil,
                let dateTo = object["date_to"] as? String,
                dateTo.range(of: datePattern, options: .regularExpression) != nil,
                let status = object["status"] as? String,
                !id.isEmpty,
                !status.isEmpty
            else { return nil }
            let rawPortion = (object["portion"] as? NSNumber)?.doubleValue ?? 1
            let rawNote = (object["note"] as? String)?
                .trimmingCharacters(in: .whitespacesAndNewlines)
            return IntranetLeave(
                id: id,
                type: type,
                dateFrom: dateFrom,
                dateTo: dateTo,
                portion: rawPortion == 0.5 ? 0.5 : 1,
                note: rawNote?.isEmpty == false ? rawNote : nil,
                status: status,
                hours: (object["hours"] as? NSNumber)?.doubleValue,
                createdAt: object["created_at"] as? String
            )
        }.sorted { $0.dateFrom > $1.dateFrom }
        return (leaves, (root["vacDays"] as? NSNumber)?.doubleValue)
    }

    func cleanIntranetHTML(_ value: String) -> String {
        var text = value.replacingOccurrences(
            of: #"<!--.*?-->"#,
            with: "",
            options: .regularExpression
        )
        text = text.replacingOccurrences(
            of: #"<[^>]+>"#,
            with: "",
            options: .regularExpression
        )
        guard let data = ("<span>\(text)</span>").data(using: .utf8),
              let attributed = try? NSAttributedString(
                data: data,
                options: [.documentType: NSAttributedString.DocumentType.html,
                          .characterEncoding: String.Encoding.utf8.rawValue],
                documentAttributes: nil
              )
        else { return text.trimmingCharacters(in: .whitespacesAndNewlines) }
        return attributed.string.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    func intranetCardValue(label: String, html: String) -> String? {
        let escaped = NSRegularExpression.escapedPattern(for: label)
        let pattern = #"<div class="text-xs text-muted">"# + escaped
            + #"</div>\s*<div class="text-lg[^"]*">(.*?)</div>"#
        guard let regex = try? NSRegularExpression(
            pattern: pattern,
            options: [.dotMatchesLineSeparators]
        ) else { return nil }
        let ns = html as NSString
        guard let match = regex.firstMatch(
            in: html,
            range: NSRange(location: 0, length: ns.length)
        ), match.numberOfRanges > 1,
        let range = Range(match.range(at: 1), in: html)
        else { return nil }
        let value = cleanIntranetHTML(String(html[range]))
        return value.isEmpty ? nil : value
    }

    func parseIntranetSummary(_ html: String) -> (cards: [String: String], workload: Double) {
        let labels: [(String, String)] = [
            ("workload", "Úvazek"),
            ("worked_month", "Odpracováno (měsíc)"),
            ("balance_month", "Saldo (měsíc)"),
            ("overtime_ordered", "Přesčas (nařízený)"),
            ("vacation_remaining", "Dovolená – zbývá"),
            ("sickday_remaining", "Sickday – zbývá")
        ]
        var cards: [String: String] = [:]
        for (key, label) in labels {
            if let value = intranetCardValue(label: label, html: html) {
                cards[key] = value
            }
        }
        let normalized = (cards["workload"] ?? "")
            .replacingOccurrences(of: ",", with: ".")
        let workload = normalized.range(of: #"[0-9]+(?:\.[0-9]+)?"#, options: .regularExpression)
            .flatMap { Double(normalized[$0]) } ?? 0
        return (cards, workload)
    }

    func parseIntranetRoster(
        _ html: String,
        ownProfileId: String,
        now: Date = Date()
    ) -> (people: [IntranetPerson], ownState: String?)? {
        var root: [String: Any]?
        for object in nextFlightObjects(from: html) where root == nil {
            root = findIntranetDictionary(
                in: object,
                requiredKeys: ["employees", "events", "absences", "fetchedAt"]
            )
        }
        guard let root,
              let employees = root["employees"] as? [[String: Any]],
              let rawEvents = root["events"] as? [[String: Any]]
        else { return nil }
        let rawAbsences = root["absences"] as? [[String: Any]] ?? []
        var eventsByPerson: [String: [IntranetAttendanceEvent]] = [:]
        for value in rawEvents {
            guard let personId = value["hr_profile_id"] as? String,
                  let kind = value["kind"] as? String,
                  let ts = value["ts"] as? String
            else { continue }
            let date = parseIntranetDate(ts)
            if let date, now.timeIntervalSince(date) > 86_400 { continue }
            eventsByPerson[personId, default: []].append(IntranetAttendanceEvent(
                id: value["id"] as? String,
                kind: kind,
                source: value["source"] as? String,
                ts: ts
            ))
        }
        var absencesByPerson: [String: String] = [:]
        for value in rawAbsences {
            guard let personId = value["hr_profile_id"] as? String,
                  let type = value["type"] as? String,
                  let status = value["status"] as? String,
                  ["approved", "auto_approved", "announced"].contains(status)
            else { continue }
            if type == "vacation" {
                absencesByPerson[personId] = "vacation"
            } else if type == "sick" || type == "sickday" {
                absencesByPerson[personId] = "sick"
            } else if type == "home_office" {
                absencesByPerson[personId] = "home_office"
            }
        }
        let activeStates: Set<String> = ["in_building", "home_office", "on_break", "doctor", "offsite"]
        let people = employees.compactMap { employee -> IntranetPerson? in
            guard let id = employee["id"] as? String,
                  let name = employee["name"] as? String,
                  !name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
            else { return nil }
            let derived = deriveIntranetAttendance(events: eventsByPerson[id] ?? [], now: now)
            let state = activeStates.contains(derived.state)
                ? derived.state
                : (absencesByPerson[id] ?? derived.state)
            return IntranetPerson(name: name, state: state, since: derived.since, phone: nil)
        }.sorted { $0.name.localizedCaseInsensitiveCompare($1.name) == .orderedAscending }
        let ownState: String?
        if ownProfileId.isEmpty {
            ownState = nil
        } else {
            let ownEvents = eventsByPerson[ownProfileId] ?? []
            let ownDerived = deriveIntranetAttendance(events: ownEvents, now: now)
            ownState = activeStates.contains(ownDerived.state)
                ? ownDerived.state
                : (absencesByPerson[ownProfileId] ?? ownDerived.state)
        }
        return (people, ownState)
    }

    func normalizedIntranetPersonName(_ value: String, sorted: Bool = false) -> String {
        let folded = value.folding(
            options: [.caseInsensitive, .diacriticInsensitive],
            locale: Locale(identifier: "cs_CZ")
        ).split(whereSeparator: { $0.isWhitespace }).map(String.init)
        return (sorted ? folded.sorted() : folded).joined(separator: " ")
    }

    func parseIntranetTeamPhones(_ html: String) -> [String: String] {
        var phones: [String: String] = [:]

        func walk(_ value: Any) {
            if let values = value as? [Any] {
                values.forEach(walk)
                return
            }
            guard let object = value as? [String: Any] else { return }
            if let href = object["href"] as? String,
               href.lowercased().hasPrefix("tel:"),
               let ariaLabel = object["aria-label"] as? String {
                let name = ariaLabel.replacingOccurrences(
                    of: #"^Zavolat\s+"#,
                    with: "",
                    options: [.regularExpression, .caseInsensitive]
                ).trimmingCharacters(in: .whitespacesAndNewlines)
                let phone = String(href.dropFirst(4)).trimmingCharacters(in: .whitespacesAndNewlines)
                let safePhone = phone.filter { "+0123456789".contains($0) }
                if !name.isEmpty, safePhone.count >= 6 {
                    phones[normalizedIntranetPersonName(name)] = safePhone
                    phones[normalizedIntranetPersonName(name, sorted: true)] = safePhone
                }
            }
            object.values.forEach(walk)
        }

        nextFlightObjects(from: html).forEach(walk)
        return phones
    }

    func loadIntranetSnapshot() {
        let url = URL(fileURLWithPath: intranetSnapshotPath)
        guard let data = try? Data(contentsOf: url),
              var snapshot = try? JSONDecoder().decode(IntranetSnapshot.self, from: data)
        else { return }
        if snapshot.fetchedAt > 0,
           Date().timeIntervalSince1970 - snapshot.fetchedAt > 150 {
            snapshot.dataState = "stale"
        }
        intranetSnapshot = snapshot
    }

    func saveIntranetSnapshot() {
        let url = URL(fileURLWithPath: intranetSnapshotPath)
        do {
            try FileManager.default.createDirectory(
                at: url.deletingLastPathComponent(),
                withIntermediateDirectories: true
            )
            var cacheSnapshot = intranetSnapshot
            cacheSnapshot.people = cacheSnapshot.people.map { person in
                var sanitized = person
                sanitized.phone = nil
                return sanitized
            }
            let data = try JSONEncoder().encode(cacheSnapshot)
            try data.write(to: url, options: .atomic)
            try FileManager.default.setAttributes(
                [.posixPermissions: 0o600],
                ofItemAtPath: url.path
            )
        } catch {
            // Cache neobsahuje přihlašovací údaje; selhání zápisu se ukáže
            // jako interní chyba při příští obnově, ne do systémového logu.
        }
    }

    func applyIntranetError(_ error: Error) {
        let serviceError = error as? IntranetServiceError
        let code = serviceError?.code ?? "internal_error"
        let now = Date().timeIntervalSince1970
        intranetFailureCount += 1
        let retryDelay: TimeInterval
        switch code {
        case "auth_denied", "permission_denied":
            retryDelay = 15 * 60
        case "unavailable":
            retryDelay = min(15 * 60, 60 * pow(2, Double(min(intranetFailureCount - 1, 4))))
        default:
            retryDelay = 5 * 60
        }
        intranetRetryAfter = Date(timeIntervalSinceNow: retryDelay)
        intranetSnapshot.dataState = code
        intranetSnapshot.errorCode = code
        intranetSnapshot.errorMessage = serviceError?.message ?? "Interní chyba Evora Smart Menu."
        if intranetSnapshot.fetchedAt == 0 || now - intranetSnapshot.fetchedAt > 300 {
            _ = runWork(["intranet-sync", "off"])
        }
        saveIntranetSnapshot()
        rebuildIntranetMenu()
        applyIntranetStatusToUI()
    }

    func syncWorkLogCollectionFromIntranet() {
        let age = Date().timeIntervalSince1970 - intranetSnapshot.fetchedAt
        let desired: String
        if intranetSnapshot.dataState != "current" || age > 300 {
            desired = "off"
        } else if intranetSnapshot.currentState == "in_building" {
            desired = "office"
        } else if intranetSnapshot.currentState == "home_office" {
            desired = "homeoffice"
        } else {
            desired = "off"
        }
        _ = runWork(["intranet-sync", desired])
    }

    func parseIntranetUnreadNotifications(_ data: Data) -> Int? {
        guard let object = try? JSONSerialization.jsonObject(with: data) as? [String: Any]
        else { return nil }
        if let value = object["unread"] as? Int { return max(0, value) }
        if let value = object["unread"] as? NSNumber { return max(0, value.intValue) }
        return nil
    }

    @objc func refreshIntranetTimerFired() {
        refreshIntranet(forceAll: false)
    }

    @objc func refreshIntranetNow() {
        refreshIntranet(forceAll: true)
    }

    func refreshIntranet(forceAll: Bool) {
        guard !intranetRefreshInFlight else { return }
        guard intranetCredentialsLoaded else { return }
        guard forceAll || Date() >= intranetRetryAfter else {
            if intranetSnapshot.fetchedAt > 0,
               Date().timeIntervalSince1970 - intranetSnapshot.fetchedAt > 150,
               intranetSnapshot.dataState == "current" {
                intranetSnapshot.dataState = "stale"
                saveIntranetSnapshot()
                rebuildIntranetMenu()
                applyIntranetStatusToUI()
            }
            return
        }
        guard hasIntranetCredentials() else {
            intranetSnapshot = .empty
            saveIntranetSnapshot()
            _ = runWork(["intranet-sync", "off"])
            rebuildIntranetMenu()
            applyIntranetStatusToUI()
            return
        }
        intranetRefreshInFlight = true
        if intranetSnapshot.fetchedAt == 0 {
            intranetSnapshot.dataState = "loading"
            rebuildIntranetMenu()
        }
        intranetRequest(path: "/api/attendance/me", method: "POST") { [weak self] result in
            guard let self else { return }
            switch result {
            case .failure(let error):
                DispatchQueue.main.async {
                    self.intranetRefreshInFlight = false
                    self.applyIntranetError(error)
                }
            case .success(let data):
                do {
                    let response = try JSONDecoder().decode(IntranetAttendanceResponse.self, from: data)
                    let now = Date()
                    let derived = self.deriveIntranetAttendance(events: response.events, now: now)
                    var updated = self.intranetSnapshot
                    updated.dataState = "current"
                    updated.fetchedAt = now.timeIntervalSince1970
                    updated.currentState = derived.state
                    updated.currentSince = derived.since
                    updated.hrProfileId = response.hrProfileId
                    updated.todayWorkedSeconds = derived.worked
                    updated.lastArrival = derived.arrival
                    updated.lastDeparture = derived.departure
                    updated.greeting = response.greeting
                    updated.workloadHours = response.uvazekH
                    updated.errorCode = nil
                    updated.errorMessage = nil

                    let summaryDue = forceAll || now.timeIntervalSince1970 - updated.summaryFetchedAt > 600
                    let rosterDue = forceAll || now.timeIntervalSince1970 - updated.rosterFetchedAt > 300
                    let historyDue = forceAll
                        || now.timeIntervalSince1970 - (updated.historyFetchedAt ?? 0) > 600
                    let leavesDue = forceAll
                        || now.timeIntervalSince1970 - (updated.leavesFetchedAt ?? 0) > 600
                    updated.historyEvents = self.mergeIntranetHistory(
                        existing: updated.historyEvents ?? [],
                        incoming: response.events,
                        now: now
                    )
                    if !response.events.isEmpty {
                        updated.historyFetchedAt = now.timeIntervalSince1970
                    }

                    let finish: (IntranetSnapshot) -> Void = { finalSnapshot in
                        DispatchQueue.main.async {
                            self.intranetSnapshot = finalSnapshot
                            self.intranetRefreshInFlight = false
                            self.intranetFailureCount = 0
                            self.intranetRetryAfter = .distantPast
                            self.saveIntranetSnapshot()
                            self.syncWorkLogCollectionFromIntranet()
                            self.rebuildIntranetMenu()
                            self.applyIntranetStatusToUI()
                        }
                    }

                    let loadNotifications: (IntranetSnapshot) -> Void = { snapshotAfterRoster in
                        self.intranetRequest(path: "/api/notifications") { notificationsResult in
                            var finalSnapshot = snapshotAfterRoster
                            if case .success(let notificationsData) = notificationsResult,
                               let unread = self.parseIntranetUnreadNotifications(notificationsData) {
                                finalSnapshot.notificationsUnread = unread
                            }
                            finish(finalSnapshot)
                        }
                    }

                    let loadLeaves: (IntranetSnapshot) -> Void = { snapshotAfterRoster in
                        guard leavesDue else {
                            loadNotifications(snapshotAfterRoster)
                            return
                        }
                        self.intranetRequest(path: "/dovolena") { leavesResult in
                            var snapshotWithLeaves = snapshotAfterRoster
                            if case .success(let leavesData) = leavesResult,
                               let html = String(data: leavesData, encoding: .utf8),
                               let parsed = self.parseIntranetLeaves(html) {
                                snapshotWithLeaves.leaves = parsed.leaves
                                snapshotWithLeaves.leavesFetchedAt = now.timeIntervalSince1970
                                if let vacationDays = parsed.vacationDays,
                                   snapshotWithLeaves.cards["vacation_remaining"] == nil {
                                    snapshotWithLeaves.cards["vacation_remaining"] = String(
                                        format: "%g dní",
                                        locale: Locale(identifier: "cs_CZ"),
                                        vacationDays
                                    )
                                }
                            }
                            loadNotifications(snapshotWithLeaves)
                        }
                    }

                    let loadRoster: (IntranetSnapshot) -> Void = { snapshotAfterSummary in
                        guard rosterDue else {
                            loadLeaves(snapshotAfterSummary)
                            return
                        }
                        self.intranetRequest(path: "/nastenka") { rosterResult in
                            var snapshotWithRoster = snapshotAfterSummary
                            if case .success(let rosterData) = rosterResult,
                               let html = String(data: rosterData, encoding: .utf8),
                               let roster = self.parseIntranetRoster(
                                   html,
                                   ownProfileId: snapshotWithRoster.hrProfileId,
                                   now: now
                               ) {
                                snapshotWithRoster.people = roster.people
                                if ["vacation", "sick", "home_office"].contains(roster.ownState),
                                   !["in_building", "home_office", "on_break", "doctor", "offsite"].contains(snapshotWithRoster.currentState),
                                   let ownState = roster.ownState {
                                    snapshotWithRoster.currentState = ownState
                                    snapshotWithRoster.currentSince = nil
                                }
                                snapshotWithRoster.rosterFetchedAt = now.timeIntervalSince1970
                            }
                            self.intranetRequest(path: "/tym") { contactsResult in
                                var finalSnapshot = snapshotWithRoster
                                if case .success(let contactsData) = contactsResult,
                                   let html = String(data: contactsData, encoding: .utf8) {
                                    let phones = self.parseIntranetTeamPhones(html)
                                    finalSnapshot.people = finalSnapshot.people.map { person in
                                        var updatedPerson = person
                                        let key = self.normalizedIntranetPersonName(person.name)
                                        let sortedKey = self.normalizedIntranetPersonName(person.name, sorted: true)
                                        updatedPerson.phone = phones[key] ?? phones[sortedKey]
                                        return updatedPerson
                                    }
                                }
                                loadLeaves(finalSnapshot)
                            }
                        }
                    }

                    let loadAttendanceHistory: (IntranetSnapshot) -> Void = { snapshotAfterSummary in
                        guard historyDue else {
                            loadRoster(snapshotAfterSummary)
                            return
                        }
                        let currentMonth = self.intranetMonthKey(
                            self.intranetMonthStart(from: now)
                        )
                        let previousMonth = self.intranetMonthKey(
                            self.intranetMonthStart(offset: -1, from: now)
                        )
                        self.intranetRequest(path: "/dochazka?month=\(currentMonth)") { currentResult in
                            var withCurrent = snapshotAfterSummary
                            if case .success(let currentData) = currentResult,
                               let html = String(data: currentData, encoding: .utf8) {
                                let events = self.parseIntranetHistory(
                                    html,
                                    ownProfileId: withCurrent.hrProfileId
                                )
                                withCurrent.historyEvents = self.mergeIntranetHistory(
                                    existing: withCurrent.historyEvents ?? [],
                                    incoming: events,
                                    now: now
                                )
                                withCurrent.historyFetchedAt = now.timeIntervalSince1970
                            }
                            self.intranetRequest(path: "/dochazka?month=\(previousMonth)") { previousResult in
                                var withPrevious = withCurrent
                                if case .success(let previousData) = previousResult,
                                   let html = String(data: previousData, encoding: .utf8) {
                                    let events = self.parseIntranetHistory(
                                        html,
                                        ownProfileId: withPrevious.hrProfileId
                                    )
                                    withPrevious.historyEvents = self.mergeIntranetHistory(
                                        existing: withPrevious.historyEvents ?? [],
                                        incoming: events,
                                        now: now
                                    )
                                    withPrevious.historyFetchedAt = now.timeIntervalSince1970
                                }
                                loadRoster(withPrevious)
                            }
                        }
                    }

                    guard summaryDue else {
                        loadAttendanceHistory(updated)
                        return
                    }
                    self.intranetRequest(path: "/moje") { summaryResult in
                        var withSummary = updated
                        if case .success(let summaryData) = summaryResult,
                           let html = String(data: summaryData, encoding: .utf8) {
                            let parsed = self.parseIntranetSummary(html)
                            if !parsed.cards.isEmpty {
                                withSummary.cards = parsed.cards
                                if parsed.workload > 0 { withSummary.workloadHours = parsed.workload }
                                withSummary.summaryFetchedAt = now.timeIntervalSince1970
                            }
                        }
                        loadAttendanceHistory(withSummary)
                    }
                } catch {
                    DispatchQueue.main.async {
                        self.intranetRefreshInFlight = false
                        self.applyIntranetError(IntranetServiceError(
                            code: "internal_error",
                            message: "Docházková data Evora Intranetu mají neočekávaný formát."
                        ))
                    }
                }
            }
        }
    }

    func formatIntranetDuration(_ seconds: Int) -> String {
        let roundedMinutes = max(0, Int((Double(seconds) / 60.0).rounded()))
        let hours = roundedMinutes / 60
        let minutes = roundedMinutes % 60
        if hours == 0 { return "\(minutes) min" }
        if minutes == 0 { return "\(hours) h" }
        return "\(hours) h \(minutes) min"
    }

    func formatIntranetLiveClock(_ seconds: Int) -> String {
        let safeSeconds = max(0, seconds)
        let hours = safeSeconds / 3600
        let minutes = (safeSeconds % 3600) / 60
        let secondsPart = safeSeconds % 60
        return String(format: "%02d:%02d:%02d", hours, minutes, secondsPart)
    }

    func intranetBreakRemainingSeconds(
        state: String,
        since: Double?,
        now: Date = Date()
    ) -> Int? {
        guard state == "on_break", let since else { return nil }
        let remaining = 30 * 60 - max(0, now.timeIntervalSince1970 - since)
        return max(0, Int(ceil(remaining)))
    }

    func formatIntranetBreakCountdown(_ seconds: Int) -> String {
        let safeSeconds = max(0, seconds)
        return String(format: "%02d:%02d", safeSeconds / 60, safeSeconds % 60)
    }

    func formatIntranetTime(_ timestamp: Double?) -> String {
        guard let timestamp else { return "—" }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "cs_CZ")
        formatter.timeZone = TimeZone(identifier: "Europe/Prague")
        formatter.dateFormat = "HH:mm"
        return formatter.string(from: Date(timeIntervalSince1970: timestamp))
    }

    func displayedIntranetWorkedSeconds(now: Date = Date()) -> Int {
        var seconds = intranetSnapshot.todayWorkedSeconds
        let activeWorkStates: Set<String> = ["in_building", "home_office", "offsite"]
        if intranetSnapshot.dataState == "current",
           activeWorkStates.contains(intranetSnapshot.currentState),
           intranetSnapshot.fetchedAt > 0 {
            seconds += max(0, Int(now.timeIntervalSince1970 - intranetSnapshot.fetchedAt))
        }
        return seconds
    }

    func seedIntranetLiveClockForSelfTest(baseNow: Date) -> (first: Int, second: Int) {
        guard CommandLine.arguments.dropFirst().first == "--self-test-intranet-history" else { return (0, 0) }
        let original = intranetSnapshot
        defer { intranetSnapshot = original }
        intranetSnapshot = IntranetSnapshot(
            dataState: "current",
            fetchedAt: baseNow.timeIntervalSince1970,
            summaryFetchedAt: baseNow.timeIntervalSince1970,
            rosterFetchedAt: baseNow.timeIntervalSince1970,
            currentState: "in_building",
            currentSince: baseNow.addingTimeInterval(-3600).timeIntervalSince1970,
            hrProfileId: "self-test",
            todayWorkedSeconds: 28_800,
            lastArrival: baseNow.addingTimeInterval(-3600).timeIntervalSince1970,
            lastDeparture: nil,
            greeting: "",
            workloadHours: 8,
            cards: [:],
            people: [],
            leavesFetchedAt: nil,
            leaves: [],
            notificationsUnread: 0,
            historyFetchedAt: nil,
            historyEvents: [],
            errorCode: nil,
            errorMessage: nil
        )
        return (
            displayedIntranetWorkedSeconds(now: baseNow),
            displayedIntranetWorkedSeconds(now: baseNow.addingTimeInterval(5))
        )
    }

    func intranetLiveStatusTitle() -> String {
        if intranetSnapshot.dataState == "current" || intranetSnapshot.dataState == "stale" {
            if let breakRemaining = intranetBreakRemainingSeconds(
                state: intranetSnapshot.currentState,
                since: intranetSnapshot.currentSince
            ) {
                return "Na přestávce · zbývá \(formatIntranetBreakCountdown(breakRemaining))"
            }
            let today = formatIntranetLiveClock(displayedIntranetWorkedSeconds())
            if ["away", "none"].contains(intranetSnapshot.currentState) {
                if let departure = intranetSnapshot.lastDeparture {
                    return "Odchod \(formatIntranetTime(departure)) · dnes \(today)"
                }
                if let arrival = intranetSnapshot.lastArrival {
                    return "Naposledy v práci \(formatIntranetTime(arrival)) · dnes \(today)"
                }
            }
            return "\(intranetStateLabel(intranetSnapshot.currentState)) · dnes \(today)"
        }
        return intranetDataStateLabel(intranetSnapshot.dataState)
    }

    func applyIntranetStatusToUI() {
        guard shiftStatusItem != nil else { return }
        shiftStatusTitleField?.stringValue = modernPanelProfileName()
        shiftStatusMetricsField?.stringValue = modernPanelProfileMetrics()
        shiftStatusImageView?.image = modernPanelProfileImage(size: NSSize(width: 60, height: 60))
        // Jediný vzhledový handler drží stavový podkres stabilní i při
        // deaktivaci a opětovném vstupu myši do systémového NSMenu okna.
        shiftStatusContainer?.refreshAppearance()
        if let liveItem = intranetMenu?.items.first, !liveItem.isSeparatorItem {
            updateReadOnlyItem(
                liveItem,
                title: intranetLiveStatusTitle(),
                color: modernPanelProfileColor()
            )
        }
        let state = intranetSnapshot.dataState
        let ready = state == "current" && !intranetSnapshot.hrProfileId.isEmpty
        let activeWorkStates: Set<String> = ["in_building", "home_office", "offsite"]
        let canStart = ["none", "away"].contains(intranetSnapshot.currentState)
        intranetOfficeItem?.isEnabled = ready && canStart
        intranetHomeItem?.isEnabled = ready && canStart
        intranetEndItem?.isEnabled = ready
            && ["in_building", "home_office"].contains(intranetSnapshot.currentState)
        if state == "current" || state == "stale" {
            let stateLabel = intranetStateLabel(intranetSnapshot.currentState)
            let duration = formatIntranetLiveClock(displayedIntranetWorkedSeconds())
            let breakRemaining = intranetBreakRemainingSeconds(
                state: intranetSnapshot.currentState,
                since: intranetSnapshot.currentSince
            )
            let breakCountdown = breakRemaining.map(formatIntranetBreakCountdown)
            let color: NSColor
            switch intranetSnapshot.currentState {
            case "in_building", "home_office", "offsite": color = .systemGreen
            case "on_break", "doctor": color = .systemOrange
            case "vacation", "sick": color = .systemBlue
            default: color = .systemBlue
            }
            let stale = state == "stale" ? " · ZASTARALÉ" : ""
            shiftStatusTitleField?.stringValue = modernPanelProfileName()
            shiftStatusTitleField?.textColor = breakCountdown == nil ? .labelColor : .systemOrange
            let liveStatus = "\(intranetLiveStatusTitle())\(stale)"
            shiftStatusDetailField?.stringValue = liveStatus
            shiftStatusDetailField?.textColor = state == "stale" ? .systemOrange : color
            shiftStatusItem.toolTip = liveStatus
            if let button = statusItem.button {
                button.title = breakCountdown.map { " ☕ \($0)" }
                    ?? (activeWorkStates.contains(intranetSnapshot.currentState) ? " \(duration)" : "")
                configureStatusButton(button)
                button.toolTip = breakCountdown.map { "Evora Smart Menu · \(stateLabel) · zbývá \($0)" }
                    ?? (activeWorkStates.contains(intranetSnapshot.currentState)
                        ? "Evora Smart Menu · \(stateLabel) · \(duration)"
                        : "Evora Smart Menu · \(stateLabel)")
            }
        } else {
            let statusColor: NSColor
            switch state {
            case "loading": statusColor = .systemBlue
            case "stale", "unavailable", "source_unavailable": statusColor = .systemOrange
            case "not_configured": statusColor = .systemRed
            default: statusColor = .systemRed
            }
            shiftStatusTitleField?.stringValue = modernPanelProfileName()
            shiftStatusTitleField?.textColor = .labelColor
            shiftStatusDetailField?.stringValue = intranetDataStateLabel(state)
            shiftStatusDetailField?.textColor = statusColor
            shiftStatusItem.toolTip = intranetDataStateLabel(state)
            if let button = statusItem.button {
                button.title = ""
                configureStatusButton(button)
                button.toolTip = "Evora Smart Menu · \(intranetDataStateLabel(state))"
            }
        }
        updateStatusButtonAnimation()
    }

    func intranetPunchLabel(_ kind: String) -> String {
        switch kind {
        case "arrival": return "Příchod"
        case "departure": return "Odchod"
        case "home_start": return "Začít Home office"
        case "home_end": return "Ukončit Home office"
        case "break_out": return "Začít přestávku"
        case "break_in": return "Ukončit přestávku"
        case "doctor_out": return "Odchod k lékaři"
        case "doctor_in": return "Návrat od lékaře"
        case "offsite_out": return "Začít služební cestu"
        case "offsite_in": return "Ukončit služební cestu"
        default: return kind
        }
    }

    func intranetAvailablePunches() -> [String] {
        switch intranetSnapshot.currentState {
        case "in_building": return ["departure", "break_out", "doctor_out", "offsite_out"]
        case "home_office": return ["home_end", "break_out", "doctor_out"]
        case "on_break": return ["break_in"]
        case "doctor": return ["doctor_in"]
        case "offsite": return ["offsite_in"]
        case "vacation", "sick": return []
        default: return ["arrival", "home_start", "doctor_out", "offsite_out"]
        }
    }

    func intranetPunchMenuItem(_ kind: String) -> NSMenuItem {
        let symbol: String
        switch kind {
        case "arrival": symbol = "building.2"
        case "departure", "home_end": symbol = "rectangle.portrait.and.arrow.right"
        case "home_start": symbol = "house"
        case "break_out", "break_in": symbol = "cup.and.saucer"
        case "doctor_out", "doctor_in": symbol = "cross.case"
        default: symbol = "car"
        }
        let entry = item(
            intranetPunchLabel(kind),
            symbol: symbol,
            action: #selector(performIntranetPunch(_:))
        )
        entry.representedObject = kind
        entry.isEnabled = intranetSnapshot.dataState == "current"
            && !intranetSnapshot.hrProfileId.isEmpty
        return entry
    }

    func intranetHistoryMenuItem(now: Date = Date()) -> NSMenuItem {
        let parent = NSMenuItem(
            title: "Historie docházky",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(to: parent, title: "Historie docházky", symbol: "calendar")
        let historyMenu = NSMenu(title: "Historie docházky")
        historyMenu.autoenablesItems = false
        let allEvents = intranetSnapshot.historyEvents ?? []

        for offset in [0, -1] {
            let monthStart = intranetMonthStart(offset: offset, from: now)
            let monthItem = NSMenuItem(
                title: intranetMonthTitle(monthStart),
                action: nil,
                keyEquivalent: ""
            )
            applyMenuIcon(
                to: monthItem,
                title: intranetMonthTitle(monthStart),
                symbol: offset == 0 ? "calendar.badge.clock" : "calendar"
            )
            let monthMenu = NSMenu(title: intranetMonthTitle(monthStart))
            monthMenu.autoenablesItems = false
            let days = intranetHistoryDays(
                monthStart: monthStart,
                events: allEvents,
                now: now
            )

            if days.isEmpty {
                monthMenu.addItem(readOnlyItem(
                    "Zdroj zatím neposkytl záznamy pro tento měsíc",
                    symbol: "info.circle",
                    color: .labelColor
                ))
            } else {
                for day in days {
                    let summary = day.workedSeconds > 0
                        ? formatIntranetDuration(day.workedSeconds)
                        : "bez vypočteného času"
                    let dayItem = NSMenuItem(
                        title: "\(intranetDayTitle(day.date)) · \(summary)",
                        action: nil,
                        keyEquivalent: ""
                    )
                    applyMenuIcon(
                        to: dayItem,
                        title: "\(intranetDayTitle(day.date)) · \(summary)",
                        symbol: "clock"
                    )
                    let dayMenu = NSMenu(title: intranetDayTitle(day.date))
                    dayMenu.autoenablesItems = false
                    dayMenu.addItem(metricItem(
                        label: "Příchod",
                        value: formatIntranetTime(day.arrival?.timeIntervalSince1970),
                        symbol: "rectangle.portrait.and.arrow.right",
                        valueColor: .labelColor
                    ))

                    var breakStart: Date?
                    var breakIntervals: [String] = []
                    for entry in day.events {
                        if entry.event.kind == "break_out" {
                            breakStart = entry.date
                        } else if entry.event.kind == "break_in", let start = breakStart {
                            breakIntervals.append(
                                "\(formatIntranetTime(start.timeIntervalSince1970))–\(formatIntranetTime(entry.date.timeIntervalSince1970))"
                            )
                            breakStart = nil
                        }
                    }
                    if let start = breakStart {
                        breakIntervals.append("od \(formatIntranetTime(start.timeIntervalSince1970))")
                    }
                    dayMenu.addItem(metricItem(
                        label: "Pauza",
                        value: breakIntervals.isEmpty ? "bez pauzy" : breakIntervals.joined(separator: ", "),
                        symbol: "cup.and.saucer",
                        valueColor: .labelColor
                    ))
                    dayMenu.addItem(metricItem(
                        label: "Odchod",
                        value: formatIntranetTime(day.departure?.timeIntervalSince1970),
                        symbol: "rectangle.portrait.and.arrow.forward",
                        valueColor: .labelColor
                    ))
                    dayMenu.addItem(.separator())
                    dayMenu.addItem(metricItem(
                        label: "Odpracováno",
                        value: formatIntranetDuration(day.workedSeconds),
                        symbol: "clock",
                        valueColor: .labelColor
                    ))
                    dayItem.submenu = dayMenu
                    monthMenu.addItem(dayItem)
                }
            }
            monthItem.submenu = monthMenu
            historyMenu.addItem(monthItem)
        }

        if let fetchedAt = intranetSnapshot.historyFetchedAt, fetchedAt > 0 {
            historyMenu.addItem(.separator())
            historyMenu.addItem(readOnlyItem(
                "Aktualizováno \(formatIntranetTime(fetchedAt))",
                symbol: "checkmark.circle",
                color: .labelColor
            ))
        }
        parent.submenu = historyMenu
        return parent
    }

    func intranetLeavesMenuItem(now: Date = Date()) -> NSMenuItem {
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "en_US_POSIX")
        formatter.timeZone = TimeZone(identifier: "Europe/Prague")
        formatter.dateFormat = "yyyy-MM-dd"
        let today = formatter.string(from: now)
        let planned = (intranetSnapshot.leaves ?? [])
            .filter { $0.dateTo >= today }
            .sorted {
                if $0.dateFrom != $1.dateFrom { return $0.dateFrom < $1.dateFrom }
                return $0.dateTo < $1.dateTo
            }
        let title = "Plánované dovolené a absence (\(planned.count))"
        let parent = NSMenuItem(title: title, action: nil, keyEquivalent: "")
        applyMenuIcon(to: parent, title: title, symbol: "calendar.badge.clock", color: .systemBlue)
        let leavesMenu = NSMenu(title: title)
        leavesMenu.autoenablesItems = false
        if planned.isEmpty {
            leavesMenu.addItem(readOnlyItem(
                intranetSnapshot.leavesFetchedAt == nil
                    ? "Plánované absence zatím nebyly načteny"
                    : "Žádná plánovaná dovolená ani absence",
                symbol: "checkmark.circle",
                color: .secondaryLabelColor
            ))
        } else {
            for leave in planned {
                let status = intranetLeaveStatus(leave.status)
                let portion = leave.portion == 0.5 ? " · půlden" : ""
                let row = metricItem(
                    label: "\(intranetLeaveTypeLabel(leave.type)) · \(formatIntranetLeaveRange(leave))\(portion)",
                    value: status.label,
                    symbol: "calendar",
                    symbolColor: status.color,
                    valueColor: status.color
                )
                if let note = leave.note, !note.isEmpty { row.toolTip = note }
                leavesMenu.addItem(row)
            }
        }
        if let fetchedAt = intranetSnapshot.leavesFetchedAt {
            leavesMenu.addItem(.separator())
            leavesMenu.addItem(readOnlyItem(
                "Aktualizováno \(formatIntranetTime(fetchedAt))",
                symbol: "checkmark.circle",
                color: .secondaryLabelColor
            ))
        }
        parent.submenu = leavesMenu
        return parent
    }

    func rebuildIntranetMenu() {
        guard intranetMenu != nil else { return }
        defer {
            applyIntranetStatusToUI()
            if !mainMenuSearchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                applyMainMenuSearchFilter()
            }
            modernMenuPanel?.reloadData()
            classicMenuNavigator?.modelDidChange()
        }
        intranetMenu.removeAllItems()

        let statusTitle = intranetLiveStatusTitle()
        intranetMenu.addItem(readOnlyItem(
            statusTitle,
            symbol: "clock",
            color: .labelColor,
            weight: .semibold
        ))

        if intranetSnapshot.fetchedAt > 0 {
            intranetMenu.addItem(readOnlyItem(
                "Poslední úspěšná obnova: \(formatIntranetTime(intranetSnapshot.fetchedAt))",
                symbol: "checkmark.circle",
                color: .labelColor
            ))
        }

        if intranetSnapshot.dataState != "current",
           let message = intranetSnapshot.errorMessage {
            intranetMenu.addItem(readOnlyItem(
                "Poslední obnova selhala · \(message)",
                symbol: "exclamationmark.triangle",
                color: .systemRed,
                weight: .semibold
            ))
        }

        intranetMenu.addItem(.separator())
        if !intranetSnapshot.cards.isEmpty {
            let cardRows: [(String, String, String, NSColor)] = [
                ("worked_month", "Odpracováno za měsíc", "clock.fill", .systemGreen),
                ("balance_month", "Saldo za měsíc", "equal.circle", .systemTeal),
                ("overtime_ordered", "Nařízený přesčas", "timer", .systemOrange),
                ("vacation_remaining", "Zbývající dovolená", "sun.max.fill", .systemYellow),
                ("sickday_remaining", "Zbývající sick days", "cross.case.fill", .systemBlue)
            ]
            for (key, label, symbol, symbolColor) in cardRows {
                let value = intranetSnapshot.cards[key] ?? "Zdroj údaj neposkytuje"
                let metric = metricItem(
                    label: label,
                    value: value,
                    symbol: symbol,
                    symbolColor: symbolColor,
                    valueColor: .labelColor
                )
                if key == "overtime_ordered" {
                    metric.representedObject = ["modernFullWidth": true] as NSDictionary
                }
                intranetMenu.addItem(metric)
            }
        }
        intranetMenu.addItem(intranetHistoryMenuItem())
        intranetMenu.addItem(intranetLeavesMenuItem())

        intranetMenu.addItem(.separator())
        let available = intranetAvailablePunches()
        if let primary = available.first {
            intranetMenu.addItem(intranetPunchMenuItem(primary))
        }
        if available.count > 1 {
            let more = NSMenuItem(title: "Další docházkové akce", action: nil, keyEquivalent: "")
            applyMenuIcon(to: more, title: "Další docházkové akce", symbol: "ellipsis.circle")
            let submenu = NSMenu(title: "Další docházkové akce")
            for kind in available.dropFirst() {
                submenu.addItem(intranetPunchMenuItem(kind))
            }
            more.submenu = submenu
            intranetMenu.addItem(more)
        }

        if !intranetSnapshot.people.isEmpty {
            let roster = NSMenuItem(title: "Kdo je kde a kontakty", action: nil, keyEquivalent: "")
            applyMenuIcon(to: roster, title: "Kdo je kde a kontakty", symbol: "person.3")
            let rosterMenu = NSMenu(title: "Kdo je kde a kontakty")
            let groups = [
                "in_building", "home_office", "offsite", "on_break",
                "vacation", "sick", "doctor", "away", "none"
            ]
            for state in groups {
                let people = intranetSnapshot.people.filter { $0.state == state }
                guard !people.isEmpty else { continue }
                let group = NSMenuItem(
                    title: "\(intranetStateLabel(state)) (\(people.count))",
                    action: nil,
                    keyEquivalent: ""
                )
                applyMenuIcon(
                    to: group,
                    title: "\(intranetStateLabel(state)) (\(people.count))",
                    symbol: "person.2"
                )
                let peopleMenu = NSMenu(title: intranetStateLabel(state))
                peopleMenu.autoenablesItems = false
                for person in people {
                    let suffix = person.since.map { " · od \(formatIntranetTime($0))" } ?? ""
                    if let phone = person.phone, !phone.isEmpty {
                        let contact = item(
                            "\(person.name)\(suffix)",
                            symbol: "phone.fill",
                            action: #selector(callIntranetContact(_:))
                        )
                        contact.representedObject = phone
                        contact.toolTip = "Zavolat \(person.name)"
                        peopleMenu.addItem(contact)
                    } else {
                        peopleMenu.addItem(readOnlyItem(
                            "\(person.name)\(suffix)",
                            color: .labelColor
                        ))
                    }
                }
                group.submenu = peopleMenu
                rosterMenu.addItem(group)
            }
            roster.submenu = rosterMenu
            intranetMenu.addItem(roster)
        }

        intranetMenu.addItem(item(
            "Dovolená a absence…",
            symbol: "calendar.badge.plus",
            action: #selector(requestIntranetLeave),
            color: .systemGreen
        ))

        intranetMenu.addItem(.separator())
        intranetMenu.addItem(item(
            intranetRefreshInFlight ? "Aktualizuji…" : "Aktualizovat nyní",
            symbol: "arrow.clockwise",
            action: #selector(refreshIntranetNow)
        ))
        intranetMenu.items.last?.isEnabled = !intranetRefreshInFlight && hasIntranetCredentials()
        intranetMenu.addItem(linkItem(
            "Otevřít Evora Intranet",
            symbol: "globe",
            url: "https://intranet.evora.cz/moje"
        ))
        intranetMenu.addItem(item(
            hasIntranetCredentials() ? "Nastavit připojení…" : "Připojit Evora Intranet…",
            symbol: "key",
            action: #selector(configureIntranetConnection)
        ))
    }

    @objc func configureIntranetConnection() {
        NSApp.activate(ignoringOtherApps: true)
        let alert = makeContextualAlert(
            "Evora Intranet",
            "Přihlášení se uloží pouze do macOS Klíčenky. Evora Smart Menu neukládá heslo, přístupový token ani GPS do svých souborů."
        )
        alert.addButton(withTitle: "Uložit a připojit")
        alert.addButton(withTitle: hasIntranetCredentials() ? "Odpojit" : "Zrušit")
        if hasIntranetCredentials() { alert.addButton(withTitle: "Zrušit") }

        let container = NSView(frame: NSRect(x: 0, y: 0, width: 380, height: 112))
        let emailLabel = NSTextField(labelWithString: "Firemní e-mail")
        emailLabel.frame = NSRect(x: 0, y: 90, width: 380, height: 18)
        let email = NSTextField(frame: NSRect(x: 0, y: 60, width: 380, height: 26))
        email.stringValue = intranetCredential(intranetEmailAccount) ?? ""
        email.placeholderString = "jmeno@evorasmart.cz"
        let passwordLabel = NSTextField(labelWithString: "Heslo")
        passwordLabel.frame = NSRect(x: 0, y: 36, width: 380, height: 18)
        let password = NSSecureTextField(frame: NSRect(x: 0, y: 4, width: 380, height: 26))
        password.placeholderString = hasIntranetCredentials() ? "Ponechte prázdné pro zachování" : "Heslo"
        container.addSubview(emailLabel)
        container.addSubview(email)
        container.addSubview(passwordLabel)
        container.addSubview(password)
        alert.accessoryView = container

        let response = alert.runModal()
        if response == .alertSecondButtonReturn {
            if hasIntranetCredentials() {
                deleteIntranetCredentials()
                intranetSnapshot = .empty
                saveIntranetSnapshot()
                _ = runWork(["intranet-sync", "off"])
                rebuildIntranetMenu()
                applyIntranetStatusToUI()
            }
            return
        }
        guard response == .alertFirstButtonReturn else { return }
        let emailValue = email.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        let passwordValue = password.stringValue
        guard emailValue.contains("@"), !emailValue.contains(" ") else {
            showAlert("Evora Intranet", "Zadejte platný firemní e-mail.")
            return
        }
        guard !passwordValue.isEmpty || intranetCredential(intranetPasswordAccount) != nil else {
            showAlert("Evora Intranet", "Heslo je povinné.")
            return
        }
        let passwordToStore = passwordValue.isEmpty
            ? (intranetCredential(intranetPasswordAccount) ?? "")
            : passwordValue
        guard storeIntranetCredentials(email: emailValue, password: passwordToStore) else {
            showAlert("Evora Intranet", "Přístup se nepodařilo bezpečně uložit do macOS Klíčenky.")
            return
        }
        intranetAccessToken = ""
        intranetRefreshToken = ""
        intranetCookieHeader = ""
        intranetTokenExpiresAt = .distantPast
        intranetRetryAfter = .distantPast
        intranetFailureCount = 0
        intranetSnapshot.dataState = "loading"
        rebuildIntranetMenu()
        refreshIntranet(forceAll: true)
    }

    @objc func performIntranetPunch(_ sender: NSMenuItem) {
        guard let kind = sender.representedObject as? String else { return }
        executeIntranetPunch(kind)
    }

    @objc func callIntranetContact(_ sender: NSMenuItem) {
        guard let phone = sender.representedObject as? String,
              let url = URL(string: "tel:\(phone)")
        else { return }
        NSWorkspace.shared.open(url)
    }

    @objc func requestIntranetLeave() {
        guard intranetSnapshot.dataState == "current",
              !intranetSnapshot.hrProfileId.isEmpty
        else {
            showAlert("Evora Intranet", "Docházková data nejsou aktuální. Nejdřív je obnovte.")
            return
        }

        NSApp.activate(ignoringOtherApps: true)
        let alert = makeContextualAlert(
            "Dovolená a absence",
            "Žádost se odešle přímo do Evora Intranetu ke schválení vedoucímu."
        )
        alert.addButton(withTitle: "Požádat o schválení")
        alert.addButton(withTitle: "Zrušit")

        let width: CGFloat = 430
        let container = NSView(frame: NSRect(x: 0, y: 0, width: width, height: 194))

        let typeLabel = NSTextField(labelWithString: "Typ")
        typeLabel.frame = NSRect(x: 0, y: 170, width: 90, height: 18)
        let typePopup = NSPopUpButton(frame: NSRect(x: 0, y: 138, width: width, height: 27))
        typePopup.addItems(withTitles: ["Dovolená", "Sick day", "Nemoc", "Lékař"])

        let fromLabel = NSTextField(labelWithString: "Od")
        fromLabel.frame = NSRect(x: 0, y: 112, width: 190, height: 18)
        let toLabel = NSTextField(labelWithString: "Do")
        toLabel.frame = NSRect(x: 220, y: 112, width: 190, height: 18)
        let fromPicker = NSDatePicker(frame: NSRect(x: 0, y: 80, width: 202, height: 27))
        let toPicker = NSDatePicker(frame: NSRect(x: 220, y: 80, width: 210, height: 27))
        for picker in [fromPicker, toPicker] {
            picker.datePickerStyle = .textFieldAndStepper
            picker.datePickerElements = .yearMonthDay
            picker.dateValue = Date()
        }

        let halfDay = NSButton(checkboxWithTitle: "Půlden", target: nil, action: nil)
        halfDay.frame = NSRect(x: 0, y: 48, width: 120, height: 24)
        let noteLabel = NSTextField(labelWithString: "Poznámka")
        noteLabel.frame = NSRect(x: 0, y: 27, width: 100, height: 18)
        let note = NSTextField(frame: NSRect(x: 0, y: 0, width: width, height: 25))
        note.placeholderString = "Volitelné"

        [typeLabel, typePopup, fromLabel, toLabel, fromPicker, toPicker, halfDay, noteLabel, note]
            .forEach(container.addSubview)
        alert.accessoryView = container

        guard alert.runModal() == .alertFirstButtonReturn else { return }
        let calendar = Calendar(identifier: .gregorian)
        guard calendar.startOfDay(for: fromPicker.dateValue) <= calendar.startOfDay(for: toPicker.dateValue) else {
            showAlert("Dovolená a absence", "Datum „Od“ nesmí být později než datum „Do“.")
            return
        }
        let typeKeys = ["vacation", "sickday", "sick", "doctor"]
        let dateFormatter = DateFormatter()
        dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        dateFormatter.timeZone = TimeZone(identifier: "Europe/Prague")
        dateFormatter.dateFormat = "yyyy-MM-dd"
        let noteValue = note.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        let body: [String: Any] = [
            "action": "create",
            "hr_profile_id": intranetSnapshot.hrProfileId,
            "type": typeKeys[max(0, min(typePopup.indexOfSelectedItem, typeKeys.count - 1))],
            "date_from": dateFormatter.string(from: fromPicker.dateValue),
            "date_to": dateFormatter.string(from: toPicker.dateValue),
            "portion": halfDay.state == .on ? 0.5 : 1.0,
            "note": noteValue.isEmpty ? NSNull() : noteValue,
            "propustky": []
        ]
        let loadingPanel = presentEvoraLoadingPanel(
            title: "Odesílám žádost",
            detail: "Evora Intranet zpracovává žádost o volno."
        )
        intranetRequest(path: "/api/hr/leave", method: "POST", body: body) { [weak self] result in
            guard let self else { return }
            DispatchQueue.main.async {
                loadingPanel.orderOut(nil)
                loadingPanel.close()
                switch result {
                case .success:
                    self.showAlert("Dovolená a absence", "Žádost byla odeslána ke schválení.")
                    self.refreshIntranet(forceAll: true)
                case .failure(let error):
                    self.showAlert("Dovolená a absence", error.localizedDescription)
                }
            }
        }
    }

    func executeIntranetPunch(_ kind: String) {
        guard intranetSnapshot.dataState == "current",
              !intranetSnapshot.hrProfileId.isEmpty
        else {
            showAlert("Evora Intranet", "Docházková data nejsou aktuální. Nejdřív je obnovte.")
            return
        }
        guard intranetAvailablePunches().contains(kind) else {
            showAlert(
                "Evora Intranet",
                "Akce „\(intranetPunchLabel(kind))“ neodpovídá aktuálnímu stavu „\(intranetStateLabel(intranetSnapshot.currentState))“. Nejdřív obnovte data."
            )
            return
        }
        NSApp.activate(ignoringOtherApps: true)
        let confirmation = makeContextualAlert(
            intranetPunchLabel(kind),
            "Tato akce se zapíše do Evora Intranetu jako oficiální docházka. GPS se z Evora Smart Menu neodesílá.",
            iconContext: "Evora Intranet docházka"
        )
        confirmation.addButton(withTitle: "Ano, zapsat")
        confirmation.addButton(withTitle: "Zrušit")
        guard confirmation.runModal() == .alertFirstButtonReturn else { return }

        let body: [String: Any] = [
            "action": "save",
            "hr_profile_id": intranetSnapshot.hrProfileId,
            "kind": kind,
            "ts": ISO8601DateFormatter().string(from: Date()),
            "source": "web",
            "lat": NSNull(),
            "lng": NSNull(),
            "gps_accuracy": NSNull(),
            "location": NSNull(),
            "client_ref": UUID().uuidString.lowercased()
        ]
        intranetRequest(path: "/api/attendance/events", method: "POST", body: body) { [weak self] result in
            guard let self else { return }
            if case .success = result,
               ["arrival", "home_start"].contains(kind) {
                _ = self.runWork(["spustit"])
            }
            DispatchQueue.main.async {
                switch result {
                case .success:
                    self.refreshIntranet(forceAll: false)
                case .failure(let error):
                    self.showAlert("Evora Intranet", error.localizedDescription)
                }
            }
        }
    }

    // MARK: - Evora Smart Hub

    func evoraToken() -> String? {
        evoraTokenCache
    }

    func loadEvoraTokenAsync() {
        DispatchQueue.global(qos: .utility).async { [weak self] in
            guard let self else { return }
            let token = self.readKeychainValue(alias: self.evoraKeychainAlias)
            DispatchQueue.main.async {
                self.evoraTokenCache = token
                self.evoraCredentialsLoaded = true
                self.rebuildEvoraMenu()
                self.refreshEvoraMenu()
            }
        }
    }

    @discardableResult
    func saveEvoraToken(_ token: String) -> Bool {
        let saved = runKeychainHelper("store", alias: evoraKeychainAlias, input: token).success
        if saved {
            evoraTokenCache = token
            evoraCredentialsLoaded = true
        }
        return saved
    }

    func deleteEvoraToken() {
        _ = runKeychainHelper("delete", alias: evoraKeychainAlias)
        evoraTokenCache = nil
        evoraCredentialsLoaded = true
    }

    func evoraHubURL() -> String {
        let configured = UserDefaults.standard.string(forKey: evoraHubDefaultsKey)
            ?? defaultEvoraHubURL
        return configured.trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
    }

    func validEvoraHubURL(_ value: String) -> String? {
        let normalized = value.trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard
            let url = URL(string: normalized),
            let scheme = url.scheme?.lowercased(),
            let host = url.host,
            !host.isEmpty,
            url.query == nil,
            url.fragment == nil,
            scheme == "https" || (scheme == "http" && ["127.0.0.1", "localhost"].contains(host.lowercased()))
        else {
            return nil
        }
        return normalized
    }

    func evoraEndpoint(_ path: String) -> URL? {
        let suffix = path.hasPrefix("/") ? path : "/\(path)"
        return URL(string: "\(evoraHubURL())\(suffix)")
    }

    func evoraRequest<T: Decodable>(
        path: String,
        method: String = "GET",
        body: [String: Any]? = nil,
        headers: [String: String] = [:],
        completion: @escaping (Result<T, Error>) -> Void
    ) {
        guard let token = evoraToken() else {
            completion(.failure(EvoraServiceError(message: "Nejdřív nastavte osobní token z Evora Smart Hubu.")))
            return
        }
        guard let url = evoraEndpoint(path) else {
            completion(.failure(EvoraServiceError(message: "Adresa Evora Smart Hubu není platná.")))
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        for (name, value) in headers {
            request.setValue(value, forHTTPHeaderField: name)
        }
        if let body {
            request.httpBody = try? JSONSerialization.data(withJSONObject: body)
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        evoraSession.dataTask(with: request) { data, response, error in
            if let error {
                completion(.failure(EvoraServiceError(message: "Evora Smart Hub není dostupný: \(error.localizedDescription)")))
                return
            }
            guard let http = response as? HTTPURLResponse else {
                completion(.failure(EvoraServiceError(message: "Evora Smart Hub nevrátil platnou odpověď.")))
                return
            }
            let payload = data ?? Data()
            guard (200..<300).contains(http.statusCode) else {
                let message = (try? JSONDecoder().decode(EvoraErrorResponse.self, from: payload).error)
                    ?? "Požadavek na Evora Smart Hub selhal (HTTP \(http.statusCode))."
                completion(.failure(EvoraServiceError(message: message)))
                return
            }
            do {
                completion(.success(try JSONDecoder().decode(T.self, from: payload)))
            } catch {
                completion(.failure(EvoraServiceError(message: "Evora Smart Hub vrátil nečitelná data.")))
            }
        }.resume()
    }

    func loadEvoraProfileImageIfNeeded(_ user: EvoraFleetResponse.User?) {
        guard let user, user.hasAvatar == true, let userId = user.id, !userId.isEmpty else {
            evoraProfileImage = nil
            evoraProfileImageVersion = ""
            modernMenuPanel?.reloadData()
            return
        }
        let version = "\(userId):\(user.avatarUpdatedAt ?? "1")"
        guard version != evoraProfileImageVersion, !evoraProfileImageRequestInFlight else { return }
        guard let token = evoraToken(),
              let url = evoraEndpoint("/api/integrations/worklog/v1/profile/avatar") else { return }
        evoraProfileImageRequestInFlight = true
        var request = URLRequest(url: url)
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("image/*", forHTTPHeaderField: "Accept")
        evoraSession.dataTask(with: request) { [weak self] data, response, _ in
            guard let self else { return }
            let http = response as? HTTPURLResponse
            let image = http.map { (200..<300).contains($0.statusCode) } == true
                ? data.flatMap(NSImage.init(data:))
                : nil
            DispatchQueue.main.async {
                self.evoraProfileImageRequestInFlight = false
                guard self.evoraUser?.id == userId else { return }
                if let image {
                    self.evoraProfileImage = image
                    self.evoraProfileImageVersion = version
                    self.applyIntranetStatusToUI()
                    self.modernMenuPanel?.reloadData()
                }
            }
        }.resume()
    }

    func downloadEvoraPortalAttachment(
        _ attachment: EvoraPortalTicketAttachment,
        completion: @escaping (Result<URL, Error>) -> Void
    ) {
        guard attachment.canDownload else {
            completion(.failure(EvoraServiceError(message: "Portál poskytl pouze název této přílohy, ne bezpečný odkaz ke stažení.")))
            return
        }
        guard let token = evoraToken(),
              let url = evoraEndpoint("/api/integrations/worklog/v1/portal-tickets/attachments/download") else {
            completion(.failure(EvoraServiceError(message: "Připojení k Evora Smart Hubu není nastavené.")))
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/octet-stream", forHTTPHeaderField: "Accept")
        request.httpBody = try? JSONSerialization.data(withJSONObject: ["token": attachment.token])
        evoraSession.dataTask(with: request) { data, response, error in
            if let error {
                completion(.failure(EvoraServiceError(message: "Přílohu se nepodařilo načíst: \(error.localizedDescription)")))
                return
            }
            guard let http = response as? HTTPURLResponse else {
                completion(.failure(EvoraServiceError(message: "Hub nevrátil platnou odpověď přílohy.")))
                return
            }
            let payload = data ?? Data()
            guard (200..<300).contains(http.statusCode) else {
                let message = (try? JSONDecoder().decode(EvoraErrorResponse.self, from: payload).error)
                    ?? "Přílohu se nepodařilo načíst (HTTP \(http.statusCode))."
                completion(.failure(EvoraServiceError(message: message)))
                return
            }
            let safeName = attachment.name
                .replacingOccurrences(of: "[^\\p{L}\\p{N} ._()-]", with: "_", options: .regularExpression)
                .prefix(180)
            let directory = FileManager.default.temporaryDirectory
                .appendingPathComponent("WorkLogAI-Evora-Attachments", isDirectory: true)
                .appendingPathComponent(UUID().uuidString, isDirectory: true)
            do {
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
                let target = directory.appendingPathComponent(safeName.isEmpty ? "priloha" : String(safeName))
                try payload.write(to: target, options: .atomic)
                completion(.success(target))
            } catch {
                completion(.failure(EvoraServiceError(message: "Staženou přílohu se nepodařilo bezpečně uložit.")))
            }
        }.resume()
    }

    func evoraConnectionLabel(_ state: String) -> String {
        switch state {
        case "online": return "Online"
        case "no_access": return "Online · bez přístupu"
        case "unavailable", "error", "offline": return "Offline"
        default: return "Stav neověřen"
        }
    }

    func evoraRelativeCheckLabel(_ value: String?) -> String? {
        guard let value, let date = parseIntranetDate(value) else { return nil }
        let age = max(0, Date().timeIntervalSince(date))
        if age < 60 { return "kontrola právě" }
        if age < 3_600 { return "kontrola před \(max(1, Int(age / 60))) min" }
        if age < 86_400 { return "kontrola před \(max(1, Int(age / 3_600))) h" }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "cs_CZ")
        formatter.dateFormat = "d. M. HH:mm"
        return "kontrola \(formatter.string(from: date))"
    }

    func evoraHealthLabel(_ value: String?) -> String? {
        guard let value, !value.isEmpty else { return nil }
        switch value.lowercased() {
        case "ok", "good", "healthy": return "Health OK"
        case "warning": return "Health varování"
        case "critical", "error", "failed": return "Health kritický"
        default: return "Health \(value)"
        }
    }

    func evoraServerMatchesSearch(_ server: EvoraMiniServer, folder: String, query: String) -> Bool {
        let normalized = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.isEmpty else { return true }
        let haystack = "\(server.project) \(server.serial) \(server.type) \(folder)"
        return haystack.range(of: normalized, options: [.caseInsensitive, .diacriticInsensitive]) != nil
    }

    func menuSearchMatches(_ item: NSMenuItem, query: String) -> Bool {
        let title = item.attributedTitle?.string.isEmpty == false
            ? item.attributedTitle?.string ?? item.title
            : item.title
        let searchable = "\(title) \(item.toolTip ?? "")"
        return searchable.range(
            of: query,
            options: [.caseInsensitive, .diacriticInsensitive]
        ) != nil
    }

    func isMainMenuEvoraSearchItem(_ item: NSMenuItem) -> Bool {
        mainMenuEvoraSearchItems.contains { $0.item === item }
            || mainMenuEvoraUniqueSearchItems.contains { $0 === item }
    }

    func isEvoraMiniserverNavigationItem(_ item: NSMenuItem) -> Bool {
        evoraFolderMenuItems.contains { $0.item === item }
            || evoraFlatSearchMenuItems.contains { $0.item === item }
            || evoraUniqueSearchItems.contains { $0 === item }
    }

    func removeMainMenuEvoraUniqueSearchItems() {
        for item in mainMenuEvoraUniqueSearchItems {
            mainMenuOriginalHidden.removeValue(forKey: ObjectIdentifier(item))
            if item.menu === menu { menu.removeItem(item) }
        }
        mainMenuEvoraUniqueSearchItems.removeAll()
    }

    func showMainMenuEvoraUniqueSearchResult(_ server: EvoraMiniServer?) {
        removeMainMenuEvoraUniqueSearchItems()
        guard let server, let anchor = mainMenuNoResultsItem else { return }
        var insertionIndex = (menu.items.firstIndex { $0 === anchor } ?? 0) + 1
        for detail in evoraClassicMiniserverDetailItems(server) {
            menu.insertItem(detail, at: insertionIndex)
            insertionIndex += 1
            mainMenuEvoraUniqueSearchItems.append(detail)
        }
    }

    func removeEvoraUniqueSearchItems() {
        for item in evoraUniqueSearchItems where item.menu === evoraMiniserversMenu {
            evoraMiniserversMenu.removeItem(item)
        }
        evoraUniqueSearchItems.removeAll()
    }

    func showEvoraUniqueSearchResult(_ server: EvoraMiniServer?) {
        removeEvoraUniqueSearchItems()
        guard let server, let anchor = evoraNoResultsItem else { return }
        var insertionIndex = (evoraMiniserversMenu.items.firstIndex { $0 === anchor } ?? 0) + 1
        for detail in evoraClassicMiniserverDetailItems(server) {
            evoraMiniserversMenu.insertItem(detail, at: insertionIndex)
            insertionIndex += 1
            evoraUniqueSearchItems.append(detail)
        }
    }

    @discardableResult
    func filterMenuTree(_ targetMenu: NSMenu, query: String, forceVisible: Bool = false) -> Bool {
        var hasVisibleResult = false
        for menuItem in targetMenu.items {
            if menuItem === mainMenuSearchItem || menuItem === mainMenuNoResultsItem {
                continue
            }
            if isMainMenuEvoraSearchItem(menuItem) {
                continue
            }
            let identifier = ObjectIdentifier(menuItem)
            if mainMenuOriginalHidden[identifier] == nil {
                mainMenuOriginalHidden[identifier] = menuItem.isHidden
            }
            if !forceVisible, isEvoraMiniserverNavigationItem(menuItem) {
                menuItem.isHidden = true
                continue
            }
            let originallyHidden = mainMenuOriginalHidden[identifier] ?? false
            if originallyHidden || menuItem.isSeparatorItem {
                menuItem.isHidden = true
                continue
            }
            if menuItem.view != nil {
                menuItem.isHidden = !forceVisible
                hasVisibleResult = hasVisibleResult || forceVisible
                continue
            }

            let ownMatch = forceVisible || menuSearchMatches(menuItem, query: query)
            let childMatch = menuItem.submenu.map {
                filterMenuTree($0, query: query, forceVisible: ownMatch)
            } ?? false
            let visible = ownMatch || childMatch
            menuItem.isHidden = !visible
            hasVisibleResult = hasVisibleResult || visible
        }
        return hasVisibleResult
    }

    func restoreMainMenuVisibility(_ targetMenu: NSMenu) {
        for menuItem in targetMenu.items {
            if let hidden = mainMenuOriginalHidden[ObjectIdentifier(menuItem)] {
                menuItem.isHidden = hidden
            }
            if let submenu = menuItem.submenu {
                restoreMainMenuVisibility(submenu)
            }
        }
    }

    func replaceMainMenuEvoraSearchItems(with servers: [EvoraMiniServer]) {
        guard menu != nil, let anchor = mainMenuNoResultsItem else { return }
        for entry in mainMenuEvoraSearchItems {
            mainMenuOriginalHidden.removeValue(forKey: ObjectIdentifier(entry.item))
            if entry.item.menu === menu { menu.removeItem(entry.item) }
        }
        mainMenuEvoraSearchItems.removeAll()
        var insertionIndex = (menu.items.firstIndex { $0 === anchor } ?? 0) + 1
        for server in servers.sorted(by: {
            $0.project.localizedCaseInsensitiveCompare($1.project) == .orderedAscending
        }) {
            let result = evoraMiniserverMenuItem(server)
            result.toolTip = "\(server.folderName) · \(server.serial) · \(server.type)"
            menu.insertItem(result, at: insertionIndex)
            insertionIndex += 1
            mainMenuEvoraSearchItems.append((item: result, folder: server.folderName, server: server))
        }
    }

    func replaceEvoraFlatSearchItems(with servers: [EvoraMiniServer]) {
        for entry in evoraFlatSearchMenuItems where entry.item.menu === evoraMiniserversMenu {
            evoraMiniserversMenu.removeItem(entry.item)
        }
        evoraFlatSearchMenuItems.removeAll()
        guard let anchor = evoraNoResultsItem else { return }
        var insertionIndex = (evoraMiniserversMenu.items.firstIndex { $0 === anchor } ?? 0) + 1
        for server in servers.sorted(by: {
            $0.project.localizedCaseInsensitiveCompare($1.project) == .orderedAscending
        }) {
            let result = evoraMiniserverMenuItem(server)
            result.toolTip = server.folderName
            evoraMiniserversMenu.insertItem(result, at: insertionIndex)
            insertionIndex += 1
            evoraFlatSearchMenuItems.append((item: result, folder: server.folderName, server: server))
        }
    }

    func applyMainMenuSearchFilter() {
        guard menu != nil else { return }
        let query = mainMenuSearchQuery.trimmingCharacters(in: .whitespacesAndNewlines)
        if query.isEmpty {
            removeMainMenuEvoraUniqueSearchItems()
            replaceMainMenuEvoraSearchItems(with: [])
            restoreMainMenuVisibility(menu)
            mainMenuOriginalHidden.removeAll()
            mainMenuSearchItem?.isHidden = false
            mainMenuNoResultsItem?.isHidden = true
            return
        }
        let matchingServers = evoraServers.filter {
            evoraServerMatchesSearch($0, folder: $0.folderName, query: query)
        }
        let uniqueServer = matchingServers.count == 1 ? matchingServers[0] : nil
        replaceMainMenuEvoraSearchItems(with: uniqueServer == nil ? matchingServers : [])
        showMainMenuEvoraUniqueSearchResult(uniqueServer)
        let hasResults = filterMenuTree(menu, query: query) || !matchingServers.isEmpty
        mainMenuSearchItem?.isHidden = false
        mainMenuNoResultsItem?.isHidden = hasResults
    }

    func scheduleMainMenuSearchFilter() {
        mainMenuSearchWorkItem?.cancel()
        mainMenuSearchRevision += 1
        let revision = mainMenuSearchRevision
        let trimmedQuery = mainMenuSearchQuery.trimmingCharacters(in: .whitespacesAndNewlines)
        let queryIsEmpty = trimmedQuery.isEmpty
        if !queryIsEmpty, trimmedQuery.count < classicSearchMinimumLength {
            // První znak pouze zůstane v editoru. Překreslení celé nabídky by
            // AppKitu odebralo field editor dřív, než uživatel dopíše slovo.
            if !mainMenuOriginalHidden.isEmpty {
                let pendingQuery = mainMenuSearchQuery
                mainMenuSearchQuery = ""
                applyMainMenuSearchFilter()
                mainMenuSearchQuery = pendingQuery
                menu.update()
                classicMenuNavigator?.modelDidChange()
                DispatchQueue.main.async { [weak self] in
                    self?.mainMenuSearchField?.ensureKeyboardFocus()
                }
            }
            return
        }
        let expectedQuery = mainMenuSearchQuery
        let work = DispatchWorkItem { [weak self] in
            guard let self, revision == self.mainMenuSearchRevision else { return }
            let liveQuery = self.mainMenuSearchField?.stringValue ?? self.mainMenuSearchQuery
            guard liveQuery == expectedQuery else {
                self.mainMenuSearchQuery = liveQuery
                self.scheduleMainMenuSearchFilter()
                return
            }
            if queryIsEmpty, self.evoraRebuildDeferred {
                self.rebuildEvoraMenu()
            }
            self.applyMainMenuSearchFilter()
            self.menu.update()
            self.classicMenuNavigator?.modelDidChange()
            DispatchQueue.main.async { [weak self] in
                self?.mainMenuSearchField?.ensureKeyboardFocus()
            }
        }
        mainMenuSearchWorkItem = work
        // Changing NSMenuItem visibility synchronously from AppKit's text
        // editor callback can re-enter menu layout and freeze menu tracking.
        // Krátká pauza po dopsání spojí celé slovo do jediného překreslení.
        DispatchQueue.main.asyncAfter(deadline: .now() + (queryIsEmpty ? 0 : classicSearchDebounce), execute: work)
    }

    func applyEvoraSearchFilter() {
        let query = evoraSearchQuery.trimmingCharacters(in: .whitespacesAndNewlines)
        if query.isEmpty {
            removeEvoraUniqueSearchItems()
            replaceEvoraFlatSearchItems(with: [])
            for folderEntry in evoraFolderMenuItems {
                folderEntry.item.isHidden = false
                applyMenuIcon(
                    to: folderEntry.item,
                    title: "\(folderEntry.folder)  (\(folderEntry.servers.count))",
                    symbol: "folder.fill",
                    color: folderEntry.color
                )
            }
            evoraNoResultsItem?.isHidden = true
            return
        }
        for folderEntry in evoraFolderMenuItems {
            folderEntry.item.isHidden = true
        }
        let matchingServers = evoraServers.filter {
            evoraServerMatchesSearch($0, folder: $0.folderName, query: query)
        }
        let uniqueServer = matchingServers.count == 1 ? matchingServers[0] : nil
        replaceEvoraFlatSearchItems(with: uniqueServer == nil ? matchingServers : [])
        showEvoraUniqueSearchResult(uniqueServer)
        evoraNoResultsItem?.isHidden = !matchingServers.isEmpty
    }

    func scheduleEvoraSearchFilter() {
        evoraSearchWorkItem?.cancel()
        evoraSearchRevision += 1
        let revision = evoraSearchRevision
        let expectedQuery = evoraSearchQuery
        let trimmedQuery = expectedQuery.trimmingCharacters(in: .whitespacesAndNewlines)
        let queryIsEmpty = trimmedQuery.isEmpty
        if !queryIsEmpty, trimmedQuery.count < classicSearchMinimumLength {
            if evoraFolderMenuItems.contains(where: { $0.item.isHidden }) {
                let pendingQuery = evoraSearchQuery
                evoraSearchQuery = ""
                applyEvoraSearchFilter()
                evoraSearchQuery = pendingQuery
                evoraMiniserversMenu.update()
                classicMenuNavigator?.modelDidChange()
                DispatchQueue.main.async { [weak self] in
                    self?.evoraSearchField?.ensureKeyboardFocus()
                }
            }
            return
        }
        let work = DispatchWorkItem { [weak self] in
            guard let self, revision == self.evoraSearchRevision else { return }
            let liveQuery = self.evoraSearchField?.stringValue ?? self.evoraSearchQuery
            guard liveQuery == expectedQuery else {
                self.evoraSearchQuery = liveQuery
                self.scheduleEvoraSearchFilter()
                return
            }
            self.applyEvoraSearchFilter()
            self.evoraMiniserversMenu.update()
            self.classicMenuNavigator?.modelDidChange()
            DispatchQueue.main.async { [weak self] in
                self?.evoraSearchField?.ensureKeyboardFocus()
            }
        }
        evoraSearchWorkItem = work
        DispatchQueue.main.asyncAfter(deadline: .now() + (queryIsEmpty ? 0 : classicSearchDebounce), execute: work)
    }

    func controlTextDidChange(_ notification: Notification) {
        guard let field = notification.object as? NSSearchField else { return }
        if field === mainMenuSearchField {
            mainMenuSearchQuery = field.stringValue
            scheduleMainMenuSearchFilter()
        } else if field === evoraSearchField {
            evoraSearchQuery = field.stringValue
            scheduleEvoraSearchFilter()
        }
    }

    @objc func searchFieldAction(_ sender: NSSearchField) {
        if sender === mainMenuSearchField {
            mainMenuSearchQuery = sender.stringValue
            mainMenuSearchWorkItem?.cancel()
            mainMenuSearchRevision += 1
            applyMainMenuSearchFilter()
            menu.update()
            classicMenuNavigator?.modelDidChange()
            DispatchQueue.main.async { [weak self] in
                self?.mainMenuSearchField?.ensureKeyboardFocus()
            }
        } else if sender === evoraSearchField {
            evoraSearchQuery = sender.stringValue
            evoraSearchWorkItem?.cancel()
            evoraSearchRevision += 1
            applyEvoraSearchFilter()
            evoraMiniserversMenu.update()
            classicMenuNavigator?.modelDidChange()
            DispatchQueue.main.async { [weak self] in
                self?.evoraSearchField?.ensureKeyboardFocus()
            }
        }
    }

    func evoraPortalTicketIsClosed(_ status: String) -> Bool {
        let normalized = status.lowercased()
        return normalized.contains("closed")
            || normalized.contains("resolved")
            || normalized.contains("solved")
            || normalized.contains("uzavřen")
    }

    func evoraPortalTicketStatus(_ status: String) -> String {
        let normalized = status.lowercased()
        if normalized == "open" || normalized == "opened" { return "Otevřený" }
        if evoraPortalTicketIsClosed(status) { return "Uzavřený" }
        if normalized.contains("await") || normalized.contains("waiting") || normalized.contains("pending") || normalized.contains("hold") || normalized.contains("ček") { return "Čeká" }
        return status.isEmpty ? "Neznámý" : status
    }

    func evoraPortalTicketColor(_ status: String) -> NSColor {
        let normalized = status.lowercased()
        if evoraPortalTicketIsClosed(status) { return .systemBlue }
        if normalized.contains("await") || normalized.contains("waiting") || normalized.contains("pending") || normalized.contains("hold") || normalized.contains("ček") {
            return .systemOrange
        }
        if normalized.contains("open") || normalized.contains("otevřen") || normalized.contains("new") {
            return .systemGreen
        }
        return .systemPurple
    }

    func compactMenuText(_ value: String, limit: Int = 88) -> String {
        let singleLine = value
            .components(separatedBy: .whitespacesAndNewlines)
            .filter { !$0.isEmpty }
            .joined(separator: " ")
        guard singleLine.count > limit else { return singleLine }
        return "\(singleLine.prefix(max(1, limit - 1)))…"
    }

    func evoraTicketsMenuItem() -> NSMenuItem {
        let parent = NSMenuItem(
            title: "LOXONE tickety  (\(evoraTickets.count))",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(
            to: parent,
            title: "LOXONE tickety  (\(evoraTickets.count))",
            symbol: "ticket"
        )
        let submenu = NSMenu(title: "LOXONE tickety")
        submenu.autoenablesItems = false
        submenu.delegate = self
        evoraTicketsSubmenu = submenu
        parent.submenu = submenu
        return parent
    }

    func populateEvoraTicketsMenu(_ submenu: NSMenu) {
        guard submenu.items.isEmpty else { return }
        let ticketStatusColor: NSColor = evoraTicketsRefreshInFlight
            ? .systemOrange
            : evoraTicketsStatus.lowercased().contains("selhala") || evoraTicketsStatus.lowercased().contains("nepřipojeno")
            ? .systemRed
            : .labelColor
        let status = readOnlyItem(evoraTicketsStatus, symbol: "ticket", color: ticketStatusColor, weight: .medium)
        submenu.addItem(status)
        submenu.addItem(.separator())
        submenu.addItem(item("Nový ticket…", symbol: "plus.bubble", action: #selector(createEvoraPortalTicket)))
        submenu.addItem(item("Aktualizovat změny", symbol: "arrow.clockwise", action: #selector(refreshEvoraTickets)))
        submenu.addItem(linkItem("Otevřít centrum v Evora Smart Hubu", symbol: "rectangle.portrait.and.arrow.right", url: "\(evoraHubURL())?page=tickets"))
        submenu.addItem(.separator())
        if evoraTickets.isEmpty {
            let empty = readOnlyItem(
                evoraTicketsRefreshInFlight ? "Načítám tickety…" : "Žádné tickety nejsou dostupné.",
                symbol: evoraTicketsRefreshInFlight ? "arrow.clockwise" : "tray",
                color: evoraTicketsRefreshInFlight ? .systemOrange : .labelColor
            )
            submenu.addItem(empty)
        } else {
            for ticket in evoraTickets {
                let subject = compactMenuText(ticket.subject)
                let ticketItem = item(
                    "#\(ticket.ticketNumber) · \(subject) — \(evoraPortalTicketStatus(ticket.status))",
                    symbol: "bubble.left.and.bubble.right",
                    action: #selector(showEvoraPortalTicket(_:)),
                    color: evoraPortalTicketColor(ticket.status)
                )
                ticketItem.representedObject = ticket.id
                ticketItem.toolTip = compactMenuText(
                    "\(evoraPortalTicketStatus(ticket.status)) · \(ticket.contactName) · \(ticket.subject)",
                    limit: 180
                )
                submenu.addItem(ticketItem)
            }
        }
    }

    func addHomeAssistantMenu(to target: NSMenu) {
        let homeAssistant = NSMenuItem(
            title: "Home Assistant odkazy",
            action: nil,
            keyEquivalent: ""
        )
        let links = NSMenu(title: "Home Assistant odkazy")
        links.autoenablesItems = false
        links.addItem(linkItem("Herškovič", symbol: "person.crop.circle", url: "https://homeassistant-herskovic.skunk-atria.ts.net", color: .systemBlue))
        links.addItem(linkItem("Vágner", symbol: "person.crop.circle", url: "https://homeassistant-vagner.skunk-atria.ts.net", color: .systemTeal))
        links.addItem(linkItem("Evora", symbol: "building.2.fill", url: "https://homeassistant-work.skunk-atria.ts.net", color: .systemGreen))
        links.addItem(linkItem("Domov", symbol: "house.fill", url: "https://homeassistant.skunk-atria.ts.net", color: .systemOrange))
        homeAssistant.submenu = links
        applyMenuIcon(to: homeAssistant, title: "Home Assistant odkazy", symbol: "house.fill", color: .systemCyan)
        target.addItem(homeAssistant)
    }

    func evoraConnectionColor(_ state: String) -> NSColor {
        let normalized = state.lowercased()
        if normalized == "online" || normalized == "no_access" { return .systemGreen }
        if normalized.contains("pause") || normalized.contains("wait") { return .systemOrange }
        if normalized == "unavailable" || normalized == "error" || normalized == "offline" { return .systemRed }
        return .systemPurple
    }

    func evoraIsFirstGenerationMiniserver(type: String) -> Bool {
        let normalized = type
            .folding(options: [.caseInsensitive, .diacriticInsensitive], locale: Locale(identifier: "cs_CZ"))
            .lowercased()
        return normalized.contains("gen. 1")
            || normalized.contains("gen 1")
            || normalized.contains("gen1")
            || normalized.contains("1. generace")
    }

    func evoraDisplayedMiniserverType(_ type: String) -> String {
        let normalized = type.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        if evoraIsFirstGenerationMiniserver(type: type) { return "Miniserver Gen. 1" }
        if normalized == "miniserver" { return "Miniserver Gen. 2" }
        return type
    }

    func evoraBundledDeviceImageFileName(type: String) -> String {
        let normalized = type.lowercased()
        if normalized.contains("compact") { return "compact-transparent.png" }
        if normalized.contains("go") { return "go.png" }
        // Seznam používá stejný jednoznačný produktový podklad jako karta.
        // Tím se ani malá ikona Gen. 1 nemůže zaměnit za většinovou Gen. 2.
        return evoraIsFirstGenerationMiniserver(type: type)
            ? "cards/miniserver-gen1.png"
            : "cards/miniserver.png"
    }

    func evoraBundledDeviceImage(type: String) -> NSImage? {
        let fileName = evoraBundledDeviceImageFileName(type: type)
        let key = "bundled:\(fileName)"
        if let cached = evoraDeviceImageCache[key] { return cached }
        guard let image = NSImage(contentsOfFile: "\(runtimeRoot)/app/devices/\(fileName)") else { return nil }
        image.isTemplate = false
        evoraDeviceImageCache[key] = image
        return image
    }

    func evoraBundledCardDeviceImageFileName(type: String) -> String {
        let normalized = type.lowercased()
        if normalized.contains("compact") { return "miniserver-compact.png" }
        if normalized.contains("go") { return "miniserver-go.png" }
        return evoraIsFirstGenerationMiniserver(type: type)
            ? "miniserver-gen1.png"
            : "miniserver.png"
    }

    func evoraBundledCardDeviceImage(type: String) -> NSImage? {
        let fileName = evoraBundledCardDeviceImageFileName(type: type)
        let key = "bundled-card:\(fileName)"
        if let cached = evoraDeviceImageCache[key] { return cached }
        guard let image = NSImage(contentsOfFile: "\(runtimeRoot)/app/devices/cards/\(fileName)") else {
            return nil
        }
        image.isTemplate = false
        evoraDeviceImageCache[key] = image
        return image
    }

    func loadEvoraDeviceImage(path: String, into imageView: NSImageView) {
        if let cached = evoraDeviceImageCache[path] {
            imageView.image = cached
            return
        }
        guard
            !evoraDeviceImageRequests.contains(path),
            let token = evoraToken(),
            let url = evoraEndpoint(path)
        else { return }
        evoraDeviceImageRequests.insert(path)
        var request = URLRequest(url: url)
        request.cachePolicy = .returnCacheDataElseLoad
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("image/png,image/*;q=0.8", forHTTPHeaderField: "Accept")
        evoraSession.dataTask(with: request) { [weak self, weak imageView] data, response, _ in
            guard let self else { return }
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            let image = status >= 200 && status < 300
                ? data.flatMap(NSImage.init(data:))
                : nil
            DispatchQueue.main.async {
                self.evoraDeviceImageRequests.remove(path)
                guard let image else { return }
                image.isTemplate = false
                self.evoraDeviceImageCache[path] = image
                imageView?.image = image
            }
        }.resume()
    }

    func evoraMiniserverSummaryItem(_ server: EvoraMiniServer) -> NSMenuItem {
        let item = NSMenuItem(title: server.project, action: nil, keyEquivalent: "")
        let width: CGFloat = 420
        let height: CGFloat = 148
        let container = NSView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        let view = NSView(frame: NSRect(x: 8, y: 4, width: width - 16, height: height - 8))
        container.addSubview(view)
        view.identifier = NSUserInterfaceItemIdentifier("evora-miniserver-summary")
        let connectionColor = evoraConnectionColor(server.connectionState)
        view.wantsLayer = true
        view.layer?.cornerRadius = 18
        view.layer?.cornerCurve = .continuous
        view.layer?.backgroundColor = connectionColor.withAlphaComponent(0.10).cgColor
        view.layer?.borderWidth = 1
        view.layer?.borderColor = connectionColor.withAlphaComponent(0.28).cgColor
        view.layer?.shadowColor = connectionColor.cgColor
        view.layer?.shadowOpacity = 0.10
        view.layer?.shadowRadius = 9
        view.layer?.shadowOffset = NSSize(width: 0, height: -2)
        if !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion {
            let pulse = CABasicAnimation(keyPath: "shadowOpacity")
            pulse.fromValue = server.connectionState == "online" ? 0.07 : 0.11
            pulse.toValue = server.connectionState == "online" ? 0.18 : 0.28
            pulse.duration = server.connectionState == "online" ? 2.4 : 1.2
            pulse.autoreverses = true
            pulse.repeatCount = .infinity
            pulse.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
            view.layer?.add(pulse, forKey: "evora.classic.miniserver.statePulse")
        }

        let cardImage = evoraBundledCardDeviceImage(type: server.type)
        let imageView = NSImageView(frame: NSRect(x: 12, y: 24, width: 104, height: 92))
        imageView.identifier = NSUserInterfaceItemIdentifier("evora-miniserver-image")
        imageView.image = cardImage
            ?? evoraBundledDeviceImage(type: server.type)
            ?? sf("server.rack", color: connectionColor)
        imageView.imageScaling = .scaleProportionallyUpOrDown
        view.addSubview(imageView)
        if cardImage == nil, let path = server.deviceImageUrl, !path.isEmpty {
            loadEvoraDeviceImage(path: path, into: imageView)
        }

        let title = NSTextField(labelWithString: server.project)
        title.identifier = NSUserInterfaceItemIdentifier("evora-miniserver-title")
        title.frame = NSRect(x: 126, y: 108, width: 262, height: 22)
        title.font = NSFont.systemFont(ofSize: 16, weight: .bold)
        title.textColor = .labelColor
        title.lineBreakMode = .byTruncatingTail
        view.addSubview(title)

        let identity = NSTextField(
            labelWithString: "\(server.serial) · \(evoraDisplayedMiniserverType(server.type))"
        )
        identity.identifier = NSUserInterfaceItemIdentifier("evora-miniserver-identity")
        identity.frame = NSRect(x: 126, y: 87, width: 262, height: 17)
        identity.font = NSFont.systemFont(ofSize: 10.5, weight: .regular)
        identity.textColor = .secondaryLabelColor
        identity.lineBreakMode = .byTruncatingTail
        view.addSubview(identity)

        let status = NSTextField(labelWithString: "\(evoraConnectionLabel(server.connectionState)) · FW \(server.currentFirmware ?? "neznámý")")
        status.identifier = NSUserInterfaceItemIdentifier("evora-miniserver-status")
        status.frame = NSRect(x: 126, y: 66, width: 262, height: 17)
        status.font = NSFont.monospacedDigitSystemFont(ofSize: 10.5, weight: .semibold)
        status.textColor = connectionColor
        status.lineBreakMode = .byTruncatingTail
        view.addSubview(status)

        let deviceText: String
        let deviceColor: NSColor
        if let total = server.elementsTotal, let online = server.elementsOnline, total > 0 {
            let offline = max(0, server.offlineDevices ?? (total - online))
            deviceText = offline > 0
                ? "Prvky \(online)/\(total) · \(offline) offline"
                : "Prvky \(online)/\(total) · vše online"
            deviceColor = offline > 0 ? .systemRed : .systemGreen
        } else {
            deviceText = "Prvky · zatím neověřeno"
            deviceColor = .secondaryLabelColor
        }
        let devices = NSTextField(labelWithString: deviceText)
        devices.identifier = NSUserInterfaceItemIdentifier("evora-miniserver-devices")
        devices.frame = NSRect(x: 126, y: 45, width: 262, height: 17)
        devices.font = NSFont.monospacedDigitSystemFont(ofSize: 10, weight: .semibold)
        devices.textColor = deviceColor
        devices.lineBreakMode = .byTruncatingTail
        view.addSubview(devices)

        var diagnostics = [String]()
        if let health = evoraHealthLabel(server.healthVerdict) { diagnostics.append(health) }
        if let check = evoraRelativeCheckLabel(server.lastCheckedAt) { diagnostics.append(check) }
        if let latency = server.lastLatencyMs { diagnostics.append("\(Int(latency.rounded())) ms") }
        if let failures = server.consecutiveFailures, failures > 0 { diagnostics.append("\(failures)× chyba") }
        let diagnosticText = diagnostics.isEmpty ? "Diagnostika zatím neověřena" : diagnostics.joined(separator: " · ")
        let healthState = server.healthVerdict?.lowercased() ?? ""
        let diagnosticColor: NSColor = healthState == "critical" || (server.consecutiveFailures ?? 0) >= 3
            ? .systemRed
            : healthState == "warning" || server.dataState == "stale" || (server.consecutiveFailures ?? 0) > 0
            ? .systemOrange
            : .secondaryLabelColor
        let diagnostic = NSTextField(labelWithString: diagnosticText)
        diagnostic.identifier = NSUserInterfaceItemIdentifier("evora-miniserver-diagnostic")
        diagnostic.frame = NSRect(x: 126, y: 24, width: 262, height: 17)
        diagnostic.font = NSFont.monospacedDigitSystemFont(ofSize: 9.5, weight: .regular)
        diagnostic.textColor = diagnosticColor
        diagnostic.lineBreakMode = .byTruncatingTail
        diagnostic.toolTip = diagnosticText
        view.addSubview(diagnostic)

        item.view = container
        item.representedObject = [
            "modernEmbedded": "miniserverSummary",
            "serial": server.serial,
        ] as NSDictionary
        // Keep the informational card fully opaque. It has no action, so it
        // remains non-interactive without using AppKit's disabled appearance.
        item.isEnabled = true
        return item
    }

    func evoraMiniserverDetailItems(_ server: EvoraMiniServer) -> [NSMenuItem] {
        var details = [evoraMiniserverSummaryItem(server), NSMenuItem.separator()]
        let appAction = item(
            "Loxone App",
            symbol: "iphone",
            action: #selector(runEvoraAction(_:))
        )
        appAction.representedObject = [
            "serial": server.serial,
            "action": "loxone_app"
        ] as NSDictionary
        appAction.isEnabled = server.loxoneAppAvailable

        let webAction = item(
            "Webové rozhraní",
            symbol: "globe",
            action: #selector(runEvoraAction(_:))
        )
        webAction.representedObject = [
            "serial": server.serial,
            "action": "web_interface"
        ] as NSDictionary
        webAction.isEnabled = evoraCapabilities?.miniserverWebInterface == true

        let passwordAction = item(
            "Kopírovat heslo",
            symbol: "key",
            action: #selector(runEvoraAction(_:))
        )
        passwordAction.representedObject = [
            "serial": server.serial,
            "action": "copy_password",
            "modernFullWidth": true
        ] as NSDictionary
        passwordAction.isEnabled = server.hasCredentials
            && evoraCapabilities?.miniserverPasswordCopy == true
        details.append(passwordAction)
        details.append(appAction)
        details.append(webAction)

        let configTitle: String
        if evoraLauncherAgent?.updateRequired == true {
            configTitle = "Nové okno Configu · aktualizujte Launcher"
        } else if server.loxoneConfigAvailable {
            configTitle = "Nové okno Configu"
        } else {
            configTitle = "Nové okno Configu · Launcher offline"
        }
        let configAction = item(
            configTitle,
            symbol: "doc.badge.gearshape",
            action: #selector(runEvoraAction(_:))
        )
        configAction.representedObject = [
            "serial": server.serial,
            "action": "loxone_config",
            "launchMode": "new_window"
        ] as NSDictionary
        configAction.isEnabled = server.loxoneConfigAvailable
        let existingConfigTitle: String
        if evoraLauncherAgent?.updateRequired == true {
            existingConfigTitle = "Běžící Config · aktualizujte Launcher"
        } else if server.loxoneConfigAvailable {
            existingConfigTitle = "Běžící Config"
        } else {
            existingConfigTitle = "Běžící Config · Launcher offline"
        }
        let existingConfigAction = item(
            existingConfigTitle,
            symbol: "macwindow",
            action: #selector(runEvoraAction(_:))
        )
        existingConfigAction.representedObject = [
            "serial": server.serial,
            "action": "loxone_config",
            "launchMode": "existing"
        ] as NSDictionary
        existingConfigAction.isEnabled = server.loxoneConfigAvailable
        details.append(existingConfigAction)
        details.append(configAction)

        if let download = server.configDownloadUrl {
            details.append(.separator())
            details.append(
                linkItem(
                    "Stáhnout Loxone Config \(server.configVersion ?? "")",
                    symbol: "arrow.down.circle",
                    url: download
                )
            )
        }
        return details
    }

    func evoraMiniserverActionGridItem(_ server: EvoraMiniServer) -> NSMenuItem {
        let item = NSMenuItem()
        let width: CGFloat = 420
        let height: CGFloat = 142
        let margin: CGFloat = 8
        let gap: CGFloat = 8
        let buttonWidth = (width - margin * 2 - gap) / 2
        let buttonHeight: CGFloat = 36
        let view = NSView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        let entries: [(String, String, NSColor, NSDictionary, Bool)] = [
            (
                "Kopírovat heslo", "key.fill", .systemYellow,
                ["serial": server.serial, "action": "copy_password"] as NSDictionary,
                server.hasCredentials && evoraCapabilities?.miniserverPasswordCopy == true
            ),
            (
                "Loxone App", "iphone", .systemTeal,
                ["serial": server.serial, "action": "loxone_app"] as NSDictionary,
                server.loxoneAppAvailable
            ),
            (
                "Webové rozhraní", "globe", .systemBlue,
                ["serial": server.serial, "action": "web_interface"] as NSDictionary,
                evoraCapabilities?.miniserverWebInterface == true
            ),
            (
                "Běžící Config", "macwindow", .systemPurple,
                ["serial": server.serial, "action": "loxone_config", "launchMode": "existing"] as NSDictionary,
                server.loxoneConfigAvailable
            ),
            (
                "Nové okno Configu", "doc.badge.gearshape", .systemGreen,
                ["serial": server.serial, "action": "loxone_config", "launchMode": "new_window"] as NSDictionary,
                server.loxoneConfigAvailable
            ),
            (
                server.configVersion.map { "Stáhnout Config \($0)" } ?? "Stáhnout Config",
                "arrow.down.circle", .systemIndigo,
                ["action": "open_url", "url": server.configDownloadUrl ?? ""] as NSDictionary,
                server.configDownloadUrl?.isEmpty == false
            ),
        ]
        for (index, entry) in entries.enumerated() {
            let row = index / 2
            let column = index % 2
            let card = ClassicMenuActionCardView(frame: NSRect(
                x: margin + CGFloat(column) * (buttonWidth + gap),
                y: height - margin - CGFloat(row + 1) * buttonHeight - CGFloat(row) * gap,
                width: buttonWidth,
                height: buttonHeight
            ))
            let payload = entry.3
            card.configure(
                title: entry.0,
                image: sf(entry.1, color: entry.2),
                tintColor: entry.2,
                enabled: entry.4,
                activation: entry.4 ? { [weak self] in
                    self?.performEvoraGridAction(payload)
                } : nil
            )
            card.toolTip = entry.4 ? entry.0 : "\(entry.0) · funkce teď není dostupná"
            view.addSubview(card)
        }
        item.view = view
        item.isEnabled = true
        return item
    }

    func evoraClassicMiniserverDetailItems(_ server: EvoraMiniServer) -> [NSMenuItem] {
        [evoraMiniserverSummaryItem(server), evoraMiniserverActionGridItem(server)]
    }

    func evoraMiniserverMenuItem(_ server: EvoraMiniServer) -> NSMenuItem {
        let connectionColor = evoraConnectionColor(server.connectionState)
        let serverItem = NSMenuItem(
            title: "\(evoraConnectionLabel(server.connectionState)) · \(server.project)",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(
            to: serverItem,
            title: "\(evoraConnectionLabel(server.connectionState)) · \(server.project)",
            image: evoraBundledDeviceImage(type: server.type)
                ?? sf("server.rack", color: connectionColor)
        )
        let serverMenu = NSMenu(title: server.project)
        for detail in evoraClassicMiniserverDetailItems(server) {
            serverMenu.addItem(detail)
        }
        serverItem.submenu = serverMenu
        return serverItem
    }

    func evoraCameraPreviewItem(_ camera: EvoraCamera) -> NSMenuItem {
        let item = NSMenuItem()
        let view = NSView(frame: NSRect(x: 0, y: 0, width: 416, height: 258))
        view.identifier = NSUserInterfaceItemIdentifier("evora-camera-card")

        let title = NSTextField(labelWithString: camera.name)
        title.identifier = NSUserInterfaceItemIdentifier("evora-camera-title")
        title.frame = NSRect(x: 10, y: 234, width: 216, height: 18)
        title.font = NSFont.systemFont(ofSize: 12, weight: .semibold)
        title.lineBreakMode = .byTruncatingTail
        view.addSubview(title)

        let streamIsReady = evoraCameraPreviewStreams[camera.id]?.isReady == true
        let initialState = streamIsReady
            ? "MILESIGHT · ŽIVĚ"
            : camera.online ? "MILESIGHT · PŘIPOJUJI" : "OFFLINE"
        let state = NSTextField(labelWithString: initialState)
        state.identifier = NSUserInterfaceItemIdentifier("evora-camera-state")
        state.frame = NSRect(x: 232, y: 234, width: 174, height: 18)
        state.alignment = .right
        state.font = NSFont.monospacedSystemFont(ofSize: 9, weight: .bold)
        state.textColor = streamIsReady ? .systemGreen : camera.online ? .systemBlue : .systemRed
        view.addSubview(state)

        let playerView = EvoraCameraPlayerView(frame: NSRect(x: 10, y: 8, width: 396, height: 223))
        playerView.identifier = NSUserInterfaceItemIdentifier("evora-camera-player")
        view.addSubview(playerView)

        let loading = NSTextField(labelWithString: camera.online ? "Připojuji úsporné plynulé video…" : "Kamera je offline")
        loading.identifier = NSUserInterfaceItemIdentifier("evora-camera-loading")
        loading.frame = NSRect(x: 28, y: 109, width: 360, height: 20)
        loading.alignment = .center
        loading.textColor = .secondaryLabelColor
        loading.font = NSFont.systemFont(ofSize: 11, weight: .medium)
        view.addSubview(loading)

        evoraCameraPreviewViews[camera.id] = playerView
        evoraCameraPreviewLabels[camera.id] = loading
        evoraCameraStateLabels[camera.id] = state
        if let snapshot = evoraCameraSnapshotCache[camera.id],
           evoraCameraPreviewStreams[camera.id]?.isReady != true {
            playerView.showSnapshot(snapshot)
        } else if camera.online {
            loadEvoraCameraSnapshot(camera.id)
        }
        if let stream = evoraCameraPreviewStreams[camera.id] {
            stream.attach(to: playerView)
            loading.isHidden = stream.isReady
            setEvoraCameraState(
                camera.id,
                title: stream.isReady ? "MILESIGHT · ŽIVĚ" : "MILESIGHT · PŘIPOJUJI",
                color: stream.isReady ? .systemGreen : .systemBlue
            )
        }
        item.view = view
        item.representedObject = ["modernEmbedded": "camera", "cameraId": camera.id] as NSDictionary
        item.isEnabled = false
        return item
    }

    func loadEvoraCameraSnapshot(_ cameraId: Int) {
        guard evoraCameraSnapshotCache[cameraId] == nil,
              !evoraCameraSnapshotRequests.contains(cameraId),
              let token = evoraToken(),
              let url = evoraEndpoint("/api/integrations/worklog/v1/cameras/\(cameraId)/snapshot")
        else { return }
        evoraCameraSnapshotRequests.insert(cameraId)
        var request = URLRequest(url: url)
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("image/jpeg", forHTTPHeaderField: "Accept")
        evoraSession.dataTask(with: request) { [weak self] data, response, _ in
            guard let self else { return }
            let status = (response as? HTTPURLResponse)?.statusCode ?? 0
            let snapshot = (200..<300).contains(status) ? data.flatMap(NSImage.init(data:)) : nil
            DispatchQueue.main.async {
                self.evoraCameraSnapshotRequests.remove(cameraId)
                guard let snapshot else { return }
                self.evoraCameraSnapshotCache[cameraId] = snapshot
                if self.evoraCameraPreviewStreams[cameraId]?.isReady != true {
                    self.evoraCameraPreviewViews[cameraId]?.showSnapshot(snapshot)
                }
            }
        }.resume()
    }

    func evoraGateControlsItem() -> NSMenuItem {
        let item = NSMenuItem()
        let view = NSView(frame: NSRect(x: 0, y: 0, width: 416, height: 66))
        view.identifier = NSUserInterfaceItemIdentifier("evora-gate-controls")
        let controls: [(symbol: String, label: String, command: String, color: NSColor, tag: Int, x: CGFloat)] = [
            ("door.garage.open", "Otevřít bránu", "open", .systemGreen, 1, 168),
            ("door.garage.closed", "Zavřít bránu", "close", .systemOrange, 2, 214),
        ]
        evoraGateControlButtons.removeAll()
        for control in controls {
            let button = NSButton(title: "", target: self, action: #selector(runEvoraGateCommand(_:)))
            button.frame = NSRect(x: control.x, y: 28, width: 36, height: 32)
            button.bezelStyle = .rounded
            button.image = sf(control.symbol, color: control.color)
            button.imagePosition = .imageOnly
            button.tag = control.tag
            button.identifier = NSUserInterfaceItemIdentifier("evora-gate-\(control.command)")
            button.isEnabled = evoraGate?.available == true
            button.toolTip = evoraGate?.available == true
                ? control.label
                : "\(control.label) · ovládání brány teď není dostupné"
            button.setAccessibilityLabel(control.label)
            view.addSubview(button)
            evoraGateControlButtons.append(button)
        }
        let feedback = NSTextField(labelWithString: evoraGate?.available == true
            ? "Brána připravena"
            : "Ovládání brány není dostupné")
        feedback.identifier = NSUserInterfaceItemIdentifier("evora-gate-feedback")
        feedback.frame = NSRect(x: 10, y: 5, width: 396, height: 17)
        feedback.alignment = .center
        feedback.font = NSFont.systemFont(ofSize: 10, weight: .medium)
        feedback.textColor = evoraGate?.available == true ? .systemGreen : .systemOrange
        feedback.lineBreakMode = .byTruncatingTail
        view.addSubview(feedback)
        evoraGateFeedbackField = feedback
        item.view = view
        item.representedObject = ["modernEmbedded": "gate"] as NSDictionary
        item.isEnabled = true
        return item
    }

    func setEvoraCameraState(_ cameraId: Int, title: String, color: NSColor) {
        evoraCameraStateLabels[cameraId]?.stringValue = title
        evoraCameraStateLabels[cameraId]?.textColor = color
    }

    func evoraCameraMenuColor() -> NSColor {
        .systemPurple
    }

    func evoraCameraDiagnosticItem(_ camera: EvoraCamera) -> NSMenuItem {
        let title = "\(camera.online ? "Online" : "Offline") · kanál \(camera.id) · \(camera.name)"
        let cameraItem = NSMenuItem(title: title, action: nil, keyEquivalent: "")
        applyMenuIcon(
            to: cameraItem,
            title: title,
            symbol: camera.online ? "video.fill" : "video.slash.fill",
            color: camera.online ? .systemGreen : .systemRed
        )
        let detail = NSMenu(title: "Diagnostika · \(camera.name)")
        detail.autoenablesItems = false
        detail.addItem(readOnlyItem("Kanál \(camera.id)", symbol: "number", color: evoraCameraMenuColor()))
        detail.addItem(readOnlyItem(
            camera.model.map { "Model · \($0)" } ?? "Model · zařízení údaj nevrátilo",
            symbol: "camera.fill",
            color: evoraCameraMenuColor()
        ))
        detail.addItem(readOnlyItem(
            camera.firmware.map { "Firmware · \($0)" } ?? "Firmware · zařízení údaj nevrátilo",
            symbol: "gearshape.2.fill",
            color: evoraCameraMenuColor()
        ))
        cameraItem.submenu = detail
        return cameraItem
    }

    func evoraCamerasMenuItem() -> NSMenuItem {
        let publishedCount = evoraCameras.count
        let parentTitle = "Milesight  (\(publishedCount))"
        let parent = NSMenuItem(
            title: parentTitle,
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(to: parent, title: parentTitle, image: milesightMenuLogo)
        let camerasMenu = NSMenu(title: "Milesight")
        camerasMenu.autoenablesItems = false
        if let nvr = evoraNvr, nvr.configured {
            let nvrOnline = nvr.connectionState == "online"
            camerasMenu.addItem(readOnlyItem(
                nvrOnline ? "NVR online" : nvr.connectionState == "auth_error" ? "NVR · přihlášení odmítnuto" : "NVR nedostupné",
                symbol: "externaldrive.connected.to.line.below",
                color: nvrOnline ? .systemGreen : .systemRed
            ))
            let details: [String] = [nvr.vendor, nvr.model, nvr.firmware].compactMap { value -> String? in
                guard let value, !value.isEmpty else { return nil }
                return value
            }
            camerasMenu.addItem(readOnlyItem(
                details.isEmpty ? "Model a firmware NVR API nevrátilo" : details.joined(separator: " · "),
                symbol: "info.circle",
                color: evoraCameraMenuColor()
            ))
            camerasMenu.addItem(readOnlyItem(
                "Kamery \(nvr.onlineCount)/\(nvr.onlineCount + nvr.offlineCount) online · \(nvr.offlineCount) offline",
                symbol: "camera.on.rectangle",
                color: nvr.offlineCount == 0 ? .systemGreen : .systemOrange
            ))
            camerasMenu.addItem(readOnlyItem(
                "Poslední kontrola · \(evoraRelativeCheckLabel(nvr.lastCheckedAt) ?? "dosud neověřeno")",
                symbol: "clock",
                color: evoraCameraMenuColor()
            ))
            camerasMenu.addItem(readOnlyItem(
                "Poslední úspěch · \(evoraRelativeCheckLabel(nvr.lastSuccessAt) ?? "dosud bez úspěchu")",
                symbol: "checkmark.circle",
                color: nvr.lastSuccessAt == nil ? .systemOrange : .systemGreen
            ))
            camerasMenu.addItem(readOnlyItem(
                nvr.lastError.map { "Poslední chyba · \($0)" } ?? "Poslední chyba · žádná",
                symbol: nvr.lastError == nil ? "checkmark.shield" : "exclamationmark.triangle.fill",
                color: nvr.lastError == nil ? .systemGreen : .systemRed
            ))
            camerasMenu.addItem(.separator())
        } else if evoraCameras.isEmpty {
            camerasMenu.addItem(readOnlyItem(
                "NVR zatím nemá načtené kamery",
                symbol: "video.slash.fill",
                color: evoraCameraMenuColor()
            ))
            camerasMenu.addItem(.separator())
            camerasMenu.addItem(linkItem(
                "Připojit NVR v Evora Smart Hubu",
                symbol: "rectangle.portrait.and.arrow.right",
                url: "\(evoraHubURL())?page=cameras"
            ))
        }
        for camera in evoraCameras.sorted(by: { $0.id < $1.id }) {
            let cameraItem = NSMenuItem(
                title: "\(camera.online ? "Online" : "Offline") · \(camera.name)",
                action: nil,
                keyEquivalent: ""
            )
            applyMenuIcon(
                to: cameraItem,
                title: "\(camera.online ? "Online" : "Offline") · \(camera.name)",
                symbol: "video.fill",
                color: camera.online ? .systemGreen : .systemRed
            )
            let previewMenu = NSMenu(title: "Kamera · \(camera.name)")
            previewMenu.autoenablesItems = false
            previewMenu.delegate = self
            previewMenu.addItem(evoraCameraPreviewItem(camera))
            previewMenu.addItem(.separator())
            previewMenu.addItem(evoraGateControlsItem())
            cameraItem.submenu = previewMenu
            camerasMenu.addItem(cameraItem)
            evoraCameraMenus[ObjectIdentifier(previewMenu)] = camera.id
        }
        parent.submenu = camerasMenu
        return parent
    }

    func startEvoraCameraPreview(_ cameraId: Int) {
        if let stream = evoraCameraPreviewStreams[cameraId],
           let playerView = evoraCameraPreviewViews[cameraId] {
            stream.attach(to: playerView)
            evoraCameraPreviewLabels[cameraId]?.isHidden = stream.isReady
            setEvoraCameraState(
                cameraId,
                title: stream.isReady ? "MILESIGHT · ŽIVĚ" : "MILESIGHT · PŘIPOJUJI",
                color: stream.isReady ? .systemGreen : .systemBlue
            )
            return
        }
        guard evoraCameras.first(where: { $0.id == cameraId })?.online == true,
              let token = evoraToken(),
              let url = evoraEndpoint("/api/integrations/worklog/v1/cameras/\(cameraId)/hls/index.m3u8?quality=preview"),
              let playerView = evoraCameraPreviewViews[cameraId]
        else {
            evoraCameraPreviewLabels[cameraId]?.stringValue = "Kamera je offline"
            evoraCameraPreviewLabels[cameraId]?.isHidden = false
            setEvoraCameraState(cameraId, title: "OFFLINE", color: .systemRed)
            return
        }
        evoraCameraPreviewLabels[cameraId]?.stringValue = "Připojuji úsporné plynulé video…"
        evoraCameraPreviewLabels[cameraId]?.isHidden = false
        setEvoraCameraState(cameraId, title: "MILESIGHT · PŘIPOJUJI", color: .systemBlue)
        let stream = EvoraCameraHLSPlayer(
            playerView: playerView,
            onConnecting: { [weak self] in
                guard let self else { return }
                self.evoraCameraPreviewLabels[cameraId]?.stringValue = "Připojuji úsporné plynulé video…"
                self.evoraCameraPreviewLabels[cameraId]?.isHidden = false
                self.setEvoraCameraState(cameraId, title: "MILESIGHT · PŘIPOJUJI", color: .systemBlue)
            },
            onReady: { [weak self] in
                self?.evoraCameraPreviewLabels[cameraId]?.isHidden = true
                self?.setEvoraCameraState(cameraId, title: "MILESIGHT · ŽIVĚ", color: .systemGreen)
            },
            onFailure: { [weak self] message in
                self?.evoraCameraPreviewLabels[cameraId]?.stringValue = message
                self?.evoraCameraPreviewLabels[cameraId]?.isHidden = false
                self?.setEvoraCameraState(cameraId, title: "MILESIGHT · BEZ VIDEA", color: .systemOrange)
            }
        )
        evoraCameraPreviewStreams[cameraId] = stream
        stream.start(url: url, token: token)
    }

    func scheduleEvoraCameraPreview(_ cameraId: Int) {
        guard evoraCameraPreviewStreams[cameraId] == nil,
              evoraCameraPreviewStartItems[cameraId] == nil
        else { return }
        let work = DispatchWorkItem { [weak self] in
            guard let self else { return }
            self.evoraCameraPreviewStartItems.removeValue(forKey: cameraId)
            self.startEvoraCameraPreview(cameraId)
        }
        evoraCameraPreviewStartItems[cameraId] = work
        // One prewarmed published stream only. Starting on the next AppKit turn
        // keeps menu tracking responsive without adding a visible delay.
        DispatchQueue.main.async(execute: work)
    }

    @objc func runEvoraGateCommand(_ sender: NSButton) {
        let command = sender.tag == 1 ? "open" : sender.tag == 2 ? "close" : ""
        guard !command.isEmpty, evoraGate?.available == true else { return }
        evoraGateControlButtons.forEach { $0.isEnabled = false }
        evoraGateFeedbackField?.stringValue = command == "open"
            ? "Odesílám příkaz k otevření…"
            : "Odesílám příkaz k zavření…"
        evoraGateFeedbackField?.textColor = .systemBlue
        evoraRequest(
            path: "/api/integrations/worklog/v1/gate/\(command)",
            method: "POST",
            body: nil
        ) { [weak self] (result: Result<EvoraGateCommandResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                self.evoraGateControlButtons.forEach {
                    $0.isEnabled = self.evoraGate?.available == true
                }
                switch result {
                case .success(let response) where response.ok && response.command == command:
                    self.evoraStatus = command == "open"
                        ? "Hub potvrdil příkaz k otevření brány"
                        : "Hub potvrdil příkaz k zavření brány"
                    self.evoraGateFeedbackField?.stringValue = command == "open"
                        ? "Hub potvrdil příkaz k otevření"
                        : "Hub potvrdil příkaz k zavření"
                    self.evoraGateFeedbackField?.textColor = .systemGreen
                case .success:
                    self.evoraGateFeedbackField?.stringValue = "Hub příkaz nepotvrdil"
                    self.evoraGateFeedbackField?.textColor = .systemRed
                case .failure:
                    self.evoraGateFeedbackField?.stringValue = "Příkaz se nepodařilo odeslat"
                    self.evoraGateFeedbackField?.textColor = .systemRed
                }
            }
        }
    }

    func stopEvoraCameraPreview(_ cameraId: Int) {
        evoraCameraPreviewStartItems.removeValue(forKey: cameraId)?.cancel()
        evoraCameraPreviewStreams.removeValue(forKey: cameraId)?.stop()
    }

    func stopAllEvoraCameraPreviews() {
        let streams = Array(evoraCameraPreviewStreams.values)
        let starts = Array(evoraCameraPreviewStartItems.values)
        evoraCameraPreviewStartItems.removeAll()
        evoraCameraPreviewStreams.removeAll()
        starts.forEach { $0.cancel() }
        streams.forEach { $0.stop() }
    }

    func seedEvoraMenuForSelfTest(servers: [EvoraMiniServer], cameras: [EvoraCamera] = [], status: String) {
        let mode = CommandLine.arguments.dropFirst().first
        guard mode == "--self-test-menu-structure"
            || mode == "--render-modern-menu-preview"
            || mode == "--render-classic-miniserver-preview"
            || mode == "--render-classic-compact-preview"
            || mode == "--render-classic-menu-preview"
        else { return }
        evoraServers = servers
        evoraCameras = cameras
        evoraStatus = status
    }

    func seedEvoraContextForPreview() {
        let mode = CommandLine.arguments.dropFirst().first
        guard mode == "--render-modern-menu-preview"
            || mode == "--render-classic-miniserver-preview"
            || mode == "--render-classic-compact-preview"
            || mode == "--render-classic-menu-preview"
        else { return }
        evoraCapabilities = EvoraFleetResponse.Capabilities(
            miniserverWebInterface: true,
            miniserverPasswordCopy: true
        )
        evoraUser = EvoraFleetResponse.User(
            id: "preview-user",
            email: "michal@evorasmart.cz",
            displayName: "Michal Schöniger",
            role: "admin",
            hasAvatar: false,
            avatarUpdatedAt: nil
        )
        evoraLauncherAgent = EvoraLauncherAgent(
            name: "Windows Launcher",
            available: true,
            helperVersion: "3.0.0.12",
            requiredHelperVersion: "3.0.0.12",
            latestHelperVersion: "3.0.0.12",
            updateRequired: false,
            updateAvailable: false
        )
        evoraHubVersion = "3.0.34"
        evoraCredentialsLoaded = true
        let now = Date()
        intranetSnapshot = IntranetSnapshot(
            dataState: "current",
            fetchedAt: now.addingTimeInterval(-2).timeIntervalSince1970,
            summaryFetchedAt: now.timeIntervalSince1970,
            rosterFetchedAt: now.timeIntervalSince1970,
            currentState: "in_building",
            currentSince: now.addingTimeInterval(-(8 * 3600 + 58 * 60)).timeIntervalSince1970,
            hrProfileId: "preview-profile",
            todayWorkedSeconds: 8 * 3600 + 58 * 60,
            lastArrival: now.addingTimeInterval(-(8 * 3600 + 58 * 60)).timeIntervalSince1970,
            lastDeparture: nil,
            greeting: "Dobrý den",
            workloadHours: 8,
            cards: [
                "worked_month": "150 h 4 m",
                "balance_month": "+14 h 4 m",
                "overtime_ordered": "—",
                "vacation_remaining": "72 h",
                "sickday_remaining": "16 h",
            ],
            people: [],
            leavesFetchedAt: now.timeIntervalSince1970,
            leaves: [],
            notificationsUnread: 0,
            historyFetchedAt: now.timeIntervalSince1970,
            historyEvents: [],
            errorCode: nil,
            errorMessage: nil
        )
        rebuildIntranetMenu()
    }

    func renderModernMenuPreview(rootTitle: String, query: String, path: String) -> Bool {
        let controller = ModernMenuPanelController(owner: self)
        return controller.renderPreview(
            rootTitle: rootTitle,
            query: query,
            to: URL(fileURLWithPath: path)
        )
    }

    func evoraCameraPreviewMenuForSelfTest() -> NSMenu? {
        guard CommandLine.arguments.dropFirst().first == "--render-classic-camera-preview" else {
            return nil
        }
        let camera = EvoraCamera(
            id: 7,
            name: "Parkoviště a brána",
            online: true,
            model: "Milesight",
            firmware: nil
        )
        evoraCameras = [camera]
        evoraGate = EvoraGateStatus(
            configured: true,
            available: true,
            project: "Brána"
        )
        let preview = NSMenu(title: "Parkoviště a brána")
        preview.autoenablesItems = false
        preview.addItem(evoraCameraPreviewItem(camera))
        preview.addItem(.separator())
        preview.addItem(evoraGateControlsItem())
        return preview
    }

    func renderClassicMiniserverPreview(_ server: EvoraMiniServer, path: String) -> Bool {
        let items = evoraClassicMiniserverDetailItems(server)
        let views = items.compactMap(\.view)
        let totalHeight = views.reduce(CGFloat(20)) { $0 + $1.frame.height + 6 }
        let canvas = NSImage(size: NSSize(width: 440, height: totalHeight))
        canvas.lockFocus()
        NSColor.windowBackgroundColor.setFill()
        NSBezierPath(rect: NSRect(x: 0, y: 0, width: 440, height: totalHeight)).fill()
        var top = totalHeight - 10
        for view in views {
            view.frame.origin = .zero
            view.layoutSubtreeIfNeeded()
            view.displayIfNeeded()
            guard let bitmap = view.bitmapImageRepForCachingDisplay(in: view.bounds) else {
                canvas.unlockFocus()
                return false
            }
            view.cacheDisplay(in: view.bounds, to: bitmap)
            let rendered = NSImage(size: view.bounds.size)
            rendered.addRepresentation(bitmap)
            top -= view.frame.height
            rendered.draw(
                in: NSRect(x: (440 - view.frame.width) / 2, y: top, width: view.frame.width, height: view.frame.height),
                from: .zero,
                operation: .sourceOver,
                fraction: 1
            )
            top -= 6
        }
        canvas.unlockFocus()
        guard let tiff = canvas.tiffRepresentation,
              let bitmap = NSBitmapImageRep(data: tiff),
              let png = bitmap.representation(using: .png, properties: [:])
        else { return false }
        do {
            try png.write(to: URL(fileURLWithPath: path), options: .atomic)
            return true
        } catch {
            return false
        }
    }

    func renderClassicMenuPreview(route: [String], path: String) -> Bool {
        guard let navigator = classicMenuNavigator,
              navigator.navigateForSelfTest(route)
        else { return false }
        navigator.refreshCurrentPage(preserveScroll: false)
        navigator.layoutSubtreeIfNeeded()
        navigator.displayIfNeeded()
        guard let bitmap = navigator.bitmapImageRepForCachingDisplay(in: navigator.bounds) else {
            return false
        }
        navigator.cacheDisplay(in: navigator.bounds, to: bitmap)
        guard let png = bitmap.representation(using: .png, properties: [:]) else {
            return false
        }
        do {
            try png.write(to: URL(fileURLWithPath: path), options: .atomic)
            return true
        } catch {
            return false
        }
    }

    func renderClassicTransientMenuPreview(
        _ menu: NSMenu,
        title: String,
        path: String
    ) -> Bool {
        guard let navigator = classicMenuNavigator else { return false }
        navigator.resetToRoot()
        navigator.showTransientPage(menu, title: title)
        navigator.refreshCurrentPage(preserveScroll: false)
        navigator.layoutSubtreeIfNeeded()
        navigator.displayIfNeeded()
        guard let bitmap = navigator.bitmapImageRepForCachingDisplay(in: navigator.bounds) else {
            return false
        }
        navigator.cacheDisplay(in: navigator.bounds, to: bitmap)
        guard let png = bitmap.representation(using: .png, properties: [:]) else {
            return false
        }
        do {
            try png.write(to: URL(fileURLWithPath: path), options: .atomic)
            return true
        } catch {
            return false
        }
    }

    func seedClassicNavigatorForSelfTest(_ route: [String]) -> (Bool, [String], [String]) {
        guard CommandLine.arguments.dropFirst().first == "--self-test-menu-structure",
              let navigator = classicMenuNavigator
        else { return (false, [], []) }
        let navigated = navigator.navigateForSelfTest(route)
        return (navigated, navigator.pathTitles, navigator.visibleLabelsForSelfTest())
    }

    func seedEvoraHubVersionForSelfTest(_ version: String) -> String {
        guard CommandLine.arguments.dropFirst().first == "--self-test-menu-structure" else { return "" }
        evoraHubVersion = version
        updateBrandedHeaderSubtitle()
        // Verze zůstává součástí diagnostiky, i když už se na kořenové
        // stránce na přání uživatele vizuálně nezobrazuje.
        return "Menu \(evoraMenuVersion) · Hub \(version)"
    }

    func searchDetailLabels(_ items: [NSMenuItem]) -> [String] {
        items.flatMap { item -> [String] in
            if let view = item.view {
                var labels = [String]()
                func collect(_ candidate: NSView) {
                    if let field = candidate as? NSTextField, !field.stringValue.isEmpty {
                        labels.append(field.stringValue)
                    } else if let button = candidate as? NSButton, !button.title.isEmpty {
                        labels.append(button.title)
                    }
                    candidate.subviews.forEach(collect)
                }
                collect(view)
                return labels
            }
            let attributed = item.attributedTitle?.string ?? ""
            let value = attributed.isEmpty ? item.title : attributed
            return value.isEmpty ? [] : [value]
        }
    }

    func seedEvoraSearchForSelfTest(_ query: String) -> (foldersVisible: Int, serverTitles: [String], uniqueDetailLabels: [String]) {
        guard CommandLine.arguments.dropFirst().first == "--self-test-menu-structure" else { return (0, [], []) }
        evoraSearchQuery = query
        evoraSearchField?.stringValue = query
        applyEvoraSearchFilter()
        let foldersVisible = evoraFolderMenuItems.filter { !$0.item.isHidden }.count
        let serverTitles = evoraFlatSearchMenuItems
            .filter { !$0.item.isHidden }
            .map { entry in
                let attributed = entry.item.attributedTitle?.string ?? ""
                return attributed.isEmpty ? entry.item.title : attributed
            }
        return (foldersVisible, serverTitles, searchDetailLabels(evoraUniqueSearchItems))
    }

    func seedMainMenuSearchForSelfTest(_ query: String) -> (systemsVisible: Bool, serverTitles: [String], uniqueDetailLabels: [String]) {
        guard CommandLine.arguments.dropFirst().first == "--self-test-menu-structure" else { return (false, [], []) }
        mainMenuSearchQuery = query
        mainMenuSearchField?.stringValue = query
        applyMainMenuSearchFilter()
        let systemsVisible = menu.items.contains { item in
            let raw = item.attributedTitle?.string.isEmpty == false ? item.attributedTitle?.string ?? item.title : item.title
            return raw.replacingOccurrences(of: "\u{fffc}", with: "")
                .trimmingCharacters(in: .whitespacesAndNewlines) == "Systémy"
                && !item.isHidden
        }
        let serverTitles = mainMenuEvoraSearchItems
            .filter { !$0.item.isHidden }
            .map { entry in
                let attributed = entry.item.attributedTitle?.string ?? ""
                return attributed.isEmpty ? entry.item.title : attributed
            }
        return (systemsVisible, serverTitles, searchDetailLabels(mainMenuEvoraUniqueSearchItems))
    }

    func seedRapidClassicSearchForSelfTest(
        _ queries: [String],
        nested: Bool
    ) -> (query: String, parentVisible: Bool, uniqueDetailLabels: [String]) {
        guard CommandLine.arguments.dropFirst().first == "--self-test-menu-structure" else { return ("", false, []) }
        guard let field = nested ? evoraSearchField : mainMenuSearchField else { return ("", false, []) }
        for query in queries {
            field.stringValue = query
            controlTextDidChange(Notification(name: NSControl.textDidChangeNotification, object: field))
        }
        RunLoop.current.run(until: Date().addingTimeInterval(0.45))
        if nested {
            return (
                evoraSearchQuery,
                evoraFolderMenuItems.contains { !$0.item.isHidden },
                searchDetailLabels(evoraUniqueSearchItems)
            )
        }
        let systemsVisible = menu.items.contains { item in
            modernPanelVisibleTitle(item) == "Systémy" && !item.isHidden
        }
        return (
            mainMenuSearchQuery,
            systemsVisible,
            searchDetailLabels(mainMenuEvoraUniqueSearchItems)
        )
    }

    func seedIncrementalClassicSearchTypingForSelfTest(_ text: String) -> (value: String, selection: NSRange) {
        guard CommandLine.arguments.dropFirst().first == "--self-test-menu-structure",
              let navigator = classicMenuNavigator,
              let field = mainMenuSearchField
        else { return ("", NSRange(location: NSNotFound, length: 0)) }

        let testWindow = NSWindow(
            contentRect: NSRect(origin: .zero, size: navigator.frame.size),
            styleMask: [.borderless],
            backing: .buffered,
            defer: false
        )
        testWindow.isReleasedWhenClosed = false
        testWindow.contentView = navigator
        testWindow.makeKeyAndOrderFront(nil)
        navigator.resetToRoot()
        field.stringValue = ""
        field.ensureKeyboardFocus(selection: NSRange(location: 0, length: 0))
        RunLoop.current.run(until: Date().addingTimeInterval(0.05))

        for character in text {
            guard let editor = field.currentEditor() as? NSTextView else {
                testWindow.orderOut(nil)
                return (field.stringValue, NSRange(location: NSNotFound, length: 0))
            }
            editor.insertText(String(character), replacementRange: editor.selectedRange)
            RunLoop.current.run(until: Date().addingTimeInterval(0.09))
        }

        let selection = field.currentEditor()?.selectedRange
            ?? NSRange(location: NSNotFound, length: 0)
        let value = field.stringValue
        mainMenuSearchWorkItem?.cancel()
        mainMenuSearchRevision += 1
        field.stringValue = ""
        mainMenuSearchQuery = ""
        applyMainMenuSearchFilter()
        navigator.modelDidChange()
        testWindow.orderOut(nil)
        return (value, selection)
    }

    func rebuildMainMenuEvoraSearchItems() {
        removeMainMenuEvoraUniqueSearchItems()
        replaceMainMenuEvoraSearchItems(with: [])
    }

    func populateEvoraFolderMenu(_ folderMenu: NSMenu) {
        let identifier = ObjectIdentifier(folderMenu)
        guard let servers = evoraLazyFolderServers[identifier], folderMenu.items.isEmpty else { return }
        for server in servers {
            folderMenu.addItem(evoraMiniserverMenuItem(server))
        }
    }

    func rebuildEvoraMenu() {
        guard evoraMenu != nil, evoraMiniserversMenu != nil else { return }
        if evoraMenuTracking || !mainMenuSearchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            evoraRebuildDeferred = true
            return
        }
        evoraRebuildDeferred = false
        let activeCameraIds = Set(evoraCameras.filter(\.online).map(\.id))
        for cameraId in Array(evoraCameraPreviewStreams.keys) where !activeCameraIds.contains(cameraId) {
            stopEvoraCameraPreview(cameraId)
        }
        evoraSearchWorkItem?.cancel()
        evoraSearchRevision += 1
        defer {
            if !mainMenuSearchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                applyMainMenuSearchFilter()
            }
            classicMenuNavigator?.modelDidChange()
        }
        evoraMenu.removeAllItems()
        evoraMiniserversMenu.removeAllItems()
        evoraUniqueSearchItems.removeAll()
        evoraFolderMenuItems.removeAll()
        evoraLazyFolderServers.removeAll()
        evoraTicketsSubmenu = nil
        evoraFlatSearchMenuItems.removeAll()
        evoraCameraMenus.removeAll()
        evoraCameraPreviewViews.removeAll()
        evoraCameraPreviewLabels.removeAll()
        evoraCameraStateLabels.removeAll()
        evoraGateControlButtons.removeAll()
        evoraGateFeedbackField = nil
        evoraNoResultsItem = nil
        rebuildMainMenuEvoraSearchItems()

        addHomeAssistantMenu(to: evoraMenu)
        evoraMenu.addItem(.separator())
        evoraMenu.addItem(evoraCamerasMenuItem())
        if let published = evoraCameras.first(where: { $0.id == 7 && $0.online }) {
            scheduleEvoraCameraPreview(published.id)
        }
        let normalizedEvoraStatus = evoraStatus.lowercased()
        let evoraStatusColor: NSColor = normalizedEvoraStatus.contains("chyba")
            || normalizedEvoraStatus.contains("nepřipojeno")
            || normalizedEvoraStatus.contains("offline")
            ? .systemRed
            : normalizedEvoraStatus.contains("načítám") || normalizedEvoraStatus.contains("aktualiz")
            ? .systemOrange
            : .systemGreen
        evoraStatusItem = item(
            evoraStatus,
            symbol: "network",
            action: #selector(refreshEvoraMenu),
            color: evoraStatusColor
        )
        evoraStatusItem.toolTip = "Kliknutím znovu načtete stav Evora Smart Hubu."
        evoraMiniserversMenu.addItem(evoraStatusItem)

        let miniserversParent = NSMenuItem(
            title: "Miniservery  (\(evoraServers.count))",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(
            to: miniserversParent,
            title: "Miniservery  (\(evoraServers.count))",
            symbol: "server.rack",
            color: evoraServers.isEmpty ? .systemOrange : .systemGreen
        )
        miniserversParent.toolTip = "Rychlé hledání a přímý detail všech Miniserverů."
        miniserversParent.submenu = evoraMiniserversMenu
        evoraMenu.addItem(miniserversParent)

        evoraMenu.addItem(evoraTicketsMenuItem())
        evoraMenu.addItem(.separator())
        evoraMenu.addItem(
            linkItem(
                "Otevřít Evora Smart Hub",
                symbol: "network",
                url: evoraHubURL()
            )
        )
        evoraMenu.addItem(
            item(
                "Obnovit systémy",
                symbol: "arrow.clockwise",
                action: #selector(refreshEvoraMenu)
            )
        )
        evoraMenu.addItem(
            item(
                "Nastavit připojení…",
                symbol: "key",
                action: #selector(configureEvoraConnection)
            )
        )

        evoraMiniserversMenu.addItem(.separator())
        let searchItem = NSMenuItem()
        let searchContainer = NSView(frame: NSRect(x: 0, y: 0, width: 420, height: 42))
        let searchField = MenuSearchField(frame: NSRect(x: 12, y: 7, width: 396, height: 28))
        searchField.placeholderString = "Hledat Miniserver…"
        searchField.stringValue = evoraSearchQuery
        // Stejně jako globální hledání necháváme průběžné změny výhradně na
        // delegátovi. Action po každém znaku by překreslila stránku a ztratila
        // field editor ještě před dopsáním názvu.
        searchField.sendsSearchStringImmediately = false
        searchField.sendsWholeSearchString = true
        searchField.delegate = self
        searchField.target = self
        searchField.action = #selector(searchFieldAction(_:))
        searchContainer.addSubview(searchField)
        searchItem.view = searchContainer
        evoraSearchField = searchField
        evoraMiniserversMenu.addItem(searchItem)

        guard !evoraServers.isEmpty else {
            evoraMiniserversMenu.addItem(.separator())
            let empty = readOnlyItem(
                !evoraCredentialsLoaded
                    ? "Načítám zabezpečené připojení…"
                    : evoraToken() == nil
                    ? "Vložte osobní token z Nastavení Hubu."
                    : "Žádné Miniservery nejsou dostupné.",
                symbol: evoraToken() == nil ? "key" : "server.rack",
                color: evoraToken() == nil ? .systemOrange : .labelColor
            )
            evoraMiniserversMenu.addItem(empty)
            return
        }

        evoraMiniserversMenu.addItem(.separator())
        let noResultsItem = readOnlyItem(
            "Žádný Miniserver neodpovídá hledání",
            symbol: "magnifyingglass",
            color: .systemOrange
        )
        noResultsItem.isHidden = true
        evoraNoResultsItem = noResultsItem
        evoraMiniserversMenu.addItem(noResultsItem)
        let grouped = Dictionary(grouping: evoraServers, by: { $0.folderName })
        for folder in grouped.keys.sorted(by: { $0.localizedCaseInsensitiveCompare($1) == .orderedAscending }) {
            let servers = (grouped[folder] ?? []).sorted {
                $0.project.localizedCaseInsensitiveCompare($1.project) == .orderedAscending
            }
            let folderColor = menuColor(hex: servers.first?.folderColor, fallback: .systemGreen)
            let folderItem = NSMenuItem(
                title: "\(folder)  (\(servers.count))",
                action: nil,
                keyEquivalent: ""
            )
            applyMenuIcon(to: folderItem, title: "\(folder)  (\(servers.count))", symbol: "folder.fill", color: folderColor)
            let folderMenu = NSMenu(title: folder)
            folderMenu.autoenablesItems = false
            folderMenu.delegate = self
            folderItem.submenu = folderMenu
            evoraMiniserversMenu.addItem(folderItem)
            evoraLazyFolderServers[ObjectIdentifier(folderMenu)] = servers
            evoraFolderMenuItems.append((item: folderItem, folder: folder, color: folderColor, servers: servers))
        }
        applyEvoraSearchFilter()
    }

    @objc func refreshEvoraMenu() {
        guard !evoraRefreshInFlight else { return }
        guard evoraCredentialsLoaded else {
            evoraStatus = "Evora Smart Hub: načítám připojení…"
            rebuildEvoraMenu()
            return
        }
        guard evoraToken() != nil else {
            evoraServers = []
            evoraCameras = []
            evoraNvr = nil
            evoraGate = nil
            evoraTasks = []
            evoraLauncherAgent = nil
            evoraCapabilities = nil
            evoraUser = nil
            evoraProfileImage = nil
            evoraProfileImageVersion = ""
            evoraHubVersion = nil
            updateBrandedHeaderSubtitle()
            evoraStatus = "Evora Smart Hub: nepřipojeno"
            rebuildTasksNotesMenu()
            rebuildEvoraMenu()
            return
        }
        let hasCachedFleet = !evoraServers.isEmpty
        evoraRefreshInFlight = true
        if !hasCachedFleet {
            evoraStatus = "Evora Smart Hub: načítám…"
            rebuildEvoraMenu()
        }
        if evoraTickets.isEmpty {
            loadEvoraTickets(forcePortalRefresh: false)
        }
        evoraRequest(
            path: "/api/integrations/worklog/v1/miniservers"
        ) { [weak self] (result: Result<EvoraFleetResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                self.evoraRefreshInFlight = false
                self.evoraLastRefresh = Date()
                switch result {
                case .success(let response):
                    self.evoraServers = response.items
                    self.evoraCameras = response.cameras ?? []
                    self.evoraNvr = response.nvr
                    self.evoraGate = response.gate
                    self.evoraTasks = response.tasks ?? []
                    self.evoraLauncherAgent = response.launcherAgent
                    self.evoraCapabilities = response.capabilities
                    self.evoraUser = response.user
                    self.loadEvoraProfileImageIfNeeded(response.user)
                    self.evoraHubVersion = response.appVersion
                    self.updateBrandedHeaderSubtitle()
                    let launcher: String
                    if response.launcherAgent?.updateRequired == true {
                        launcher = "Windows Launcher vyžaduje aktualizaci"
                    } else if response.launcherAgent?.available == true {
                        launcher = response.launcherAgent?.updateAvailable == true
                            ? "Windows Launcher online · aktualizace dostupná"
                            : "Windows Launcher online"
                    } else {
                        launcher = "Windows Launcher offline"
                    }
                    self.evoraStatus = "\(response.items.count) Miniserverů · \(launcher)"
                case .failure(let error):
                    if self.evoraServers.isEmpty {
                        self.evoraCameras = []
                        self.evoraNvr = nil
                        self.evoraGate = nil
                        self.evoraTasks = []
                        self.evoraLauncherAgent = nil
                        self.evoraCapabilities = nil
                        self.evoraUser = nil
                        self.evoraProfileImage = nil
                        self.evoraProfileImageVersion = ""
                        self.evoraHubVersion = nil
                        self.updateBrandedHeaderSubtitle()
                        self.evoraStatus = "Chyba: \(error.localizedDescription)"
                    } else {
                        self.evoraStatus = "\(self.evoraServers.count) Miniserverů · poslední stav uložen"
                    }
                }
                self.rebuildTasksNotesMenu()
                self.rebuildEvoraMenu()
            }
        }
    }

    @objc func refreshEvoraTickets() {
        loadEvoraTickets(forcePortalRefresh: true)
    }

    func loadEvoraTickets(forcePortalRefresh: Bool) {
        guard !evoraTicketsRefreshInFlight else { return }
        guard evoraToken() != nil else {
            evoraTickets = []
            evoraTicketsStatus = "Tickety: nepřipojeno"
            rebuildEvoraMenu()
            return
        }
        evoraTicketsRefreshInFlight = true
        evoraTicketsStatus = "Tickety: načítám…"
        rebuildEvoraMenu()
        evoraRequest(
            path: "/api/integrations/worklog/v1/portal-tickets\(forcePortalRefresh ? "?refresh=1" : "")"
        ) { [weak self] (result: Result<EvoraPortalTicketListResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                self.evoraTicketsRefreshInFlight = false
                switch result {
                case .success(let response):
                    self.evoraTickets = response.items
                    let open = response.items.filter { !self.evoraPortalTicketIsClosed($0.status) }.count
                    self.evoraTicketsStatus = "\(response.items.count) ticketů · \(open) otevřených"
                case .failure(let error):
                    self.evoraTicketsStatus = self.evoraTickets.isEmpty
                        ? "Tickety: \(error.localizedDescription)"
                        : "\(self.evoraTickets.count) ticketů · aktualizace selhala"
                }
                self.rebuildEvoraMenu()
            }
        }
    }

    func menuWillOpen(_ menu: NSMenu) {
        if menu === classicPresentationMenu {
            mainMenuSearchQuery = mainMenuSearchField?.stringValue ?? ""
            applyMainMenuSearchFilter()
            classicMenuNavigator?.resetToRoot()
            scheduleClassicMenuPositioning()
            classicMenuNavigator?.playOpeningAnimation()
        } else if menu === self.menu {
            mainMenuSearchQuery = mainMenuSearchField?.stringValue ?? ""
            applyMainMenuSearchFilter()
            DispatchQueue.main.async { [weak self] in self?.mainMenuSearchField?.ensureKeyboardFocus() }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) { [weak self] in
                self?.mainMenuSearchField?.ensureKeyboardFocus()
            }
        } else if menu === evoraTicketsSubmenu {
            populateEvoraTicketsMenu(menu)
        } else if evoraLazyFolderServers[ObjectIdentifier(menu)] != nil {
            populateEvoraFolderMenu(menu)
        } else if let cameraId = evoraCameraMenus[ObjectIdentifier(menu)] {
            scheduleEvoraCameraPreview(cameraId)
        } else if menu === evoraMenu {
            evoraMenuTracking = true
            if evoraServers.isEmpty && !evoraRefreshInFlight {
                refreshEvoraMenu()
            } else if evoraTickets.isEmpty {
                loadEvoraTickets(forcePortalRefresh: false)
            }
        } else if menu === evoraMiniserversMenu {
            evoraMenuTracking = true
            DispatchQueue.main.async { [weak self] in self?.evoraSearchField?.ensureKeyboardFocus() }
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.08) { [weak self] in
                self?.evoraSearchField?.ensureKeyboardFocus()
            }
            if evoraServers.isEmpty && !evoraRefreshInFlight {
                refreshEvoraMenu()
            }
        } else if menu === intranetMenu {
            if Date().timeIntervalSince1970 - intranetSnapshot.fetchedAt > 60 {
                refreshIntranet(forceAll: false)
            }
        }
    }

    func menuDidClose(_ menu: NSMenu) {
        if menu === classicPresentationMenu || menu === self.menu {
            releaseClassicMenuPositionLock()
            mainMenuSearchWorkItem?.cancel()
            mainMenuSearchRevision += 1
            mainMenuSearchQuery = ""
            mainMenuSearchField?.stringValue = ""
            applyMainMenuSearchFilter()
            evoraSearchWorkItem?.cancel()
            evoraSearchRevision += 1
            evoraSearchQuery = ""
            evoraSearchField?.stringValue = ""
            applyEvoraSearchFilter()
            evoraMenuTracking = false
            if evoraRebuildDeferred,
               mainMenuSearchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                DispatchQueue.main.async { [weak self] in
                    guard let self, !self.evoraMenuTracking else { return }
                    self.rebuildEvoraMenu()
                }
            }
        } else if evoraCameraMenus[ObjectIdentifier(menu)] != nil {
            // Publikovaný kanál zůstává předehřátý, aby příští otevření
            // nezačínalo znovu dlouhým navazováním HLS.
            return
        } else if menu === evoraMenu {
            evoraMenuTracking = false
            if evoraRebuildDeferred,
               mainMenuSearchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                DispatchQueue.main.async { [weak self] in
                    guard let self, !self.evoraMenuTracking else { return }
                    self.rebuildEvoraMenu()
                }
            }
        }
    }

    // MARK: - Icons

    func sf(_ name: String, color: NSColor? = nil) -> NSImage? {
        let baseConfig = NSImage.SymbolConfiguration(
            pointSize: 13,
            weight: .medium
        )
        let config = color.map {
            baseConfig.applying(NSImage.SymbolConfiguration(paletteColors: [$0]))
        } ?? baseConfig

        let img = NSImage(
            systemSymbolName: name,
            accessibilityDescription: nil
        )?.withSymbolConfiguration(config)

        img?.isTemplate = color == nil

        return img
    }

    func applyMenuIcon(
        to item: NSMenuItem,
        title: String,
        image: NSImage?,
        textColor: NSColor? = nil
    ) {
        item.title = title
        guard let image else { return }

        let icon = (image.copy() as? NSImage) ?? image
        icon.size = NSSize(width: 16, height: 16)

        let attachment = NSTextAttachment()
        attachment.image = icon
        attachment.bounds = NSRect(x: 0, y: -1.5, width: 16, height: 16)

        let decorated = NSMutableAttributedString(
            attributedString: NSAttributedString(attachment: attachment)
        )
        decorated.append(NSAttributedString(string: "  "))
        var attributes: [NSAttributedString.Key: Any] = [.font: NSFont.menuFont(ofSize: 0)]
        if let textColor { attributes[.foregroundColor] = textColor }
        decorated.append(NSAttributedString(string: title, attributes: attributes))

        // Some macOS versions suppress NSMenuItem.image in status-bar menus.
        // Keeping the SF Symbol in the title makes the icon deterministic while
        // preserving native highlighting, keyboard navigation and submenus.
        item.image = nil
        item.attributedTitle = decorated
    }

    func applyMenuIcon(
        to item: NSMenuItem,
        title: String,
        symbol: String?,
        color: NSColor? = nil
    ) {
        let resolvedColor = color ?? semanticMenuColor(for: symbol)
        applyMenuIcon(
            to: item,
            title: title,
            image: symbol.flatMap { sf($0, color: resolvedColor) },
            textColor: resolvedColor
        )
    }

    func evoraSmartHubIcon(size: NSSize) -> NSImage {
        let image = NSImage(size: size)
        image.lockFocus()
        let clip = NSBezierPath(
            roundedRect: NSRect(origin: .zero, size: size),
            xRadius: size.width * 0.22,
            yRadius: size.height * 0.22
        )
        clip.addClip()
        evoraSmartHubLogo.draw(
            in: NSRect(origin: .zero, size: size),
            from: .zero,
            operation: .sourceOver,
            fraction: 1,
            respectFlipped: true,
            hints: [.interpolation: NSImageInterpolation.high]
        )
        image.unlockFocus()
        image.isTemplate = false
        return image
    }

    func intranetMenuLogo(size: NSSize) -> NSImage {
        let image = NSImage(size: size)
        image.lockFocus()
        NSColor(calibratedRed: 0.43, green: 0.76, blue: 0.12, alpha: 1).setFill()
        NSBezierPath(
            roundedRect: NSRect(origin: .zero, size: size),
            xRadius: size.width * 0.22,
            yRadius: size.height * 0.22
        ).fill()
        let text = "e" as NSString
        let font = NSFont.systemFont(ofSize: size.height * 0.72, weight: .bold)
        let attributes: [NSAttributedString.Key: Any] = [
            .font: font,
            .foregroundColor: NSColor.white
        ]
        let textSize = text.size(withAttributes: attributes)
        text.draw(
            at: NSPoint(
                x: (size.width - textSize.width) / 2,
                y: (size.height - textSize.height) / 2 + size.height * 0.03
            ),
            withAttributes: attributes
        )
        image.unlockFocus()
        image.isTemplate = false
        return image
    }

    func configureStatusButton(_ button: NSStatusBarButton) {
        button.image = evoraSmartHubIcon(size: NSSize(width: 18, height: 18))
        button.imagePosition = button.title.isEmpty ? .imageOnly : .imageLeading
        button.imageScaling = .scaleProportionallyDown
    }

    func modernPanelBrandImage(size: NSSize) -> NSImage {
        evoraSmartHubIcon(size: size)
    }

    func modernPanelVersionText() -> String {
        let hub = evoraHubVersion.map { "Hub \($0)" } ?? "Hub nepřipojen"
        return "Menu \(evoraMenuVersion) · \(hub)"
    }

    func modernPanelProfileName() -> String {
        if bundledProfilePhoto != nil {
            return "Bc. Michal Schöniger"
        }
        let displayName = evoraUser?.displayName?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        if !displayName.isEmpty { return displayName }
        let email = evoraUser?.email.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
        if !email.isEmpty { return email }
        return "Evora Smart Hub"
    }

    func modernPanelProfileDetail() -> String {
        let role = evoraUser?.role == "admin" ? "Správce" : "Technik"
        return "\(role) · \(intranetLiveStatusTitle())"
    }

    func modernPanelProfileMetrics() -> String {
        let worked = intranetSnapshot.cards["worked_month"] ?? "—"
        let balance = intranetSnapshot.cards["balance_month"] ?? "—"
        return "Měsíc \(worked)  ·  saldo \(balance)"
    }

    func modernPanelProfileColor() -> NSColor {
        if intranetSnapshot.dataState != "current" && intranetSnapshot.dataState != "stale" {
            return intranetSnapshot.dataState == "loading" ? .systemBlue : .systemRed
        }
        if intranetSnapshot.dataState == "stale" { return .systemOrange }
        switch intranetSnapshot.currentState {
        case "in_building", "home_office", "offsite": return .systemGreen
        case "on_break", "doctor": return .systemOrange
        case "vacation", "sick": return .systemBlue
        default: return .secondaryLabelColor
        }
    }

    func modernPanelProfileImage(size: NSSize) -> NSImage {
        if let bundledProfilePhoto {
            let sourceSize = bundledProfilePhoto.size
            let cropSide = min(sourceSize.width, sourceSize.height) * 0.58
            let crop = NSRect(
                x: (sourceSize.width - cropSide) / 2,
                y: max(0, sourceSize.height * 0.38),
                width: cropSide,
                height: cropSide
            )
            let output = NSImage(size: size)
            output.lockFocus()
            bundledProfilePhoto.draw(
                in: NSRect(origin: .zero, size: size),
                from: crop,
                operation: .sourceOver,
                fraction: 1,
                respectFlipped: true,
                hints: [.interpolation: NSImageInterpolation.high]
            )
            output.unlockFocus()
            output.isTemplate = false
            return output
        }
        if let evoraProfileImage {
            let output = NSImage(size: size)
            output.lockFocus()
            evoraProfileImage.draw(
                in: NSRect(origin: .zero, size: size),
                from: .zero,
                operation: .sourceOver,
                fraction: 1,
                respectFlipped: true,
                hints: [.interpolation: NSImageInterpolation.high]
            )
            output.unlockFocus()
            output.isTemplate = false
            return output
        }
        let name = modernPanelProfileName()
        let initials = name
            .split(whereSeparator: { $0.isWhitespace || $0 == "." || $0 == "@" })
            .prefix(2)
            .compactMap(\.first)
            .map { String($0).uppercased() }
            .joined()
        let output = NSImage(size: size)
        output.lockFocus()
        NSColor(calibratedRed: 0.12, green: 0.57, blue: 0.19, alpha: 1).setFill()
        NSBezierPath(ovalIn: NSRect(origin: .zero, size: size)).fill()
        let text = (initials.isEmpty ? "E" : initials) as NSString
        let attributes: [NSAttributedString.Key: Any] = [
            .font: NSFont.systemFont(ofSize: size.height * 0.34, weight: .bold),
            .foregroundColor: NSColor.white,
        ]
        let textSize = text.size(withAttributes: attributes)
        text.draw(
            at: NSPoint(x: (size.width - textSize.width) / 2, y: (size.height - textSize.height) / 2),
            withAttributes: attributes
        )
        output.unlockFocus()
        output.isTemplate = false
        return output
    }

    func modernPanelVisibleTitle(_ item: NSMenuItem) -> String {
        let raw = item.attributedTitle?.string.isEmpty == false
            ? item.attributedTitle?.string ?? item.title
            : item.title
        let normalized = raw.replacingOccurrences(of: "\u{fffc}", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
        return normalized == "NSMenuItem" ? "" : normalized
    }

    func modernPanelRootItems() -> [NSMenuItem] {
        let categories = Set([
            "Docházka",
            "Záznam práce",
            "Přehledy a výkazy",
            "Systémy",
            "Nastavení",
        ])
        return menu.items.filter { categories.contains(modernPanelVisibleTitle($0)) && $0.submenu != nil }
    }

    func modernPanelPrepare(_ targetMenu: NSMenu) {
        menuWillOpen(targetMenu)
    }

    func modernPanelSearchItems(_ query: String) -> [NSMenuItem] {
        let rootMatches = modernPanelRootItems().filter {
            modernPanelVisibleTitle($0).range(
                of: query,
                options: [.caseInsensitive, .diacriticInsensitive]
            ) != nil
        }
        let matchingServers = evoraServers.filter {
            evoraServerMatchesSearch($0, folder: $0.folderName, query: query)
        }.sorted {
            $0.project.localizedCaseInsensitiveCompare($1.project) == .orderedAscending
        }
        if rootMatches.isEmpty, matchingServers.count == 1, let server = matchingServers.first {
            return evoraMiniserverDetailItems(server)
        }
        let serverMatches = matchingServers.prefix(100).map { server -> NSMenuItem in
            let item = evoraMiniserverMenuItem(server)
            item.image = evoraBundledDeviceImage(type: server.type) ?? item.image
            return item
        }
        return rootMatches + serverMatches
    }

    func modernPanelText(_ item: NSMenuItem) -> (String, String) {
        let title = modernPanelVisibleTitle(item)
        if let marker = title.range(of: "●") {
            let label = title[..<marker.lowerBound]
                .trimmingCharacters(in: .whitespacesAndNewlines)
            let status = title[marker.upperBound...]
                .trimmingCharacters(in: .whitespacesAndNewlines)
            if !label.isEmpty, !status.isEmpty {
                return (label, status)
            }
        }
        var labels: [String] = []
        var containsSearchField = false
        func collect(_ view: NSView) {
            if view is NSSearchField {
                containsSearchField = true
                return
            }
            if let field = view as? NSTextField {
                let value = field.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
                if !value.isEmpty { labels.append(value) }
            }
            view.subviews.forEach(collect)
        }
        if let view = item.view { collect(view) }
        if containsSearchField { return ("", "") }
        let unique = labels.reduce(into: [String]()) { result, value in
            if !result.contains(value) { result.append(value) }
        }
        if !title.isEmpty {
            let detail = unique.filter { $0 != title }.prefix(2).joined(separator: " · ")
            return (title, detail)
        }
        guard let first = unique.first else { return ("", "") }
        return (first, unique.dropFirst().prefix(2).joined(separator: " · "))
    }

    func modernPanelImage(_ item: NSMenuItem) -> NSImage? {
        if let attributedTitle = item.attributedTitle {
            var attachmentImage: NSImage?
            attributedTitle.enumerateAttribute(
                .attachment,
                in: NSRange(location: 0, length: attributedTitle.length)
            ) { value, _, stop in
                if let attachment = value as? NSTextAttachment, let image = attachment.image {
                    attachmentImage = image
                    stop.pointee = true
                }
            }
            if let attachmentImage { return attachmentImage }
        }
        func find(_ view: NSView) -> NSImage? {
            if let imageView = view as? NSImageView, let image = imageView.image { return image }
            for child in view.subviews {
                if let image = find(child) { return image }
            }
            return nil
        }
        return item.view.flatMap(find)
    }

    func modernPanelDescendant(_ root: NSView, identifier: String) -> NSView? {
        if root.identifier == NSUserInterfaceItemIdentifier(identifier) { return root }
        for child in root.subviews {
            if let match = modernPanelDescendant(child, identifier: identifier) { return match }
        }
        return nil
    }

    func modernPanelEmbeddedView(_ item: NSMenuItem, width: CGFloat) -> NSView? {
        guard
            let payload = item.representedObject as? NSDictionary,
            let kind = payload["modernEmbedded"] as? String,
            let view = item.view
        else { return nil }

        switch kind {
        case "miniserverSummary":
            let height: CGFloat = 152
            let serial = payload["serial"] as? String
            let server = serial.flatMap { requested in evoraServers.first { $0.serial == requested } }
            let color = server.map { evoraConnectionColor($0.connectionState) } ?? .systemGreen
            view.frame = NSRect(x: 0, y: 0, width: width, height: height)
            view.alphaValue = 1
            view.subviews.forEach { $0.alphaValue = 1 }
            view.wantsLayer = true
            view.layer?.cornerRadius = 18
            view.layer?.cornerCurve = .continuous
            view.layer?.borderWidth = 1
            view.layer?.borderColor = color.withAlphaComponent(0.28).cgColor
            view.layer?.backgroundColor = color.withAlphaComponent(0.09).cgColor
            view.layer?.shadowColor = color.cgColor
            view.layer?.shadowOpacity = 0.08
            view.layer?.shadowRadius = 8
            view.layer?.shadowOffset = NSSize(width: 0, height: -2)
            view.layer?.removeAnimation(forKey: "evora.miniserver.statePulse")
            if !NSWorkspace.shared.accessibilityDisplayShouldReduceMotion {
                let pulse = CABasicAnimation(keyPath: "shadowOpacity")
                switch server?.connectionState {
                case "online":
                    pulse.fromValue = 0.06
                    pulse.toValue = 0.15
                    pulse.duration = 2.4
                case "degraded", "no_access":
                    pulse.fromValue = 0.09
                    pulse.toValue = 0.24
                    pulse.duration = 1.5
                default:
                    pulse.fromValue = 0.12
                    pulse.toValue = 0.30
                    pulse.duration = 1.0
                }
                pulse.autoreverses = true
                pulse.repeatCount = .infinity
                pulse.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
                view.layer?.add(pulse, forKey: "evora.miniserver.statePulse")
            }
            modernPanelDescendant(view, identifier: "evora-miniserver-image")?.frame = NSRect(x: 20, y: 30, width: 106, height: 92)
            let textX: CGFloat = 148
            let textWidth = max(160, width - textX - 20)
            modernPanelDescendant(view, identifier: "evora-miniserver-title")?.frame = NSRect(x: textX, y: 114, width: textWidth, height: 24)
            (modernPanelDescendant(view, identifier: "evora-miniserver-title") as? NSTextField)?.font = .systemFont(ofSize: 18, weight: .bold)
            modernPanelDescendant(view, identifier: "evora-miniserver-identity")?.frame = NSRect(x: textX, y: 89, width: textWidth, height: 18)
            modernPanelDescendant(view, identifier: "evora-miniserver-status")?.frame = NSRect(x: textX, y: 66, width: textWidth, height: 18)
            modernPanelDescendant(view, identifier: "evora-miniserver-devices")?.frame = NSRect(x: textX, y: 43, width: textWidth, height: 18)
            modernPanelDescendant(view, identifier: "evora-miniserver-diagnostic")?.frame = NSRect(x: textX, y: 20, width: textWidth, height: 18)
            return view

        case "camera":
            let videoWidth = max(360, width - 24)
            let videoHeight = videoWidth * 9 / 16
            let height = videoHeight + 54
            view.frame = NSRect(x: 0, y: 0, width: width, height: height)
            view.wantsLayer = true
            view.layer?.cornerRadius = 18
            view.layer?.cornerCurve = .continuous
            view.layer?.masksToBounds = true
            view.layer?.borderWidth = 1
            view.layer?.borderColor = NSColor.separatorColor.withAlphaComponent(0.5).cgColor
            view.layer?.backgroundColor = NSColor.controlBackgroundColor.cgColor
            modernPanelDescendant(view, identifier: "evora-camera-title")?.frame = NSRect(x: 16, y: videoHeight + 26, width: width - 210, height: 19)
            modernPanelDescendant(view, identifier: "evora-camera-state")?.frame = NSRect(x: width - 186, y: videoHeight + 26, width: 170, height: 19)
            modernPanelDescendant(view, identifier: "evora-camera-player")?.frame = NSRect(x: 12, y: 12, width: videoWidth, height: videoHeight)
            modernPanelDescendant(view, identifier: "evora-camera-loading")?.frame = NSRect(x: 30, y: 12 + (videoHeight - 20) / 2, width: width - 60, height: 20)
            view.needsLayout = true
            return view

        case "gate":
            let height: CGFloat = 70
            view.frame = NSRect(x: 0, y: 0, width: width, height: height)
            let buttons = view.subviews.compactMap { $0 as? NSButton }.sorted { $0.tag < $1.tag }
            let buttonWidth: CGFloat = 52
            let gap: CGFloat = 12
            let startX = (width - buttonWidth * 2 - gap) / 2
            for (index, button) in buttons.enumerated() {
                button.frame = NSRect(x: startX + CGFloat(index) * (buttonWidth + gap), y: 27, width: buttonWidth, height: 36)
            }
            modernPanelDescendant(view, identifier: "evora-gate-feedback")?.frame = NSRect(
                x: 12,
                y: 5,
                width: width - 24,
                height: 17
            )
            return view

        default:
            return nil
        }
    }

    func modernPanelColor(_ item: NSMenuItem) -> NSColor? {
        var attributedColor: NSColor?
        if let attributedTitle = item.attributedTitle {
            attributedTitle.enumerateAttribute(
                .foregroundColor,
                in: NSRange(location: 0, length: attributedTitle.length)
            ) { value, _, _ in
                if let color = value as? NSColor, color != .labelColor {
                    attributedColor = color
                }
            }
        }
        if let attributedColor { return attributedColor }
        let value = modernPanelVisibleTitle(item).folding(
            options: [.caseInsensitive, .diacriticInsensitive],
            locale: Locale(identifier: "cs_CZ")
        ).lowercased()
        if value.contains("offline") || value.contains("chyba") || value.contains("selhal") || value.contains("nepripojeno") {
            return .systemRed
        }
        if value.contains("nacitam") || value.contains("aktualizu") || value.contains("ceka") || value.contains("prestav") {
            return .systemOrange
        }
        if value.contains("online") || value.contains("aktivni") || value.contains("v praci") || value.contains("aktualni") {
            return .systemGreen
        }
        return nil
    }

    func modernPanelUpdateLiveItems() {
        guard let status = intranetMenu?.items.first, !status.isSeparatorItem else { return }
        updateReadOnlyItem(status, title: intranetLiveStatusTitle(), color: modernPanelProfileColor())
    }

    func modernPanelShouldClose(after item: NSMenuItem) -> Bool {
        guard let action = item.action else { return false }
        if action == #selector(openURL(_:)) || action == #selector(openExcel) || action == #selector(callIntranetContact(_:)) {
            return true
        }
        if action == #selector(runEvoraAction(_:)),
           let payload = item.representedObject as? NSDictionary,
           let kind = payload["action"] as? String {
            return kind != "copy_password"
        }
        return false
    }

    func modernPanelPerform(_ item: NSMenuItem) {
        guard let action = item.action else { return }
        NSApp.sendAction(action, to: item.target, from: item)
    }

    func modernPanelDidShow() {
        if let published = evoraCameras.first(where: { $0.id == 7 && $0.online }) {
            scheduleEvoraCameraPreview(published.id)
        }
    }

    func modernPanelDidClose() {
        // Moderní panel je dočasně skrytý; sdílený kanál zůstává předehřátý
        // pro klasickou nabídku v horní liště.
    }

    func installClassicMenuNavigator() {
        let presentation = NSMenu(title: "Evora Smart Menu")
        presentation.autoenablesItems = false
        presentation.delegate = self
        let navigator = ClassicMenuNavigatorView(owner: self, rootMenu: menu)
        let container = NSMenuItem()
        container.view = navigator
        presentation.addItem(container)
        classicPresentationMenu = presentation
        classicMenuNavigator = navigator
    }

    func classicNavigatorPrepare(_ targetMenu: NSMenu) {
        menuWillOpen(targetMenu)
    }

    func classicNavigatorDidShow(_ targetMenu: NSMenu) {
        let wasTrackingSystems = evoraMenuTracking
        evoraMenuTracking = evoraMenu.map { menuHierarchy($0, contains: targetMenu, visited: []) } ?? false
        if wasTrackingSystems, !evoraMenuTracking, evoraRebuildDeferred,
           mainMenuSearchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            DispatchQueue.main.async { [weak self] in
                guard let self, !self.evoraMenuTracking else { return }
                self.rebuildEvoraMenu()
            }
        }
    }

    func classicNavigatorLayoutDidFinish() {
        guard let panel = classicMenuNavigator?.window, panel.isVisible else { return }
        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0
            context.allowsImplicitAnimation = false
            classicPresentationMenu?.update()
            panel.contentView?.layoutSubtreeIfNeeded()
            positionClassicMenuPanel()
        }
        DispatchQueue.main.async { [weak self] in
            guard let panel = self?.classicMenuNavigator?.window, panel.isVisible else { return }
            self?.positionClassicMenuPanel()
            panel.displayIfNeeded()
        }
    }

    private func ensureClassicMenuPositionLock(_ panel: NSWindow) {
        guard classicMenuFrameObservers.isEmpty else { return }
        for notification in [NSWindow.didMoveNotification, NSWindow.didResizeNotification] {
            let observer = NotificationCenter.default.addObserver(
                forName: notification,
                object: panel,
                queue: .main
            ) { [weak self] _ in
                self?.positionClassicMenuPanel()
            }
            classicMenuFrameObservers.append(observer)
        }
    }

    private func releaseClassicMenuPositionLock() {
        classicMenuFrameObservers.forEach(NotificationCenter.default.removeObserver)
        classicMenuFrameObservers.removeAll()
        classicMenuPositionCorrectionInProgress = false
    }

    private func positionClassicMenuPanel() {
        guard let panel = classicMenuNavigator?.window,
              panel.isVisible,
              let screen = statusItem.button?.window?.screen ?? panel.screen,
              !classicMenuPositionCorrectionInProgress
        else { return }
        ensureClassicMenuPositionLock(panel)
        let visibleFrame = screen.visibleFrame
        let targetFrame = NSRect(
            x: visibleFrame.maxX - classicMenuScreenEdgeInset - panel.frame.width,
            y: visibleFrame.maxY - classicMenuScreenEdgeInset - panel.frame.height,
            width: panel.frame.width,
            height: panel.frame.height
        )
        if abs(panel.frame.origin.x - targetFrame.origin.x) > 0.5
            || abs(panel.frame.origin.y - targetFrame.origin.y) > 0.5 {
            classicMenuPositionCorrectionInProgress = true
            // Celý rám se nastaví jedním neanimovaným krokem. AppKit tak
            // nikdy nevykreslí novou výšku se starým originem u menu baru.
            panel.setFrame(targetFrame, display: false, animate: false)
            panel.displayIfNeeded()
            classicMenuPositionCorrectionInProgress = false
        }
    }

    private func scheduleClassicMenuPositioning() {
        // První průchod ukotví nový panel. Druhý zachytí dokončení AppKit
        // layoutu, ale díky zámku pohybu se mezitím nevykreslí přicvaknutý
        // stav u menu baru.
        DispatchQueue.main.async { [weak self] in
            self?.positionClassicMenuPanel()
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.02) { [weak self] in
            self?.positionClassicMenuPanel()
        }
    }

    func classicNavigatorPerform(_ item: NSMenuItem) {
        guard let action = item.action else { return }
        if action == #selector(showEvoraPortalTicket(_:)) {
            showEvoraPortalTicketInClassicMenu(item)
            return
        }
        if action == #selector(createEvoraPortalTicket) {
            let composer = evoraClassicTicketComposerMenu(ticket: nil)
            classicMenuNavigator?.showTransientPage(composer, title: "Nový LOXONE ticket")
            return
        }
        closeClassicMenu()
        DispatchQueue.main.async {
            NSApp.sendAction(action, to: item.target, from: item)
        }
    }

    func closeClassicMenu() {
        classicPresentationMenu?.cancelTracking()
    }

    private func menuHierarchy(_ source: NSMenu, contains target: NSMenu, visited: Set<ObjectIdentifier>) -> Bool {
        if source === target { return true }
        let identifier = ObjectIdentifier(source)
        guard !visited.contains(identifier) else { return false }
        var nextVisited = visited
        nextVisited.insert(identifier)
        for item in source.items {
            if let submenu = item.submenu,
               menuHierarchy(submenu, contains: target, visited: nextVisited) {
                return true
            }
        }
        return false
    }

    @objc func handleStatusItemInteraction() {
        guard let button = statusItem.button else { return }
        // Levý i pravý klik používá jediný klasický NSMenu popover. Uvnitř
        // se obsah přepíná na místě a nikdy nevytváří samostatné okno.
        // Osm bodů odpovídá běžnému bočnímu okraji systémového menu. Bod pod
        // spodní hranou status-itemu zabrání AppKitu přicvaknout panel přímo
        // k menu baru a vytvoří stejný optický odskok nahoře i vpravo.
        scheduleClassicMenuPositioning()
        (classicPresentationMenu ?? menu).popUp(
            positioning: nil,
            at: NSPoint(x: 0, y: button.bounds.minY - classicMenuScreenEdgeInset),
            in: button
        )
    }

    func updateStatusButtonAnimation() {
        guard let button = statusItem.button else { return }
        let isSynchronizing = intranetRefreshInFlight
            || evoraRefreshInFlight
            || evoraTicketsRefreshInFlight
        guard isSynchronizing else {
            statusPulseDimmed = false
            if button.alphaValue != 1 {
                NSAnimationContext.runAnimationGroup { context in
                    context.duration = 0.2
                    button.animator().alphaValue = 1
                }
            }
            return
        }

        statusPulseDimmed.toggle()
        NSAnimationContext.runAnimationGroup { context in
            context.duration = 0.42
            context.timingFunction = CAMediaTimingFunction(name: .easeInEaseOut)
            button.animator().alphaValue = statusPulseDimmed ? 0.58 : 1
        }
    }

    func updateBrandedHeaderSubtitle() {
        // Verze zůstává interně dostupná pro diagnostiku a aktualizaci, ale
        // uživatelské kořenové záhlaví je na přání zcela bez loga a textu.
    }

    func intranetStatusSummaryItem() -> NSMenuItem {
        let item = NSMenuItem(title: "Intranet", action: nil, keyEquivalent: "")
        let width: CGFloat = 420
        let height: CGFloat = 94
        let wrapper = NSView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        let container = ClassicMenuAdaptiveView(frame: NSRect(x: 8, y: 4, width: width - 16, height: height - 8))
        wrapper.addSubview(container)
        container.wantsLayer = true
        container.layer?.cornerRadius = 19
        container.layer?.cornerCurve = .continuous
        container.layer?.borderWidth = 1
        container.layer?.shadowOpacity = 0.055
        container.layer?.shadowRadius = 8
        container.layer?.shadowOffset = NSSize(width: 0, height: -2)

        let icon = NSImageView(frame: NSRect(x: 14, y: 13, width: 60, height: 60))
        icon.image = modernPanelProfileImage(size: NSSize(width: 60, height: 60))
        icon.imageScaling = .scaleProportionallyUpOrDown
        icon.wantsLayer = true
        icon.layer?.cornerRadius = 30
        icon.layer?.cornerCurve = .continuous
        icon.layer?.masksToBounds = true
        icon.layer?.borderWidth = 2
        container.addSubview(icon)

        let title = NSTextField(labelWithString: modernPanelProfileName())
        title.frame = NSRect(x: 92, y: 56, width: 260, height: 24)
        title.font = NSFont.systemFont(ofSize: 17, weight: .semibold)
        title.lineBreakMode = .byTruncatingTail
        container.addSubview(title)

        let detail = NSTextField(labelWithString: "Načítám stav…")
        detail.frame = NSRect(x: 92, y: 33, width: 260, height: 18)
        detail.font = NSFont.monospacedDigitSystemFont(ofSize: 11, weight: .medium)
        detail.textColor = .systemBlue
        detail.lineBreakMode = .byTruncatingTail
        container.addSubview(detail)

        let metrics = NSTextField(labelWithString: modernPanelProfileMetrics())
        metrics.frame = NSRect(x: 92, y: 12, width: 260, height: 17)
        metrics.font = NSFont.monospacedDigitSystemFont(ofSize: 10.5, weight: .regular)
        metrics.textColor = .secondaryLabelColor
        metrics.lineBreakMode = .byTruncatingTail
        container.addSubview(metrics)

        let close = ModernMenuActionButton(
            image: sf("xmark", color: .systemRed) ?? NSImage(),
            target: self,
            action: #selector(quitMenu)
        )
        close.identifier = NSUserInterfaceItemIdentifier("evora-profile-close")
        close.frame = NSRect(x: 360, y: 49, width: 30, height: 30)
        close.isBordered = false
        close.focusRingType = .none
        close.imagePosition = .imageOnly
        close.contentTintColor = .systemRed
        close.toolTip = "Ukončit Evora Smart Menu"
        close.setAccessibilityLabel("Ukončit Evora Smart Menu")
        close.pressChanged = { [weak close] pressed in
            close?.alphaValue = pressed ? 0.55 : 1
        }
        container.addSubview(close)
        container.appearanceHandler = { [weak self, weak title, weak detail, weak metrics, weak icon] view in
            let statusColor = self?.modernPanelProfileColor() ?? .secondaryLabelColor
            view.layer?.backgroundColor = statusColor.withAlphaComponent(
                evoraMenuUsesDarkAppearance(view) ? 0.10 : 0.065
            ).cgColor
            view.layer?.borderColor = statusColor.withAlphaComponent(0.34).cgColor
            view.layer?.shadowColor = statusColor.withAlphaComponent(0.42).cgColor
            title?.textColor = evoraMenuPrimaryTextColor(view)
            detail?.textColor = statusColor
            metrics?.textColor = evoraMenuSecondaryTextColor(view)
            icon?.layer?.borderColor = statusColor.withAlphaComponent(0.74).cgColor
        }
        container.refreshAppearance()

        shiftStatusTitleField = title
        shiftStatusDetailField = detail
        shiftStatusMetricsField = metrics
        shiftStatusImageView = icon
        shiftStatusContainer = container
        item.view = wrapper
        item.isEnabled = true
        return item
    }

    func loxoneLikeIcon() -> NSImage {
        let size = NSSize(
            width: 18,
            height: 18
        )

        let image = NSImage(size: size)

        image.lockFocus()

        let outer = NSBezierPath()
        outer.lineWidth = 1.6

        outer.move(
            to: NSPoint(x: 9, y: 1.6)
        )

        outer.line(
            to: NSPoint(x: 15.4, y: 5.1)
        )

        outer.line(
            to: NSPoint(x: 15.4, y: 12.9)
        )

        outer.line(
            to: NSPoint(x: 9, y: 16.4)
        )

        outer.line(
            to: NSPoint(x: 2.6, y: 12.9)
        )

        outer.line(
            to: NSPoint(x: 2.6, y: 5.1)
        )

        outer.close()

        NSColor.labelColor.setStroke()
        outer.stroke()

        let inner = NSBezierPath()
        inner.lineWidth = 1.7

        inner.move(
            to: NSPoint(x: 6.2, y: 5.0)
        )

        inner.line(
            to: NSPoint(x: 6.2, y: 12.8)
        )

        inner.line(
            to: NSPoint(x: 11.8, y: 12.8)
        )

        inner.stroke()

        image.unlockFocus()

        image.isTemplate = true

        return image
    }

    // MARK: - Menu items

    func semanticMenuColor(for symbol: String?) -> NSColor {
        guard let symbol else { return .systemTeal }
        let value = symbol.lowercased()
        if value.contains("stop") || value.contains("xmark") || value.contains("trash") || value.contains("power") {
            return .systemRed
        }
        if value.contains("pause") || value.contains("car") || value.contains("wrench") || value.contains("exclamation") {
            return .systemOrange
        }
        if value.contains("play") || value.contains("check") || value.contains("calendar") || value.contains("clock.badge") {
            return .systemGreen
        }
        if value.contains("gear") || value.contains("sparkles") || value.contains("key") {
            return .systemPurple
        }
        if value.contains("phone") || value.contains("person") || value.contains("iphone") || value.contains("bubble") || value.contains("ticket") {
            return .systemTeal
        }
        if value.contains("arrow.clockwise") || value.contains("arrow.down") || value.contains("doc") || value.contains("table") || value.contains("square.and.pencil") {
            return .systemBlue
        }
        if value.contains("house") || value.contains("building") || value.contains("network") || value.contains("globe") || value.contains("link") {
            return .systemCyan
        }
        return .systemIndigo
    }

    func menuColor(hex: String?, fallback: NSColor = .systemGreen) -> NSColor {
        guard let raw = hex?.trimmingCharacters(in: .whitespacesAndNewlines) else { return fallback }
        let normalized = raw.hasPrefix("#") ? String(raw.dropFirst()) : raw
        guard normalized.count == 6, let value = Int(normalized, radix: 16) else { return fallback }
        return NSColor(
            srgbRed: CGFloat((value >> 16) & 0xff) / 255,
            green: CGFloat((value >> 8) & 0xff) / 255,
            blue: CGFloat(value & 0xff) / 255,
            alpha: 1
        )
    }

    func item(
        _ title: String,
        symbol: String?,
        action: Selector,
        color: NSColor? = nil
    ) -> NSMenuItem {

        let item = NSMenuItem(
            title: title,
            action: action,
            keyEquivalent: ""
        )

        item.target = self
        applyMenuIcon(to: item, title: title, symbol: symbol, color: color ?? semanticMenuColor(for: symbol))

        return item
    }

    func linkItem(
        _ title: String,
        symbol: String?,
        url: String,
        color: NSColor? = nil
    ) -> NSMenuItem {

        let item = NSMenuItem(
            title: title,
            action: #selector(openURL(_:)),
            keyEquivalent: ""
        )

        item.target = self
        item.representedObject = url
        applyMenuIcon(to: item, title: title, symbol: symbol, color: color ?? semanticMenuColor(for: symbol))

        return item
    }

    func readOnlyItem(
        _ title: String,
        symbol: String? = nil,
        color: NSColor = .labelColor,
        weight: NSFont.Weight = .regular
    ) -> NSMenuItem {
        let menuItem = NSMenuItem()
        let width: CGFloat = 390
        let height: CGFloat = 25
        let view = NSView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        var textX: CGFloat = 13

        if let symbol, let image = sf(symbol, color: color) {
            let imageView = NSImageView(frame: NSRect(x: 13, y: 4, width: 17, height: 17))
            imageView.image = image
            imageView.contentTintColor = color
            view.addSubview(imageView)
            textX = 39
        }

        let text = NSTextField(labelWithString: title)
        text.frame = NSRect(x: textX, y: 4, width: width - textX - 12, height: 18)
        text.font = NSFont.systemFont(ofSize: NSFont.systemFontSize, weight: weight)
        text.textColor = color
        text.lineBreakMode = .byTruncatingTail
        view.addSubview(text)
        menuItem.view = view
        return menuItem
    }

    func updateReadOnlyItem(_ item: NSMenuItem, title: String, color: NSColor) {
        item.title = title
        guard let view = item.view else { return }
        for subview in view.subviews {
            if let field = subview as? NSTextField {
                field.stringValue = title
                field.textColor = color
            } else if let image = subview as? NSImageView {
                image.contentTintColor = color
            }
        }
    }

    func metricItem(
        label: String,
        value: String,
        symbol: String? = nil,
        symbolColor: NSColor = .labelColor,
        valueColor: NSColor = .labelColor
    ) -> NSMenuItem {
        let menuItem = NSMenuItem()
        let width: CGFloat = 390
        let height: CGFloat = 27
        let view = NSView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        var labelX: CGFloat = 13

        if let symbol, let image = sf(symbol, color: symbolColor) {
            let imageView = NSImageView(frame: NSRect(x: 13, y: 5, width: 17, height: 17))
            imageView.image = image
            imageView.contentTintColor = symbolColor
            view.addSubview(imageView)
            labelX = 39
        }

        let valueWidth: CGFloat = 132
        let labelField = NSTextField(labelWithString: label)
        labelField.frame = NSRect(
            x: labelX,
            y: 5,
            width: width - labelX - valueWidth - 18,
            height: 18
        )
        labelField.font = NSFont.systemFont(ofSize: NSFont.systemFontSize)
        labelField.textColor = .labelColor
        labelField.lineBreakMode = .byTruncatingTail
        view.addSubview(labelField)

        let valueField = NSTextField(labelWithString: value)
        valueField.frame = NSRect(
            x: width - valueWidth - 12,
            y: 5,
            width: valueWidth,
            height: 18
        )
        valueField.alignment = .right
        valueField.font = NSFont.monospacedDigitSystemFont(
            ofSize: NSFont.systemFontSize,
            weight: .semibold
        )
        valueField.textColor = valueColor
        valueField.lineBreakMode = .byTruncatingHead
        view.addSubview(valueField)

        menuItem.view = view
        return menuItem
    }

    func statusAttributed(
        label: String,
        value: String,
        color: NSColor,
        image: NSImage? = nil,
        symbol: String? = nil
    ) -> NSAttributedString {

        let output = NSMutableAttributedString()
        let requestedImage = image ?? symbol.flatMap { sf($0) }
        if let requestedImage {
            let icon = (requestedImage.copy() as? NSImage) ?? requestedImage
            icon.size = NSSize(width: 16, height: 16)
            let attachment = NSTextAttachment()
            attachment.image = icon
            attachment.bounds = NSRect(x: 0, y: -1.5, width: 16, height: 16)
            output.append(NSAttributedString(attachment: attachment))
            output.append(NSAttributedString(string: "  "))
        }
        let labelStart = output.length
        output.append(NSAttributedString(string: "\(label)    "))

        output.addAttributes(
            [
                .foregroundColor: NSColor.labelColor,
                .font: NSFont.systemFont(
                    ofSize: NSFont.systemFontSize
                )
            ],
            range: NSRange(
                location: labelStart,
                length: output.length - labelStart
            )
        )

        let state = NSAttributedString(
            string: value,
            attributes: [
                .foregroundColor: color,
                .font: NSFont.systemFont(
                    ofSize: NSFont.systemFontSize,
                    weight: .semibold
                )
            ]
        )

        output.append(state)

        return output
    }

    func evoraTaskStatusLabel(_ status: String) -> String {
        switch status {
        case "new": return "Nový"
        case "planned": return "Naplánovaný"
        case "in_progress": return "Probíhá"
        case "waiting": return "Čeká"
        case "done": return "Hotovo"
        case "cancelled": return "Zrušený"
        default: return status
        }
    }

    func evoraTaskColor(_ task: EvoraTaskSummary) -> NSColor {
        if task.status == "done" { return .systemGreen }
        if task.status == "cancelled" { return .secondaryLabelColor }
        if task.priority == "urgent" { return .systemRed }
        if task.priority == "high" { return .systemOrange }
        if task.status == "in_progress" { return .systemBlue }
        return .systemIndigo
    }

    func evoraTaskDueLabel(_ value: String?) -> String? {
        guard let value, let date = parseIntranetDate(value) else { return nil }
        let formatter = DateFormatter()
        formatter.locale = Locale(identifier: "cs_CZ")
        formatter.timeZone = TimeZone(identifier: "Europe/Prague")
        formatter.dateFormat = "d. M. yyyy"
        return formatter.string(from: date)
    }

    func rebuildTasksNotesMenu() {
        guard tasksNotesMenu != nil else { return }
        defer { classicMenuNavigator?.modelDidChange() }
        tasksNotesMenu.removeAllItems()
        tasksNotesMenu.autoenablesItems = false
        tasksNotesMenu.addItem(item(
            "Nový lísteček…",
            symbol: "note.text.badge.plus",
            action: #selector(addPersonalNote),
            color: .systemYellow
        ))
        tasksNotesMenu.addItem(linkItem(
            "Otevřít všechny úkoly v Hubu",
            symbol: "arrow.up.right.square",
            url: "\(evoraHubURL())?page=service_tasks",
            color: .systemBlue
        ))
        tasksNotesMenu.addItem(.separator())

        let notesParent = NSMenuItem(title: "Moje lístečky  (\(personalNotes.count))", action: nil, keyEquivalent: "")
        applyMenuIcon(to: notesParent, title: "Moje lístečky  (\(personalNotes.count))", symbol: "note.text", color: .systemYellow)
        let notesMenu = NSMenu(title: "Moje lístečky")
        notesMenu.autoenablesItems = false
        if !personalNotesLoaded {
            notesMenu.addItem(readOnlyItem("Načítám osobní lístečky…", symbol: "clock", color: .systemOrange))
        } else if personalNotes.isEmpty {
            notesMenu.addItem(readOnlyItem("Zatím nemáte žádný lísteček.", symbol: "note.text", color: .secondaryLabelColor))
        } else {
            for note in personalNotes.sorted(by: { $0.updatedAt > $1.updatedAt }) {
                let title = note.title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                    ? compactMenuText(note.body, limit: 54)
                    : compactMenuText(note.title, limit: 54)
                let noteItem = item(title.isEmpty ? "Lísteček" : title, symbol: "note.text", action: #selector(editPersonalNote(_:)), color: .systemYellow)
                noteItem.representedObject = note.id
                noteItem.toolTip = compactMenuText(note.body, limit: 180)
                notesMenu.addItem(noteItem)
            }
        }
        notesParent.submenu = notesMenu
        tasksNotesMenu.addItem(notesParent)

        let activeTasks = evoraTasks.filter { !["done", "cancelled"].contains($0.status) }
        let tasksParent = NSMenuItem(title: "Úkoly z Hubu  (\(activeTasks.count))", action: nil, keyEquivalent: "")
        applyMenuIcon(to: tasksParent, title: "Úkoly z Hubu  (\(activeTasks.count))", symbol: "checklist", color: .systemIndigo)
        let taskMenu = NSMenu(title: "Úkoly z Hubu")
        taskMenu.autoenablesItems = false
        if activeTasks.isEmpty {
            taskMenu.addItem(readOnlyItem("Žádný aktivní úkol.", symbol: "checkmark.circle", color: .systemGreen))
        } else {
            for task in activeTasks.prefix(80) {
                let title = "\(task.publicId) · \(compactMenuText(task.title, limit: 64))"
                let taskItem = linkItem(
                    title,
                    symbol: task.priority == "urgent" ? "exclamationmark.triangle.fill" : "checklist",
                    url: "\(evoraHubURL())?page=service_tasks&task=\(task.id)",
                    color: evoraTaskColor(task)
                )
                let details = [
                    Optional(evoraTaskStatusLabel(task.status)),
                    task.project,
                    task.assigneeName,
                    evoraTaskDueLabel(task.dueAt).map { "termín \($0)" },
                ].compactMap { $0 }.filter { !$0.isEmpty }
                taskItem.toolTip = details.joined(separator: " · ")
                taskMenu.addItem(taskItem)
            }
        }
        tasksParent.submenu = taskMenu
        tasksNotesMenu.addItem(tasksParent)
        if !mainMenuSearchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            applyMainMenuSearchFilter()
        }
    }

    @objc func addPersonalNote() {
        presentPersonalNote(id: nil)
    }

    @objc func editPersonalNote(_ sender: NSMenuItem) {
        presentPersonalNote(id: sender.representedObject as? String)
    }

    func presentPersonalNote(id: String?) {
        let existing = id.flatMap { requested in personalNotes.first { $0.id == requested } }
        NSApp.activate(ignoringOtherApps: true)
        let alert = makeContextualAlert(
            existing == nil ? "Nový lísteček" : "Upravit lísteček",
            "Lísteček je osobní a ukládá se pouze lokálně pro tento účet Macu.",
            iconContext: "poznámka"
        )
        alert.addButton(withTitle: "Uložit")
        if existing != nil { alert.addButton(withTitle: "Smazat") }
        alert.addButton(withTitle: "Zrušit")
        let container = NSView(frame: NSRect(x: 0, y: 0, width: 470, height: 230))
        let titleLabel = NSTextField(labelWithString: "Název")
        titleLabel.frame = NSRect(x: 0, y: 208, width: 470, height: 17)
        let titleField = NSTextField(frame: NSRect(x: 0, y: 176, width: 470, height: 26))
        titleField.placeholderString = "Například Zavolat zákazníkovi"
        titleField.stringValue = existing?.title ?? ""
        let bodyLabel = NSTextField(labelWithString: "Poznámka")
        bodyLabel.frame = NSRect(x: 0, y: 151, width: 470, height: 17)
        let bodyScroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: 470, height: 146))
        bodyScroll.hasVerticalScroller = true
        bodyScroll.borderType = .bezelBorder
        let bodyField = NSTextView(frame: NSRect(x: 0, y: 0, width: 450, height: 146))
        bodyField.isRichText = false
        bodyField.font = .systemFont(ofSize: 13)
        bodyField.textContainerInset = NSSize(width: 8, height: 8)
        bodyField.string = existing?.body ?? ""
        bodyScroll.documentView = bodyField
        [titleLabel, titleField, bodyLabel, bodyScroll].forEach { container.addSubview($0) }
        alert.accessoryView = container
        alert.window.initialFirstResponder = titleField
        let response = alert.runModal()
        if existing != nil, response == .alertSecondButtonReturn {
            let confirmation = makeContextualAlert(
                "Smazat lísteček?",
                "Tuto osobní poznámku nelze po smazání obnovit.",
                iconContext: "poznámka"
            )
            confirmation.addButton(withTitle: "Smazat")
            confirmation.addButton(withTitle: "Ponechat")
            guard confirmation.runModal() == .alertFirstButtonReturn, let id else { return }
            let previous = personalNotes
            personalNotes.removeAll { $0.id == id }
            if !savePersonalNotes() {
                personalNotes = previous
                showAlert("Lístečky", "Lísteček se nepodařilo odstranit z lokálního úložiště.")
            }
            rebuildTasksNotesMenu()
            return
        }
        guard response == .alertFirstButtonReturn else { return }
        let title = titleField.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        let body = bodyField.string.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !title.isEmpty || !body.isEmpty else {
            showAlert("Lístečky", "Vyplňte název nebo text poznámky.")
            return
        }
        let previous = personalNotes
        let now = Date().timeIntervalSince1970
        if let id, let index = personalNotes.firstIndex(where: { $0.id == id }) {
            personalNotes[index].title = title
            personalNotes[index].body = body
            personalNotes[index].updatedAt = now
        } else {
            personalNotes.append(EvoraPersonalNote(
                id: UUID().uuidString.lowercased(),
                title: title,
                body: body,
                createdAt: now,
                updatedAt: now
            ))
        }
        personalNotes.sort { $0.updatedAt > $1.updatedAt }
        if !savePersonalNotes() {
            personalNotes = previous
            showAlert("Lístečky", "Lísteček se nepodařilo uložit do lokálního úložiště.")
        }
        rebuildTasksNotesMenu()
    }

    // MARK: - Build menu

    func buildMenu() {
        menu = NSMenu(title: "Evora Smart Menu")
        menu.autoenablesItems = false
        menu.delegate = self

        shiftStatusItem = intranetStatusSummaryItem()
        menu.addItem(shiftStatusItem)

        let globalSearchItem = NSMenuItem()
        let globalSearchContainer = NSView(frame: NSRect(x: 0, y: 0, width: 420, height: 38))
        let globalSearchField = MenuSearchField(frame: NSRect(x: 12, y: 5, width: 396, height: 28))
        globalSearchField.placeholderString = "Hledat v celé nabídce…"
        // Delegate drží průběžně celý rozepsaný dotaz. Action se odešle až
        // po potvrzení celé hodnoty, takže napsání „VZT1“ nebo „melori“ nikdy
        // nerozbije field editor po prvním písmenu.
        globalSearchField.sendsSearchStringImmediately = false
        globalSearchField.sendsWholeSearchString = true
        globalSearchField.delegate = self
        globalSearchField.target = self
        globalSearchField.action = #selector(searchFieldAction(_:))
        globalSearchContainer.addSubview(globalSearchField)
        globalSearchItem.view = globalSearchContainer
        mainMenuSearchItem = globalSearchItem
        mainMenuSearchField = globalSearchField
        menu.addItem(globalSearchItem)

        let noSearchResults = NSMenuItem(
            title: "Žádná položka neodpovídá hledání",
            action: nil,
            keyEquivalent: ""
        )
        noSearchResults.isEnabled = false
        noSearchResults.isHidden = true
        mainMenuNoResultsItem = noSearchResults
        menu.addItem(noSearchResults)

        menu.addItem(.separator())

        let attendance = NSMenuItem(
            title: "Docházka",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(to: attendance, title: "Docházka", symbol: "calendar.badge.clock", color: .systemGreen)
        intranetMenu = NSMenu(title: "Docházka")
        intranetMenu.autoenablesItems = false
        intranetMenu.delegate = self
        attendance.submenu = intranetMenu
        menu.addItem(attendance)
        rebuildIntranetMenu()

        let records = NSMenuItem(
            title: "Záznam práce",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(to: records, title: "Záznam práce", symbol: "square.and.pencil", color: .systemBlue)
        let recordsMenu = NSMenu(title: "Záznam práce")
        recordsMenu.autoenablesItems = false
        recordsMenu.addItem(item("Přidat poznámku…", symbol: "square.and.pencil", action: #selector(addNote)))
        recordsMenu.addItem(item("Telefon / hovor…", symbol: "phone.fill", action: #selector(addCall)))
        recordsMenu.addItem(item("Výjezd / cesta…", symbol: "car.fill", action: #selector(addTravel)))
        recordsMenu.addItem(item("Práce mimo PC…", symbol: "wrench.and.screwdriver.fill", action: #selector(addOffPC)))
        records.submenu = recordsMenu
        menu.addItem(records)

        let reports = NSMenuItem(
            title: "Přehledy a výkazy",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(to: reports, title: "Přehledy a výkazy", symbol: "doc.text.magnifyingglass", color: .systemTeal)
        let reportsMenu = NSMenu(title: "Přehledy a výkazy")
        reportsMenu.autoenablesItems = false
        reportsMenu.addItem(item("Průběžný souhrn", symbol: "list.bullet.rectangle", action: #selector(showSummary)))
        reportsMenu.addItem(item("AI souhrn", symbol: "sparkles", action: #selector(showAISummary)))
        reportsMenu.addItem(item("Poslední aktivita", symbol: "clock.arrow.circlepath", action: #selector(showRecent)))
        reportsMenu.addItem(.separator())
        reportsMenu.addItem(item("Vytvořit výkaz", symbol: "doc.text.fill", action: #selector(makeReport)))
        reportsMenu.addItem(item("Otevřít Excel", symbol: "tablecells.fill", action: #selector(openExcel)))
        reports.submenu = reportsMenu
        menu.addItem(reports)

        let tasksNotes = NSMenuItem(
            title: "Úkoly a poznámky",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(to: tasksNotes, title: "Úkoly a poznámky", symbol: "checklist", color: .systemIndigo)
        tasksNotesMenu = NSMenu(title: "Úkoly a poznámky")
        tasksNotesMenu.autoenablesItems = false
        tasksNotes.submenu = tasksNotesMenu
        menu.addItem(tasksNotes)
        rebuildTasksNotesMenu()

        let systems = NSMenuItem(
            title: "Systémy",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(to: systems, title: "Systémy", symbol: "square.grid.2x2", color: .systemOrange)
        let systemsMenu = NSMenu(title: "Systémy")
        systemsMenu.autoenablesItems = false
        evoraMenu = systemsMenu
        evoraMenu.delegate = self
        evoraMiniserversMenu = NSMenu(title: "Miniservery")
        evoraMiniserversMenu.autoenablesItems = false
        evoraMiniserversMenu.delegate = self
        systems.submenu = systemsMenu
        menu.addItem(systems)
        rebuildEvoraMenu()

        let controls = NSMenuItem(
            title: "Nastavení",
            action: nil,
            keyEquivalent: ""
        )
        applyMenuIcon(to: controls, title: "Nastavení", symbol: "gearshape.2", color: .systemPurple)
        let controlsMenu = NSMenu(title: "Nastavení")
        controlsMenu.autoenablesItems = false

        macStatusItem = NSMenuItem(title: "Mac agent: kontroluji…", action: nil, keyEquivalent: "")
        macStatusItem.isEnabled = true
        controlsMenu.addItem(macStatusItem)
        windowsStatusItem = NSMenuItem(title: "Windows klient: kontroluji…", action: nil, keyEquivalent: "")
        windowsStatusItem.isEnabled = true
        controlsMenu.addItem(windowsStatusItem)
        trackingStatusItem = NSMenuItem(title: "Sledování: kontroluji…", action: nil, keyEquivalent: "")
        trackingStatusItem.isEnabled = true
        controlsMenu.addItem(trackingStatusItem)
        controlsMenu.addItem(.separator())

        startAgentItem = item("Spustit Mac agent", symbol: "play.circle.fill", action: #selector(startAgent))
        restartAgentItem = item("Restartovat Mac agent", symbol: "arrow.clockwise.circle.fill", action: #selector(restartAgent))
        stopAgentItem = item("Zastavit Mac agent", symbol: "stop.circle.fill", action: #selector(stopAgent))
        controlsMenu.addItem(startAgentItem)
        controlsMenu.addItem(restartAgentItem)
        controlsMenu.addItem(stopAgentItem)
        controlsMenu.addItem(.separator())
        pauseAgentItem = item("Pozastavit sledování", symbol: "pause.circle.fill", action: #selector(pauseAgent))
        resumeAgentItem = item("Pokračovat ve sledování", symbol: "play.circle.fill", action: #selector(resumeAgent))
        controlsMenu.addItem(pauseAgentItem)
        controlsMenu.addItem(resumeAgentItem)
        controls.submenu = controlsMenu
        menu.addItem(controls)

        statusItem.menu = nil
        if let button = statusItem.button {
            button.target = self
            button.action = #selector(handleStatusItemInteraction)
            button.sendAction(on: [.leftMouseUp, .rightMouseUp])
        }
        applyMainMenuSearchFilter()
        installClassicMenuNavigator()
    }

    // MARK: - Refresh

    @objc func tickClock() {
        applyIntranetStatusToUI()
        modernMenuPanel?.refreshLiveContent()
    }

    @objc func refreshAll() {
        if refreshInFlight {
            return
        }

        refreshInFlight = true

        DispatchQueue.global(qos: .utility).async { [weak self] in
            guard let self = self else {
                return
            }

            let q = self.quick()

            DispatchQueue.main.async { [weak self] in
                guard let self = self else {
                    return
                }

                self.refreshInFlight = false
                if let q { self.applyRefresh(q) }
                else { self.applyRefreshFailure() }
            }
        }
    }

    private func applyRefreshFailure() {
        macStatusItem.attributedTitle = statusAttributed(
            label: "Mac agent",
            value: cachedAgent ? "● POSLEDNÍ STAV ONLINE" : "● STAV NEOVĚŘEN",
            color: .systemOrange,
            symbol: "desktopcomputer"
        )
        windowsStatusItem.attributedTitle = statusAttributed(
            label: "Windows klient",
            value: cachedWindows == "NIKDY" ? "● STAV NEOVĚŘEN" : "● POSLEDNÍ STAV \(cachedWindows)",
            color: .systemOrange,
            symbol: "pc"
        )
        trackingStatusItem.attributedTitle = statusAttributed(
            label: "Sledování",
            value: "● OBNOVA STAVU SELHALA",
            color: .systemOrange,
            symbol: "exclamationmark.triangle"
        )
    }

    private func applyRefresh(_ q: [String: Any]) {



        let agent =
            (q["agent_running"] as? Bool)
            ?? false

        let windows =
            (q["windows"] as? String)
            ?? "NIKDY"

        let windowsAge =
            q["windows_last_seconds"]
            as? Double

        let trackingPaused =
            (q["paused"] as? Bool)
            ?? false

        cachedAgent = agent
        cachedWindows = windows

        // Mac agent status
        if agent {
            macStatusItem.attributedTitle =
                statusAttributed(
                    label: "Mac agent",
                    value: "● ONLINE",
                    color: .systemGreen,
                    symbol: "desktopcomputer"
                )
        } else {
            macStatusItem.attributedTitle =
                statusAttributed(
                    label: "Mac agent",
                    value: "● OFFLINE",
                    color: .systemRed,
                    symbol: "desktopcomputer"
                )
        }

        // Windows status
        if windows == "ONLINE" {

            let age =
                Int(
                    windowsAge
                    ?? 0
                )

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● ONLINE · \(age) s",
                    color: .systemGreen,
                    symbol: "pc"
                )

        } else if windows == "ZPOZDENI" {

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● ZPOŽDĚNÍ",
                    color: .systemOrange,
                    symbol: "pc"
                )

        } else if windows == "OFFLINE" {

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● OFFLINE",
                    color: .systemRed,
                    symbol: "pc"
                )

        } else {

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● BEZ DAT",
                    color: .systemOrange,
                    symbol: "pc"
                )
        }

        trackingStatusItem.attributedTitle = statusAttributed(
            label: "Sledování",
            value: agent ? (trackingPaused ? "⏸ POZASTAVENO" : "● AKTIVNÍ") : "● NEAKTIVNÍ",
            color: agent ? (trackingPaused ? .systemOrange : .systemGreen) : .systemRed,
            symbol: trackingPaused ? "pause.circle.fill" : "eye.fill"
        )

        // Agent action visibility
        startAgentItem.isHidden = agent
        restartAgentItem.isHidden = !agent
        stopAgentItem.isHidden = !agent
        pauseAgentItem.isHidden = !agent || trackingPaused
        resumeAgentItem.isHidden = !agent || !trackingPaused

        applyIntranetStatusToUI()
        reconcileTrackingWithIntranet(agent: agent, trackingPaused: trackingPaused)
    
    }

    private func reconcileTrackingWithIntranet(agent: Bool, trackingPaused: Bool) {
        guard intranetSnapshot.dataState == "current", !trackingReconciliationInFlight else { return }
        let desiredActive = ["in_building", "home_office", "offsite"]
            .contains(intranetSnapshot.currentState)
        let command: [String]?
        if desiredActive, !agent {
            command = ["spustit"]
        } else if desiredActive, trackingPaused {
            command = ["pokracovat"]
        } else if !desiredActive, agent, !trackingPaused {
            command = ["pauza"]
        } else {
            command = nil
        }
        guard let command else { return }
        trackingReconciliationInFlight = true
        DispatchQueue.global(qos: .utility).async { [weak self] in
            guard let self else { return }
            _ = self.runWork(command)
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.35) {
                self.trackingReconciliationInFlight = false
                self.refreshAll()
            }
        }
    }

    // MARK: - Agent control

    func ensureAgent() -> Bool {

        let q1 = quick()

        if
            (
                q1?[
                    "agent_running"
                ]
                as? Bool
            )
            == true
        {
            return true
        }

        _ = runWork(
            [
                "spustit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1.5
        )

        let q2 = quick()

        return
            (
                q2?[
                    "agent_running"
                ]
                as? Bool
            )
            == true
    }

    @objc func startAgent() {

        _ = runWork(
            [
                "spustit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        refreshAll()
    }

    @objc func restartAgent() {

        _ = runWork(
            [
                "zastavit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        _ = runWork(
            [
                "spustit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        refreshAll()
    }

    @objc func stopAgent() {

        _ = runWork(
            [
                "zastavit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        refreshAll()
    }

    // MARK: - Shift control

    func startShift(
        _ mode: String
    ) {
        executeIntranetPunch(mode == "office" ? "arrival" : "home_start")
    }

    @objc func startOffice() {
        startShift(
            "office"
        )
    }

    @objc func startHome() {
        startShift(
            "homeoffice"
        )
    }

    @objc func stopShift() {
        switch intranetSnapshot.currentState {
        case "home_office":
            executeIntranetPunch("home_end")
        case "in_building":
            executeIntranetPunch("departure")
        case "on_break", "doctor", "offsite":
            showAlert(
                "Evora Intranet",
                "Nejdřív ukončete aktuální stav „\(intranetStateLabel(intranetSnapshot.currentState))“ v nabídce Evora Intranet."
            )
        default:
            showAlert("Evora Intranet", "Pracovní doba už není aktivní.")
        }
    }

    // MARK: - Alerts

    func contextualDialogIcon(_ context: String) -> NSImage {
        let normalized = context.folding(
            options: [.caseInsensitive, .diacriticInsensitive],
            locale: Locale(identifier: "cs_CZ")
        ).lowercased()
        let problems = [
            "chyba", "chybi", "neplatn", "nepodar", "selhal", "nedokazal",
            "povinn", "vyprsel", "nejsou aktualni", "odmitnut"
        ]
        let symbol: (name: String, color: NSColor)?
        if problems.contains(where: normalized.contains) {
            symbol = ("exclamationmark.triangle.fill", .systemRed)
        } else if normalized.contains("dovolen") || normalized.contains("absence") || normalized.contains("volno") {
            symbol = ("calendar.badge.plus", .systemGreen)
        } else if normalized.contains("ticket") || normalized.contains("portal") {
            symbol = ("ticket.fill", .systemBlue)
        } else if normalized.contains("priloh") {
            symbol = ("paperclip", .systemBlue)
        } else if normalized.contains("hesl") || normalized.contains("klicenk") || normalized.contains("zabezpec") {
            symbol = ("lock.shield.fill", .systemPurple)
        } else if normalized.contains("config") {
            symbol = ("wrench.and.screwdriver.fill", .systemOrange)
        } else if normalized.contains("intranet") || normalized.contains("dochazk") || normalized.contains("prichod") || normalized.contains("odchod") {
            return intranetMenuLogo(size: NSSize(width: 64, height: 64))
        } else if normalized.contains("souhrn") || normalized.contains("vykaz") || normalized.contains("report") {
            symbol = ("doc.text.magnifyingglass", .systemTeal)
        } else if normalized.contains("worklog") || normalized.contains("zaznam") || normalized.contains("poznamk") {
            symbol = ("clock.badge.checkmark", .systemGreen)
        } else {
            symbol = nil
        }
        guard let symbol,
              let image = NSImage(
                systemSymbolName: symbol.name,
                accessibilityDescription: context
              )?.withSymbolConfiguration(
                NSImage.SymbolConfiguration(pointSize: 48, weight: .medium).applying(
                    NSImage.SymbolConfiguration(paletteColors: [symbol.color])
                )
              )
        else {
            return evoraSmartHubIcon(size: NSSize(width: 64, height: 64))
        }
        image.isTemplate = false
        return image
    }

    func makeContextualAlert(
        _ title: String,
        _ body: String = "",
        iconContext: String? = nil
    ) -> NSAlert {
        let alert = NSAlert()
        alert.messageText = title
        alert.informativeText = body
        alert.icon = contextualDialogIcon(iconContext ?? "\(title) \(body)")
        return alert
    }

    func showAlert(
        _ title: String,
        _ body: String
    ) {

        if modernMenuPanel?.isVisible == true {
            modernMenuPanel?.showInlineNotice(
                title: title,
                body: body,
                color: modernPanelColorForNotice(title: title, body: body)
            )
            return
        }

        NSApp.activate(
            ignoringOtherApps: true
        )

        let alert = makeContextualAlert(title, body)

        alert.addButton(
            withTitle: "OK"
        )

        alert.runModal()
    }

    func modernPanelColorForNotice(title: String, body: String) -> NSColor {
        let value = "\(title) \(body)".folding(
            options: [.caseInsensitive, .diacriticInsensitive],
            locale: Locale(identifier: "cs_CZ")
        ).lowercased()
        if ["chyba", "selhal", "nepodar", "neplatn", "odmitnut"].contains(where: value.contains) {
            return .systemRed
        }
        if value.contains("zkopirovano") || value.contains("uspes") || value.contains("otevren") {
            return .systemGreen
        }
        return .systemBlue
    }

    func showScrollableAlert(
        _ title: String,
        _ body: String
    ) {

        NSApp.activate(
            ignoringOtherApps: true
        )

        let alert = makeContextualAlert(title, iconContext: "souhrn výkaz report")
        alert.addButton(withTitle: "Zavřít")

        let scroll = NSScrollView(
            frame: NSRect(
                x: 0,
                y: 0,
                width: 560,
                height: 500
            )
        )

        scroll.hasVerticalScroller = true
        scroll.hasHorizontalScroller = false
        scroll.autohidesScrollers = true
        scroll.borderType = .bezelBorder

        let textView = NSTextView(
            frame: NSRect(
                x: 0,
                y: 0,
                width: 540,
                height: 500
            )
        )

        textView.isEditable = false
        textView.isSelectable = true
        textView.drawsBackground = false
        textView.isRichText = false
        textView.font = NSFont.monospacedSystemFont(
            ofSize: 12,
            weight: .regular
        )
        textView.textContainerInset = NSSize(
            width: 10,
            height: 10
        )
        textView.textContainer?.widthTracksTextView = true
        textView.textContainer?.containerSize = NSSize(
            width: 540,
            height: CGFloat.greatestFiniteMagnitude
        )
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.autoresizingMask = [.width]
        textView.string = body

        scroll.documentView = textView
        alert.accessoryView = scroll

        alert.runModal()
    }

    func inputDialog(
        _ title: String,
        command: String
    ) {

        NSApp.activate(
            ignoringOtherApps: true
        )

        let alert = makeContextualAlert(
            title,
            "Napiš stručně, co se řešilo. Délka v minutách je volitelná.",
            iconContext: "WorkLog záznam"
        )

        alert.addButton(
            withTitle: "Uložit"
        )

        alert.addButton(
            withTitle: "Zrušit"
        )

        let container =
            NSView(
                frame:
                    NSRect(
                        x: 0,
                        y: 0,
                        width: 440,
                        height: 72
                    )
            )

        let textField =
            NSTextField(
                frame:
                    NSRect(
                        x: 0,
                        y: 40,
                        width: 440,
                        height: 26
                    )
            )

        textField.placeholderString =
            "Co se řešilo?"

        let minutesField =
            NSTextField(
                frame:
                    NSRect(
                        x: 0,
                        y: 4,
                        width: 180,
                        height: 26
                    )
            )

        minutesField.placeholderString =
            "Délka v minutách"

        container.addSubview(
            textField
        )

        container.addSubview(
            minutesField
        )

        alert.accessoryView =
            container

        alert.window
            .initialFirstResponder =
            textField

        guard
            alert.runModal()
            == .alertFirstButtonReturn
        else {
            return
        }

        let body =
            textField
                .stringValue
                .trimmingCharacters(
                    in:
                        .whitespacesAndNewlines
                )

        if body.isEmpty {
            return
        }

        var args =
            [
                command,
                body
            ]

        let mins =
            minutesField
                .stringValue
                .trimmingCharacters(
                    in:
                        .whitespacesAndNewlines
                )

        if !mins.isEmpty {

            args +=
                [
                    "--minutes",
                    mins
                ]
        }

        showAlert(
            "WorkLog",
            runWork(args)
        )
    }

    // MARK: - Manual entries

    @objc func addNote() {
        inputDialog(
            "Přidat poznámku",
            command:
                "poznamka"
        )
    }

    @objc func addCall() {
        inputDialog(
            "Telefon / hovor",
            command:
                "hovor"
        )
    }

    @objc func addTravel() {
        inputDialog(
            "Výjezd / cesta",
            command:
                "vyjezd"
        )
    }

    @objc func addOffPC() {
        inputDialog(
            "Práce mimo PC",
            command:
                "mimo-pc"
        )
    }

    // MARK: - Reports

    @objc func showSummary() {
        showAlert(
            "Průběžný souhrn",
            runWork(
                [
                    "souhrn"
                ]
            )
        )
    }

    @objc func showAISummary() {
        showAlert(
            "AI souhrn",
            runWork(
                [
                    "souhrn-ai"
                ]
            )
        )
    }

    @objc func showRecent() {
        showScrollableAlert(
            "Poslední aktivita",
            runWork(
                [
                    "posledni",
                    "8"
                ]
            )
        )
    }

    @objc func makeReport() {
        showAlert(
            "Výkaz práce",
            runWork(
                [
                    "vykaz"
                ]
            )
        )
    }

    @objc func openExcel() {

        NSWorkspace.shared.open(
            URL(
                fileURLWithPath:
                    "\(runtimeRoot)/Pracovni_vykaz.xlsx"
            )
        )
    }

    // MARK: - Evora actions

    func evoraTextView(_ value: String, width: CGFloat = 560, height: CGFloat = 360) -> NSScrollView {
        let scroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        scroll.hasVerticalScroller = true
        scroll.hasHorizontalScroller = false
        scroll.autohidesScrollers = true
        scroll.borderType = .bezelBorder
        let textView = NSTextView(frame: NSRect(x: 0, y: 0, width: width - 20, height: height))
        textView.isEditable = false
        textView.isSelectable = true
        textView.drawsBackground = false
        textView.isRichText = false
        textView.font = NSFont.systemFont(ofSize: 12)
        textView.textContainerInset = NSSize(width: 10, height: 10)
        textView.textContainer?.widthTracksTextView = true
        textView.textContainer?.containerSize = NSSize(width: width - 20, height: CGFloat.greatestFiniteMagnitude)
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.autoresizingMask = [.width]
        textView.string = value
        scroll.documentView = textView
        return scroll
    }

    func evoraAttributedTextView(_ value: NSAttributedString, width: CGFloat = 560, height: CGFloat = 360) -> NSScrollView {
        let scroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        scroll.hasVerticalScroller = true
        scroll.hasHorizontalScroller = false
        scroll.autohidesScrollers = true
        scroll.scrollerStyle = .overlay
        scroll.verticalScrollElasticity = .automatic
        scroll.horizontalScrollElasticity = .none
        scroll.usesPredominantAxisScrolling = true
        scroll.borderType = .noBorder
        let textView = NSTextView(frame: NSRect(x: 0, y: 0, width: width - 20, height: height))
        textView.isEditable = false
        textView.isSelectable = true
        textView.isRichText = true
        textView.drawsBackground = true
        textView.backgroundColor = .windowBackgroundColor
        textView.textContainerInset = NSSize(width: 12, height: 12)
        textView.textContainer?.widthTracksTextView = true
        textView.textContainer?.containerSize = NSSize(width: width - 20, height: CGFloat.greatestFiniteMagnitude)
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.autoresizingMask = [.width]
        textView.textStorage?.setAttributedString(value)
        scroll.documentView = textView
        return scroll
    }

    func evoraPortalTicketText(_ ticket: EvoraPortalTicketDetail) -> String {
        var sections: [String] = [
            "#\(ticket.ticketNumber) · \(evoraPortalTicketStatus(ticket.status))",
            ticket.subject,
            "Kontakt: \(ticket.contactName.isEmpty ? "neuveden" : ticket.contactName)",
            "Založeno: \(ticket.createdTime)"
        ]
        if !ticket.attachments.isEmpty {
            sections.append("Přílohy ticketu: \(ticket.attachments.map(\.name).joined(separator: ", "))")
        }
        for thread in ticket.threads {
            let fullName = "\(thread.author.firstName) \(thread.author.lastName)"
                .trimmingCharacters(in: .whitespacesAndNewlines)
            let author = fullName.isEmpty
                ? (thread.author.isLoxone ? "LOXONE podpora" : "Evora Smart")
                : fullName
            var message = "\(thread.createdTime) · \(author)\(thread.author.isLoxone ? " · LOXONE" : "")\n\n\(thread.content)"
            if !thread.attachments.isEmpty {
                message += "\n\nPřílohy: \(thread.attachments.map(\.name).joined(separator: ", "))"
            }
            sections.append(message)
        }
        return sections.joined(separator: "\n\n────────────────────────\n\n")
    }

    func evoraPortalAttachmentKey(_ attachment: EvoraPortalTicketAttachment) -> String {
        "\(attachment.id)\n\(attachment.name)"
    }

    func evoraPortalAttachmentIsImage(_ attachment: EvoraPortalTicketAttachment) -> Bool {
        let name = attachment.name.lowercased()
        return [".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp"].contains { name.hasSuffix($0) }
    }

    func loadEvoraPortalImagePreviews(
        _ attachments: [EvoraPortalTicketAttachment],
        completion: @escaping ([String: NSImage]) -> Void
    ) {
        let images = attachments.filter { $0.canDownload && evoraPortalAttachmentIsImage($0) }
        guard !images.isEmpty else {
            completion([:])
            return
        }
        let group = DispatchGroup()
        var previews: [String: NSImage] = [:]
        for attachment in images {
            group.enter()
            downloadEvoraPortalAttachment(attachment) { result in
                let image: NSImage?
                switch result {
                case .success(let file):
                    image = NSImage(contentsOf: file)
                    try? FileManager.default.removeItem(at: file.deletingLastPathComponent())
                case .failure:
                    image = nil
                }
                DispatchQueue.main.async {
                    if let image {
                        image.isTemplate = false
                        previews[self.evoraPortalAttachmentKey(attachment)] = image
                    }
                    group.leave()
                }
            }
        }
        group.notify(queue: .main) {
            completion(previews)
        }
    }

    func evoraPortalTicketAttributedText(
        _ ticket: EvoraPortalTicketDetail,
        imagePreviews: [String: NSImage] = [:],
        maximumImageSize: NSSize = NSSize(width: 500, height: 260)
    ) -> NSAttributedString {
        let result = NSMutableAttributedString()
        let bodyStyle = NSMutableParagraphStyle()
        bodyStyle.lineSpacing = 3
        bodyStyle.paragraphSpacing = 8
        let bubbleStyle = NSMutableParagraphStyle()
        bubbleStyle.lineSpacing = 4
        bubbleStyle.paragraphSpacing = 14
        bubbleStyle.firstLineHeadIndent = 10
        bubbleStyle.headIndent = 10
        bubbleStyle.tailIndent = -10

        func append(_ text: String, _ attributes: [NSAttributedString.Key: Any]) {
            result.append(NSAttributedString(string: text, attributes: attributes))
        }

        func appendAttachments(_ attachments: [EvoraPortalTicketAttachment]) {
            guard !attachments.isEmpty else { return }
            for attachment in attachments {
                append("📎  \(attachment.name)\n", [
                    .font: NSFont.systemFont(ofSize: 10, weight: .medium),
                    .foregroundColor: attachment.canDownload ? NSColor.systemBlue : NSColor.labelColor,
                    .paragraphStyle: bodyStyle
                ])
                if let source = imagePreviews[evoraPortalAttachmentKey(attachment)] {
                    let image = (source.copy() as? NSImage) ?? source
                    let sourceSize = image.size
                    if sourceSize.width > 0, sourceSize.height > 0 {
                        let scale = min(
                            1,
                            maximumImageSize.width / sourceSize.width,
                            maximumImageSize.height / sourceSize.height
                        )
                        image.size = NSSize(width: sourceSize.width * scale, height: sourceSize.height * scale)
                    }
                    let imageAttachment = NSTextAttachment()
                    imageAttachment.image = image
                    result.append(NSAttributedString(attachment: imageAttachment))
                    append("\n\n", [.paragraphStyle: bodyStyle])
                } else if !attachment.canDownload {
                    append("Portál poskytl pouze název; soubor přes API neposkytuje.\n\n", [
                        .font: NSFont.systemFont(ofSize: 9),
                        .foregroundColor: NSColor.secondaryLabelColor,
                        .paragraphStyle: bodyStyle
                    ])
                }
            }
        }

        append("#\(ticket.ticketNumber) · \(evoraPortalTicketStatus(ticket.status))\n", [
            .font: NSFont.boldSystemFont(ofSize: 13),
            .foregroundColor: evoraPortalTicketColor(ticket.status),
            .paragraphStyle: bodyStyle
        ])
        append("\(ticket.subject)\nKontakt: \(ticket.contactName.isEmpty ? "neuveden" : ticket.contactName) · Založeno: \(ticket.createdTime)\n\n", [
            .font: NSFont.systemFont(ofSize: 12),
            .foregroundColor: NSColor.labelColor,
            .paragraphStyle: bodyStyle
        ])
        appendAttachments(ticket.attachments)

        for thread in ticket.threads {
            let fullName = "\(thread.author.firstName) \(thread.author.lastName)"
                .trimmingCharacters(in: .whitespacesAndNewlines)
            let author = fullName.isEmpty
                ? (thread.author.isLoxone ? "LOXONE podpora" : "Evora Smart")
                : fullName
            let accent = thread.author.isLoxone ? NSColor.systemGreen : NSColor.systemTeal
            append("●  \(author)\n", [
                .font: NSFont.boldSystemFont(ofSize: 11),
                .foregroundColor: accent,
                .paragraphStyle: bodyStyle
            ])
            append("\(thread.createdTime)\n", [
                .font: NSFont.systemFont(ofSize: 9),
                .foregroundColor: NSColor.secondaryLabelColor,
                .paragraphStyle: bodyStyle
            ])
            append("\(thread.content.trimmingCharacters(in: .whitespacesAndNewlines))\n", [
                .font: NSFont.systemFont(ofSize: 12),
                .foregroundColor: NSColor.labelColor,
                .paragraphStyle: bubbleStyle
            ])
            appendAttachments(thread.attachments)
        }
        return result
    }

    func evoraClassicTicketNoticeItem(
        title: String,
        detail: String,
        symbol: String,
        color: NSColor,
        spinning: Bool
    ) -> NSMenuItem {
        let item = NSMenuItem()
        let width: CGFloat = 420
        let height: CGFloat = 112
        let wrapper = NSView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        let card = ClassicMenuAdaptiveView(frame: NSRect(x: 8, y: 4, width: width - 16, height: height - 8))
        card.wantsLayer = true
        card.layer?.cornerRadius = 16
        card.layer?.cornerCurve = .continuous
        card.layer?.borderWidth = 0.5
        wrapper.addSubview(card)

        let iconFrame = NSRect(x: 18, y: 31, width: 42, height: 42)
        let iconView: NSView
        if spinning {
            let progress = NSProgressIndicator(frame: iconFrame)
            progress.style = .spinning
            progress.controlSize = .regular
            progress.startAnimation(nil)
            iconView = progress
        } else {
            let image = NSImageView(frame: iconFrame)
            image.image = sf(symbol, color: color)
            image.contentTintColor = color
            image.imageScaling = .scaleProportionallyDown
            iconView = image
        }
        card.addSubview(iconView)

        let titleField = NSTextField(labelWithString: title)
        titleField.frame = NSRect(x: 74, y: 58, width: 304, height: 22)
        titleField.font = .systemFont(ofSize: 14, weight: .semibold)
        titleField.lineBreakMode = .byTruncatingTail
        card.addSubview(titleField)

        let detailField = NSTextField(wrappingLabelWithString: detail)
        detailField.frame = NSRect(x: 74, y: 21, width: 304, height: 34)
        detailField.font = .systemFont(ofSize: 10.5, weight: .regular)
        detailField.maximumNumberOfLines = 2
        card.addSubview(detailField)

        card.appearanceHandler = { [weak titleField, weak detailField] view in
            view.layer?.backgroundColor = evoraMenuSurfaceColor(view, elevated: true).cgColor
            view.layer?.borderColor = evoraMenuBorderColor(view).cgColor
            titleField?.textColor = evoraMenuPrimaryTextColor(view)
            detailField?.textColor = evoraMenuSecondaryTextColor(view)
        }
        card.refreshAppearance()
        item.view = wrapper
        item.isEnabled = true
        return item
    }

    func evoraClassicTicketContentItem(
        _ ticket: EvoraPortalTicketDetail,
        imagePreviews: [String: NSImage]
    ) -> NSMenuItem {
        let item = NSMenuItem()
        let width: CGFloat = 420
        let cardWidth = width - 16
        let textWidth = cardWidth - 24
        let attributed = evoraPortalTicketAttributedText(
            ticket,
            imagePreviews: imagePreviews,
            maximumImageSize: NSSize(width: textWidth - 28, height: 230)
        )

        let measuringStorage = NSTextStorage(attributedString: attributed)
        let measuringLayout = NSLayoutManager()
        let measuringContainer = NSTextContainer(containerSize: NSSize(
            width: textWidth - 20,
            height: CGFloat.greatestFiniteMagnitude
        ))
        measuringContainer.lineFragmentPadding = 5
        measuringContainer.widthTracksTextView = false
        measuringContainer.heightTracksTextView = false
        measuringStorage.addLayoutManager(measuringLayout)
        measuringLayout.addTextContainer(measuringContainer)
        measuringLayout.ensureLayout(for: measuringContainer)
        let measuredHeight = ceil(measuringLayout.usedRect(for: measuringContainer).height + 24)
        let textHeight = min(max(120, measuredHeight), 6000)

        let textView = NSTextView(frame: NSRect(x: 0, y: 0, width: textWidth, height: textHeight))
        textView.isEditable = false
        textView.isSelectable = true
        textView.isRichText = true
        textView.drawsBackground = false
        textView.textContainerInset = NSSize(width: 10, height: 10)
        textView.textContainer?.widthTracksTextView = true
        textView.textContainer?.heightTracksTextView = false
        textView.textContainer?.containerSize = NSSize(
            width: textWidth,
            height: CGFloat.greatestFiniteMagnitude
        )
        textView.minSize = NSSize(width: textWidth, height: textHeight)
        textView.maxSize = NSSize(width: textWidth, height: textHeight)
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.textStorage?.setAttributedString(attributed)

        let totalHeight = textHeight + 24
        let wrapper = NSView(frame: NSRect(x: 0, y: 0, width: width, height: totalHeight))
        let card = ClassicMenuAdaptiveView(frame: NSRect(x: 8, y: 4, width: cardWidth, height: totalHeight - 8))
        card.wantsLayer = true
        card.layer?.cornerRadius = 16
        card.layer?.cornerCurve = .continuous
        card.layer?.borderWidth = 0.5
        textView.frame = NSRect(x: 12, y: 8, width: textWidth, height: textHeight)
        card.addSubview(textView)
        wrapper.addSubview(card)
        card.appearanceHandler = { [weak textView] view in
            view.layer?.backgroundColor = evoraMenuSurfaceColor(view, elevated: true).cgColor
            view.layer?.borderColor = evoraMenuBorderColor(view).cgColor
            textView?.backgroundColor = .clear
        }
        card.refreshAppearance()
        item.view = wrapper
        item.isEnabled = true
        return item
    }

    func evoraStyleClassicFormButton(
        _ button: ClassicMenuClosureButton,
        title: String,
        color: NSColor
    ) {
        button.isBordered = false
        button.focusRingType = .none
        button.wantsLayer = true
        button.layer?.cornerRadius = 11
        button.layer?.cornerCurve = .continuous
        button.layer?.backgroundColor = color.cgColor
        button.attributedTitle = NSAttributedString(
            string: title,
            attributes: [
                .font: NSFont.systemFont(ofSize: 11.5, weight: .semibold),
                .foregroundColor: NSColor.white,
            ]
        )
        button.pressChanged = { [weak button] pressed in
            button?.alphaValue = pressed ? 0.70 : 1
        }
    }

    func evoraClassicTicketComposerMenu(
        ticket: EvoraPortalTicketDetail?,
        draft: EvoraPortalDraft? = nil
    ) -> NSMenu {
        let isReply = ticket != nil
        let menu = NSMenu(title: isReply ? "Odpověď do ticketu" : "Nový LOXONE ticket")
        menu.autoenablesItems = false
        let item = NSMenuItem()
        let width: CGFloat = 420
        let height: CGFloat = 330
        let wrapper = NSView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        let card = ClassicMenuAdaptiveView(frame: NSRect(x: 8, y: 4, width: width - 16, height: height - 8))
        card.wantsLayer = true
        card.layer?.cornerRadius = 16
        card.layer?.cornerCurve = .continuous
        card.layer?.borderWidth = 0.5
        wrapper.addSubview(card)

        let subjectLabel = NSTextField(labelWithString: "Předmět")
        subjectLabel.frame = NSRect(x: 16, y: 288, width: 372, height: 17)
        subjectLabel.font = .systemFont(ofSize: 10.5, weight: .semibold)
        card.addSubview(subjectLabel)

        let subjectField = NSTextField(frame: NSRect(x: 16, y: 257, width: 372, height: 26))
        subjectField.stringValue = draft?.subject ?? ticket?.subject ?? ""
        subjectField.isEditable = !isReply
        subjectField.isSelectable = true
        subjectField.font = .systemFont(ofSize: 11.5)
        card.addSubview(subjectField)

        let bodyLabel = NSTextField(labelWithString: "Celá veřejná zpráva")
        bodyLabel.frame = NSRect(x: 16, y: 232, width: 372, height: 17)
        bodyLabel.font = .systemFont(ofSize: 10.5, weight: .semibold)
        card.addSubview(bodyLabel)

        let bodyScroll = NSScrollView(frame: NSRect(x: 16, y: 82, width: 372, height: 145))
        bodyScroll.hasVerticalScroller = true
        bodyScroll.autohidesScrollers = true
        bodyScroll.borderType = .noBorder
        bodyScroll.wantsLayer = true
        bodyScroll.layer?.cornerRadius = 10
        bodyScroll.layer?.cornerCurve = .continuous
        bodyScroll.layer?.borderWidth = 0.5
        let bodyField = NSTextView(frame: NSRect(x: 0, y: 0, width: 352, height: 145))
        bodyField.isRichText = false
        bodyField.isEditable = true
        bodyField.isSelectable = true
        bodyField.font = .systemFont(ofSize: 11.5)
        bodyField.textContainerInset = NSSize(width: 9, height: 9)
        bodyField.string = draft?.body ?? ""
        bodyScroll.documentView = bodyField
        card.addSubview(bodyScroll)

        let errorField = NSTextField(wrappingLabelWithString: "")
        errorField.frame = NSRect(x: 16, y: 48, width: 372, height: 28)
        errorField.font = .systemFont(ofSize: 9.5, weight: .medium)
        errorField.textColor = .systemRed
        errorField.maximumNumberOfLines = 2
        card.addSubview(errorField)

        let review = ClassicMenuClosureButton(frame: NSRect(x: 16, y: 10, width: 372, height: 34))
        evoraStyleClassicFormButton(review, title: "Zkontrolovat celý návrh", color: .systemBlue)
        review.handler = { [weak self, weak menu, weak subjectField, weak bodyField, weak errorField] in
            guard let self, let menu, let subjectField, let bodyField, let errorField else { return }
            let subject = subjectField.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
            let body = bodyField.string.trimmingCharacters(in: .whitespacesAndNewlines)
            guard subject.count >= 3 else {
                errorField.stringValue = "Předmět musí mít alespoň 3 znaky."
                return
            }
            guard body.count >= (isReply ? 1 : 3) else {
                errorField.stringValue = "Zpráva je příliš krátká."
                return
            }
            errorField.stringValue = ""
            let nextDraft = EvoraPortalDraft(
                ticketId: ticket?.id,
                ticketNumber: ticket?.ticketNumber,
                subject: subject,
                body: body
            )
            guard self.classicMenuNavigator?.isShowing(menu) == true else { return }
            let reviewMenu = self.evoraClassicTicketReviewMenu(nextDraft)
            self.classicMenuNavigator?.showTransientPage(
                reviewMenu,
                title: "Kontrola před odesláním"
            )
        }
        card.addSubview(review)

        card.appearanceHandler = { [weak subjectLabel, weak subjectField, weak bodyLabel, weak bodyScroll, weak bodyField] view in
            view.layer?.backgroundColor = evoraMenuSurfaceColor(view, elevated: true).cgColor
            view.layer?.borderColor = evoraMenuBorderColor(view).cgColor
            subjectLabel?.textColor = evoraMenuSecondaryTextColor(view)
            bodyLabel?.textColor = evoraMenuSecondaryTextColor(view)
            subjectField?.textColor = evoraMenuPrimaryTextColor(view)
            subjectField?.backgroundColor = evoraMenuSurfaceColor(view)
            bodyField?.textColor = evoraMenuPrimaryTextColor(view)
            bodyField?.backgroundColor = evoraMenuSurfaceColor(view)
            bodyScroll?.layer?.backgroundColor = evoraMenuSurfaceColor(view).cgColor
            bodyScroll?.layer?.borderColor = evoraMenuBorderColor(view).cgColor
        }
        card.refreshAppearance()
        item.view = wrapper
        item.isEnabled = true
        menu.addItem(item)
        return menu
    }

    func evoraClassicTicketReviewMenu(_ draft: EvoraPortalDraft) -> NSMenu {
        let menu = NSMenu(title: "Kontrola před odesláním")
        menu.autoenablesItems = false
        let item = NSMenuItem()
        let width: CGFloat = 420
        let height: CGFloat = 392
        let wrapper = NSView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        let card = ClassicMenuAdaptiveView(frame: NSRect(x: 8, y: 4, width: width - 16, height: height - 8))
        card.wantsLayer = true
        card.layer?.cornerRadius = 16
        card.layer?.cornerCurve = .continuous
        card.layer?.borderWidth = 0.5
        wrapper.addSubview(card)

        let explanation = NSTextField(wrappingLabelWithString: "Níže je celý návrh. Nic se neodešle, dokud nestisknete modré tlačítko.")
        explanation.frame = NSRect(x: 16, y: 340, width: 372, height: 34)
        explanation.font = .systemFont(ofSize: 10.5, weight: .medium)
        explanation.maximumNumberOfLines = 2
        card.addSubview(explanation)

        let preview = "Kam: Loxone Partner Portal\nAkce: \(draft.isReply ? "Veřejná odpověď do #\(draft.ticketNumber ?? "")" : "Vytvořit nový ticket")\nPředmět: \(draft.subject)\n\nCELÝ TEXT ZPRÁVY\n\n\(draft.body)"
        let previewScroll = NSScrollView(frame: NSRect(x: 16, y: 132, width: 372, height: 198))
        previewScroll.hasVerticalScroller = true
        previewScroll.autohidesScrollers = true
        previewScroll.borderType = .noBorder
        previewScroll.wantsLayer = true
        previewScroll.layer?.cornerRadius = 10
        previewScroll.layer?.cornerCurve = .continuous
        previewScroll.layer?.borderWidth = 0.5
        let previewField = NSTextView(frame: NSRect(x: 0, y: 0, width: 352, height: 198))
        previewField.isEditable = false
        previewField.isSelectable = true
        previewField.isRichText = false
        previewField.font = .systemFont(ofSize: 11)
        previewField.textContainerInset = NSSize(width: 9, height: 9)
        previewField.string = preview
        previewScroll.documentView = previewField
        card.addSubview(previewScroll)

        let passwordLabel = NSTextField(labelWithString: "Jednorázové potvrzení heslem")
        passwordLabel.frame = NSRect(x: 16, y: 106, width: 372, height: 17)
        passwordLabel.font = .systemFont(ofSize: 10.5, weight: .semibold)
        card.addSubview(passwordLabel)
        let password = NSSecureTextField(frame: NSRect(x: 16, y: 76, width: 372, height: 26))
        password.placeholderString = "Heslo do Evora Smart Hubu"
        password.font = .systemFont(ofSize: 11.5)
        card.addSubview(password)

        let errorField = NSTextField(labelWithString: "")
        errorField.frame = NSRect(x: 16, y: 49, width: 372, height: 18)
        errorField.font = .systemFont(ofSize: 9.5, weight: .medium)
        errorField.textColor = .systemRed
        errorField.lineBreakMode = .byTruncatingTail
        card.addSubview(errorField)

        let send = ClassicMenuClosureButton(frame: NSRect(x: 16, y: 10, width: 372, height: 34))
        evoraStyleClassicFormButton(
            send,
            title: draft.isReply ? "Potvrdit a odeslat odpověď" : "Potvrdit a vytvořit ticket",
            color: .systemBlue
        )
        send.handler = { [weak self, weak menu, weak password, weak errorField, weak send] in
            guard let self, let menu, let password, let errorField, let send else { return }
            let passwordValue = password.stringValue
            guard !passwordValue.isEmpty else {
                errorField.stringValue = "Heslo je povinné."
                return
            }
            errorField.stringValue = "Ověřuji a odesílám…"
            errorField.textColor = .systemBlue
            send.isEnabled = false
            password.isEnabled = false
            self.sendEvoraPortalDraftInline(
                draft,
                password: passwordValue,
                sourceMenu: menu
            ) { result in
                password.stringValue = ""
                switch result {
                case .success:
                    let success = NSMenu(title: "Hotovo")
                    success.autoenablesItems = false
                    success.addItem(self.evoraClassicTicketNoticeItem(
                        title: draft.isReply ? "Odpověď byla odeslána" : "Ticket byl vytvořen",
                        detail: "Evora Smart Hub potvrdil bezpečné dokončení požadavku.",
                        symbol: "checkmark.circle.fill",
                        color: .systemGreen,
                        spinning: false
                    ))
                    _ = self.classicMenuNavigator?.replaceTransientPage(
                        expected: menu,
                        with: success,
                        title: "Hotovo"
                    )
                    self.refreshEvoraTickets()
                case .failure(let error):
                    errorField.stringValue = error.localizedDescription
                    errorField.textColor = .systemRed
                    send.isEnabled = true
                    password.isEnabled = true
                }
            }
        }
        card.addSubview(send)

        card.appearanceHandler = { [weak explanation, weak previewScroll, weak previewField, weak passwordLabel, weak password] view in
            view.layer?.backgroundColor = evoraMenuSurfaceColor(view, elevated: true).cgColor
            view.layer?.borderColor = evoraMenuBorderColor(view).cgColor
            explanation?.textColor = evoraMenuSecondaryTextColor(view)
            previewField?.textColor = evoraMenuPrimaryTextColor(view)
            previewField?.backgroundColor = evoraMenuSurfaceColor(view)
            previewScroll?.layer?.backgroundColor = evoraMenuSurfaceColor(view).cgColor
            previewScroll?.layer?.borderColor = evoraMenuBorderColor(view).cgColor
            passwordLabel?.textColor = evoraMenuSecondaryTextColor(view)
            password?.textColor = evoraMenuPrimaryTextColor(view)
            password?.backgroundColor = evoraMenuSurfaceColor(view)
        }
        card.refreshAppearance()
        item.view = wrapper
        item.isEnabled = true
        menu.addItem(item)
        return menu
    }

    func sendEvoraPortalDraftInline(
        _ draft: EvoraPortalDraft,
        password: String,
        sourceMenu: NSMenu,
        completion: @escaping (Result<Void, Error>) -> Void
    ) {
        let action = draft.isReply ? "portal_ticket_reply" : "portal_ticket_create"
        let confirmationPayload: [String: Any] = draft.isReply
            ? ["ticketId": draft.ticketId ?? "", "content": draft.body]
            : ["subject": draft.subject, "description": draft.body]
        evoraRequest(
            path: "/api/integrations/worklog/v1/portal-tickets/confirm",
            method: "POST",
            body: ["action": action, "password": password, "payload": confirmationPayload]
        ) { [weak self, weak sourceMenu] (confirmation: Result<EvoraConfirmationResponse, Error>) in
            DispatchQueue.main.async {
                guard let self, let sourceMenu,
                      self.classicMenuNavigator?.isShowing(sourceMenu) == true
                else { return }
                switch confirmation {
                case .failure(let error):
                    completion(.failure(error))
                case .success(let response):
                    let path = draft.isReply
                        ? "/api/integrations/worklog/v1/portal-tickets/\(draft.ticketId ?? "")/replies"
                        : "/api/integrations/worklog/v1/portal-tickets"
                    let body: [String: Any] = draft.isReply
                        ? ["content": draft.body]
                        : ["subject": draft.subject, "description": draft.body]
                    self.evoraRequest(
                        path: path,
                        method: "POST",
                        body: body,
                        headers: ["X-Action-Confirmation": response.confirmationId]
                    ) { [weak self, weak sourceMenu] (result: Result<EvoraPortalMutationResponse, Error>) in
                        DispatchQueue.main.async {
                            guard let self, let sourceMenu,
                                  self.classicMenuNavigator?.isShowing(sourceMenu) == true
                            else { return }
                            switch result {
                            case .success:
                                completion(.success(()))
                            case .failure(let error):
                                completion(.failure(error))
                            }
                        }
                    }
                }
            }
        }
    }

    func evoraClassicTicketDetailMenu(
        _ ticket: EvoraPortalTicketDetail,
        imagePreviews: [String: NSImage]
    ) -> NSMenu {
        let detail = NSMenu(title: "#\(ticket.ticketNumber)")
        detail.autoenablesItems = false
        detail.addItem(evoraClassicTicketContentItem(ticket, imagePreviews: imagePreviews))
        detail.addItem(.separator())

        let reply = NSMenuItem(title: "Odpovědět na ticket…", action: nil, keyEquivalent: "")
        applyMenuIcon(
            to: reply,
            title: "Odpovědět na ticket…",
            symbol: "bubble.left.and.bubble.right",
            color: .systemTeal
        )
        reply.submenu = evoraClassicTicketComposerMenu(ticket: ticket)
        detail.addItem(reply)

        let attachments = evoraPortalTicketAttachments(ticket)
        if !attachments.isEmpty {
            let attachmentsItem = NSMenuItem(
                title: "Přílohy  (\(attachments.count))",
                action: nil,
                keyEquivalent: ""
            )
            applyMenuIcon(
                to: attachmentsItem,
                title: "Přílohy  (\(attachments.count))",
                symbol: "paperclip",
                color: .systemBlue
            )
            let attachmentMenu = NSMenu(title: "Přílohy")
            attachmentMenu.autoenablesItems = false
            for attachment in attachments {
                if attachment.canDownload {
                    let attachmentItem = item(
                        attachment.name,
                        symbol: "doc",
                        action: #selector(openEvoraPortalAttachmentFromClassicMenu(_:)),
                        color: .systemBlue
                    )
                    attachmentItem.representedObject = attachment
                    attachmentMenu.addItem(attachmentItem)
                } else {
                    attachmentMenu.addItem(readOnlyItem(
                        attachment.name,
                        symbol: "doc",
                        color: .secondaryLabelColor
                    ))
                }
            }
            attachmentsItem.submenu = attachmentMenu
            detail.addItem(attachmentsItem)
        }

        detail.addItem(linkItem(
            "Otevřít tiketové centrum v Hubu",
            symbol: "arrow.up.right.square",
            url: "\(evoraHubURL())?page=tickets",
            color: .systemCyan
        ))
        return detail
    }

    func showEvoraPortalTicketInClassicMenu(_ sender: NSMenuItem) {
        guard let id = sender.representedObject as? String,
              let navigator = classicMenuNavigator
        else { return }
        let loading = NSMenu(title: "Načítám ticket…")
        loading.autoenablesItems = false
        loading.addItem(evoraClassicTicketNoticeItem(
            title: "Načítám ticket…",
            detail: "Bezpečně načítám aktuální komunikaci a přílohy z Hubu.",
            symbol: "ticket",
            color: .systemBlue,
            spinning: true
        ))
        navigator.showTransientPage(loading, title: "Načítám ticket…")

        evoraRequest(
            path: "/api/integrations/worklog/v1/portal-tickets/\(id)"
        ) { [weak self, weak loading] (result: Result<EvoraPortalTicketDetailResponse, Error>) in
            DispatchQueue.main.async {
                guard let self, let loading,
                      self.classicMenuNavigator?.isShowing(loading) == true
                else { return }
                switch result {
                case .success(let response):
                    let attachments = self.evoraPortalTicketAttachments(response.ticket)
                    self.loadEvoraPortalImagePreviews(attachments) { [weak self, weak loading] previews in
                        guard let self, let loading,
                              self.classicMenuNavigator?.isShowing(loading) == true
                        else { return }
                        let detail = self.evoraClassicTicketDetailMenu(
                            response.ticket,
                            imagePreviews: previews
                        )
                        _ = self.classicMenuNavigator?.replaceTransientPage(
                            expected: loading,
                            with: detail,
                            title: "#\(response.ticket.ticketNumber) · \(response.ticket.subject)"
                        )
                    }
                case .failure(let error):
                    let failed = NSMenu(title: "Ticket se nepodařilo načíst")
                    failed.autoenablesItems = false
                    failed.addItem(self.evoraClassicTicketNoticeItem(
                        title: "Ticket se nepodařilo načíst",
                        detail: error.localizedDescription,
                        symbol: "exclamationmark.triangle.fill",
                        color: .systemRed,
                        spinning: false
                    ))
                    let retry = self.item(
                        "Zkusit znovu",
                        symbol: "arrow.clockwise",
                        action: #selector(self.showEvoraPortalTicket(_:))
                    )
                    retry.representedObject = id
                    failed.addItem(retry)
                    _ = self.classicMenuNavigator?.replaceTransientPage(
                        expected: loading,
                        with: failed,
                        title: "Ticket se nepodařilo načíst"
                    )
                }
            }
        }
    }

    @objc func openEvoraPortalAttachmentFromClassicMenu(_ sender: NSMenuItem) {
        guard let attachment = sender.representedObject as? EvoraPortalTicketAttachment else { return }
        downloadEvoraPortalAttachment(attachment) { [weak self] result in
            DispatchQueue.main.async {
                switch result {
                case .success(let file):
                    NSWorkspace.shared.open(file)
                case .failure(let error):
                    self?.showAlert("Přílohy ticketu", error.localizedDescription)
                }
            }
        }
    }

    func evoraPortalTicketAttachments(_ ticket: EvoraPortalTicketDetail) -> [EvoraPortalTicketAttachment] {
        var result: [EvoraPortalTicketAttachment] = []
        var seen = Set<String>()
        for attachment in ticket.attachments + ticket.threads.flatMap(\.attachments) {
            let key = "\(attachment.id)\n\(attachment.name)"
            guard seen.insert(key).inserted else { continue }
            result.append(attachment)
        }
        return result
    }

    func presentEvoraPortalAttachments(_ attachments: [EvoraPortalTicketAttachment]) {
        guard !attachments.isEmpty else {
            showAlert("Přílohy ticketu", "Portál u tohoto ticketu nevrátil žádnou skutečnou přílohu.")
            return
        }
        let downloadable = attachments.filter(\.canDownload)
        let displayOnly = attachments.filter { !$0.canDownload }
        NSApp.activate(ignoringOtherApps: true)
        let attachmentInfo: String
        if downloadable.isEmpty {
            attachmentInfo = "Portál poskytl názvy souborů bez bezpečných adres. Zobrazuji je proto jen jako přehled, nikoli jako nefunkční tlačítka."
        } else if displayOnly.isEmpty {
            attachmentInfo = "Vyberte přílohu. Evora Smart Menu ji bezpečně načte přes Evora Smart Hub a otevře v odpovídající aplikaci macOS."
        } else {
            attachmentInfo = "Dostupné přílohy lze otevřít. Soubory, u kterých Portál poskytl jen název, jsou uvedené zvlášť jako přehled."
        }
        let alert = makeContextualAlert("Přílohy ticketu", attachmentInfo, iconContext: "přílohy")

        let width: CGFloat = 520
        let listHeight = displayOnly.isEmpty
            ? CGFloat(0)
            : min(CGFloat(220), max(CGFloat(72), CGFloat(displayOnly.count * 22 + 20)))
        let downloadableHeight: CGFloat = downloadable.isEmpty ? 0 : 59
        let displayOnlyHeight: CGFloat = displayOnly.isEmpty ? 0 : listHeight + 25
        let sectionSpacing: CGFloat = downloadable.isEmpty || displayOnly.isEmpty ? 0 : 12
        let containerHeight = downloadableHeight + displayOnlyHeight + sectionSpacing
        let container = NSView(frame: NSRect(x: 0, y: 0, width: width, height: containerHeight))
        var cursor = containerHeight
        var selector: NSPopUpButton?

        if !downloadable.isEmpty {
            let heading = NSTextField(labelWithString: "Dostupné ke stažení")
            heading.font = NSFont.systemFont(ofSize: 12, weight: .semibold)
            heading.frame = NSRect(x: 0, y: cursor - 17, width: width, height: 17)
            container.addSubview(heading)
            cursor -= 25

            let popUp = NSPopUpButton(frame: NSRect(x: 0, y: cursor - 32, width: width, height: 32), pullsDown: false)
            popUp.addItems(withTitles: downloadable.map(\.name))
            container.addSubview(popUp)
            selector = popUp
            cursor -= 32
        }

        if !displayOnly.isEmpty {
            if !downloadable.isEmpty { cursor -= sectionSpacing }
            let heading = NSTextField(labelWithString: "Názvy souborů z Portálu")
            heading.font = NSFont.systemFont(ofSize: 12, weight: .semibold)
            heading.frame = NSRect(x: 0, y: cursor - 17, width: width, height: 17)
            container.addSubview(heading)
            cursor -= 25

            let list = evoraTextView(
                displayOnly.map { "• \($0.name)" }.joined(separator: "\n"),
                width: width,
                height: listHeight
            )
            list.frame = NSRect(x: 0, y: cursor - listHeight, width: width, height: listHeight)
            container.addSubview(list)
        }

        alert.accessoryView = container
        if downloadable.isEmpty {
            alert.addButton(withTitle: "Zavřít")
            _ = alert.runModal()
            return
        }
        alert.addButton(withTitle: "Otevřít vybranou")
        alert.addButton(withTitle: "Zavřít")
        guard alert.runModal() == .alertFirstButtonReturn, let selector else { return }
        let index = max(0, min(selector.indexOfSelectedItem, downloadable.count - 1))
        downloadEvoraPortalAttachment(downloadable[index]) { [weak self] result in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success(let file):
                    NSWorkspace.shared.open(file)
                case .failure(let error):
                    self.showAlert("Přílohy ticketu", error.localizedDescription)
                }
            }
        }
    }

    func presentEvoraLoadingPanel(title: String, detail: String) -> NSPanel {
        NSApp.activate(ignoringOtherApps: true)
        let panel = NSPanel(
            contentRect: NSRect(x: 0, y: 0, width: 390, height: 132),
            styleMask: [.titled, .utilityWindow],
            backing: .buffered,
            defer: false
        )
        panel.title = "Evora Smart Menu"
        panel.isReleasedWhenClosed = false
        panel.level = .floating
        panel.hidesOnDeactivate = false
        panel.animationBehavior = .utilityWindow

        let content = NSView(frame: panel.contentRect(forFrameRect: panel.frame))
        let spinner = NSProgressIndicator(frame: NSRect(x: 24, y: 43, width: 38, height: 38))
        spinner.style = .spinning
        spinner.controlSize = .large
        spinner.startAnimation(nil)
        let titleLabel = NSTextField(labelWithString: title)
        titleLabel.font = NSFont.systemFont(ofSize: 15, weight: .semibold)
        titleLabel.frame = NSRect(x: 80, y: 68, width: 282, height: 23)
        let detailLabel = NSTextField(wrappingLabelWithString: detail)
        detailLabel.font = NSFont.systemFont(ofSize: 11)
        detailLabel.textColor = .secondaryLabelColor
        detailLabel.frame = NSRect(x: 80, y: 31, width: 282, height: 35)
        content.addSubview(spinner)
        content.addSubview(titleLabel)
        content.addSubview(detailLabel)
        panel.contentView = content
        panel.center()
        panel.makeKeyAndOrderFront(nil)
        return panel
    }

    @objc func showEvoraPortalTicket(_ sender: NSMenuItem) {
        // Jediná podporovaná cesta je proklikávací klasický panel. Tento
        // selector se používá i v kopiích položek z globálního hledání, proto
        // zde nesmí existovat fallback na NSPanel/NSAlert.
        showEvoraPortalTicketInClassicMenu(sender)
        if classicMenuNavigator?.window?.isVisible != true {
            DispatchQueue.main.async { [weak self] in
                self?.handleStatusItemInteraction()
            }
        }
    }

    func presentEvoraPortalTicket(
        _ ticket: EvoraPortalTicketDetail,
        imagePreviews: [String: NSImage] = [:]
    ) {
        NSApp.activate(ignoringOtherApps: true)
        let attachments = evoraPortalTicketAttachments(ticket)
        let ticketInfo = attachments.isEmpty
            ? "\(evoraPortalTicketStatus(ticket.status)) · veřejná komunikace z Loxone Partner Portálu."
            : "\(evoraPortalTicketStatus(ticket.status)) · veřejná komunikace · \(attachments.count) příloh."
        if let modernMenuPanel, modernMenuPanel.isVisible {
            var actions: [(title: String, image: NSImage?, color: NSColor?, handler: () -> Void)] = [
                (
                    "Odpovědět na ticket…",
                    sf("bubble.left.and.bubble.right", color: .systemTeal),
                    .systemTeal,
                    { [weak self] in self?.presentEvoraPortalComposer(ticket: ticket) }
                ),
            ]
            if !attachments.isEmpty {
                actions.append((
                    "Přílohy (\(attachments.count))…",
                    sf("paperclip", color: .systemBlue),
                    .systemBlue,
                    { [weak self] in self?.presentEvoraPortalAttachments(attachments) }
                ))
            }
            actions.append((
                "Otevřít tiketové centrum v Hubu",
                sf("arrow.up.right.square", color: .systemCyan),
                .systemCyan,
                { [weak self, weak modernMenuPanel] in
                    guard let self, let url = URL(string: "\(self.evoraHubURL())?page=tickets") else { return }
                    modernMenuPanel?.closeForExternalAction()
                    NSWorkspace.shared.open(url)
                }
            ))
            modernMenuPanel.showAttributedDetail(
                title: "#\(ticket.ticketNumber) · \(ticket.subject)",
                detail: ticketInfo,
                content: evoraPortalTicketAttributedText(ticket, imagePreviews: imagePreviews),
                actions: actions
            )
            return
        }
        let alert = makeContextualAlert(
            "#\(ticket.ticketNumber) · \(ticket.subject)",
            ticketInfo,
            iconContext: "LOXONE ticket"
        )
        alert.addButton(withTitle: "Odpovědět…")
        if !attachments.isEmpty {
            alert.addButton(withTitle: "Přílohy (\(attachments.count))…")
        }
        alert.addButton(withTitle: "Otevřít v Hubu")
        alert.addButton(withTitle: "Zavřít")
        alert.accessoryView = evoraAttributedTextView(
            evoraPortalTicketAttributedText(ticket, imagePreviews: imagePreviews),
            height: 430
        )
        let answer = alert.runModal()
        if answer == .alertFirstButtonReturn {
            presentEvoraPortalComposer(ticket: ticket)
            return
        }
        if !attachments.isEmpty, answer == .alertSecondButtonReturn {
            presentEvoraPortalAttachments(attachments)
            return
        }
        let hubResponse: NSApplication.ModalResponse = attachments.isEmpty ? .alertSecondButtonReturn : .alertThirdButtonReturn
        if answer == hubResponse, let url = URL(string: "\(evoraHubURL())?page=tickets") {
            NSWorkspace.shared.open(url)
        }
    }

    @objc func createEvoraPortalTicket() {
        guard let navigator = classicMenuNavigator else { return }
        let composer = evoraClassicTicketComposerMenu(ticket: nil)
        navigator.showTransientPage(composer, title: "Nový LOXONE ticket")
        if navigator.window?.isVisible != true {
            DispatchQueue.main.async { [weak self] in
                self?.handleStatusItemInteraction()
            }
        }
    }

    func presentEvoraPortalComposer(ticket: EvoraPortalTicketDetail?, draft: EvoraPortalDraft? = nil) {
        NSApp.activate(ignoringOtherApps: true)
        let isReply = ticket != nil
        let alert = makeContextualAlert(
            isReply ? "Odpověď do ticketu #\(ticket?.ticketNumber ?? "")" : "Nový LOXONE ticket",
            "Po pokračování se zobrazí úplný náhled. Nic se neodešle bez následného potvrzení heslem.",
            iconContext: "LOXONE ticket"
        )
        alert.addButton(withTitle: "Zkontrolovat návrh")
        alert.addButton(withTitle: "Zrušit")

        let containerHeight: CGFloat = isReply ? 255 : 300
        let container = NSView(frame: NSRect(x: 0, y: 0, width: 560, height: containerHeight))
        let subjectLabel = NSTextField(labelWithString: "Předmět")
        subjectLabel.frame = NSRect(x: 0, y: containerHeight - 20, width: 560, height: 17)
        let subjectField = NSTextField(frame: NSRect(x: 0, y: containerHeight - 52, width: 560, height: 26))
        subjectField.stringValue = draft?.subject ?? ticket?.subject ?? ""
        subjectField.isEditable = !isReply
        subjectField.isSelectable = true
        let bodyLabel = NSTextField(labelWithString: "Celá zpráva")
        bodyLabel.frame = NSRect(x: 0, y: containerHeight - 79, width: 560, height: 17)
        let bodyScroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: 560, height: containerHeight - 84))
        bodyScroll.hasVerticalScroller = true
        bodyScroll.borderType = .bezelBorder
        let bodyField = NSTextView(frame: NSRect(x: 0, y: 0, width: 540, height: containerHeight - 84))
        bodyField.isRichText = false
        bodyField.font = NSFont.systemFont(ofSize: 12)
        bodyField.textContainerInset = NSSize(width: 8, height: 8)
        bodyField.string = draft?.body ?? ""
        bodyScroll.documentView = bodyField
        container.addSubview(subjectLabel)
        container.addSubview(subjectField)
        container.addSubview(bodyLabel)
        container.addSubview(bodyScroll)
        alert.accessoryView = container
        alert.window.initialFirstResponder = isReply ? bodyField : subjectField

        guard alert.runModal() == .alertFirstButtonReturn else { return }
        let subject = subjectField.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        let body = bodyField.string.trimmingCharacters(in: .whitespacesAndNewlines)
        guard subject.count >= 3 else {
            showAlert("LOXONE tickety", "Předmět musí mít alespoň 3 znaky.")
            presentEvoraPortalComposer(ticket: ticket, draft: EvoraPortalDraft(ticketId: ticket?.id, ticketNumber: ticket?.ticketNumber, subject: subject, body: body))
            return
        }
        guard body.count >= (isReply ? 1 : 3) else {
            showAlert("LOXONE tickety", "Zpráva je příliš krátká.")
            presentEvoraPortalComposer(ticket: ticket, draft: EvoraPortalDraft(ticketId: ticket?.id, ticketNumber: ticket?.ticketNumber, subject: subject, body: body))
            return
        }
        reviewEvoraPortalDraft(
            EvoraPortalDraft(
                ticketId: ticket?.id,
                ticketNumber: ticket?.ticketNumber,
                subject: subject,
                body: body
            ),
            ticket: ticket
        )
    }

    func reviewEvoraPortalDraft(_ draft: EvoraPortalDraft, ticket: EvoraPortalTicketDetail?) {
        NSApp.activate(ignoringOtherApps: true)
        let action = draft.isReply ? "Přidat veřejnou odpověď do #\(draft.ticketNumber ?? "")" : "Vytvořit nový ticket"
        let preview = "Kam: Loxone Partner Portal\nAkce: \(action)\nPředmět: \(draft.subject)\n\nCELÝ TEXT ZPRÁVY\n\n\(draft.body)"
        let alert = makeContextualAlert(
            "Kontrola před odesláním",
            "Níže je úplný návrh. V této chvíli ještě nic nebylo odesláno.",
            iconContext: "LOXONE ticket kontrola"
        )
        alert.addButton(withTitle: "Pokračovat k heslu")
        alert.addButton(withTitle: "Zpět upravit")
        alert.addButton(withTitle: "Zrušit")
        alert.accessoryView = evoraTextView(preview, height: 380)
        let answer = alert.runModal()
        if answer == .alertFirstButtonReturn {
            confirmEvoraPortalDraft(draft)
        } else if answer == .alertSecondButtonReturn {
            presentEvoraPortalComposer(ticket: ticket, draft: draft)
        }
    }

    func confirmEvoraPortalDraft(_ draft: EvoraPortalDraft) {
        NSApp.activate(ignoringOtherApps: true)
        let alert = makeContextualAlert(
            "Potvrdit odeslání heslem",
            "Heslo slouží jen k jednorázovému potvrzení přesně zkontrolovaného návrhu.",
            iconContext: "heslo zabezpečení"
        )
        alert.addButton(withTitle: "Potvrdit a odeslat")
        alert.addButton(withTitle: "Zrušit")
        let password = NSSecureTextField(frame: NSRect(x: 0, y: 0, width: 420, height: 26))
        password.placeholderString = "Heslo do Evora Smart Hubu"
        alert.accessoryView = password
        alert.window.initialFirstResponder = password
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        guard !password.stringValue.isEmpty else {
            showAlert("LOXONE tickety", "Heslo je povinné.")
            return
        }
        let action = draft.isReply ? "portal_ticket_reply" : "portal_ticket_create"
        let payload: [String: Any] = draft.isReply
            ? ["ticketId": draft.ticketId ?? "", "content": draft.body]
            : ["subject": draft.subject, "description": draft.body]
        evoraRequest(
            path: "/api/integrations/worklog/v1/portal-tickets/confirm",
            method: "POST",
            body: ["action": action, "password": password.stringValue, "payload": payload]
        ) { [weak self] (result: Result<EvoraConfirmationResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success(let response):
                    self.sendEvoraPortalDraft(draft, confirmationId: response.confirmationId)
                case .failure(let error):
                    self.showAlert("LOXONE tickety", error.localizedDescription)
                }
            }
        }
    }

    func sendEvoraPortalDraft(_ draft: EvoraPortalDraft, confirmationId: String) {
        let path = draft.isReply
            ? "/api/integrations/worklog/v1/portal-tickets/\(draft.ticketId ?? "")/replies"
            : "/api/integrations/worklog/v1/portal-tickets"
        let body: [String: Any] = draft.isReply
            ? ["content": draft.body]
            : ["subject": draft.subject, "description": draft.body]
        evoraRequest(
            path: path,
            method: "POST",
            body: body,
            headers: ["X-Action-Confirmation": confirmationId]
        ) { [weak self] (result: Result<EvoraPortalMutationResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success:
                    self.showAlert("LOXONE tickety", draft.isReply ? "Odpověď byla odeslána." : "Ticket byl vytvořen.")
                    self.refreshEvoraTickets()
                case .failure(let error):
                    self.showAlert("LOXONE tickety", error.localizedDescription)
                }
            }
        }
    }

    @objc func configureEvoraConnection() {
        NSApp.activate(ignoringOtherApps: true)
        let alert = makeContextualAlert(
            "Evora Smart Hub",
            "Vložte adresu Hubu a osobní WorkLog token vytvořený v Nastavení Evora Smart Hubu. Token se uloží pouze do macOS Klíčenky.",
            iconContext: "Evora Smart Hub"
        )
        alert.addButton(withTitle: "Uložit")
        alert.addButton(withTitle: "Odpojit tento Mac")
        alert.addButton(withTitle: "Zrušit")

        let container = NSView(
            frame: NSRect(x: 0, y: 0, width: 480, height: 104)
        )
        let urlLabel = NSTextField(labelWithString: "Adresa Evora Smart Hubu")
        urlLabel.frame = NSRect(x: 0, y: 82, width: 480, height: 17)
        let urlField = NSTextField(
            frame: NSRect(x: 0, y: 52, width: 480, height: 26)
        )
        urlField.stringValue = evoraHubURL()
        let tokenLabel = NSTextField(labelWithString: "Osobní WorkLog token")
        tokenLabel.frame = NSRect(x: 0, y: 30, width: 480, height: 17)
        let tokenField = NSSecureTextField(
            frame: NSRect(x: 0, y: 0, width: 480, height: 26)
        )
        tokenField.placeholderString = evoraToken() == nil
            ? "esh_worklog_…"
            : "ponechte prázdné, pokud token neměníte"
        container.addSubview(urlLabel)
        container.addSubview(urlField)
        container.addSubview(tokenLabel)
        container.addSubview(tokenField)
        alert.accessoryView = container
        alert.window.initialFirstResponder = evoraToken() == nil
            ? tokenField
            : urlField

        let answer = alert.runModal()
        if answer == .alertSecondButtonReturn {
            deleteEvoraToken()
            evoraServers = []
            evoraLauncherAgent = nil
            evoraCapabilities = nil
            evoraStatus = "Evora Smart Hub: nepřipojeno"
            evoraTickets = []
            evoraTicketsStatus = "Tickety: nepřipojeno"
            rebuildEvoraMenu()
            return
        }
        guard answer == .alertFirstButtonReturn else { return }
        guard let normalizedURL = validEvoraHubURL(urlField.stringValue) else {
            showAlert(
                "Evora Smart Hub",
                "Použijte platnou HTTPS adresu bez parametrů. HTTP je povolené pouze pro localhost."
            )
            return
        }
        let newToken = tokenField.stringValue.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        if evoraToken() == nil && newToken.isEmpty {
            showAlert("Evora Smart Hub", "Osobní WorkLog token je povinný.")
            return
        }
        if !newToken.isEmpty {
            guard newToken.hasPrefix("esh_worklog_") else {
                showAlert("Evora Smart Hub", "Vložený token nemá platný formát.")
                return
            }
            guard saveEvoraToken(newToken) else {
                showAlert("Evora Smart Hub", "Token se nepodařilo uložit do macOS Klíčenky.")
                return
            }
        }
        UserDefaults.standard.set(normalizedURL, forKey: evoraHubDefaultsKey)
        evoraLastRefresh = .distantPast
        refreshEvoraMenu()
    }

    func chooseEvoraConfigLaunchMode() -> String? {
        NSApp.activate(ignoringOtherApps: true)
        let alert = makeContextualAlert(
            "Otevřít Loxone Config",
            "Otevření v Loxone Configu spustí nové okno. Druhá volba použije již běžící přesnou verzi, otevře Domů a zvolí Připojit manuálně.",
            iconContext: "Loxone Config"
        )
        alert.addButton(withTitle: "Otevřít v Loxone Config")
        alert.addButton(withTitle: "Otevřít v běžícím Configu")
        alert.addButton(withTitle: "Zrušit")
        switch alert.runModal() {
        case .alertFirstButtonReturn: return "new_window"
        case .alertSecondButtonReturn: return "existing"
        default: return nil
        }
    }

    @discardableResult
    func copyPasswordToPasteboard(_ password: String) -> Bool {
        guard !password.isEmpty else { return false }
        let pasteboard = NSPasteboard.general
        var copied = false
        for attempt in 0..<3 {
            pasteboard.clearContents()
            copied = pasteboard.setString(password, forType: .string)
                && pasteboard.string(forType: .string) == password
            if copied { break }
            if attempt < 2 { Thread.sleep(forTimeInterval: 0.04) }
        }
        guard copied else { return false }
        let expectedChangeCount = pasteboard.changeCount
        DispatchQueue.main.asyncAfter(deadline: .now() + 60) {
            let current = NSPasteboard.general
            if current.changeCount == expectedChangeCount {
                current.clearContents()
            }
        }
        return true
    }

    func performEvoraGridAction(_ payload: NSDictionary) {
        guard let action = payload["action"] as? String else { return }
        closeClassicMenu()
        if action == "open_url" {
            guard
                let value = payload["url"] as? String,
                let url = URL(string: value),
                ["http", "https"].contains(url.scheme?.lowercased() ?? ""),
                url.user == nil,
                url.password == nil
            else { return }
            NSWorkspace.shared.open(url)
            return
        }
        let proxy = NSMenuItem()
        proxy.representedObject = payload
        runEvoraAction(proxy)
    }

    @objc func runEvoraGridAction(_ sender: EvoraPayloadButton) {
        guard let payload = sender.payload else { return }
        performEvoraGridAction(payload)
    }

    @objc func runEvoraAction(_ sender: NSMenuItem) {
        guard
            let payload = sender.representedObject as? NSDictionary,
            let serial = payload["serial"] as? String,
            let action = payload["action"] as? String
        else {
            return
        }
        var requestBody: [String: Any] = ["action": action]
        if action == "loxone_config" {
            let representedMode = payload["launchMode"] as? String
            guard let launchMode = representedMode ?? chooseEvoraConfigLaunchMode() else { return }
            requestBody["launchMode"] = launchMode
        }
        switch action {
        case "loxone_app": evoraStatus = "Připravuji Loxone App pro \(serial)…"
        case "web_interface": evoraStatus = "Připravuji web Miniserveru \(serial)…"
        case "copy_password": evoraStatus = "Načítám heslo pro bezpečné zkopírování…"
        default: evoraStatus = "Předávám \(serial) do Windows…"
        }
        rebuildEvoraMenu()
        evoraRequest(
            path: "/api/integrations/worklog/v1/miniservers/\(serial)/actions",
            method: "POST",
            body: requestBody
        ) { [weak self] (result: Result<EvoraActionResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success(let response):
                    if response.action == "loxone_app" {
                        guard
                            let value = response.url,
                            let url = URL(string: value),
                            url.scheme?.lowercased() == "loxone"
                        else {
                            self.evoraStatus = "Loxone App: neplatná odpověď"
                            self.rebuildEvoraMenu()
                            self.showAlert("Evora Smart Hub", "Hub nevrátil bezpečný odkaz pro Loxone App.")
                            return
                        }
                        self.evoraStatus = "Loxone App otevřena pro \(serial)"
                        self.rebuildEvoraMenu()
                        if !NSWorkspace.shared.open(url) {
                            self.showAlert("Loxone App", "macOS nedokázal otevřít schéma loxone://. Ověřte instalaci Loxone App.")
                        }
                        return
                    }
                    if response.action == "web_interface" {
                        guard
                            let value = response.url,
                            let url = URL(string: value),
                            ["http", "https"].contains(url.scheme?.lowercased() ?? ""),
                            url.user == nil,
                            url.password == nil
                        else {
                            self.evoraStatus = "Web Miniserveru: neplatná odpověď"
                            self.rebuildEvoraMenu()
                            self.showAlert("Web Miniserveru", "Hub nevrátil bezpečnou adresu webového rozhraní.")
                            return
                        }
                        self.evoraStatus = "Otevírám web Miniserveru…"
                        self.rebuildEvoraMenu()
                        if !NSWorkspace.shared.open(url) {
                            self.showAlert("Web Miniserveru", "macOS nedokázal otevřít webové rozhraní.")
                        }
                        return
                    }
                    if response.action == "copy_password" {
                        guard let password = response.password, self.copyPasswordToPasteboard(password) else {
                            self.evoraStatus = "Heslo se nepodařilo zkopírovat"
                            self.rebuildEvoraMenu()
                            self.showAlert("Kopírovat heslo", "Hub nevrátil uložené heslo nebo macOS schránka zápis nepřijala.")
                            return
                        }
                        self.evoraStatus = "Heslo pro \(serial) je ve schránce"
                        self.rebuildEvoraMenu()
                        self.showAlert(
                            "Heslo zkopírováno",
                            "Heslo je ve schránce nejvýše 60 sekund. Pokud mezitím zkopírujete něco jiného, Menu novou hodnotu nesmaže."
                        )
                        return
                    }
                    guard let job = response.job else {
                        self.evoraStatus = "Config: neplatná odpověď"
                        self.rebuildEvoraMenu()
                        self.showAlert("Loxone Config", "Hub nevrátil vytvořený požadavek.")
                        return
                    }
                    self.evoraStatus = "Windows Launcher převzal požadavek…"
                    self.rebuildEvoraMenu()
                    self.pollEvoraConfigJob(job.id, attempt: 0)
                case .failure(let error):
                    self.evoraStatus = "Chyba: \(error.localizedDescription)"
                    self.rebuildEvoraMenu()
                    self.showAlert("Evora Smart Hub", error.localizedDescription)
                }
            }
        }
    }

    func pollEvoraConfigJob(_ id: String, attempt: Int) {
        guard attempt < 150 else {
            evoraStatus = "Loxone Config: vypršel čas kontroly"
            rebuildEvoraMenu()
            showAlert("Loxone Config", "Windows Launcher nepotvrdil výsledek v časovém limitu.")
            return
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { [weak self] in
            guard let self else { return }
            self.evoraRequest(
                path: "/api/integrations/worklog/v1/config-jobs/\(id)"
            ) { [weak self] (result: Result<EvoraJobResponse, Error>) in
                DispatchQueue.main.async {
                    guard let self else { return }
                    switch result {
                    case .failure(let error):
                        self.evoraStatus = "Config: \(error.localizedDescription)"
                        self.rebuildEvoraMenu()
                        self.showAlert("Loxone Config", error.localizedDescription)
                    case .success(let response):
                        let job = response.job
                        if job.state == "succeeded" {
                            if job.errorCode == "REMOTE_CONNECT_ALREADY_ACTIVE" {
                                self.evoraStatus = "Miniserver je už připojený"
                                self.rebuildEvoraMenu()
                                self.showAlert("Miniserver je už připojený", job.message)
                                return
                            }
                            self.evoraStatus = "Loxone Config \(job.requiredVersion) je otevřený"
                            self.rebuildEvoraMenu()
                        } else if ["missing_config", "failed", "expired"].contains(job.state) {
                            self.evoraStatus = "Config: \(job.message)"
                            self.rebuildEvoraMenu()
                            self.showEvoraConfigFailure(job)
                        } else {
                            self.evoraStatus = job.message
                            self.rebuildEvoraMenu()
                            self.pollEvoraConfigJob(id, attempt: attempt + 1)
                        }
                    }
                }
            }
        }
    }

    func showEvoraConfigFailure(_ job: EvoraConfigJob) {
        NSApp.activate(ignoringOtherApps: true)
        let title = job.state == "missing_config"
            ? "Požadovaný Loxone Config chybí"
            : "Loxone Config se nepodařilo otevřít"
        let alert = makeContextualAlert(title, job.message)
        if job.state == "missing_config", job.configUrl != nil {
            alert.addButton(withTitle: "Stáhnout Config \(job.requiredVersion)")
            alert.addButton(withTitle: "Zavřít")
            if alert.runModal() == .alertFirstButtonReturn,
               let value = job.configUrl,
               let url = URL(string: value) {
                NSWorkspace.shared.open(url)
            }
        } else {
            alert.addButton(withTitle: "OK")
            alert.runModal()
        }
    }

    // MARK: - Links

    @objc func openURL(
        _ sender: NSMenuItem
    ) {

        guard
            let value =
                sender
                    .representedObject
                as? String,

            let url =
                URL(
                    string:
                        value
                )

        else {
            return
        }

        NSWorkspace
            .shared
            .open(url)
    }

    // MARK: - Misc

    @objc func pauseAgent() {
        let message = runWork(["pauza"])
        refreshAll()
        showAlert("Evora Smart Menu", message)
    }

    @objc func resumeAgent() {
        let message = runWork(["pokracovat"])
        refreshAll()
        showAlert("Evora Smart Menu", message)
    }

    @objc func quitMenu() {
        NSApp.terminate(nil)
    }

    func runLiveCameraDiagnostic() -> Int32 {
        guard let token = readKeychainValue(alias: "evora-token"),
              let baseURL = validEvoraHubURL(evoraHubURL()),
              let fleetURL = URL(string: "\(baseURL)/api/integrations/worklog/v1/miniservers"),
              let masterURL = URL(string: "\(baseURL)/api/integrations/worklog/v1/cameras/7/hls/index.m3u8?quality=preview")
        else {
            print("LIVE_DIAGNOSTIC credentials=missing")
            return 2
        }

        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 25
        let session = URLSession(configuration: configuration)

        func request(_ url: URL) -> (status: Int, mime: String, data: Data) {
            var output = (status: 0, mime: "", data: Data())
            let semaphore = DispatchSemaphore(value: 0)
            var request = URLRequest(url: url)
            request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            session.dataTask(with: request) { data, response, _ in
                if let response = response as? HTTPURLResponse {
                    output.status = response.statusCode
                    output.mime = response.mimeType ?? ""
                }
                output.data = data ?? Data()
                semaphore.signal()
            }.resume()
            _ = semaphore.wait(timeout: .now() + 26)
            return output
        }

        func firstResource(_ data: Data, relativeTo base: URL) -> URL? {
            guard let manifest = String(data: data, encoding: .utf8) else { return nil }
            let value = manifest
                .split(whereSeparator: \Character.isNewline)
                .map(String.init)
                .first { !$0.isEmpty && !$0.hasPrefix("#") }
            guard let value else { return nil }
            return URL(string: value, relativeTo: base)?.absoluteURL
        }

        let fleet = request(fleetURL)
        var cameraOnline = false
        var gateConfigured = false
        var gateAvailable = false
        var copyCapability = false
        if fleet.status == 200,
           let root = try? JSONSerialization.jsonObject(with: fleet.data) as? [String: Any] {
            let cameras = root["cameras"] as? [[String: Any]] ?? []
            cameraOnline = cameras.contains {
                ($0["id"] as? Int) == 7 && ($0["online"] as? Bool) == true
            }
            let gate = root["gate"] as? [String: Any]
            gateConfigured = gate?["configured"] as? Bool == true
            gateAvailable = gate?["available"] as? Bool == true
            let capabilities = root["capabilities"] as? [String: Any]
            copyCapability = capabilities?["miniserverPasswordCopy"] as? Bool == true
        }

        let master = request(masterURL)
        var mediaStatus = 0
        var segmentStatus = 0
        var segmentBytes = 0
        var advertisedCodec = "unknown"
        var mediaURL: URL?
        if master.status == 200 {
            mediaURL = firstResource(master.data, relativeTo: masterURL)
            if let manifest = String(data: master.data, encoding: .utf8),
               let codecRange = manifest.range(of: "CODECS=\"") {
                let suffix = manifest[codecRange.upperBound...]
                if let end = suffix.firstIndex(of: "\"") {
                    let value = String(suffix[..<end])
                    advertisedCodec = value.range(of: "hvc1|hev1|h265", options: [.regularExpression, .caseInsensitive]) != nil
                        ? "h265"
                        : value.range(of: "avc1|h264", options: [.regularExpression, .caseInsensitive]) != nil
                            ? "h264"
                            : "other"
                }
            }
        }
        if let mediaURL {
            for _ in 0..<6 {
                let media = request(mediaURL)
                mediaStatus = media.status
                if media.status == 200,
                   let segmentURL = firstResource(media.data, relativeTo: mediaURL) {
                    let segment = request(segmentURL)
                    segmentStatus = segment.status
                    segmentBytes = segment.data.count
                    if segment.status == 200 && segmentBytes > 0 { break }
                }
                Thread.sleep(forTimeInterval: 0.35)
            }
        }

        var playbackReady = false
        var localMasterStatus = 0
        var localMediaStatus = 0
        var localSegmentStatus = 0
        let probeProxy = EvoraAuthenticatedHLSLoopbackProxy(
            upstreamMasterURL: masterURL,
            authorizationToken: token
        )
        if let localMasterURL = probeProxy.start() {
            let localMaster = request(localMasterURL)
            localMasterStatus = localMaster.status
            if let localMediaURL = firstResource(localMaster.data, relativeTo: localMasterURL) {
                let localMedia = request(localMediaURL)
                localMediaStatus = localMedia.status
                if let localSegmentURL = firstResource(localMedia.data, relativeTo: localMediaURL) {
                    localSegmentStatus = request(localSegmentURL).status
                }
            }
        }
        probeProxy.stop()
        let playerView = EvoraCameraPlayerView(frame: NSRect(x: 0, y: 0, width: 640, height: 360))
        let diagnosticScreen = NSScreen.main?.visibleFrame ?? NSRect(x: 0, y: 0, width: 1_440, height: 900)
        let panel = NSPanel(
            contentRect: NSRect(
                x: diagnosticScreen.maxX - 640,
                y: diagnosticScreen.maxY - 360,
                width: 640,
                height: 360
            ),
            styleMask: [.borderless],
            backing: .buffered,
            defer: false
        )
        panel.alphaValue = 0.01
        panel.ignoresMouseEvents = true
        panel.contentView = playerView
        panel.orderFront(nil)
        let player = EvoraCameraHLSPlayer(
            playerView: playerView,
            onConnecting: {},
            onReady: { playbackReady = true },
            onFailure: { _ in }
        )
        player.start(url: masterURL, token: token)
        let deadline = Date().addingTimeInterval(14)
        while !playbackReady && Date() < deadline {
            RunLoop.current.run(until: Date().addingTimeInterval(0.05))
        }
        let playerItemStatus = player.diagnosticItemStatus
        let playerTimeControl = player.diagnosticTimeControlStatus
        let playerErrorDomain = player.diagnosticErrorDomain
        let playerErrorCode = player.diagnosticErrorCode
        player.stop()
        panel.orderOut(nil)
        panel.close()
        session.invalidateAndCancel()

        print(
            "LIVE_DIAGNOSTIC fleet=\(fleet.status) camera=\(cameraOnline ? "online" : "unavailable") "
            + "master=\(master.status) media=\(mediaStatus) segment=\(segmentStatus) bytes=\(segmentBytes) codec=\(advertisedCodec) "
            + "loopback=\(localMasterStatus)/\(localMediaStatus)/\(localSegmentStatus) "
            + "player=\(playbackReady ? "ready" : "not_ready") item=\(playerItemStatus) time=\(playerTimeControl) "
            + "av_error=\(playerErrorDomain):\(playerErrorCode) gate=\(gateConfigured ? (gateAvailable ? "available" : "configured_offline") : "unconfigured") "
            + "copy=\(copyCapability ? "enabled" : "disabled")"
        )
        return master.status == 200
            && mediaStatus == 200
            && segmentStatus == 200
            && segmentBytes > 0
            && playbackReady
            ? 0
            : 1
    }
}

let commandLine = CommandLine.arguments
let commandDelegate = AppDelegate()
if ProcessInfo.processInfo.environment["EVORA_MENU_PREVIEW_APPEARANCE"] == "dark" {
    _ = NSApplication.shared
    NSApp.appearance = NSAppearance(named: .darkAqua)
} else if ProcessInfo.processInfo.environment["EVORA_MENU_PREVIEW_APPEARANCE"] == "light" {
    _ = NSApplication.shared
    NSApp.appearance = NSAppearance(named: .aqua)
}

if commandLine.count > 1, commandLine[1] == "--store-intranet-credentials" {
    guard let email = readLine()?.trimmingCharacters(in: .whitespacesAndNewlines),
          let password = readLine(),
          email.contains("@"),
          !email.contains(" "),
          !password.isEmpty
    else {
        fputs("Neplatný e-mail nebo heslo.\n", stderr)
        exit(2)
    }
    guard commandDelegate.storeIntranetCredentials(email: email, password: password) else {
        fputs("Přístup se nepodařilo uložit do macOS Klíčenky.\n", stderr)
        exit(1)
    }
    print("Přístup k Evora Intranetu byl uložen do macOS Klíčenky.")
    exit(0)
}

if commandLine.count > 1, commandLine[1] == "--clear-intranet-credentials" {
    commandDelegate.deleteIntranetCredentials()
    print("Přístup k Evora Intranetu byl z macOS Klíčenky odstraněn.")
    exit(0)
}

if commandLine.count > 1, commandLine[1] == "--diagnose-live-camera" {
    _ = NSApplication.shared
    NSApp.setActivationPolicy(.accessory)
    exit(commandDelegate.runLiveCameraDiagnostic())
}

if commandLine.count == 3, commandLine[1] == "--render-classic-ticket-preview" {
    _ = NSApplication.shared
    NSApp.setActivationPolicy(.accessory)
    commandDelegate.statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    defer { NSStatusBar.system.removeStatusItem(commandDelegate.statusItem) }
    commandDelegate.buildMenu()
    let ticket = AppDelegate.EvoraPortalTicketDetail(
        id: "preview-ticket",
        ticketNumber: "1907222",
        subject: "Pohybový senzor hlásí aktivitu bez skutečného pohybu",
        status: "waiting",
        createdTime: "25. 8. 2026 18:42",
        threadCount: 2,
        contactName: "Servisní kontakt",
        threads: [
            AppDelegate.EvoraPortalTicketThread(
                id: "preview-thread-1",
                createdTime: "25. 8. 2026 18:42",
                content: "Celý víkend se podle statistiky zobrazoval pohyb, přestože v prostoru nikdo nebyl. Prosím o kontrolu doporučeného nastavení.",
                author: AppDelegate.EvoraPortalTicketAuthor(
                    type: "customer",
                    firstName: "Servisní",
                    lastName: "technik",
                    isLoxone: false
                ),
                attachments: []
            ),
            AppDelegate.EvoraPortalTicketThread(
                id: "preview-thread-2",
                createdTime: "25. 8. 2026 19:05",
                content: "Děkujeme za popis. Zkontrolujte prosím citlivost a pošlete diagnostiku zařízení.",
                author: AppDelegate.EvoraPortalTicketAuthor(
                    type: "support",
                    firstName: "LOXONE",
                    lastName: "Support",
                    isLoxone: true
                ),
                attachments: []
            ),
        ],
        attachments: []
    )
    let detail = commandDelegate.evoraClassicTicketDetailMenu(ticket, imagePreviews: [:])
    guard commandDelegate.renderClassicTransientMenuPreview(
        detail,
        title: "#\(ticket.ticketNumber) · \(ticket.subject)",
        path: commandLine[2]
    ) else {
        fputs("Náhled ticketu uvnitř klasické nabídky se nepodařilo vyrenderovat.\n", stderr)
        exit(1)
    }
    print("Náhled ticketu uvnitř klasické nabídky byl vytvořen.")
    exit(0)
}

if commandLine.count == 3, commandLine[1] == "--render-classic-ticket-composer-preview" {
    _ = NSApplication.shared
    NSApp.setActivationPolicy(.accessory)
    commandDelegate.statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    defer { NSStatusBar.system.removeStatusItem(commandDelegate.statusItem) }
    commandDelegate.buildMenu()
    let draft = AppDelegate.EvoraPortalDraft(
        ticketId: nil,
        ticketNumber: nil,
        subject: "Pohybový senzor hlásí aktivitu bez pohybu",
        body: "Prosím o kontrolu doporučeného nastavení citlivosti a diagnostiky zařízení."
    )
    let composer = commandDelegate.evoraClassicTicketComposerMenu(ticket: nil, draft: draft)
    guard commandDelegate.renderClassicTransientMenuPreview(
        composer,
        title: "Nový LOXONE ticket",
        path: commandLine[2]
    ) else {
        fputs("Náhled editoru ticketu uvnitř klasické nabídky se nepodařilo vyrenderovat.\n", stderr)
        exit(1)
    }
    print("Náhled editoru ticketu uvnitř klasické nabídky byl vytvořen.")
    exit(0)
}

if commandLine.count == 3, commandLine[1] == "--render-classic-ticket-review-preview" {
    _ = NSApplication.shared
    NSApp.setActivationPolicy(.accessory)
    commandDelegate.statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    defer { NSStatusBar.system.removeStatusItem(commandDelegate.statusItem) }
    commandDelegate.buildMenu()
    let draft = AppDelegate.EvoraPortalDraft(
        ticketId: "preview-ticket",
        ticketNumber: "1907222",
        subject: "Pohybový senzor hlásí aktivitu bez pohybu",
        body: "Děkuji za odpověď. Citlivost jsem zkontroloval a přikládám celou diagnostiku zařízení."
    )
    let review = commandDelegate.evoraClassicTicketReviewMenu(draft)
    guard commandDelegate.renderClassicTransientMenuPreview(
        review,
        title: "Kontrola před odesláním",
        path: commandLine[2]
    ) else {
        fputs("Náhled kontroly ticketu uvnitř klasické nabídky se nepodařilo vyrenderovat.\n", stderr)
        exit(1)
    }
    print("Náhled kontroly ticketu uvnitř klasické nabídky byl vytvořen.")
    exit(0)
}

if commandLine.count == 3, commandLine[1] == "--render-classic-camera-preview" {
    _ = NSApplication.shared
    NSApp.setActivationPolicy(.accessory)
    commandDelegate.statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    defer { NSStatusBar.system.removeStatusItem(commandDelegate.statusItem) }
    commandDelegate.buildMenu()
    guard let cameraMenu = commandDelegate.evoraCameraPreviewMenuForSelfTest(),
          commandDelegate.renderClassicTransientMenuPreview(
              cameraMenu,
              title: "Online · Parkoviště a brána",
              path: commandLine[2]
          )
    else {
        fputs("Náhled kamery a ovládání brány se nepodařilo vyrenderovat.\n", stderr)
        exit(1)
    }
    print("Náhled kamery a ovládání brány byl vytvořen.")
    exit(0)
}

if commandLine.count == 3,
   ["--render-classic-miniserver-preview", "--render-classic-compact-preview"].contains(commandLine[1]) {
    _ = NSApplication.shared
    NSApp.setActivationPolicy(.accessory)
    commandDelegate.statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    defer { NSStatusBar.system.removeStatusItem(commandDelegate.statusItem) }
    commandDelegate.buildMenu()
    let compact = commandLine[1] == "--render-classic-compact-preview"
    let server = AppDelegate.EvoraMiniServer(
        serial: "PREVIEW000001",
        project: compact ? "PRO-23-031 · Student Agency" : "DM WELLNESS VZ1",
        type: compact ? "Miniserver Compact" : "Miniserver",
        folderName: "Wellness",
        folderColor: "#16A34A",
        connectionState: "online",
        currentFirmware: "17.1.7.27",
        elementsOnline: 42,
        elementsTotal: 42,
        offlineDevices: 0,
        lastCheckedAt: "2026-08-25T15:40:00.000Z",
        lastLatencyMs: 28,
        consecutiveFailures: 0,
        healthVerdict: "ok",
        healthRefreshedAt: "2026-08-25T15:40:00.000Z",
        dataState: "current",
        hasCredentials: true,
        loxoneAppAvailable: true,
        loxoneConfigAvailable: true,
        configVersion: "17.1.7.27",
        configDownloadUrl: "https://example.invalid/config",
        deviceImageUrl: nil
    )
    commandDelegate.seedEvoraMenuForSelfTest(servers: [server], status: "1 Miniserver · Windows Launcher online")
    commandDelegate.seedEvoraContextForPreview()
    guard commandDelegate.renderClassicMiniserverPreview(server, path: commandLine[2]) else {
        fputs("Náhled klasického detailu Miniserveru se nepodařilo vyrenderovat.\n", stderr)
        exit(1)
    }
    print("Náhled klasického detailu Miniserveru byl vytvořen.")
    exit(0)
}

if commandLine.count == 4, commandLine[1] == "--render-classic-menu-preview" {
    _ = NSApplication.shared
    NSApp.setActivationPolicy(.accessory)
    commandDelegate.statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    defer { NSStatusBar.system.removeStatusItem(commandDelegate.statusItem) }
    commandDelegate.buildMenu()
    let server = AppDelegate.EvoraMiniServer(
        serial: "PREVIEW000001",
        project: "DM WELLNESS VZ1",
        type: "Miniserver",
        folderName: "Wellness",
        folderColor: "#16A34A",
        connectionState: "online",
        currentFirmware: "17.1.7.27",
        elementsOnline: 42,
        elementsTotal: 42,
        offlineDevices: 0,
        lastCheckedAt: "2026-08-25T15:40:00.000Z",
        lastLatencyMs: 28,
        consecutiveFailures: 0,
        healthVerdict: "ok",
        healthRefreshedAt: "2026-08-25T15:40:00.000Z",
        dataState: "current",
        hasCredentials: true,
        loxoneAppAvailable: true,
        loxoneConfigAvailable: true,
        configVersion: "17.1.7.27",
        configDownloadUrl: "https://example.invalid/config",
        deviceImageUrl: nil
    )
    commandDelegate.seedEvoraMenuForSelfTest(
        servers: [server],
        status: "1 Miniserver · Windows Launcher online"
    )
    commandDelegate.seedEvoraContextForPreview()
    commandDelegate.rebuildEvoraMenu()
    let route = commandLine[2] == "-"
        ? []
        : commandLine[2].split(separator: "|").map(String.init)
    guard commandDelegate.renderClassicMenuPreview(route: route, path: commandLine[3]) else {
        fputs("Náhled jednostránkové klasické nabídky se nepodařilo vyrenderovat.\n", stderr)
        exit(1)
    }
    print("Náhled jednostránkové klasické nabídky byl vytvořen.")
    exit(0)
}

if commandLine.count == 5, commandLine[1] == "--render-modern-menu-preview" {
    _ = NSApplication.shared
    NSApp.setActivationPolicy(.accessory)
    commandDelegate.statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    defer { NSStatusBar.system.removeStatusItem(commandDelegate.statusItem) }
    commandDelegate.buildMenu()
    let previewServers = [
        AppDelegate.EvoraMiniServer(
            serial: "PREVIEW000001",
            project: "DM WELLNESS VZ1",
            type: "Miniserver",
            folderName: "Wellness",
            folderColor: "#16A34A",
            connectionState: "online",
            currentFirmware: "17.1.7.27",
            elementsOnline: 42,
            elementsTotal: 42,
            offlineDevices: 0,
            lastCheckedAt: "2026-08-25T15:40:00.000Z",
            lastLatencyMs: 28,
            consecutiveFailures: 0,
            healthVerdict: "ok",
            healthRefreshedAt: "2026-08-25T15:40:00.000Z",
            dataState: "current",
            hasCredentials: true,
            loxoneAppAvailable: true,
            loxoneConfigAvailable: true,
            configVersion: "17.1.7.27",
            configDownloadUrl: nil,
            deviceImageUrl: nil
        ),
        AppDelegate.EvoraMiniServer(
            serial: "PREVIEW000002",
            project: "Administrativní budova",
            type: "Miniserver Compact",
            folderName: "Evora Smart",
            folderColor: "#2563EB",
            connectionState: "degraded",
            currentFirmware: "16.0.3.30",
            elementsOnline: 37,
            elementsTotal: 40,
            offlineDevices: 3,
            lastCheckedAt: "2026-08-25T15:35:00.000Z",
            lastLatencyMs: 81,
            consecutiveFailures: 1,
            healthVerdict: "warning",
            healthRefreshedAt: "2026-08-25T15:35:00.000Z",
            dataState: "current",
            hasCredentials: true,
            loxoneAppAvailable: true,
            loxoneConfigAvailable: true,
            configVersion: "16.0.3.30",
            configDownloadUrl: nil,
            deviceImageUrl: nil
        ),
        AppDelegate.EvoraMiniServer(
            serial: "PREVIEW000003",
            project: "Ukázkový Miniserver Go",
            type: "Miniserver Go",
            folderName: "Servis",
            folderColor: "#9333EA",
            connectionState: "offline",
            currentFirmware: "15.6.3.4",
            elementsOnline: 0,
            elementsTotal: 12,
            offlineDevices: 12,
            lastCheckedAt: "2026-08-25T14:10:00.000Z",
            lastLatencyMs: nil,
            consecutiveFailures: 4,
            healthVerdict: "critical",
            healthRefreshedAt: "2026-08-25T14:10:00.000Z",
            dataState: "stale",
            hasCredentials: false,
            loxoneAppAvailable: false,
            loxoneConfigAvailable: false,
            configVersion: "15.6.3.4",
            configDownloadUrl: nil,
            deviceImageUrl: nil
        )
    ]
    commandDelegate.seedEvoraMenuForSelfTest(
        servers: previewServers,
        status: "3 Miniservery · Windows Launcher online"
    )
    commandDelegate.seedEvoraContextForPreview()
    commandDelegate.rebuildEvoraMenu()
    guard commandDelegate.renderModernMenuPreview(
        rootTitle: commandLine[2],
        query: commandLine[3],
        path: commandLine[4]
    ) else {
        fputs("Náhled moderního menu se nepodařilo vyrenderovat.\n", stderr)
        exit(1)
    }
    print("Náhled moderního menu byl vytvořen.")
    exit(0)
}

if commandLine.count > 1, commandLine[1] == "--self-test-intranet-history" {
    let fixedNow = ISO8601DateFormatter().date(from: "2026-08-22T15:00:00Z")!
    let events = [
        AppDelegate.IntranetAttendanceEvent(id: "a1", kind: "arrival", source: "test", ts: "2026-08-21T05:00:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "b1", kind: "break_out", source: "test", ts: "2026-08-21T10:00:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "b2", kind: "break_in", source: "test", ts: "2026-08-21T10:30:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "d1", kind: "departure", source: "test", ts: "2026-08-21T14:00:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "p1", kind: "arrival", source: "test", ts: "2026-07-15T06:00:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "p2", kind: "departure", source: "test", ts: "2026-07-15T14:00:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "old", kind: "arrival", source: "test", ts: "2026-06-30T06:00:00Z")
    ]
    let merged = commandDelegate.mergeIntranetHistory(
        existing: [events[0]],
        incoming: events,
        now: fixedNow
    )
    let currentDays = commandDelegate.intranetHistoryDays(
        monthStart: commandDelegate.intranetMonthStart(from: fixedNow),
        events: merged,
        now: fixedNow
    )
    let previousDays = commandDelegate.intranetHistoryDays(
        monthStart: commandDelegate.intranetMonthStart(offset: -1, from: fixedNow),
        events: merged,
        now: fixedNow
    )
    let overnightNow = ISO8601DateFormatter().date(from: "2026-08-23T01:00:00Z")!
    let overnightEvents = [
        AppDelegate.IntranetAttendanceEvent(id: "h1", kind: "home_start", source: "test", ts: "2026-08-22T20:04:00Z"),
        AppDelegate.IntranetAttendanceEvent(id: "h2", kind: "home_end", source: "test", ts: "2026-08-23T00:59:00Z")
    ]
    let overnightDerived = commandDelegate.deriveIntranetAttendance(events: overnightEvents, now: overnightNow)
    let overnightDays = commandDelegate.intranetHistoryDays(
        monthStart: commandDelegate.intranetMonthStart(from: overnightNow),
        events: overnightEvents,
        now: overnightNow
    )
    let breakStartedAt = fixedNow.timeIntervalSince1970
    let fullBreak = commandDelegate.intranetBreakRemainingSeconds(
        state: "on_break",
        since: breakStartedAt,
        now: fixedNow
    )
    let fiveMinuteBreak = commandDelegate.intranetBreakRemainingSeconds(
        state: "on_break",
        since: breakStartedAt,
        now: fixedNow.addingTimeInterval(5 * 60)
    )
    let expiredBreak = commandDelegate.intranetBreakRemainingSeconds(
        state: "on_break",
        since: breakStartedAt,
        now: fixedNow.addingTimeInterval(31 * 60)
    )
    let noBreak = commandDelegate.intranetBreakRemainingSeconds(
        state: "in_building",
        since: breakStartedAt,
        now: fixedNow
    )
    let liveClock = commandDelegate.seedIntranetLiveClockForSelfTest(baseNow: fixedNow)
    guard merged.count == 6,
          currentDays.count == 1,
          previousDays.count == 1,
          currentDays[0].workedSeconds == 30_600,
          previousDays[0].workedSeconds == 28_800,
          overnightDerived.state == "away",
          overnightDerived.worked == 17_700,
          overnightDays.count == 1,
          overnightDays[0].workedSeconds == 17_700,
          overnightDays[0].events.count == 2,
          fullBreak == 1_800,
          fiveMinuteBreak == 1_500,
          expiredBreak == 0,
          noBreak == nil,
          liveClock.first == 28_800,
          liveClock.second == 28_805,
          commandDelegate.formatIntranetBreakCountdown(fiveMinuteBreak ?? -1) == "25:00"
    else {
        fputs("Self-test historie docházky selhal.\n", stderr)
        exit(1)
    }
    print("Historie docházky a 30minutový odpočet přestávky jsou v pořádku.")
    exit(0)
}

if commandLine.count > 1, commandLine[1] == "--self-test-menu-structure" {
    commandDelegate.statusItem = NSStatusBar.system.statusItem(withLength: NSStatusItem.variableLength)
    defer { NSStatusBar.system.removeStatusItem(commandDelegate.statusItem) }
    commandDelegate.buildMenu()

    func visibleMenuTitle(_ item: NSMenuItem) -> String {
        let raw = item.attributedTitle?.string.isEmpty == false ? item.attributedTitle?.string ?? item.title : item.title
        return raw.replacingOccurrences(of: "\u{fffc}", with: "")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    func menuItem(in menu: NSMenu, titled title: String) -> NSMenuItem? {
        for item in menu.items {
            if visibleMenuTitle(item) == title { return item }
            if let submenu = item.submenu, let match = menuItem(in: submenu, titled: title) { return match }
        }
        return nil
    }

    func actionItemsHaveIcons(_ menu: NSMenu) -> Bool {
        for item in menu.items {
            if item.action != nil, item.view == nil, item.attributedTitle?.length ?? 0 == 0 { return false }
            if let submenu = item.submenu, !actionItemsHaveIcons(submenu) { return false }
        }
        return true
    }

    func button(in view: NSView?, toolTip: String) -> NSButton? {
        guard let view else { return nil }
        if let candidate = view as? NSButton, candidate.toolTip == toolTip { return candidate }
        for child in view.subviews {
            if let match = button(in: child, toolTip: toolTip) { return match }
        }
        return nil
    }

    let systems = menuItem(in: commandDelegate.menu, titled: "Systémy")
    let tasksNotes = menuItem(in: commandDelegate.menu, titled: "Úkoly a poznámky")
    let statusLabels = commandDelegate.searchDetailLabels([commandDelegate.shiftStatusItem])
    let fakeServer = AppDelegate.EvoraMiniServer(
        serial: "TEST00000001",
        project: "Testovací projekt",
        type: "Miniserver Compact",
        folderName: "Testovací složka",
        folderColor: "#D97706",
        connectionState: "online",
        currentFirmware: "16.0.0.0",
        elementsOnline: 11,
        elementsTotal: 12,
        offlineDevices: 1,
        lastCheckedAt: "2026-08-23T20:00:00.000Z",
        lastLatencyMs: 42,
        consecutiveFailures: 0,
        healthVerdict: "ok",
        healthRefreshedAt: "2026-08-23T20:00:00.000Z",
        dataState: "current",
        hasCredentials: true,
        loxoneAppAvailable: true,
        loxoneConfigAvailable: false,
        configVersion: "16.0.0.0",
        configDownloadUrl: nil,
        deviceImageUrl: nil
    )
    let fakeCamera = AppDelegate.EvoraCamera(
        id: 0,
        name: "Testovací kamera",
        online: true,
        model: "MS-C5376-PA",
        firmware: "33.8.0.3"
    )
    commandDelegate.seedEvoraMenuForSelfTest(
        servers: [fakeServer],
        cameras: [fakeCamera],
        status: "1 Miniserver · Windows Launcher offline"
    )
    let headerSubtitle = commandDelegate.seedEvoraHubVersionForSelfTest("3.0.28")
    commandDelegate.rebuildEvoraMenu()
    let folder = menuItem(in: commandDelegate.evoraMenu, titled: "Testovací složka  (1)")
    let miniservers = menuItem(in: commandDelegate.evoraMenu, titled: "Miniservery  (1)")
    let folderWasLazy = folder?.submenu?.items.isEmpty == true
    if let folderMenu = folder?.submenu { commandDelegate.populateEvoraFolderMenu(folderMenu) }
    let server = menuItem(in: commandDelegate.evoraMenu, titled: "Online · Testovací projekt")
    let cameras = menuItem(in: commandDelegate.evoraMenu, titled: "Milesight  (1)")
    let camera = menuItem(in: commandDelegate.evoraMenu, titled: "Online · Testovací kamera")
    let quitControl = button(
        in: commandDelegate.menu.items.first?.view,
        toolTip: "Ukončit Evora Smart Menu"
    )
    let summaryLabels = server?.submenu.map { commandDelegate.searchDetailLabels(Array($0.items.prefix(1))) } ?? []
    let flattenedSearch = commandDelegate.seedEvoraSearchForSelfTest("projekt")
    _ = commandDelegate.seedEvoraSearchForSelfTest("")
    let globalFlattenedSearch = commandDelegate.seedMainMenuSearchForSelfTest("projekt")
    _ = commandDelegate.seedMainMenuSearchForSelfTest("")
    let rapidNestedSearch = commandDelegate.seedRapidClassicSearchForSelfTest(
        ["p", "projek", "nesprávný mezivýsledek", "projekt"],
        nested: true
    )
    let clearedNestedSearch = commandDelegate.seedRapidClassicSearchForSelfTest(["projekt", ""], nested: true)
    let rapidGlobalSearch = commandDelegate.seedRapidClassicSearchForSelfTest(
        ["t", "test", "neplatný mezivýsledek", "projekt"],
        nested: false
    )
    let clearedGlobalSearch = commandDelegate.seedRapidClassicSearchForSelfTest(["projekt", ""], nested: false)
    let incrementalGlobalSearch = commandDelegate.seedIncrementalClassicSearchTypingForSelfTest("VZT1")
    let incrementalFolderSearch = commandDelegate.seedIncrementalClassicSearchTypingForSelfTest("melori")
    let drillDown = commandDelegate.seedClassicNavigatorForSelfTest([
        "Systémy",
        "Miniservery  (1)",
        "Testovací složka  (1)",
        "Online · Testovací projekt",
    ])
    let compactTicketTitle = commandDelegate.compactMenuText(
        "První řádek\n\nDruhý    řádek s velmi dlouhým textem, který nesmí roztáhnout nabídku přes monitor.",
        limit: 48
    )
    let bundledDeviceFiles = [
        commandDelegate.evoraBundledDeviceImageFileName(type: "Miniserver"),
        commandDelegate.evoraBundledDeviceImageFileName(type: "Miniserver Gen. 1"),
        commandDelegate.evoraBundledDeviceImageFileName(type: "Miniserver Compact"),
        commandDelegate.evoraBundledDeviceImageFileName(type: "Miniserver Go")
    ]
    let bundledCardDeviceFiles = [
        commandDelegate.evoraBundledCardDeviceImageFileName(type: "Miniserver"),
        commandDelegate.evoraBundledCardDeviceImageFileName(type: "Miniserver Gen. 1"),
        commandDelegate.evoraBundledCardDeviceImageFileName(type: "Miniserver Compact"),
        commandDelegate.evoraBundledCardDeviceImageFileName(type: "Miniserver Go")
    ]
    let dialogContexts = [
        "Dovolená a absence",
        "Evora Intranet docházka",
        "LOXONE ticket",
        "přílohy",
        "heslo zabezpečení",
        "Loxone Config",
        "Evora Smart Hub"
    ]

    var failures: [String] = []
    if commandDelegate.menu.title != "Evora Smart Menu" { failures.append("název") }
    if headerSubtitle != "Menu 3.0.22 · Hub 3.0.28" { failures.append("živá verze Hubu") }
    if (commandDelegate.shiftStatusItem.view?.frame.height ?? 0) < 90 { failures.append("vzdušná profilová karta") }
    if !statusLabels.contains("Bc. Michal Schöniger") { failures.append("jméno v profilové kartě") }
    if tasksNotes?.submenu == nil { failures.append("úkoly a poznámky") }
    if systems?.submenu !== commandDelegate.evoraMenu { failures.append("přímé Systémy") }
    if miniservers?.submenu !== commandDelegate.evoraMiniserversMenu { failures.append("samostatná stránka Miniserverů") }
    if !folderWasLazy { failures.append("líné načtení složky Systémy") }
    if systems?.submenu?.items.contains(where: { visibleMenuTitle($0) == "Home Assistant odkazy" }) != true { failures.append("Home Assistant") }
    if cameras?.submenu == nil || camera?.submenu?.items.first?.view == nil { failures.append("náhled kamery") }
    if !commandDelegate.evoraCameraMenuColor().isEqual(NSColor.systemPurple) { failures.append("fialové kamery") }
    if systems?.submenu?.items.contains(where: { visibleMenuTitle($0) == "Evora Smart Hub" }) == true { failures.append("nadbytečná mezisložka") }
    if (folder?.attributedTitle?.length ?? 0) == 0 { failures.append("barevná složka") }
    if (server?.attributedTitle?.length ?? 0) == 0 { failures.append("stav Miniserveru") }
    if flattenedSearch.foldersVisible != 0
        || !flattenedSearch.serverTitles.isEmpty
        || !flattenedSearch.uniqueDetailLabels.contains("Testovací projekt")
        || !flattenedSearch.uniqueDetailLabels.contains("Loxone App")
        || !flattenedSearch.uniqueDetailLabels.contains("Kopírovat heslo") {
        failures.append("okamžitý detail hledaného Miniserveru")
    }
    if globalFlattenedSearch.systemsVisible
        || !globalFlattenedSearch.serverTitles.isEmpty
        || !globalFlattenedSearch.uniqueDetailLabels.contains("Testovací projekt")
        || !globalFlattenedSearch.uniqueDetailLabels.contains("Nové okno Configu") {
        failures.append("okamžitý detail globálního hledání")
    }
    if rapidNestedSearch.query != "projekt"
        || rapidNestedSearch.parentVisible
        || !rapidNestedSearch.uniqueDetailLabels.contains("Testovací projekt") {
        failures.append("rychlé hledání v Systémech bez starého výsledku")
    }
    if clearedNestedSearch.query != "" || !clearedNestedSearch.parentVisible || !clearedNestedSearch.uniqueDetailLabels.isEmpty {
        failures.append("smazání hledání v Systémech")
    }
    if rapidGlobalSearch.query != "projekt"
        || rapidGlobalSearch.parentVisible
        || !rapidGlobalSearch.uniqueDetailLabels.contains("Testovací projekt") {
        failures.append("rychlé globální hledání bez starého výsledku")
    }
    if clearedGlobalSearch.query != "" || !clearedGlobalSearch.parentVisible || !clearedGlobalSearch.uniqueDetailLabels.isEmpty {
        failures.append("smazání globálního hledání")
    }
    if incrementalGlobalSearch.value != "VZT1"
        || incrementalGlobalSearch.selection.location != 4
        || incrementalGlobalSearch.selection.length != 0 {
        failures.append(
            "postupné psaní ve vyhledávání "
                + "(text \(incrementalGlobalSearch.value), výběr \(incrementalGlobalSearch.selection))"
        )
    }
    if incrementalFolderSearch.value != "melori"
        || incrementalFolderSearch.selection.location != 6
        || incrementalFolderSearch.selection.length != 0 {
        failures.append(
            "souvislé psaní názvu složky ve vyhledávání "
                + "(text \(incrementalFolderSearch.value), výběr \(incrementalFolderSearch.selection))"
        )
    }
    if !drillDown.0
        || drillDown.1 != [
            "Evora Smart Menu",
            "Systémy",
            "Miniservery  (1)",
            "Testovací složka  (1)",
            "Online · Testovací projekt",
        ]
        || !drillDown.2.contains("Testovací projekt")
        || !drillDown.2.contains("Kopírovat heslo") {
        failures.append(
            "jednopanelová navigace se šipkou zpět "
                + "(navigace \(drillDown.0), cesta \(drillDown.1), obsah \(drillDown.2))"
        )
    }
    if !summaryLabels.contains("Testovací projekt") { failures.append("detail projektu") }
    if !summaryLabels.contains(where: { $0.contains("Online · FW 16.0.0.0") }) { failures.append("detail firmware") }
    if !summaryLabels.contains("Prvky 11/12 · 1 offline") { failures.append("offline prvky") }
    if !summaryLabels.contains(where: { $0.contains("Health OK") && $0.contains("42 ms") }) { failures.append("diagnostika Miniserveru") }
    if menuItem(in: commandDelegate.menu, titled: "Dovolená a absence…") == nil { failures.append("nativní absence") }
    if dialogContexts.contains(where: { commandDelegate.contextualDialogIcon($0).size.width <= 0 }) { failures.append("ikony dialogů") }
    if quitControl?.contentTintColor?.isEqual(NSColor.systemRed) != true
        || quitControl?.frame.width != 30
        || quitControl?.frame.height != 30 {
        failures.append("malý červený křížek vpravo nahoře")
    }
    if menuItem(in: commandDelegate.menu, titled: "Ukončit pouze menu") != nil {
        failures.append("nadbytečné velké ukončení")
    }
    if !actionItemsHaveIcons(commandDelegate.menu) { failures.append("ikony akcí") }
    if compactTicketTitle.contains("\n") || compactTicketTitle.count > 48 || !compactTicketTitle.hasSuffix("…") {
        failures.append("jednořádkové názvy ticketů")
    }
    if bundledDeviceFiles != ["cards/miniserver.png", "cards/miniserver-gen1.png", "compact-transparent.png", "go.png"] {
        failures.append("vložené obrázky Miniserverů")
    }
    if bundledCardDeviceFiles != ["miniserver.png", "miniserver-gen1.png", "miniserver-compact.png", "miniserver-go.png"] {
        failures.append("kvalitní obrázky karet Miniserverů")
    }
    if commandDelegate.evoraDisplayedMiniserverType("Miniserver") != "Miniserver Gen. 2"
        || commandDelegate.evoraDisplayedMiniserverType("Miniserver Gen. 1") != "Miniserver Gen. 1" {
        failures.append("rozlišení generace Miniserveru")
    }
    if !failures.isEmpty {
        fputs("Self-test struktury Evora Smart Menu selhal: \(failures.joined(separator: ", ")).\n", stderr)
        exit(1)
    }
    print("Struktura Evora Smart Menu 3.0.22 je v pořádku.")
    exit(0)
}

if commandLine.count == 5, commandLine[1] == "--test-intranet-parsers" {
    do {
        let attendanceData = try Data(contentsOf: URL(fileURLWithPath: commandLine[2]))
        let summaryData = try Data(contentsOf: URL(fileURLWithPath: commandLine[3]))
        let rosterData = try Data(contentsOf: URL(fileURLWithPath: commandLine[4]))
        let attendance = try JSONDecoder().decode(
            AppDelegate.IntranetAttendanceResponse.self,
            from: attendanceData
        )
        guard let summaryHTML = String(data: summaryData, encoding: .utf8),
              let rosterHTML = String(data: rosterData, encoding: .utf8),
              let roster = commandDelegate.parseIntranetRoster(
                  rosterHTML,
                  ownProfileId: attendance.hrProfileId
              )
        else { throw AppDelegate.IntranetServiceError(code: "parser", message: "Parser nezpracoval vstup.") }
        let summary = commandDelegate.parseIntranetSummary(summaryHTML)
        let states = Dictionary(grouping: roster.people, by: { $0.state }).mapValues(\.count)
        var employeeIds = Set<String>()
        var eventIds = Set<String>()
        var eventKinds: [String: Int] = [:]
        var eventKeys = Set<String>()
        var eventDatesParsed = 0
        var eventDatesToday = 0
        var debugCalendar = Calendar(identifier: .gregorian)
        debugCalendar.timeZone = TimeZone(identifier: "Europe/Prague") ?? .current
        for object in commandDelegate.nextFlightObjects(from: rosterHTML) {
            guard let root = commandDelegate.findIntranetDictionary(
                in: object,
                requiredKeys: ["employees", "events", "absences", "fetchedAt"]
            ) else { continue }
            for employee in root["employees"] as? [[String: Any]] ?? [] {
                if let id = employee["id"] as? String { employeeIds.insert(id) }
            }
            for event in root["events"] as? [[String: Any]] ?? [] {
                eventKeys.formUnion(event.keys)
                if let id = event["hr_profile_id"] as? String { eventIds.insert(id) }
                if let kind = event["kind"] as? String { eventKinds[kind, default: 0] += 1 }
                if let ts = event["ts"] as? String,
                   let date = commandDelegate.parseIntranetDate(ts) {
                    eventDatesParsed += 1
                    if debugCalendar.isDateInToday(date) { eventDatesToday += 1 }
                }
            }
        }
        let result: [String: Any] = [
            "attendance_events": attendance.events.count,
            "summary_keys": summary.cards.keys.sorted(),
            "roster_people": roster.people.count,
            "roster_states": states,
            "own_state_available": roster.ownState != nil,
            "roster_event_keys": eventKeys.sorted(),
            "roster_event_kinds": eventKinds,
            "roster_employee_ids": employeeIds.count,
            "roster_event_ids": eventIds.count,
            "roster_id_overlap": employeeIds.intersection(eventIds).count,
            "roster_dates_parsed": eventDatesParsed,
            "roster_dates_today": eventDatesToday
        ]
        let output = try JSONSerialization.data(withJSONObject: result, options: [.sortedKeys])
        print(String(data: output, encoding: .utf8) ?? "{}")
        exit(0)
    } catch {
        fputs("Test parseru selhal.\n", stderr)
        exit(1)
    }
}

let app = NSApplication.shared
let delegate = commandDelegate
app.delegate = delegate
app.setActivationPolicy(.accessory)
app.run()
