import Cocoa
import Security

final class AppDelegate: NSObject, NSApplicationDelegate, NSMenuDelegate, NSSearchFieldDelegate {

    struct ShiftState: Codable {
        var active: Bool
        var mode: String
        var accumulated: Int
        var lastTick: Double
    }

    struct EvoraMiniServer: Decodable {
        let serial: String
        let project: String
        let type: String
        let folderName: String
        let connectionState: String
        let currentFirmware: String?
        let hasCredentials: Bool
        let loxoneAppAvailable: Bool
        let loxoneConfigAvailable: Bool
        let configVersion: String?
        let configDownloadUrl: String?
        let deviceImageUrl: String?
    }

    struct EvoraLauncherAgent: Decodable {
        let name: String
        let available: Bool
        let helperVersion: String?
        let requiredHelperVersion: String?
        let latestHelperVersion: String?
        let updateRequired: Bool?
        let updateAvailable: Bool?
    }

    struct EvoraFleetResponse: Decodable {
        let launcherAgent: EvoraLauncherAgent?
        let items: [EvoraMiniServer]
    }

    struct EvoraConfigJob: Decodable {
        let id: String
        let state: String
        let message: String
        let requiredVersion: String
        let configUrl: String?
    }

    struct EvoraActionResponse: Decodable {
        let action: String
        let url: String?
        let job: EvoraConfigJob?
    }

    struct EvoraJobResponse: Decodable {
        let job: EvoraConfigJob
    }

    struct EvoraPortalTicketSummary: Decodable {
        let id: String
        let ticketNumber: String
        let subject: String
        let status: String
        let createdTime: String
        let threadCount: Int
        let contactName: String
    }

    struct EvoraPortalTicketAttachment: Decodable {
        let id: String
        let name: String
        let token: String
        let downloadable: Bool?

        var canDownload: Bool { downloadable != false && !token.isEmpty }
    }

    struct EvoraPortalTicketAuthor: Decodable {
        let type: String
        let firstName: String
        let lastName: String
        let isLoxone: Bool
    }

    struct EvoraPortalTicketThread: Decodable {
        let id: String
        let createdTime: String
        let content: String
        let author: EvoraPortalTicketAuthor
        let attachments: [EvoraPortalTicketAttachment]
    }

    struct EvoraPortalTicketDetail: Decodable {
        let id: String
        let ticketNumber: String
        let subject: String
        let status: String
        let createdTime: String
        let threadCount: Int
        let contactName: String
        let threads: [EvoraPortalTicketThread]
        let attachments: [EvoraPortalTicketAttachment]
    }

    struct EvoraPortalTicketListResponse: Decodable {
        let items: [EvoraPortalTicketSummary]
    }

    struct EvoraPortalTicketDetailResponse: Decodable {
        let ticket: EvoraPortalTicketDetail
    }

    struct EvoraConfirmationResponse: Decodable {
        let confirmationId: String
        let expiresAt: String
    }

    struct EvoraPortalMutationResponse: Decodable {
        let ok: Bool
        let ticketId: String?
        let ticketNumber: String?
    }

    struct EvoraPortalDraft {
        let ticketId: String?
        let ticketNumber: String?
        let subject: String
        let body: String

        var isReply: Bool { ticketId != nil }
    }

    struct EvoraErrorResponse: Decodable {
        let error: String
        let code: String?
    }

    struct EvoraServiceError: LocalizedError {
        let message: String

        var errorDescription: String? {
            message
        }
    }

    var statusItem: NSStatusItem!
    private var clockTimer: Timer?
    private var refreshTimer: Timer?

    var menu: NSMenu!
    var macStatusItem: NSMenuItem!
    var windowsStatusItem: NSMenuItem!
    var shiftStatusItem: NSMenuItem!

    var startAgentItem: NSMenuItem!
    var restartAgentItem: NSMenuItem!
    var stopAgentItem: NSMenuItem!
    var evoraMenu: NSMenu!
    var evoraStatusItem: NSMenuItem!

    private var evoraRefreshInFlight = false
    private var evoraTicketsRefreshInFlight = false
    private var evoraLastRefresh = Date.distantPast
    private var evoraServers: [EvoraMiniServer] = []
    private var evoraLauncherAgent: EvoraLauncherAgent?
    private var evoraTickets: [EvoraPortalTicketSummary] = []
    private var evoraTicketsStatus = "Tickety: načítám…"
    private var evoraStatus = "Kontroluji připojení…"
    private var evoraSearchQuery = ""
    private weak var evoraSearchField: NSSearchField?
    private var evoraFolderMenuItems: [(item: NSMenuItem, folder: String, servers: [(item: NSMenuItem, server: EvoraMiniServer)])] = []
    private weak var evoraNoResultsItem: NSMenuItem?
    private let evoraKeychainService = "cz.worklogai.evora-smart-hub"
    private let evoraKeychainAccount = "personal-api-token"
    private let evoraHubDefaultsKey = "EvoraSmartHubURL"
    private let defaultEvoraHubURL = "https://homeassistant-work.skunk-atria.ts.net:8443/api/loxone-servis"
    private lazy var evoraSession: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 30
        return URLSession(configuration: configuration)
    }()

    let home = FileManager.default.homeDirectoryForCurrentUser.path

    var workPath: String {
        "\(home)/Documents/WorkLogAI/bin/work"
    }

    var shiftPath: String {
        "\(home)/Documents/WorkLogAI/menu_shift_state.json"
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        statusItem = NSStatusBar.system.statusItem(
            withLength: NSStatusItem.variableLength
        )

        if let button = statusItem.button {
            button.toolTip = "WorkLog AI"
        }

        buildMenu()
        refreshEvoraMenu()
        refreshAll()

        clockTimer = Timer(
            timeInterval: 1.0,
            target: self,
            selector: #selector(tickClock),
            userInfo: nil,
            repeats: true
        )

        if let clockTimer {
            RunLoop.main.add(clockTimer, forMode: .common)
        }

        refreshTimer = Timer(
            timeInterval: 5.0,
            target: self,
            selector: #selector(refreshAll),
            userInfo: nil,
            repeats: true
        )

        if let refreshTimer {
            RunLoop.main.add(refreshTimer, forMode: .common)
        }
    }

    private var refreshInFlight = false
    private var cachedAgent = false
    private var cachedWindows = "NIKDY"

    // MARK: - Work CLI

    func runWork(_ args: [String]) -> String {
        let process = Process()
        let pipe = Pipe()

        process.executableURL = URL(fileURLWithPath: workPath)
        process.arguments = args
        process.standardOutput = pipe
        process.standardError = pipe

        do {
            try process.run()
            process.waitUntilExit()

            let data = pipe.fileHandleForReading.readDataToEndOfFile()

            return String(
                data: data,
                encoding: .utf8
            ) ?? ""

        } catch {
            return "CHYBA: \(error.localizedDescription)"
        }
    }

    func quick() -> [String: Any] {
        let out = runWork(["rychle"])

        guard
            let data = out.data(using: .utf8),
            let json = try? JSONSerialization.jsonObject(
                with: data
            ) as? [String: Any]
        else {
            return [:]
        }

        return json
    }

    // MARK: - Evora Smart Hub

    func evoraToken() -> String? {
        let query: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: evoraKeychainService,
            kSecAttrAccount: evoraKeychainAccount,
            kSecMatchLimit: kSecMatchLimitOne,
            kSecReturnData: true
        ]
        var result: CFTypeRef?
        guard
            SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
            let data = result as? Data,
            let token = String(data: data, encoding: .utf8),
            !token.isEmpty
        else {
            return nil
        }
        return token
    }

    @discardableResult
    func saveEvoraToken(_ token: String) -> Bool {
        let identity: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: evoraKeychainService,
            kSecAttrAccount: evoraKeychainAccount
        ]
        SecItemDelete(identity as CFDictionary)
        var item = identity
        item[kSecValueData] = Data(token.utf8)
        item[kSecAttrAccessible] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(item as CFDictionary, nil) == errSecSuccess
    }

    func deleteEvoraToken() {
        let query: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: evoraKeychainService,
            kSecAttrAccount: evoraKeychainAccount
        ]
        SecItemDelete(query as CFDictionary)
    }

    func evoraHubURL() -> String {
        let configured = UserDefaults.standard.string(forKey: evoraHubDefaultsKey)
            ?? defaultEvoraHubURL
        return configured.trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
    }

    func validEvoraHubURL(_ value: String) -> String? {
        let normalized = value.trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard
            let url = URL(string: normalized),
            let scheme = url.scheme?.lowercased(),
            let host = url.host,
            !host.isEmpty,
            url.query == nil,
            url.fragment == nil,
            scheme == "https" || (scheme == "http" && ["127.0.0.1", "localhost"].contains(host.lowercased()))
        else {
            return nil
        }
        return normalized
    }

    func evoraEndpoint(_ path: String) -> URL? {
        let suffix = path.hasPrefix("/") ? path : "/\(path)"
        return URL(string: "\(evoraHubURL())\(suffix)")
    }

    func evoraRequest<T: Decodable>(
        path: String,
        method: String = "GET",
        body: [String: Any]? = nil,
        headers: [String: String] = [:],
        completion: @escaping (Result<T, Error>) -> Void
    ) {
        guard let token = evoraToken() else {
            completion(.failure(EvoraServiceError(message: "Nejdřív nastavte osobní token z Evora Smart Hubu.")))
            return
        }
        guard let url = evoraEndpoint(path) else {
            completion(.failure(EvoraServiceError(message: "Adresa Evora Smart Hubu není platná.")))
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        for (name, value) in headers {
            request.setValue(value, forHTTPHeaderField: name)
        }
        if let body {
            request.httpBody = try? JSONSerialization.data(withJSONObject: body)
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        evoraSession.dataTask(with: request) { data, response, error in
            if let error {
                completion(.failure(EvoraServiceError(message: "Evora Smart Hub není dostupný: \(error.localizedDescription)")))
                return
            }
            guard let http = response as? HTTPURLResponse else {
                completion(.failure(EvoraServiceError(message: "Evora Smart Hub nevrátil platnou odpověď.")))
                return
            }
            let payload = data ?? Data()
            guard (200..<300).contains(http.statusCode) else {
                let message = (try? JSONDecoder().decode(EvoraErrorResponse.self, from: payload).error)
                    ?? "Požadavek na Evora Smart Hub selhal (HTTP \(http.statusCode))."
                completion(.failure(EvoraServiceError(message: message)))
                return
            }
            do {
                completion(.success(try JSONDecoder().decode(T.self, from: payload)))
            } catch {
                completion(.failure(EvoraServiceError(message: "Evora Smart Hub vrátil nečitelná data.")))
            }
        }.resume()
    }

    func downloadEvoraPortalAttachment(
        _ attachment: EvoraPortalTicketAttachment,
        completion: @escaping (Result<URL, Error>) -> Void
    ) {
        guard attachment.canDownload else {
            completion(.failure(EvoraServiceError(message: "Portál poskytl pouze název této přílohy, ne bezpečný odkaz ke stažení.")))
            return
        }
        guard let token = evoraToken(),
              let url = evoraEndpoint("/api/integrations/worklog/v1/portal-tickets/attachments/download") else {
            completion(.failure(EvoraServiceError(message: "Připojení k Evora Smart Hubu není nastavené.")))
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("application/octet-stream", forHTTPHeaderField: "Accept")
        request.httpBody = try? JSONSerialization.data(withJSONObject: ["token": attachment.token])
        evoraSession.dataTask(with: request) { data, response, error in
            if let error {
                completion(.failure(EvoraServiceError(message: "Přílohu se nepodařilo načíst: \(error.localizedDescription)")))
                return
            }
            guard let http = response as? HTTPURLResponse else {
                completion(.failure(EvoraServiceError(message: "Hub nevrátil platnou odpověď přílohy.")))
                return
            }
            let payload = data ?? Data()
            guard (200..<300).contains(http.statusCode) else {
                let message = (try? JSONDecoder().decode(EvoraErrorResponse.self, from: payload).error)
                    ?? "Přílohu se nepodařilo načíst (HTTP \(http.statusCode))."
                completion(.failure(EvoraServiceError(message: message)))
                return
            }
            let safeName = attachment.name
                .replacingOccurrences(of: "[^\\p{L}\\p{N} ._()-]", with: "_", options: .regularExpression)
                .prefix(180)
            let directory = FileManager.default.temporaryDirectory
                .appendingPathComponent("WorkLogAI-Evora-Attachments", isDirectory: true)
                .appendingPathComponent(UUID().uuidString, isDirectory: true)
            do {
                try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
                let target = directory.appendingPathComponent(safeName.isEmpty ? "priloha" : String(safeName))
                try payload.write(to: target, options: .atomic)
                completion(.success(target))
            } catch {
                completion(.failure(EvoraServiceError(message: "Staženou přílohu se nepodařilo bezpečně uložit.")))
            }
        }.resume()
    }

    func evoraConnectionLabel(_ state: String) -> String {
        switch state {
        case "online": return "Odpovídá"
        case "no_access": return "Odpovídá · bez přístupu"
        case "unavailable", "error": return "Neodpovídá"
        default: return "Neověřeno"
        }
    }

    func evoraServerMatchesSearch(_ server: EvoraMiniServer, folder: String, query: String) -> Bool {
        let normalized = query.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !normalized.isEmpty else { return true }
        let haystack = "\(server.project) \(server.serial) \(server.type) \(folder)"
        return haystack.range(of: normalized, options: [.caseInsensitive, .diacriticInsensitive]) != nil
    }

    func applyEvoraSearchFilter() {
        let query = evoraSearchQuery
        var visibleTotal = 0
        for folderEntry in evoraFolderMenuItems {
            var visibleInFolder = 0
            for serverEntry in folderEntry.servers {
                let matches = evoraServerMatchesSearch(serverEntry.server, folder: folderEntry.folder, query: query)
                serverEntry.item.isHidden = !matches
                if matches { visibleInFolder += 1 }
            }
            folderEntry.item.isHidden = visibleInFolder == 0
            folderEntry.item.title = "📁  \(folderEntry.folder)  (\(visibleInFolder))"
            visibleTotal += visibleInFolder
        }
        evoraNoResultsItem?.isHidden = query.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || visibleTotal > 0
    }

    func controlTextDidChange(_ notification: Notification) {
        guard let field = notification.object as? NSSearchField, field === evoraSearchField else { return }
        evoraSearchQuery = field.stringValue
        applyEvoraSearchFilter()
    }

    func evoraPortalTicketIsClosed(_ status: String) -> Bool {
        let normalized = status.lowercased()
        return normalized.contains("closed")
            || normalized.contains("resolved")
            || normalized.contains("solved")
            || normalized.contains("uzavřen")
    }

    func evoraPortalTicketStatus(_ status: String) -> String {
        let normalized = status.lowercased()
        if normalized == "open" || normalized == "opened" { return "Otevřený" }
        if evoraPortalTicketIsClosed(status) { return "Uzavřený" }
        if normalized.contains("waiting") || normalized.contains("pending") { return "Čeká" }
        return status.isEmpty ? "Neznámý" : status
    }

    func evoraTicketsMenuItem() -> NSMenuItem {
        let parent = NSMenuItem(
            title: "🎫  LOXONE tickety  (\(evoraTickets.count))",
            action: nil,
            keyEquivalent: ""
        )
        let submenu = NSMenu(title: "LOXONE tickety")
        let status = NSMenuItem(title: evoraTicketsStatus, action: nil, keyEquivalent: "")
        status.isEnabled = false
        submenu.addItem(status)
        submenu.addItem(.separator())
        submenu.addItem(item("Nový ticket…", symbol: "plus.bubble", action: #selector(createEvoraPortalTicket)))
        submenu.addItem(item("Aktualizovat změny", symbol: "arrow.clockwise", action: #selector(refreshEvoraTickets)))
        submenu.addItem(linkItem("Otevřít centrum v Evora Smart Hubu", symbol: "rectangle.portrait.and.arrow.right", url: "\(evoraHubURL())?page=tickets"))
        submenu.addItem(.separator())
        if evoraTickets.isEmpty {
            let empty = NSMenuItem(
                title: evoraTicketsRefreshInFlight ? "Načítám tickety…" : "Žádné tickety nejsou dostupné.",
                action: nil,
                keyEquivalent: ""
            )
            empty.isEnabled = false
            submenu.addItem(empty)
        } else {
            for ticket in evoraTickets {
                let marker = evoraPortalTicketIsClosed(ticket.status) ? "⚪️" : "🟢"
                let ticketItem = item(
                    "\(marker)  #\(ticket.ticketNumber) · \(ticket.subject)",
                    symbol: "bubble.left.and.bubble.right",
                    action: #selector(showEvoraPortalTicket(_:))
                )
                ticketItem.representedObject = ticket.id
                ticketItem.toolTip = "\(evoraPortalTicketStatus(ticket.status)) · \(ticket.contactName)"
                submenu.addItem(ticketItem)
            }
        }
        parent.submenu = submenu
        return parent
    }

    func rebuildEvoraMenu() {
        guard evoraMenu != nil else { return }
        evoraMenu.removeAllItems()
        evoraFolderMenuItems.removeAll()
        evoraNoResultsItem = nil

        evoraStatusItem = NSMenuItem(
            title: evoraStatus,
            action: nil,
            keyEquivalent: ""
        )
        evoraStatusItem.isEnabled = false
        evoraMenu.addItem(evoraStatusItem)
        evoraMenu.addItem(.separator())
        let searchItem = NSMenuItem()
        let searchContainer = NSView(frame: NSRect(x: 0, y: 0, width: 310, height: 38))
        let searchField = NSSearchField(frame: NSRect(x: 10, y: 5, width: 290, height: 28))
        searchField.placeholderString = "Hledat Miniserver…"
        searchField.stringValue = evoraSearchQuery
        searchField.sendsSearchStringImmediately = true
        searchField.delegate = self
        searchContainer.addSubview(searchField)
        searchItem.view = searchContainer
        evoraSearchField = searchField
        evoraMenu.addItem(searchItem)
        evoraMenu.addItem(.separator())
        evoraMenu.addItem(
            linkItem(
                "Otevřít Evora Smart Hub",
                symbol: "network",
                url: evoraHubURL()
            )
        )
        evoraMenu.addItem(
            item(
                "Obnovit Miniservery",
                symbol: "arrow.clockwise",
                action: #selector(refreshEvoraMenu)
            )
        )
        evoraMenu.addItem(
            item(
                "Nastavit připojení…",
                symbol: "key",
                action: #selector(configureEvoraConnection)
            )
        )
        evoraMenu.addItem(.separator())
        evoraMenu.addItem(evoraTicketsMenuItem())

        guard !evoraServers.isEmpty else {
            evoraMenu.addItem(.separator())
            let empty = NSMenuItem(
                title: evoraToken() == nil
                    ? "Vložte osobní token z Nastavení Hubu."
                    : "Žádné Miniservery nejsou dostupné.",
                action: nil,
                keyEquivalent: ""
            )
            empty.isEnabled = false
            evoraMenu.addItem(empty)
            return
        }

        evoraMenu.addItem(.separator())
        let noResultsItem = NSMenuItem(title: "Žádný Miniserver neodpovídá hledání", action: nil, keyEquivalent: "")
        noResultsItem.isEnabled = false
        noResultsItem.isHidden = true
        evoraNoResultsItem = noResultsItem
        evoraMenu.addItem(noResultsItem)
        let grouped = Dictionary(grouping: evoraServers, by: { $0.folderName })
        for folder in grouped.keys.sorted(by: { $0.localizedCaseInsensitiveCompare($1) == .orderedAscending }) {
            let servers = (grouped[folder] ?? []).sorted {
                $0.project.localizedCaseInsensitiveCompare($1.project) == .orderedAscending
            }
            let folderItem = NSMenuItem(
                title: "📁  \(folder)  (\(servers.count))",
                action: nil,
                keyEquivalent: ""
            )
            let folderMenu = NSMenu(title: folder)
            var folderServers: [(item: NSMenuItem, server: EvoraMiniServer)] = []
            for server in servers {
                let statusMarker = server.connectionState == "online" ? "🟢" : "⚪️"
                let serverItem = NSMenuItem(
                    title: "\(statusMarker)  \(server.project)",
                    action: nil,
                    keyEquivalent: ""
                )
                let serverMenu = NSMenu(title: server.project)
                let identity = NSMenuItem(
                    title: "\(server.serial) · \(server.type)",
                    action: nil,
                    keyEquivalent: ""
                )
                identity.isEnabled = false
                serverMenu.addItem(identity)
                let status = NSMenuItem(
                    title: "\(evoraConnectionLabel(server.connectionState)) · FW \(server.currentFirmware ?? "neznámý")",
                    action: nil,
                    keyEquivalent: ""
                )
                status.isEnabled = false
                serverMenu.addItem(status)
                serverMenu.addItem(.separator())

                let appAction = item(
                    "Otevřít v Loxone App",
                    symbol: "iphone",
                    action: #selector(runEvoraAction(_:))
                )
                appAction.representedObject = [
                    "serial": server.serial,
                    "action": "loxone_app"
                ] as NSDictionary
                appAction.isEnabled = server.loxoneAppAvailable
                serverMenu.addItem(appAction)

                let configTitle: String
                if evoraLauncherAgent?.updateRequired == true {
                    configTitle = "Otevřít v Loxone Config · aktualizujte Launcher"
                } else if server.loxoneConfigAvailable {
                    configTitle = "Otevřít v Loxone Config"
                } else {
                    configTitle = "Otevřít v Loxone Config · Launcher offline"
                }
                let configAction = item(
                    configTitle,
                    symbol: "doc.badge.gearshape",
                    action: #selector(runEvoraAction(_:))
                )
                configAction.representedObject = [
                    "serial": server.serial,
                    "action": "loxone_config"
                ] as NSDictionary
                configAction.isEnabled = server.loxoneConfigAvailable
                serverMenu.addItem(configAction)

                if let download = server.configDownloadUrl {
                    serverMenu.addItem(.separator())
                    serverMenu.addItem(
                        linkItem(
                            "Stáhnout Loxone Config \(server.configVersion ?? "")",
                            symbol: "arrow.down.circle",
                            url: download
                        )
                    )
                }
                serverItem.submenu = serverMenu
                folderMenu.addItem(serverItem)
                folderServers.append((item: serverItem, server: server))
            }
            folderItem.submenu = folderMenu
            evoraMenu.addItem(folderItem)
            evoraFolderMenuItems.append((item: folderItem, folder: folder, servers: folderServers))
        }
        applyEvoraSearchFilter()
    }

    @objc func refreshEvoraMenu() {
        guard !evoraRefreshInFlight else { return }
        guard evoraToken() != nil else {
            evoraServers = []
            evoraLauncherAgent = nil
            evoraStatus = "Evora Smart Hub: nepřipojeno"
            rebuildEvoraMenu()
            return
        }
        evoraRefreshInFlight = true
        evoraStatus = "Evora Smart Hub: načítám…"
        rebuildEvoraMenu()
        loadEvoraTickets(forcePortalRefresh: false)
        evoraRequest(
            path: "/api/integrations/worklog/v1/miniservers"
        ) { [weak self] (result: Result<EvoraFleetResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                self.evoraRefreshInFlight = false
                self.evoraLastRefresh = Date()
                switch result {
                case .success(let response):
                    self.evoraServers = response.items
                    self.evoraLauncherAgent = response.launcherAgent
                    let launcher: String
                    if response.launcherAgent?.updateRequired == true {
                        launcher = "Windows Launcher vyžaduje aktualizaci"
                    } else if response.launcherAgent?.available == true {
                        launcher = response.launcherAgent?.updateAvailable == true
                            ? "Windows Launcher online · aktualizace dostupná"
                            : "Windows Launcher online"
                    } else {
                        launcher = "Windows Launcher offline"
                    }
                    self.evoraStatus = "\(response.items.count) Miniserverů · \(launcher)"
                case .failure(let error):
                    self.evoraServers = []
                    self.evoraLauncherAgent = nil
                    self.evoraStatus = "Chyba: \(error.localizedDescription)"
                }
                self.rebuildEvoraMenu()
            }
        }
    }

    @objc func refreshEvoraTickets() {
        loadEvoraTickets(forcePortalRefresh: true)
    }

    func loadEvoraTickets(forcePortalRefresh: Bool) {
        guard !evoraTicketsRefreshInFlight else { return }
        guard evoraToken() != nil else {
            evoraTickets = []
            evoraTicketsStatus = "Tickety: nepřipojeno"
            rebuildEvoraMenu()
            return
        }
        evoraTicketsRefreshInFlight = true
        evoraTicketsStatus = "Tickety: načítám…"
        rebuildEvoraMenu()
        evoraRequest(
            path: "/api/integrations/worklog/v1/portal-tickets\(forcePortalRefresh ? "?refresh=1" : "")"
        ) { [weak self] (result: Result<EvoraPortalTicketListResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                self.evoraTicketsRefreshInFlight = false
                switch result {
                case .success(let response):
                    self.evoraTickets = response.items
                    let open = response.items.filter { !self.evoraPortalTicketIsClosed($0.status) }.count
                    self.evoraTicketsStatus = "\(response.items.count) ticketů · \(open) otevřených"
                case .failure(let error):
                    self.evoraTicketsStatus = self.evoraTickets.isEmpty
                        ? "Tickety: \(error.localizedDescription)"
                        : "\(self.evoraTickets.count) ticketů · aktualizace selhala"
                }
                self.rebuildEvoraMenu()
            }
        }
    }

    func menuWillOpen(_ menu: NSMenu) {
        guard menu === evoraMenu else { return }
        if Date().timeIntervalSince(evoraLastRefresh) > 30 {
            refreshEvoraMenu()
        } else if evoraTickets.isEmpty {
            loadEvoraTickets(forcePortalRefresh: false)
        }
    }

    // MARK: - Shift state

    func loadShift() -> ShiftState {
        let url = URL(fileURLWithPath: shiftPath)

        guard
            let data = try? Data(contentsOf: url),
            let state = try? JSONDecoder().decode(
                ShiftState.self,
                from: data
            )
        else {
            return ShiftState(
                active: false,
                mode: "",
                accumulated: 0,
                lastTick: Date().timeIntervalSince1970
            )
        }

        return state
    }

    func saveShift(_ state: ShiftState) {
        let url = URL(fileURLWithPath: shiftPath)

        try? FileManager.default.createDirectory(
            at: url.deletingLastPathComponent(),
            withIntermediateDirectories: true
        )

        if let data = try? JSONEncoder().encode(state) {
            try? data.write(
                to: url,
                options: .atomic
            )
        }
    }

    // MARK: - Icons

    func sf(_ name: String) -> NSImage? {
        let config = NSImage.SymbolConfiguration(
            pointSize: 13,
            weight: .medium
        )

        let img = NSImage(
            systemSymbolName: name,
            accessibilityDescription: nil
        )?.withSymbolConfiguration(config)

        img?.isTemplate = true

        return img
    }

    func loxoneLikeIcon() -> NSImage {
        let size = NSSize(
            width: 18,
            height: 18
        )

        let image = NSImage(size: size)

        image.lockFocus()

        let outer = NSBezierPath()
        outer.lineWidth = 1.6

        outer.move(
            to: NSPoint(x: 9, y: 1.6)
        )

        outer.line(
            to: NSPoint(x: 15.4, y: 5.1)
        )

        outer.line(
            to: NSPoint(x: 15.4, y: 12.9)
        )

        outer.line(
            to: NSPoint(x: 9, y: 16.4)
        )

        outer.line(
            to: NSPoint(x: 2.6, y: 12.9)
        )

        outer.line(
            to: NSPoint(x: 2.6, y: 5.1)
        )

        outer.close()

        NSColor.labelColor.setStroke()
        outer.stroke()

        let inner = NSBezierPath()
        inner.lineWidth = 1.7

        inner.move(
            to: NSPoint(x: 6.2, y: 5.0)
        )

        inner.line(
            to: NSPoint(x: 6.2, y: 12.8)
        )

        inner.line(
            to: NSPoint(x: 11.8, y: 12.8)
        )

        inner.stroke()

        image.unlockFocus()

        image.isTemplate = true

        return image
    }

    // MARK: - Menu items

    func item(
        _ title: String,
        symbol: String?,
        action: Selector
    ) -> NSMenuItem {

        let item = NSMenuItem(
            title: title,
            action: action,
            keyEquivalent: ""
        )

        item.target = self

        return item
    }

    func linkItem(
        _ title: String,
        symbol: String?,
        url: String
    ) -> NSMenuItem {

        let item = NSMenuItem(
            title: title,
            action: #selector(openURL(_:)),
            keyEquivalent: ""
        )

        item.target = self
        item.representedObject = url

        return item
    }

    func statusAttributed(
        label: String,
        value: String,
        color: NSColor
    ) -> NSAttributedString {

        let output = NSMutableAttributedString(
            string: "\(label)    "
        )

        output.addAttributes(
            [
                .foregroundColor: NSColor.labelColor,
                .font: NSFont.systemFont(
                    ofSize: NSFont.systemFontSize
                )
            ],
            range: NSRange(
                location: 0,
                length: output.length
            )
        )

        let state = NSAttributedString(
            string: value,
            attributes: [
                .foregroundColor: color,
                .font: NSFont.systemFont(
                    ofSize: NSFont.systemFontSize,
                    weight: .semibold
                )
            ]
        )

        output.append(state)

        return output
    }

    // MARK: - Build menu

    func buildMenu() {
        menu = NSMenu()

        let header = NSMenuItem(
            title: "WorkLog AI",
            action: nil,
            keyEquivalent: ""
        )

        header.isEnabled = false

        menu.addItem(header)

        macStatusItem = NSMenuItem(
            title: "Mac agent: kontroluji…",
            action: nil,
            keyEquivalent: ""
        )

        macStatusItem.isEnabled = false

        menu.addItem(macStatusItem)

        windowsStatusItem = NSMenuItem(
            title: "Windows klient: kontroluji…",
            action: nil,
            keyEquivalent: ""
        )

        windowsStatusItem.isEnabled = false

        menu.addItem(windowsStatusItem)

        shiftStatusItem = NSMenuItem(
            title: "Pracovní čas: neaktivní",
            action: nil,
            keyEquivalent: ""
        )

        shiftStatusItem.isEnabled = false

        menu.addItem(shiftStatusItem)

        menu.addItem(.separator())

        startAgentItem = item(
            "▶  Spustit Mac agent",
            symbol: "play.circle.fill",
            action: #selector(startAgent)
        )

        restartAgentItem = item(
            "🔄  Restartovat Mac agent",
            symbol: "arrow.clockwise.circle.fill",
            action: #selector(restartAgent)
        )

        stopAgentItem = item(
            "⏹️  Zastavit Mac agent",
            symbol: "stop.circle.fill",
            action: #selector(stopAgent)
        )

        menu.addItem(startAgentItem)
        menu.addItem(restartAgentItem)
        menu.addItem(stopAgentItem)

        menu.addItem(.separator())

        menu.addItem(
            item(
                "🏢  Začít kancelář",
                symbol: "briefcase.fill",
                action: #selector(startOffice)
            )
        )

        menu.addItem(
            item(
                "🏠  Začít Home office",
                symbol: "house.fill",
                action: #selector(startHome)
            )
        )

        menu.addItem(
            item(
                "🏁  Ukončit pracovní čas",
                symbol: "stop.fill",
                action: #selector(stopShift)
            )
        )

        menu.addItem(.separator())

        menu.addItem(
            item(
                "📝  Přidat poznámku…",
                symbol: "square.and.pencil",
                action: #selector(addNote)
            )
        )

        menu.addItem(
            item(
                "📞  Telefon / hovor…",
                symbol: "phone.fill",
                action: #selector(addCall)
            )
        )

        menu.addItem(
            item(
                "🚗  Výjezd / cesta…",
                symbol: "car.fill",
                action: #selector(addTravel)
            )
        )

        menu.addItem(
            item(
                "🛠️  Práce mimo PC…",
                symbol: "wrench.and.screwdriver.fill",
                action: #selector(addOffPC)
            )
        )

        menu.addItem(.separator())

        menu.addItem(
            item(
                "📋  Průběžný souhrn",
                symbol: "list.bullet.rectangle",
                action: #selector(showSummary)
            )
        )

        menu.addItem(
            item(
                "✨  AI souhrn",
                symbol: "sparkles",
                action: #selector(showAISummary)
            )
        )

        menu.addItem(
            item(
                "🕘  Poslední aktivita",
                symbol: "clock.arrow.circlepath",
                action: #selector(showRecent)
            )
        )

        menu.addItem(
            item(
                "📊  Vytvořit výkaz",
                symbol: "doc.text.fill",
                action: #selector(makeReport)
            )
        )

        menu.addItem(
            item(
                "📗  Otevřít Excel",
                symbol: "tablecells.fill",
                action: #selector(openExcel)
            )
        )

        menu.addItem(.separator())

        let ha = NSMenuItem(
            title: "🏠  Home Assistant odkazy",
            action: nil,
            keyEquivalent: ""
        )

        let haMenu = NSMenu(
            title: "🏠  Home Assistant odkazy"
        )

        haMenu.addItem(
            linkItem(
                "Herškovič",
                symbol: "person.crop.circle",
                url: "https://homeassistant-herskovic.skunk-atria.ts.net"
            )
        )

        haMenu.addItem(
            linkItem(
                "Vágner",
                symbol: "person.crop.circle",
                url: "https://homeassistant-vagner.skunk-atria.ts.net"
            )
        )

        haMenu.addItem(
            linkItem(
                "Evora",
                symbol: "building.2.fill",
                url: "https://homeassistant-work.skunk-atria.ts.net"
            )
        )

        haMenu.addItem(
            linkItem(
                "Domov",
                symbol: "house.fill",
                url: "https://homeassistant.skunk-atria.ts.net"
            )
        )

        ha.submenu = haMenu

        menu.addItem(ha)

        let evora = NSMenuItem(
            title: "💠  Evora Smart Hub",
            action: nil,
            keyEquivalent: ""
        )
        evoraMenu = NSMenu(title: "💠  Evora Smart Hub")
        evoraMenu.delegate = self
        evora.submenu = evoraMenu
        menu.addItem(evora)
        rebuildEvoraMenu()

        menu.addItem(
            linkItem(
                "🌐  Intranet Evora",
                symbol: "globe",
                url: "https://intranet.evora.cz/moje"
            )
        )

        menu.addItem(.separator())

        menu.addItem(
            item(
                "⏸️  Pozastavit sledování",
                symbol: "pause.circle.fill",
                action: #selector(pauseAgent)
            )
        )

        menu.addItem(
            item(
                "▶️  Pokračovat ve sledování",
                symbol: "play.circle.fill",
                action: #selector(resumeAgent)
            )
        )

        menu.addItem(.separator())

        menu.addItem(
            item(
                "❌  Ukončit pouze menu",
                symbol: "xmark.circle",
                action: #selector(quitMenu)
            )
        )

        statusItem.menu = menu
    }

    // MARK: - Refresh

    @objc func tickClock() {
        let shift = loadShift()

        guard shift.active else {
            return
        }

        let now = Date().timeIntervalSince1970

        var displayed =
            shift.accumulated

        if cachedAgent {
            displayed +=
                max(
                    0,
                    Int(
                        now
                        - shift.lastTick
                    )
                )
        }

        let h =
            displayed
            / 3600

        let m =
            (displayed % 3600)
            / 60

        let sec =
            displayed
            % 60

        let label =
            shift.mode == "office"
            ? "Kancelář"
            : "Home office"

        shiftStatusItem.attributedTitle =
            statusAttributed(
                label: "Pracovní režim",
                value: String(
                    format:
                        "%@ · %02d:%02d:%02d",
                    label,
                    h,
                    m,
                    sec
                ),
                color:
                    cachedAgent
                    ? .systemBlue
                    : .systemRed
            )

        if let button = statusItem.button {
            let symbolName =
                shift.mode == "office"
                ? "building.2.fill"
                : "house.fill"

            button.image = NSImage(
                systemSymbolName: symbolName,
                accessibilityDescription: nil
            )

            button.imagePosition = .imageLeading

            let windowsMark =
                cachedWindows == "ONLINE"
                ? " W✓"
                : " W!"

            button.title =
                String(
                    format: " %02d:%02d:%02d%@",
                    h,
                    m,
                    sec,
                    windowsMark
                )
        }
    }

    @objc func refreshAll() {
        if refreshInFlight {
            return
        }

        refreshInFlight = true

        DispatchQueue.global(qos: .utility).async { [weak self] in
            guard let self = self else {
                return
            }

            let q = self.quick()

            DispatchQueue.main.async { [weak self] in
                guard let self = self else {
                    return
                }

                self.refreshInFlight = false
                self.applyRefresh(q)
            }
        }
    }

    private func applyRefresh(_ q: [String: Any]) {



        let agent =
            (q["agent_running"] as? Bool)
            ?? false

        let windows =
            (q["windows"] as? String)
            ?? "NIKDY"

        let windowsAge =
            q["windows_last_seconds"]
            as? Double

        cachedAgent = agent
        cachedWindows = windows

        // Mac agent status
        if agent {
            macStatusItem.attributedTitle =
                statusAttributed(
                    label: "Mac agent",
                    value: "● ONLINE",
                    color: .systemGreen
                )
        } else {
            macStatusItem.attributedTitle =
                statusAttributed(
                    label: "Mac agent",
                    value: "● OFFLINE",
                    color: .systemRed
                )
        }

        // Windows status
        if windows == "ONLINE" {

            let age =
                Int(
                    windowsAge
                    ?? 0
                )

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● ONLINE · \(age) s",
                    color: .systemGreen
                )

        } else if windows == "ZPOZDENI" {

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● ZPOŽDĚNÍ",
                    color: .systemOrange
                )

        } else if windows == "OFFLINE" {

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● OFFLINE",
                    color: .systemRed
                )

        } else {

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● BEZ DAT",
                    color: .secondaryLabelColor
                )
        }

        // Agent action visibility
        startAgentItem.isHidden = agent
        restartAgentItem.isHidden = !agent
        stopAgentItem.isHidden = !agent

        // Shift
        var shift = loadShift()

        let now =
            Date()
                .timeIntervalSince1970

        if shift.active {

            if agent {

                let delta =
                    max(
                        0,
                        Int(
                            now
                            - shift.lastTick
                        )
                    )

                shift.accumulated += delta
            }

            shift.lastTick = now

            saveShift(shift)
        }

        let h =
            shift.accumulated
            / 3600

        let m =
            (
                shift.accumulated
                % 3600
            )
            / 60

        let s =
            shift.accumulated
            % 60

        if shift.active {

            let label =
                shift.mode == "office"
                ? "Kancelář"
                : "Home office"

            shiftStatusItem.attributedTitle =
                statusAttributed(
                    label: "Pracovní režim",
                    value: String(
                        format:
                            "%@ · %02d:%02d:%02d",
                        label,
                        h,
                        m,
                        s
                    ),
                    color:
                        agent
                        ? .systemBlue
                        : .systemRed
                )

            // Horní lištu při aktivní směně aktualizuje pouze tickClock()
        

        } else {

            shiftStatusItem.attributedTitle =
                statusAttributed(
                    label: "Pracovní režim",
                    value: "NEAKTIVNÍ",
                    color: .secondaryLabelColor
                )

            if let button = statusItem.button {
                button.title = ""
                button.image = loxoneLikeIcon()
            }
        }
    
    }

    // MARK: - Agent control

    func ensureAgent() -> Bool {

        let q1 = quick()

        if
            (
                q1[
                    "agent_running"
                ]
                as? Bool
            )
            == true
        {
            return true
        }

        _ = runWork(
            [
                "spustit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1.5
        )

        let q2 = quick()

        return
            (
                q2[
                    "agent_running"
                ]
                as? Bool
            )
            == true
    }

    @objc func startAgent() {

        _ = runWork(
            [
                "spustit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        refreshAll()
    }

    @objc func restartAgent() {

        _ = runWork(
            [
                "zastavit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        _ = runWork(
            [
                "spustit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        refreshAll()
    }

    @objc func stopAgent() {

        _ = runWork(
            [
                "zastavit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        refreshAll()
    }

    // MARK: - Shift control

    func startShift(
        _ mode: String
    ) {

        guard ensureAgent()
        else {

            showAlert(
                "WorkLog",
                "Mac agent se nepodařilo spustit. Pracovní čas nebyl zahájen."
            )

            return
        }

        let cmd =
            mode == "office"
            ? "kancelar"
            : "homeoffice"

        _ = runWork(
            [
                cmd
            ]
        )

        let shift =
            ShiftState(
                active: true,
                mode: mode,
                accumulated: 0,
                lastTick:
                    Date()
                        .timeIntervalSince1970
            )

        saveShift(shift)

        refreshAll()
    }

    @objc func startOffice() {
        startShift(
            "office"
        )
    }

    @objc func startHome() {
        startShift(
            "homeoffice"
        )
    }

    @objc func stopShift() {

        _ = runWork(
            [
                "konec-prace"
            ]
        )

        saveShift(
            ShiftState(
                active: false,
                mode: "",
                accumulated: 0,
                lastTick:
                    Date()
                        .timeIntervalSince1970
            )
        )

        refreshAll()
    }

    // MARK: - Alerts

    func showAlert(
        _ title: String,
        _ body: String
    ) {

        NSApp.activate(
            ignoringOtherApps: true
        )

        let alert =
            NSAlert()

        alert.messageText =
            title

        alert.informativeText =
            body

        alert.addButton(
            withTitle: "OK"
        )

        alert.runModal()
    }

    func showScrollableAlert(
        _ title: String,
        _ body: String
    ) {

        NSApp.activate(
            ignoringOtherApps: true
        )

        let alert = NSAlert()
        alert.messageText = title
        alert.addButton(withTitle: "Zavřít")

        let scroll = NSScrollView(
            frame: NSRect(
                x: 0,
                y: 0,
                width: 560,
                height: 500
            )
        )

        scroll.hasVerticalScroller = true
        scroll.hasHorizontalScroller = false
        scroll.autohidesScrollers = true
        scroll.borderType = .bezelBorder

        let textView = NSTextView(
            frame: NSRect(
                x: 0,
                y: 0,
                width: 540,
                height: 500
            )
        )

        textView.isEditable = false
        textView.isSelectable = true
        textView.drawsBackground = false
        textView.isRichText = false
        textView.font = NSFont.monospacedSystemFont(
            ofSize: 12,
            weight: .regular
        )
        textView.textContainerInset = NSSize(
            width: 10,
            height: 10
        )
        textView.textContainer?.widthTracksTextView = true
        textView.textContainer?.containerSize = NSSize(
            width: 540,
            height: CGFloat.greatestFiniteMagnitude
        )
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.autoresizingMask = [.width]
        textView.string = body

        scroll.documentView = textView
        alert.accessoryView = scroll

        alert.runModal()
    }

    func inputDialog(
        _ title: String,
        command: String
    ) {

        NSApp.activate(
            ignoringOtherApps: true
        )

        let alert =
            NSAlert()

        alert.messageText =
            title

        alert.informativeText =
            "Napiš stručně, co se řešilo. Délka v minutách je volitelná."

        alert.addButton(
            withTitle: "Uložit"
        )

        alert.addButton(
            withTitle: "Zrušit"
        )

        let container =
            NSView(
                frame:
                    NSRect(
                        x: 0,
                        y: 0,
                        width: 440,
                        height: 72
                    )
            )

        let textField =
            NSTextField(
                frame:
                    NSRect(
                        x: 0,
                        y: 40,
                        width: 440,
                        height: 26
                    )
            )

        textField.placeholderString =
            "Co se řešilo?"

        let minutesField =
            NSTextField(
                frame:
                    NSRect(
                        x: 0,
                        y: 4,
                        width: 180,
                        height: 26
                    )
            )

        minutesField.placeholderString =
            "Délka v minutách"

        container.addSubview(
            textField
        )

        container.addSubview(
            minutesField
        )

        alert.accessoryView =
            container

        alert.window
            .initialFirstResponder =
            textField

        guard
            alert.runModal()
            == .alertFirstButtonReturn
        else {
            return
        }

        let body =
            textField
                .stringValue
                .trimmingCharacters(
                    in:
                        .whitespacesAndNewlines
                )

        if body.isEmpty {
            return
        }

        var args =
            [
                command,
                body
            ]

        let mins =
            minutesField
                .stringValue
                .trimmingCharacters(
                    in:
                        .whitespacesAndNewlines
                )

        if !mins.isEmpty {

            args +=
                [
                    "--minutes",
                    mins
                ]
        }

        showAlert(
            "WorkLog",
            runWork(args)
        )
    }

    // MARK: - Manual entries

    @objc func addNote() {
        inputDialog(
            "Přidat poznámku",
            command:
                "poznamka"
        )
    }

    @objc func addCall() {
        inputDialog(
            "Telefon / hovor",
            command:
                "hovor"
        )
    }

    @objc func addTravel() {
        inputDialog(
            "Výjezd / cesta",
            command:
                "vyjezd"
        )
    }

    @objc func addOffPC() {
        inputDialog(
            "Práce mimo PC",
            command:
                "mimo-pc"
        )
    }

    // MARK: - Reports

    @objc func showSummary() {
        showAlert(
            "📋  Průběžný souhrn",
            runWork(
                [
                    "souhrn"
                ]
            )
        )
    }

    @objc func showAISummary() {
        showAlert(
            "✨  AI souhrn",
            runWork(
                [
                    "souhrn-ai"
                ]
            )
        )
    }

    @objc func showRecent() {
        showScrollableAlert(
            "🕘  Poslední aktivita",
            runWork(
                [
                    "posledni",
                    "8"
                ]
            )
        )
    }

    @objc func makeReport() {
        showAlert(
            "Výkaz práce",
            runWork(
                [
                    "vykaz"
                ]
            )
        )
    }

    @objc func openExcel() {

        NSWorkspace.shared.open(
            URL(
                fileURLWithPath:
                    "\(home)/Documents/WorkLogAI/Pracovni_vykaz.xlsx"
            )
        )
    }

    // MARK: - Evora actions

    func evoraTextView(_ value: String, width: CGFloat = 560, height: CGFloat = 360) -> NSScrollView {
        let scroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        scroll.hasVerticalScroller = true
        scroll.hasHorizontalScroller = false
        scroll.autohidesScrollers = true
        scroll.borderType = .bezelBorder
        let textView = NSTextView(frame: NSRect(x: 0, y: 0, width: width - 20, height: height))
        textView.isEditable = false
        textView.isSelectable = true
        textView.drawsBackground = false
        textView.isRichText = false
        textView.font = NSFont.systemFont(ofSize: 12)
        textView.textContainerInset = NSSize(width: 10, height: 10)
        textView.textContainer?.widthTracksTextView = true
        textView.textContainer?.containerSize = NSSize(width: width - 20, height: CGFloat.greatestFiniteMagnitude)
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.autoresizingMask = [.width]
        textView.string = value
        scroll.documentView = textView
        return scroll
    }

    func evoraAttributedTextView(_ value: NSAttributedString, width: CGFloat = 560, height: CGFloat = 360) -> NSScrollView {
        let scroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: width, height: height))
        scroll.hasVerticalScroller = true
        scroll.hasHorizontalScroller = false
        scroll.autohidesScrollers = true
        scroll.borderType = .noBorder
        let textView = NSTextView(frame: NSRect(x: 0, y: 0, width: width - 20, height: height))
        textView.isEditable = false
        textView.isSelectable = true
        textView.isRichText = true
        textView.drawsBackground = true
        textView.backgroundColor = .windowBackgroundColor
        textView.textContainerInset = NSSize(width: 12, height: 12)
        textView.textContainer?.widthTracksTextView = true
        textView.textContainer?.containerSize = NSSize(width: width - 20, height: CGFloat.greatestFiniteMagnitude)
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.autoresizingMask = [.width]
        textView.textStorage?.setAttributedString(value)
        scroll.documentView = textView
        return scroll
    }

    func evoraPortalTicketText(_ ticket: EvoraPortalTicketDetail) -> String {
        var sections: [String] = [
            "#\(ticket.ticketNumber) · \(evoraPortalTicketStatus(ticket.status))",
            ticket.subject,
            "Kontakt: \(ticket.contactName.isEmpty ? "neuveden" : ticket.contactName)",
            "Založeno: \(ticket.createdTime)"
        ]
        if !ticket.attachments.isEmpty {
            sections.append("Přílohy ticketu: \(ticket.attachments.map(\.name).joined(separator: ", "))")
        }
        for thread in ticket.threads {
            let fullName = "\(thread.author.firstName) \(thread.author.lastName)"
                .trimmingCharacters(in: .whitespacesAndNewlines)
            let author = fullName.isEmpty
                ? (thread.author.isLoxone ? "LOXONE podpora" : "Evora Smart")
                : fullName
            var message = "\(thread.createdTime) · \(author)\(thread.author.isLoxone ? " · LOXONE" : "")\n\n\(thread.content)"
            if !thread.attachments.isEmpty {
                message += "\n\nPřílohy: \(thread.attachments.map(\.name).joined(separator: ", "))"
            }
            sections.append(message)
        }
        return sections.joined(separator: "\n\n────────────────────────\n\n")
    }

    func evoraPortalTicketAttributedText(_ ticket: EvoraPortalTicketDetail) -> NSAttributedString {
        let result = NSMutableAttributedString()
        let bodyStyle = NSMutableParagraphStyle()
        bodyStyle.lineSpacing = 3
        bodyStyle.paragraphSpacing = 8
        let bubbleStyle = NSMutableParagraphStyle()
        bubbleStyle.lineSpacing = 4
        bubbleStyle.paragraphSpacing = 14
        bubbleStyle.firstLineHeadIndent = 10
        bubbleStyle.headIndent = 10
        bubbleStyle.tailIndent = -10

        func append(_ text: String, _ attributes: [NSAttributedString.Key: Any]) {
            result.append(NSAttributedString(string: text, attributes: attributes))
        }

        append("#\(ticket.ticketNumber) · \(evoraPortalTicketStatus(ticket.status))\n", [
            .font: NSFont.boldSystemFont(ofSize: 13),
            .foregroundColor: NSColor.systemGreen,
            .paragraphStyle: bodyStyle
        ])
        append("\(ticket.subject)\nKontakt: \(ticket.contactName.isEmpty ? "neuveden" : ticket.contactName) · Založeno: \(ticket.createdTime)\n\n", [
            .font: NSFont.systemFont(ofSize: 12),
            .foregroundColor: NSColor.labelColor,
            .paragraphStyle: bodyStyle
        ])

        for thread in ticket.threads {
            let fullName = "\(thread.author.firstName) \(thread.author.lastName)"
                .trimmingCharacters(in: .whitespacesAndNewlines)
            let author = fullName.isEmpty
                ? (thread.author.isLoxone ? "LOXONE podpora" : "Evora Smart")
                : fullName
            let accent = thread.author.isLoxone ? NSColor.systemGreen : NSColor.systemTeal
            append("●  \(author)\n", [
                .font: NSFont.boldSystemFont(ofSize: 11),
                .foregroundColor: accent,
                .paragraphStyle: bodyStyle
            ])
            append("\(thread.createdTime)\n", [
                .font: NSFont.systemFont(ofSize: 9),
                .foregroundColor: NSColor.secondaryLabelColor,
                .paragraphStyle: bodyStyle
            ])
            append("\(thread.content.trimmingCharacters(in: .whitespacesAndNewlines))\n", [
                .font: NSFont.systemFont(ofSize: 12),
                .foregroundColor: NSColor.labelColor,
                .backgroundColor: thread.author.isLoxone ? NSColor.systemGreen.withAlphaComponent(0.08) : NSColor.systemTeal.withAlphaComponent(0.08),
                .paragraphStyle: bubbleStyle
            ])
            if !thread.attachments.isEmpty {
                append("📎  \(thread.attachments.map(\.name).joined(separator: ", "))\n\n", [
                    .font: NSFont.systemFont(ofSize: 10),
                    .foregroundColor: NSColor.systemBlue,
                    .paragraphStyle: bodyStyle
                ])
            }
        }
        return result
    }

    func evoraPortalTicketAttachments(_ ticket: EvoraPortalTicketDetail) -> [EvoraPortalTicketAttachment] {
        var result: [EvoraPortalTicketAttachment] = []
        var seen = Set<String>()
        for attachment in ticket.attachments + ticket.threads.flatMap(\.attachments) {
            let key = "\(attachment.id)\n\(attachment.name)"
            guard seen.insert(key).inserted else { continue }
            result.append(attachment)
        }
        return result
    }

    func presentEvoraPortalAttachments(_ attachments: [EvoraPortalTicketAttachment]) {
        guard !attachments.isEmpty else {
            showAlert("Přílohy ticketu", "Portál u tohoto ticketu nevrátil žádnou skutečnou přílohu.")
            return
        }
        let downloadable = attachments.filter(\.canDownload)
        let displayOnly = attachments.filter { !$0.canDownload }
        NSApp.activate(ignoringOtherApps: true)
        let alert = NSAlert()
        alert.messageText = "Přílohy ticketu"
        if downloadable.isEmpty {
            alert.informativeText = "Portál poskytl názvy souborů bez bezpečných adres. Zobrazuji je proto jen jako přehled, nikoli jako nefunkční tlačítka."
        } else if displayOnly.isEmpty {
            alert.informativeText = "Vyberte přílohu. WorkFlowAI ji bezpečně načte přes Evora Smart Hub a otevře v odpovídající aplikaci macOS."
        } else {
            alert.informativeText = "Dostupné přílohy lze otevřít. Soubory, u kterých Portál poskytl jen název, jsou uvedené zvlášť jako přehled."
        }

        let width: CGFloat = 520
        let listHeight = displayOnly.isEmpty
            ? CGFloat(0)
            : min(CGFloat(220), max(CGFloat(72), CGFloat(displayOnly.count * 22 + 20)))
        let downloadableHeight: CGFloat = downloadable.isEmpty ? 0 : 59
        let displayOnlyHeight: CGFloat = displayOnly.isEmpty ? 0 : listHeight + 25
        let sectionSpacing: CGFloat = downloadable.isEmpty || displayOnly.isEmpty ? 0 : 12
        let containerHeight = downloadableHeight + displayOnlyHeight + sectionSpacing
        let container = NSView(frame: NSRect(x: 0, y: 0, width: width, height: containerHeight))
        var cursor = containerHeight
        var selector: NSPopUpButton?

        if !downloadable.isEmpty {
            let heading = NSTextField(labelWithString: "Dostupné ke stažení")
            heading.font = NSFont.systemFont(ofSize: 12, weight: .semibold)
            heading.frame = NSRect(x: 0, y: cursor - 17, width: width, height: 17)
            container.addSubview(heading)
            cursor -= 25

            let popUp = NSPopUpButton(frame: NSRect(x: 0, y: cursor - 32, width: width, height: 32), pullsDown: false)
            popUp.addItems(withTitles: downloadable.map(\.name))
            container.addSubview(popUp)
            selector = popUp
            cursor -= 32
        }

        if !displayOnly.isEmpty {
            if !downloadable.isEmpty { cursor -= sectionSpacing }
            let heading = NSTextField(labelWithString: "Názvy souborů z Portálu")
            heading.font = NSFont.systemFont(ofSize: 12, weight: .semibold)
            heading.frame = NSRect(x: 0, y: cursor - 17, width: width, height: 17)
            container.addSubview(heading)
            cursor -= 25

            let list = evoraTextView(
                displayOnly.map { "• \($0.name)" }.joined(separator: "\n"),
                width: width,
                height: listHeight
            )
            list.frame = NSRect(x: 0, y: cursor - listHeight, width: width, height: listHeight)
            container.addSubview(list)
        }

        alert.accessoryView = container
        if downloadable.isEmpty {
            alert.addButton(withTitle: "Zavřít")
            _ = alert.runModal()
            return
        }
        alert.addButton(withTitle: "Otevřít vybranou")
        alert.addButton(withTitle: "Zavřít")
        guard alert.runModal() == .alertFirstButtonReturn, let selector else { return }
        let index = max(0, min(selector.indexOfSelectedItem, downloadable.count - 1))
        downloadEvoraPortalAttachment(downloadable[index]) { [weak self] result in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success(let file):
                    NSWorkspace.shared.open(file)
                case .failure(let error):
                    self.showAlert("Přílohy ticketu", error.localizedDescription)
                }
            }
        }
    }

    @objc func showEvoraPortalTicket(_ sender: NSMenuItem) {
        guard let id = sender.representedObject as? String else { return }
        evoraRequest(
            path: "/api/integrations/worklog/v1/portal-tickets/\(id)"
        ) { [weak self] (result: Result<EvoraPortalTicketDetailResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success(let response):
                    self.presentEvoraPortalTicket(response.ticket)
                case .failure(let error):
                    self.showAlert("LOXONE tickety", error.localizedDescription)
                }
            }
        }
    }

    func presentEvoraPortalTicket(_ ticket: EvoraPortalTicketDetail) {
        NSApp.activate(ignoringOtherApps: true)
        let attachments = evoraPortalTicketAttachments(ticket)
        let alert = NSAlert()
        alert.messageText = "#\(ticket.ticketNumber) · \(ticket.subject)"
        alert.informativeText = attachments.isEmpty
            ? "\(evoraPortalTicketStatus(ticket.status)) · veřejná komunikace z Loxone Partner Portálu."
            : "\(evoraPortalTicketStatus(ticket.status)) · veřejná komunikace · \(attachments.count) příloh."
        alert.addButton(withTitle: "Odpovědět…")
        if !attachments.isEmpty {
            alert.addButton(withTitle: "Přílohy (\(attachments.count))…")
        }
        alert.addButton(withTitle: "Otevřít v Hubu")
        alert.addButton(withTitle: "Zavřít")
        alert.accessoryView = evoraAttributedTextView(evoraPortalTicketAttributedText(ticket), height: 430)
        let answer = alert.runModal()
        if answer == .alertFirstButtonReturn {
            presentEvoraPortalComposer(ticket: ticket)
            return
        }
        if !attachments.isEmpty, answer == .alertSecondButtonReturn {
            presentEvoraPortalAttachments(attachments)
            return
        }
        let hubResponse: NSApplication.ModalResponse = attachments.isEmpty ? .alertSecondButtonReturn : .alertThirdButtonReturn
        if answer == hubResponse, let url = URL(string: "\(evoraHubURL())?page=tickets") {
            NSWorkspace.shared.open(url)
        }
    }

    @objc func createEvoraPortalTicket() {
        presentEvoraPortalComposer(ticket: nil)
    }

    func presentEvoraPortalComposer(ticket: EvoraPortalTicketDetail?, draft: EvoraPortalDraft? = nil) {
        NSApp.activate(ignoringOtherApps: true)
        let isReply = ticket != nil
        let alert = NSAlert()
        alert.messageText = isReply ? "Odpověď do ticketu #\(ticket?.ticketNumber ?? "")" : "Nový LOXONE ticket"
        alert.informativeText = "Po pokračování se zobrazí úplný náhled. Nic se neodešle bez následného potvrzení heslem."
        alert.addButton(withTitle: "Zkontrolovat návrh")
        alert.addButton(withTitle: "Zrušit")

        let containerHeight: CGFloat = isReply ? 255 : 300
        let container = NSView(frame: NSRect(x: 0, y: 0, width: 560, height: containerHeight))
        let subjectLabel = NSTextField(labelWithString: "Předmět")
        subjectLabel.frame = NSRect(x: 0, y: containerHeight - 20, width: 560, height: 17)
        let subjectField = NSTextField(frame: NSRect(x: 0, y: containerHeight - 52, width: 560, height: 26))
        subjectField.stringValue = draft?.subject ?? ticket?.subject ?? ""
        subjectField.isEditable = !isReply
        subjectField.isSelectable = true
        let bodyLabel = NSTextField(labelWithString: "Celá zpráva")
        bodyLabel.frame = NSRect(x: 0, y: containerHeight - 79, width: 560, height: 17)
        let bodyScroll = NSScrollView(frame: NSRect(x: 0, y: 0, width: 560, height: containerHeight - 84))
        bodyScroll.hasVerticalScroller = true
        bodyScroll.borderType = .bezelBorder
        let bodyField = NSTextView(frame: NSRect(x: 0, y: 0, width: 540, height: containerHeight - 84))
        bodyField.isRichText = false
        bodyField.font = NSFont.systemFont(ofSize: 12)
        bodyField.textContainerInset = NSSize(width: 8, height: 8)
        bodyField.string = draft?.body ?? ""
        bodyScroll.documentView = bodyField
        container.addSubview(subjectLabel)
        container.addSubview(subjectField)
        container.addSubview(bodyLabel)
        container.addSubview(bodyScroll)
        alert.accessoryView = container
        alert.window.initialFirstResponder = isReply ? bodyField : subjectField

        guard alert.runModal() == .alertFirstButtonReturn else { return }
        let subject = subjectField.stringValue.trimmingCharacters(in: .whitespacesAndNewlines)
        let body = bodyField.string.trimmingCharacters(in: .whitespacesAndNewlines)
        guard subject.count >= 3 else {
            showAlert("LOXONE tickety", "Předmět musí mít alespoň 3 znaky.")
            presentEvoraPortalComposer(ticket: ticket, draft: EvoraPortalDraft(ticketId: ticket?.id, ticketNumber: ticket?.ticketNumber, subject: subject, body: body))
            return
        }
        guard body.count >= (isReply ? 1 : 3) else {
            showAlert("LOXONE tickety", "Zpráva je příliš krátká.")
            presentEvoraPortalComposer(ticket: ticket, draft: EvoraPortalDraft(ticketId: ticket?.id, ticketNumber: ticket?.ticketNumber, subject: subject, body: body))
            return
        }
        reviewEvoraPortalDraft(
            EvoraPortalDraft(
                ticketId: ticket?.id,
                ticketNumber: ticket?.ticketNumber,
                subject: subject,
                body: body
            ),
            ticket: ticket
        )
    }

    func reviewEvoraPortalDraft(_ draft: EvoraPortalDraft, ticket: EvoraPortalTicketDetail?) {
        NSApp.activate(ignoringOtherApps: true)
        let action = draft.isReply ? "Přidat veřejnou odpověď do #\(draft.ticketNumber ?? "")" : "Vytvořit nový ticket"
        let preview = "Kam: Loxone Partner Portal\nAkce: \(action)\nPředmět: \(draft.subject)\n\nCELÝ TEXT ZPRÁVY\n\n\(draft.body)"
        let alert = NSAlert()
        alert.messageText = "Kontrola před odesláním"
        alert.informativeText = "Níže je úplný návrh. V této chvíli ještě nic nebylo odesláno."
        alert.addButton(withTitle: "Pokračovat k heslu")
        alert.addButton(withTitle: "Zpět upravit")
        alert.addButton(withTitle: "Zrušit")
        alert.accessoryView = evoraTextView(preview, height: 380)
        let answer = alert.runModal()
        if answer == .alertFirstButtonReturn {
            confirmEvoraPortalDraft(draft)
        } else if answer == .alertSecondButtonReturn {
            presentEvoraPortalComposer(ticket: ticket, draft: draft)
        }
    }

    func confirmEvoraPortalDraft(_ draft: EvoraPortalDraft) {
        NSApp.activate(ignoringOtherApps: true)
        let alert = NSAlert()
        alert.messageText = "Potvrdit odeslání heslem"
        alert.informativeText = "Heslo slouží jen k jednorázovému potvrzení přesně zkontrolovaného návrhu."
        alert.addButton(withTitle: "Potvrdit a odeslat")
        alert.addButton(withTitle: "Zrušit")
        let password = NSSecureTextField(frame: NSRect(x: 0, y: 0, width: 420, height: 26))
        password.placeholderString = "Heslo do Evora Smart Hubu"
        alert.accessoryView = password
        alert.window.initialFirstResponder = password
        guard alert.runModal() == .alertFirstButtonReturn else { return }
        guard !password.stringValue.isEmpty else {
            showAlert("LOXONE tickety", "Heslo je povinné.")
            return
        }
        let action = draft.isReply ? "portal_ticket_reply" : "portal_ticket_create"
        let payload: [String: Any] = draft.isReply
            ? ["ticketId": draft.ticketId ?? "", "content": draft.body]
            : ["subject": draft.subject, "description": draft.body]
        evoraRequest(
            path: "/api/integrations/worklog/v1/portal-tickets/confirm",
            method: "POST",
            body: ["action": action, "password": password.stringValue, "payload": payload]
        ) { [weak self] (result: Result<EvoraConfirmationResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success(let response):
                    self.sendEvoraPortalDraft(draft, confirmationId: response.confirmationId)
                case .failure(let error):
                    self.showAlert("LOXONE tickety", error.localizedDescription)
                }
            }
        }
    }

    func sendEvoraPortalDraft(_ draft: EvoraPortalDraft, confirmationId: String) {
        let path = draft.isReply
            ? "/api/integrations/worklog/v1/portal-tickets/\(draft.ticketId ?? "")/replies"
            : "/api/integrations/worklog/v1/portal-tickets"
        let body: [String: Any] = draft.isReply
            ? ["content": draft.body]
            : ["subject": draft.subject, "description": draft.body]
        evoraRequest(
            path: path,
            method: "POST",
            body: body,
            headers: ["X-Action-Confirmation": confirmationId]
        ) { [weak self] (result: Result<EvoraPortalMutationResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success:
                    self.showAlert("LOXONE tickety", draft.isReply ? "Odpověď byla odeslána." : "Ticket byl vytvořen.")
                    self.refreshEvoraTickets()
                case .failure(let error):
                    self.showAlert("LOXONE tickety", error.localizedDescription)
                }
            }
        }
    }

    @objc func configureEvoraConnection() {
        NSApp.activate(ignoringOtherApps: true)
        let alert = NSAlert()
        alert.messageText = "Evora Smart Hub"
        alert.informativeText = "Vložte adresu Hubu a osobní WorkLog token vytvořený v Nastavení Evora Smart Hubu. Token se uloží pouze do macOS Klíčenky."
        alert.addButton(withTitle: "Uložit")
        alert.addButton(withTitle: "Odpojit tento Mac")
        alert.addButton(withTitle: "Zrušit")

        let container = NSView(
            frame: NSRect(x: 0, y: 0, width: 480, height: 104)
        )
        let urlLabel = NSTextField(labelWithString: "Adresa Evora Smart Hubu")
        urlLabel.frame = NSRect(x: 0, y: 82, width: 480, height: 17)
        let urlField = NSTextField(
            frame: NSRect(x: 0, y: 52, width: 480, height: 26)
        )
        urlField.stringValue = evoraHubURL()
        let tokenLabel = NSTextField(labelWithString: "Osobní WorkLog token")
        tokenLabel.frame = NSRect(x: 0, y: 30, width: 480, height: 17)
        let tokenField = NSSecureTextField(
            frame: NSRect(x: 0, y: 0, width: 480, height: 26)
        )
        tokenField.placeholderString = evoraToken() == nil
            ? "esh_worklog_…"
            : "ponechte prázdné, pokud token neměníte"
        container.addSubview(urlLabel)
        container.addSubview(urlField)
        container.addSubview(tokenLabel)
        container.addSubview(tokenField)
        alert.accessoryView = container
        alert.window.initialFirstResponder = evoraToken() == nil
            ? tokenField
            : urlField

        let answer = alert.runModal()
        if answer == .alertSecondButtonReturn {
            deleteEvoraToken()
            evoraServers = []
            evoraLauncherAgent = nil
            evoraStatus = "Evora Smart Hub: nepřipojeno"
            evoraTickets = []
            evoraTicketsStatus = "Tickety: nepřipojeno"
            rebuildEvoraMenu()
            return
        }
        guard answer == .alertFirstButtonReturn else { return }
        guard let normalizedURL = validEvoraHubURL(urlField.stringValue) else {
            showAlert(
                "Evora Smart Hub",
                "Použijte platnou HTTPS adresu bez parametrů. HTTP je povolené pouze pro localhost."
            )
            return
        }
        let newToken = tokenField.stringValue.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        if evoraToken() == nil && newToken.isEmpty {
            showAlert("Evora Smart Hub", "Osobní WorkLog token je povinný.")
            return
        }
        if !newToken.isEmpty {
            guard newToken.hasPrefix("esh_worklog_") else {
                showAlert("Evora Smart Hub", "Vložený token nemá platný formát.")
                return
            }
            guard saveEvoraToken(newToken) else {
                showAlert("Evora Smart Hub", "Token se nepodařilo uložit do macOS Klíčenky.")
                return
            }
        }
        UserDefaults.standard.set(normalizedURL, forKey: evoraHubDefaultsKey)
        evoraLastRefresh = .distantPast
        refreshEvoraMenu()
    }

    @objc func runEvoraAction(_ sender: NSMenuItem) {
        guard
            let payload = sender.representedObject as? NSDictionary,
            let serial = payload["serial"] as? String,
            let action = payload["action"] as? String
        else {
            return
        }
        evoraStatus = action == "loxone_app"
            ? "Připravuji Loxone App pro \(serial)…"
            : "Předávám \(serial) do Windows…"
        rebuildEvoraMenu()
        evoraRequest(
            path: "/api/integrations/worklog/v1/miniservers/\(serial)/actions",
            method: "POST",
            body: ["action": action]
        ) { [weak self] (result: Result<EvoraActionResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success(let response):
                    if response.action == "loxone_app" {
                        guard
                            let value = response.url,
                            let url = URL(string: value),
                            url.scheme?.lowercased() == "loxone"
                        else {
                            self.evoraStatus = "Loxone App: neplatná odpověď"
                            self.rebuildEvoraMenu()
                            self.showAlert("Evora Smart Hub", "Hub nevrátil bezpečný odkaz pro Loxone App.")
                            return
                        }
                        self.evoraStatus = "Loxone App otevřena pro \(serial)"
                        self.rebuildEvoraMenu()
                        if !NSWorkspace.shared.open(url) {
                            self.showAlert("Loxone App", "macOS nedokázal otevřít schéma loxone://. Ověřte instalaci Loxone App.")
                        }
                        return
                    }
                    guard let job = response.job else {
                        self.evoraStatus = "Config: neplatná odpověď"
                        self.rebuildEvoraMenu()
                        self.showAlert("Loxone Config", "Hub nevrátil vytvořený požadavek.")
                        return
                    }
                    self.evoraStatus = "Windows Launcher převzal požadavek…"
                    self.rebuildEvoraMenu()
                    self.pollEvoraConfigJob(job.id, attempt: 0)
                case .failure(let error):
                    self.evoraStatus = "Chyba: \(error.localizedDescription)"
                    self.rebuildEvoraMenu()
                    self.showAlert("Evora Smart Hub", error.localizedDescription)
                }
            }
        }
    }

    func pollEvoraConfigJob(_ id: String, attempt: Int) {
        guard attempt < 150 else {
            evoraStatus = "Loxone Config: vypršel čas kontroly"
            rebuildEvoraMenu()
            showAlert("Loxone Config", "Windows Launcher nepotvrdil výsledek v časovém limitu.")
            return
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { [weak self] in
            guard let self else { return }
            self.evoraRequest(
                path: "/api/integrations/worklog/v1/config-jobs/\(id)"
            ) { [weak self] (result: Result<EvoraJobResponse, Error>) in
                DispatchQueue.main.async {
                    guard let self else { return }
                    switch result {
                    case .failure(let error):
                        self.evoraStatus = "Config: \(error.localizedDescription)"
                        self.rebuildEvoraMenu()
                        self.showAlert("Loxone Config", error.localizedDescription)
                    case .success(let response):
                        let job = response.job
                        if job.state == "succeeded" {
                            self.evoraStatus = "Loxone Config \(job.requiredVersion) je otevřený"
                            self.rebuildEvoraMenu()
                        } else if ["missing_config", "failed", "expired"].contains(job.state) {
                            self.evoraStatus = "Config: \(job.message)"
                            self.rebuildEvoraMenu()
                            self.showEvoraConfigFailure(job)
                        } else {
                            self.evoraStatus = job.message
                            self.rebuildEvoraMenu()
                            self.pollEvoraConfigJob(id, attempt: attempt + 1)
                        }
                    }
                }
            }
        }
    }

    func showEvoraConfigFailure(_ job: EvoraConfigJob) {
        NSApp.activate(ignoringOtherApps: true)
        let alert = NSAlert()
        alert.messageText = job.state == "missing_config"
            ? "Požadovaný Loxone Config chybí"
            : "Loxone Config se nepodařilo otevřít"
        alert.informativeText = job.message
        if job.state == "missing_config", job.configUrl != nil {
            alert.addButton(withTitle: "Stáhnout Config \(job.requiredVersion)")
            alert.addButton(withTitle: "Zavřít")
            if alert.runModal() == .alertFirstButtonReturn,
               let value = job.configUrl,
               let url = URL(string: value) {
                NSWorkspace.shared.open(url)
            }
        } else {
            alert.addButton(withTitle: "OK")
            alert.runModal()
        }
    }

    // MARK: - Links

    @objc func openURL(
        _ sender: NSMenuItem
    ) {

        guard
            let value =
                sender
                    .representedObject
                as? String,

            let url =
                URL(
                    string:
                        value
                )

        else {
            return
        }

        NSWorkspace
            .shared
            .open(url)
    }

    // MARK: - Misc

    @objc func pauseAgent() {
        showAlert(
            "WorkLog",
            runWork(
                [
                    "pauza"
                ]
            )
        )
    }

    @objc func resumeAgent() {
        showAlert(
            "WorkLog",
            runWork(
                [
                    "pokracovat"
                ]
            )
        )
    }

    @objc func quitMenu() {
        NSApp.terminate(nil)
    }
}

let app =
    NSApplication.shared

let delegate =
    AppDelegate()

app.delegate =
    delegate

app.setActivationPolicy(
    .accessory
)

app.run()
