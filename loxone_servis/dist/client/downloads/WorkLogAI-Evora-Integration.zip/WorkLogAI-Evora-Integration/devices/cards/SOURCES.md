# Oficiální fotografie Miniserverů

Velké karty používají samostatné produktové podklady s průhledným pozadím. Malé
ikony v seznamech zůstávají v nadřazeném adresáři `devices/`.

- `miniserver.png` - LOXONE Miniserver Gen. 2, art. 100335; čelní transparentní
  produktový podklad přímo z oficiálního datasheetu LOXONE.
- `miniserver-gen1.png` - LOXONE Miniserver Gen. 1, art. 100001; samostatný
  čelní transparentní produktový podklad z oficiálního datasheetu LOXONE.
- `miniserver-compact.png` - LOXONE Miniserver Compact, art. 100512; uživatelem
  výslovně zvolený čelní transparentní výřez z dodaného produktového snímku.
- `miniserver-go.png` - LOXONE Miniserver Go, art. 100336; oficiální čelní
  produktový obrázek z press materiálů LOXONE.

Ostatní tři podklady pocházejí přímo z materiálů LOXONE a nejsou generované ani
tvarově upravené. Klient vybírá Gen. 1 pouze pro typ explicitně vrácený Partner
Portálem jako `Miniserver Gen. 1`; běžný typ `Miniserver` používá Gen. 2.
