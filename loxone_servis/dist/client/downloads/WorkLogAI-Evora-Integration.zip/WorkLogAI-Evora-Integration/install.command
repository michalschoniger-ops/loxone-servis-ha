#!/bin/zsh
set -euo pipefail

SCRIPT_DIR="${0:A:h}"
WORKLOG_BASE="$HOME/Library/Application Support/WorkLogAI"
SOURCE_TARGET="$WORKLOG_BASE/app/WorkLogMenu.swift"
BINARY_TARGET="$WORKLOG_BASE/bin/worklog-menu"
HELPER_TARGET="$WORKLOG_BASE/bin/worklog-keychain-helper"
ASSET_TARGET="$WORKLOG_BASE/app/evora-hub-mark.png"
SOURCE_INPUT="$SCRIPT_DIR/WorkLogMenu.swift"
HELPER_INPUT="$SCRIPT_DIR/WorkLogKeychainHelper.swift"
ASSET_INPUT="$SCRIPT_DIR/evora-hub-mark.png"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$WORKLOG_BASE/backups/evora-integration-$STAMP"
BUILD_DIR="$(mktemp -d "${TMPDIR:-/tmp}/worklog-evora.XXXXXX")"
BUILD_BINARY="$BUILD_DIR/worklog-menu"
BUILD_HELPER="$BUILD_DIR/worklog-keychain-helper"
MENU_LABEL="cz.worklogai.menubar"
MENU_PLIST="$HOME/Library/LaunchAgents/$MENU_LABEL.plist"
USER_DOMAIN="gui/$(id -u)"

cleanup() {
  rm -rf "$BUILD_DIR"
}
trap cleanup EXIT

if [[ ! -f "$SOURCE_INPUT" || ! -f "$HELPER_INPUT" || ! -f "$ASSET_INPUT" ]]; then
  echo "Instalační balíček není kompletní."
  exit 1
fi

if [[ ! -d "$WORKLOG_BASE/app" || ! -d "$WORKLOG_BASE/bin" ]]; then
  echo "Stávající WorkLogAI nebyl nalezen v $WORKLOG_BASE."
  exit 1
fi

mkdir -p "$BACKUP_DIR"
[[ -f "$SOURCE_TARGET" ]] && cp -p "$SOURCE_TARGET" "$BACKUP_DIR/WorkLogMenu.swift"
[[ -f "$BINARY_TARGET" ]] && cp -p "$BINARY_TARGET" "$BACKUP_DIR/worklog-menu"
[[ -f "$HELPER_TARGET" ]] && cp -p "$HELPER_TARGET" "$BACKUP_DIR/worklog-keychain-helper"
[[ -f "$ASSET_TARGET" ]] && cp -p "$ASSET_TARGET" "$BACKUP_DIR/evora-hub-mark.png"

echo "Kompiluji bezpečné Evora Smart Menu…"
swiftc -warnings-as-errors "$SOURCE_INPUT" -framework Cocoa -o "$BUILD_BINARY"
swiftc -warnings-as-errors "$HELPER_INPUT" -framework Foundation -framework Security -o "$BUILD_HELPER"
codesign --force --sign - "$BUILD_BINARY" >/dev/null
codesign --force --sign - "$BUILD_HELPER" >/dev/null

cp -p "$SOURCE_INPUT" "$SOURCE_TARGET"
cp -p "$ASSET_INPUT" "$ASSET_TARGET"
install -m 0755 "$BUILD_BINARY" "$BINARY_TARGET"
install -m 0755 "$BUILD_HELPER" "$HELPER_TARGET"

pkill -x worklog-menu 2>/dev/null || true
if [[ -f "$MENU_PLIST" ]]; then
  if launchctl print "$USER_DOMAIN/$MENU_LABEL" >/dev/null 2>&1; then
    launchctl bootout "$USER_DOMAIN/$MENU_LABEL" 2>/dev/null || true
  fi
  launchctl bootstrap "$USER_DOMAIN" "$MENU_PLIST"
  launchctl kickstart -k "$USER_DOMAIN/$MENU_LABEL"
else
  nohup "$BINARY_TARGET" >>"$WORKLOG_BASE/menu.log" 2>>"$WORKLOG_BASE/menu.err.log" </dev/null &!
fi
sleep 2

if ! pgrep -x worklog-menu >/dev/null; then
  echo "Menu se po instalaci nespustilo. Původní soubory jsou v $BACKUP_DIR."
  exit 1
fi

echo "Hotovo. Evora Smart Menu 3.0.7 používá Evora Intranet, diagnostiku Miniserverů, živou verzi Hubu a souvislý zabezpečený druhý stream kamer z Hubu."
echo "Záloha původní verze: $BACKUP_DIR"
