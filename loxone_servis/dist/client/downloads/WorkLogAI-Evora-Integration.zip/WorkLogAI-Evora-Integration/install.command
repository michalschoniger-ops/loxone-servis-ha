#!/bin/zsh
set -euo pipefail

SCRIPT_DIR="${0:A:h}"
WORKLOG_BASE="$HOME/Documents/WorkLogAI"
SOURCE_TARGET="$WORKLOG_BASE/app/WorkLogMenu.swift"
BINARY_TARGET="$WORKLOG_BASE/bin/worklog-menu"
SOURCE_INPUT="$SCRIPT_DIR/WorkLogMenu.swift"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$WORKLOG_BASE/backups/evora-integration-$STAMP"
BUILD_DIR="$(mktemp -d "${TMPDIR:-/tmp}/worklog-evora.XXXXXX")"
BUILD_BINARY="$BUILD_DIR/worklog-menu"
MENU_LABEL="cz.worklogai.menubar"
MENU_PLIST="$HOME/Library/LaunchAgents/$MENU_LABEL.plist"
USER_DOMAIN="gui/$(id -u)"

cleanup() {
  rm -rf "$BUILD_DIR"
}
trap cleanup EXIT

if [[ ! -f "$SOURCE_INPUT" ]]; then
  echo "Chybí WorkLogMenu.swift ve složce instalačního balíčku."
  exit 1
fi

if [[ ! -d "$WORKLOG_BASE/app" || ! -d "$WORKLOG_BASE/bin" ]]; then
  echo "Stávající WorkLogAI nebyl nalezen v $WORKLOG_BASE."
  exit 1
fi

mkdir -p "$BACKUP_DIR"
[[ -f "$SOURCE_TARGET" ]] && cp -p "$SOURCE_TARGET" "$BACKUP_DIR/WorkLogMenu.swift"
[[ -f "$BINARY_TARGET" ]] && cp -p "$BINARY_TARGET" "$BACKUP_DIR/worklog-menu"

echo "Kompiluji bezpečné menu WorkLog AI…"
swiftc "$SOURCE_INPUT" -framework Cocoa -framework Security -o "$BUILD_BINARY"
codesign --force --sign - "$BUILD_BINARY" >/dev/null

cp -p "$SOURCE_INPUT" "$SOURCE_TARGET"
install -m 0755 "$BUILD_BINARY" "$BINARY_TARGET"

pkill -x worklog-menu 2>/dev/null || true
if [[ -f "$MENU_PLIST" ]]; then
  if launchctl print "$USER_DOMAIN/$MENU_LABEL" >/dev/null 2>&1; then
    launchctl bootout "$USER_DOMAIN/$MENU_LABEL" 2>/dev/null || true
  fi
  launchctl bootstrap "$USER_DOMAIN" "$MENU_PLIST"
  launchctl kickstart -k "$USER_DOMAIN/$MENU_LABEL"
else
  nohup "$BINARY_TARGET" >>"$WORKLOG_BASE/menu.log" 2>>"$WORKLOG_BASE/menu.err.log" </dev/null &!
fi
sleep 2

if ! pgrep -x worklog-menu >/dev/null; then
  echo "Menu se po instalaci nespustilo. Původní soubory jsou v $BACKUP_DIR."
  exit 1
fi

echo "Hotovo. Otevřete menu WorkLog AI → Evora Smart Hub → Nastavit připojení…"
echo "Záloha původní verze: $BACKUP_DIR"
