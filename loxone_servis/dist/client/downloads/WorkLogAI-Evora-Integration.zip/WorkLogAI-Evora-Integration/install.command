#!/bin/zsh
set -euo pipefail

SCRIPT_DIR="${0:A:h}"
WORKLOG_BASE="$HOME/Library/Application Support/WorkLogAI"
SOURCE_TARGET="$WORKLOG_BASE/app/WorkLogMenu.swift"
BINARY_TARGET="$WORKLOG_BASE/bin/worklog-menu"
HELPER_TARGET="$WORKLOG_BASE/bin/worklog-keychain-helper"
ASSET_TARGET="$WORKLOG_BASE/app/evora-hub-mark.png"
PROFILE_TARGET="$WORKLOG_BASE/app/profile-photo.jpeg"
DEVICE_TARGET_DIR="$WORKLOG_BASE/app/devices"
CARD_TARGET_DIR="$DEVICE_TARGET_DIR/cards"
SOURCE_INPUT="$SCRIPT_DIR/WorkLogMenu.swift"
HELPER_INPUT="$SCRIPT_DIR/WorkLogKeychainHelper.swift"
ASSET_INPUT="$SCRIPT_DIR/evora-hub-mark.png"
PROFILE_INPUT="$SCRIPT_DIR/profile-photo.jpeg"
DEVICE_INPUT_DIR="$SCRIPT_DIR/devices"
CARD_INPUT_DIR="$DEVICE_INPUT_DIR/cards"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="$WORKLOG_BASE/backups/evora-integration-$STAMP"
BUILD_DIR="$(mktemp -d "${TMPDIR:-/tmp}/worklog-evora.XXXXXX")"
BUILD_BINARY="$BUILD_DIR/worklog-menu"
BUILD_HELPER="$BUILD_DIR/worklog-keychain-helper"
MENU_LABEL="cz.worklogai.menubar"
MENU_PLIST="$HOME/Library/LaunchAgents/$MENU_LABEL.plist"
USER_DOMAIN="gui/$(id -u)"

cleanup() {
  rm -f "$BUILD_BINARY" "$BUILD_HELPER"
  rmdir "$BUILD_DIR" 2>/dev/null || true
}
trap cleanup EXIT

if [[ ! -f "$SOURCE_INPUT" || ! -f "$HELPER_INPUT" || ! -f "$ASSET_INPUT" \
   || ! -f "$PROFILE_INPUT" \
   || ! -f "$DEVICE_INPUT_DIR/miniserver.png" \
   || ! -f "$DEVICE_INPUT_DIR/compact-transparent.png" \
   || ! -f "$DEVICE_INPUT_DIR/go.png" \
   || ! -f "$CARD_INPUT_DIR/miniserver.png" \
   || ! -f "$CARD_INPUT_DIR/miniserver-gen1.png" \
   || ! -f "$CARD_INPUT_DIR/miniserver-compact.png" \
   || ! -f "$CARD_INPUT_DIR/miniserver-go.png" ]]; then
  echo "Instalační balíček není kompletní."
  exit 1
fi

if [[ ! -d "$WORKLOG_BASE/app" || ! -d "$WORKLOG_BASE/bin" ]]; then
  echo "Stávající WorkLogAI nebyl nalezen v $WORKLOG_BASE."
  exit 1
fi

mkdir -p "$BACKUP_DIR"
[[ -f "$SOURCE_TARGET" ]] && cp -p "$SOURCE_TARGET" "$BACKUP_DIR/WorkLogMenu.swift"
[[ -f "$BINARY_TARGET" ]] && cp -p "$BINARY_TARGET" "$BACKUP_DIR/worklog-menu"
[[ -f "$HELPER_TARGET" ]] && cp -p "$HELPER_TARGET" "$BACKUP_DIR/worklog-keychain-helper"
[[ -f "$ASSET_TARGET" ]] && cp -p "$ASSET_TARGET" "$BACKUP_DIR/evora-hub-mark.png"
[[ -f "$PROFILE_TARGET" ]] && cp -p "$PROFILE_TARGET" "$BACKUP_DIR/profile-photo.jpeg"
if [[ -d "$DEVICE_TARGET_DIR" ]]; then
  mkdir -p "$BACKUP_DIR/devices"
  cp -p "$DEVICE_TARGET_DIR"/*.png "$BACKUP_DIR/devices/" 2>/dev/null || true
  if [[ -d "$CARD_TARGET_DIR" ]]; then
    mkdir -p "$BACKUP_DIR/devices/cards"
    cp -p "$CARD_TARGET_DIR"/*.png "$BACKUP_DIR/devices/cards/" 2>/dev/null || true
  fi
fi

echo "Kompiluji bezpečné Evora Smart Menu…"
swiftc -warnings-as-errors "$SOURCE_INPUT" -framework Cocoa -framework AVFoundation -framework Network -o "$BUILD_BINARY"
swiftc -warnings-as-errors "$HELPER_INPUT" -framework Foundation -framework Security -o "$BUILD_HELPER"
codesign --force --sign - "$BUILD_BINARY" >/dev/null
codesign --force --sign - "$BUILD_HELPER" >/dev/null

cp -p "$SOURCE_INPUT" "$SOURCE_TARGET"
cp -p "$ASSET_INPUT" "$ASSET_TARGET"
cp -p "$PROFILE_INPUT" "$PROFILE_TARGET"
mkdir -p "$DEVICE_TARGET_DIR"
cp -p "$DEVICE_INPUT_DIR/miniserver.png" "$DEVICE_TARGET_DIR/miniserver.png"
cp -p "$DEVICE_INPUT_DIR/compact-transparent.png" "$DEVICE_TARGET_DIR/compact-transparent.png"
cp -p "$DEVICE_INPUT_DIR/go.png" "$DEVICE_TARGET_DIR/go.png"
mkdir -p "$CARD_TARGET_DIR"
cp -p "$CARD_INPUT_DIR/miniserver.png" "$CARD_TARGET_DIR/miniserver.png"
cp -p "$CARD_INPUT_DIR/miniserver-gen1.png" "$CARD_TARGET_DIR/miniserver-gen1.png"
cp -p "$CARD_INPUT_DIR/miniserver-compact.png" "$CARD_TARGET_DIR/miniserver-compact.png"
cp -p "$CARD_INPUT_DIR/miniserver-go.png" "$CARD_TARGET_DIR/miniserver-go.png"
install -m 0755 "$BUILD_BINARY" "$BINARY_TARGET"
install -m 0755 "$BUILD_HELPER" "$HELPER_TARGET"

pkill -x worklog-menu 2>/dev/null || true
if [[ -f "$MENU_PLIST" ]]; then
  if launchctl print "$USER_DOMAIN/$MENU_LABEL" >/dev/null 2>&1; then
    launchctl bootout "$USER_DOMAIN/$MENU_LABEL" 2>/dev/null || true
    for _ in {1..20}; do
      if ! launchctl print "$USER_DOMAIN/$MENU_LABEL" >/dev/null 2>&1; then
        break
      fi
      sleep 0.1
    done
  fi
  if ! launchctl bootstrap "$USER_DOMAIN" "$MENU_PLIST"; then
    sleep 1
    launchctl bootstrap "$USER_DOMAIN" "$MENU_PLIST"
  fi
  launchctl kickstart -k "$USER_DOMAIN/$MENU_LABEL"
else
  nohup "$BINARY_TARGET" >>"$WORKLOG_BASE/menu.log" 2>>"$WORKLOG_BASE/menu.err.log" </dev/null &!
fi
sleep 2

if ! pgrep -x worklog-menu >/dev/null; then
  echo "Menu se po instalaci nespustilo. Původní soubory jsou v $BACKUP_DIR."
  exit 1
fi

echo "Hotovo. Evora Smart Menu 3.0.30 používá stabilní tmavší systémové macOS menu bez vlastního plovoucího panelu, bez zneaktivnění dosavadního okna a bez blikání profilové karty nebo stavové ikony. Barevné ponechává pouze ikony, zachovává klasické řádky zleva doprava, drží fleet snapshot v paměti a během otevření nepřestavuje strom. Detail Miniserveru sestaví líně jako jednu kartu s klasickými akčními řádky. Nabízí Evora Intranet včetně GPS konkrétní jízdy a volbu okna Loxone Configu; Parkoviště a brána, Milesight ani Loxone Builder se v macOS Menu nezobrazují."
echo "Záloha původní verze: $BACKUP_DIR"
