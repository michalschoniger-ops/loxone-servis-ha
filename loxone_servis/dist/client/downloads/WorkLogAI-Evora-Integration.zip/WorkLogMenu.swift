import Cocoa
import Security

final class AppDelegate: NSObject, NSApplicationDelegate, NSMenuDelegate {

    struct ShiftState: Codable {
        var active: Bool
        var mode: String
        var accumulated: Int
        var lastTick: Double
    }

    struct EvoraMiniServer: Decodable {
        let serial: String
        let project: String
        let type: String
        let folderName: String
        let connectionState: String
        let currentFirmware: String?
        let hasCredentials: Bool
        let loxoneAppAvailable: Bool
        let loxoneConfigAvailable: Bool
        let configVersion: String?
        let configDownloadUrl: String?
        let deviceImageUrl: String?
    }

    struct EvoraLauncherAgent: Decodable {
        let name: String
        let available: Bool
    }

    struct EvoraFleetResponse: Decodable {
        let launcherAgent: EvoraLauncherAgent?
        let items: [EvoraMiniServer]
    }

    struct EvoraConfigJob: Decodable {
        let id: String
        let state: String
        let message: String
        let requiredVersion: String
        let configUrl: String?
    }

    struct EvoraActionResponse: Decodable {
        let action: String
        let url: String?
        let job: EvoraConfigJob?
    }

    struct EvoraJobResponse: Decodable {
        let job: EvoraConfigJob
    }

    struct EvoraErrorResponse: Decodable {
        let error: String
        let code: String?
    }

    struct EvoraServiceError: LocalizedError {
        let message: String

        var errorDescription: String? {
            message
        }
    }

    var statusItem: NSStatusItem!
    private var clockTimer: Timer?
    private var refreshTimer: Timer?

    var menu: NSMenu!
    var macStatusItem: NSMenuItem!
    var windowsStatusItem: NSMenuItem!
    var shiftStatusItem: NSMenuItem!

    var startAgentItem: NSMenuItem!
    var restartAgentItem: NSMenuItem!
    var stopAgentItem: NSMenuItem!
    var evoraMenu: NSMenu!
    var evoraStatusItem: NSMenuItem!

    private var evoraRefreshInFlight = false
    private var evoraLastRefresh = Date.distantPast
    private var evoraServers: [EvoraMiniServer] = []
    private var evoraStatus = "Kontroluji připojení…"
    private var evoraDeviceImages: [String: NSImage] = [:]
    private var evoraDeviceImageLoads: Set<String> = []
    private let evoraKeychainService = "cz.worklogai.evora-smart-hub"
    private let evoraKeychainAccount = "personal-api-token"
    private let evoraHubDefaultsKey = "EvoraSmartHubURL"
    private let defaultEvoraHubURL = "https://homeassistant-work.skunk-atria.ts.net:8443/api/loxone-servis"
    private lazy var evoraSession: URLSession = {
        let configuration = URLSessionConfiguration.ephemeral
        configuration.requestCachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        configuration.urlCache = nil
        configuration.timeoutIntervalForRequest = 20
        configuration.timeoutIntervalForResource = 30
        return URLSession(configuration: configuration)
    }()

    let home = FileManager.default.homeDirectoryForCurrentUser.path

    var workPath: String {
        "\(home)/Documents/WorkLogAI/bin/work"
    }

    var shiftPath: String {
        "\(home)/Documents/WorkLogAI/menu_shift_state.json"
    }

    func applicationDidFinishLaunching(_ notification: Notification) {
        statusItem = NSStatusBar.system.statusItem(
            withLength: NSStatusItem.variableLength
        )

        if let button = statusItem.button {
            button.toolTip = "WorkLog AI"
        }

        buildMenu()
        refreshEvoraMenu()
        refreshAll()

        clockTimer = Timer(
            timeInterval: 1.0,
            target: self,
            selector: #selector(tickClock),
            userInfo: nil,
            repeats: true
        )

        if let clockTimer {
            RunLoop.main.add(clockTimer, forMode: .common)
        }

        refreshTimer = Timer(
            timeInterval: 5.0,
            target: self,
            selector: #selector(refreshAll),
            userInfo: nil,
            repeats: true
        )

        if let refreshTimer {
            RunLoop.main.add(refreshTimer, forMode: .common)
        }
    }

    private var refreshInFlight = false
    private var cachedAgent = false
    private var cachedWindows = "NIKDY"

    // MARK: - Work CLI

    func runWork(_ args: [String]) -> String {
        let process = Process()
        let pipe = Pipe()

        process.executableURL = URL(fileURLWithPath: workPath)
        process.arguments = args
        process.standardOutput = pipe
        process.standardError = pipe

        do {
            try process.run()
            process.waitUntilExit()

            let data = pipe.fileHandleForReading.readDataToEndOfFile()

            return String(
                data: data,
                encoding: .utf8
            ) ?? ""

        } catch {
            return "CHYBA: \(error.localizedDescription)"
        }
    }

    func quick() -> [String: Any] {
        let out = runWork(["rychle"])

        guard
            let data = out.data(using: .utf8),
            let json = try? JSONSerialization.jsonObject(
                with: data
            ) as? [String: Any]
        else {
            return [:]
        }

        return json
    }

    // MARK: - Evora Smart Hub

    func evoraToken() -> String? {
        let query: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: evoraKeychainService,
            kSecAttrAccount: evoraKeychainAccount,
            kSecMatchLimit: kSecMatchLimitOne,
            kSecReturnData: true
        ]
        var result: CFTypeRef?
        guard
            SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess,
            let data = result as? Data,
            let token = String(data: data, encoding: .utf8),
            !token.isEmpty
        else {
            return nil
        }
        return token
    }

    @discardableResult
    func saveEvoraToken(_ token: String) -> Bool {
        let identity: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: evoraKeychainService,
            kSecAttrAccount: evoraKeychainAccount
        ]
        SecItemDelete(identity as CFDictionary)
        var item = identity
        item[kSecValueData] = Data(token.utf8)
        item[kSecAttrAccessible] = kSecAttrAccessibleAfterFirstUnlockThisDeviceOnly
        return SecItemAdd(item as CFDictionary, nil) == errSecSuccess
    }

    func deleteEvoraToken() {
        let query: [CFString: Any] = [
            kSecClass: kSecClassGenericPassword,
            kSecAttrService: evoraKeychainService,
            kSecAttrAccount: evoraKeychainAccount
        ]
        SecItemDelete(query as CFDictionary)
    }

    func evoraHubURL() -> String {
        let configured = UserDefaults.standard.string(forKey: evoraHubDefaultsKey)
            ?? defaultEvoraHubURL
        return configured.trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
    }

    func validEvoraHubURL(_ value: String) -> String? {
        let normalized = value.trimmingCharacters(in: .whitespacesAndNewlines)
            .trimmingCharacters(in: CharacterSet(charactersIn: "/"))
        guard
            let url = URL(string: normalized),
            let scheme = url.scheme?.lowercased(),
            let host = url.host,
            !host.isEmpty,
            url.query == nil,
            url.fragment == nil,
            scheme == "https" || (scheme == "http" && ["127.0.0.1", "localhost"].contains(host.lowercased()))
        else {
            return nil
        }
        return normalized
    }

    func evoraEndpoint(_ path: String) -> URL? {
        let suffix = path.hasPrefix("/") ? path : "/\(path)"
        return URL(string: "\(evoraHubURL())\(suffix)")
    }

    func evoraRequest<T: Decodable>(
        path: String,
        method: String = "GET",
        body: [String: String]? = nil,
        completion: @escaping (Result<T, Error>) -> Void
    ) {
        guard let token = evoraToken() else {
            completion(.failure(EvoraServiceError(message: "Nejdřív nastavte osobní token z Evora Smart Hubu.")))
            return
        }
        guard let url = evoraEndpoint(path) else {
            completion(.failure(EvoraServiceError(message: "Adresa Evora Smart Hubu není platná.")))
            return
        }
        var request = URLRequest(url: url)
        request.httpMethod = method
        request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        if let body {
            request.httpBody = try? JSONSerialization.data(withJSONObject: body)
            request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        }
        evoraSession.dataTask(with: request) { data, response, error in
            if let error {
                completion(.failure(EvoraServiceError(message: "Evora Smart Hub není dostupný: \(error.localizedDescription)")))
                return
            }
            guard let http = response as? HTTPURLResponse else {
                completion(.failure(EvoraServiceError(message: "Evora Smart Hub nevrátil platnou odpověď.")))
                return
            }
            let payload = data ?? Data()
            guard (200..<300).contains(http.statusCode) else {
                let message = (try? JSONDecoder().decode(EvoraErrorResponse.self, from: payload).error)
                    ?? "Požadavek na Evora Smart Hub selhal (HTTP \(http.statusCode))."
                completion(.failure(EvoraServiceError(message: message)))
                return
            }
            do {
                completion(.success(try JSONDecoder().decode(T.self, from: payload)))
            } catch {
                completion(.failure(EvoraServiceError(message: "Evora Smart Hub vrátil nečitelná data.")))
            }
        }.resume()
    }

    func evoraConnectionLabel(_ state: String) -> String {
        switch state {
        case "online": return "Odpovídá"
        case "no_access": return "Odpovídá · bez přístupu"
        case "unavailable", "error": return "Neodpovídá"
        default: return "Neověřeno"
        }
    }

    func evoraMenuImage(_ server: EvoraMiniServer) -> NSImage? {
        guard
            let path = server.deviceImageUrl,
            let source = evoraDeviceImages[path]
        else {
            return nil
        }
        let size = NSSize(width: 20, height: 16)
        let image = NSImage(size: size)
        image.lockFocus()
        source.draw(
            in: NSRect(origin: .zero, size: size),
            from: .zero,
            operation: .sourceOver,
            fraction: server.connectionState == "online" ? 1.0 : 0.48,
            respectFlipped: true,
            hints: [.interpolation: NSImageInterpolation.high]
        )
        image.unlockFocus()
        image.isTemplate = false
        return image
    }

    func loadEvoraDeviceImages(_ servers: [EvoraMiniServer]) {
        let paths = Set(servers.compactMap(\.deviceImageUrl))
        for path in paths {
            guard
                !path.isEmpty,
                !path.contains(".."),
                !path.contains(":"),
                path.hasPrefix("devices/"),
                evoraDeviceImages[path] == nil,
                !evoraDeviceImageLoads.contains(path),
                let token = evoraToken(),
                let url = evoraEndpoint("/\(path)")
            else {
                continue
            }
            evoraDeviceImageLoads.insert(path)
            var request = URLRequest(url: url)
            request.cachePolicy = .reloadIgnoringLocalAndRemoteCacheData
            request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
            request.setValue("image/png", forHTTPHeaderField: "Accept")
            evoraSession.dataTask(with: request) { [weak self] data, response, _ in
                DispatchQueue.main.async {
                    guard let self else { return }
                    self.evoraDeviceImageLoads.remove(path)
                    guard
                        let http = response as? HTTPURLResponse,
                        http.statusCode == 200,
                        let data,
                        data.count <= 1_000_000,
                        let image = NSImage(data: data)
                    else {
                        return
                    }
                    self.evoraDeviceImages[path] = image
                    self.rebuildEvoraMenu()
                }
            }.resume()
        }
    }

    func rebuildEvoraMenu() {
        guard evoraMenu != nil else { return }
        evoraMenu.removeAllItems()

        evoraStatusItem = NSMenuItem(
            title: evoraStatus,
            action: nil,
            keyEquivalent: ""
        )
        evoraStatusItem.isEnabled = false
        evoraMenu.addItem(evoraStatusItem)
        evoraMenu.addItem(.separator())
        evoraMenu.addItem(
            linkItem(
                "Otevřít Evora Smart Hub",
                symbol: "network",
                url: evoraHubURL()
            )
        )
        evoraMenu.addItem(
            item(
                "Obnovit Miniservery",
                symbol: "arrow.clockwise",
                action: #selector(refreshEvoraMenu)
            )
        )
        evoraMenu.addItem(
            item(
                "Nastavit připojení…",
                symbol: "key",
                action: #selector(configureEvoraConnection)
            )
        )

        guard !evoraServers.isEmpty else {
            evoraMenu.addItem(.separator())
            let empty = NSMenuItem(
                title: evoraToken() == nil
                    ? "Vložte osobní token z Nastavení Hubu."
                    : "Žádné Miniservery nejsou dostupné.",
                action: nil,
                keyEquivalent: ""
            )
            empty.isEnabled = false
            evoraMenu.addItem(empty)
            return
        }

        evoraMenu.addItem(.separator())
        let grouped = Dictionary(grouping: evoraServers, by: { $0.folderName })
        for folder in grouped.keys.sorted(by: { $0.localizedCaseInsensitiveCompare($1) == .orderedAscending }) {
            let servers = (grouped[folder] ?? []).sorted {
                $0.project.localizedCaseInsensitiveCompare($1.project) == .orderedAscending
            }
            let folderItem = NSMenuItem(
                title: "📁  \(folder)  (\(servers.count))",
                action: nil,
                keyEquivalent: ""
            )
            let folderMenu = NSMenu(title: folder)
            for server in servers {
                let serverItem = NSMenuItem(
                    title: server.project,
                    action: nil,
                    keyEquivalent: ""
                )
                serverItem.image = evoraMenuImage(server)
                let serverMenu = NSMenu(title: server.project)
                let identity = NSMenuItem(
                    title: "\(server.serial) · \(server.type)",
                    action: nil,
                    keyEquivalent: ""
                )
                identity.isEnabled = false
                serverMenu.addItem(identity)
                let status = NSMenuItem(
                    title: "\(evoraConnectionLabel(server.connectionState)) · FW \(server.currentFirmware ?? "neznámý")",
                    action: nil,
                    keyEquivalent: ""
                )
                status.isEnabled = false
                serverMenu.addItem(status)
                serverMenu.addItem(.separator())

                let appAction = item(
                    "Otevřít v Loxone App",
                    symbol: "iphone",
                    action: #selector(runEvoraAction(_:))
                )
                appAction.representedObject = [
                    "serial": server.serial,
                    "action": "loxone_app"
                ] as NSDictionary
                appAction.isEnabled = server.loxoneAppAvailable
                serverMenu.addItem(appAction)

                let configTitle = server.loxoneConfigAvailable
                    ? "Otevřít v Loxone Config"
                    : "Otevřít v Loxone Config · Launcher offline"
                let configAction = item(
                    configTitle,
                    symbol: "doc.badge.gearshape",
                    action: #selector(runEvoraAction(_:))
                )
                configAction.representedObject = [
                    "serial": server.serial,
                    "action": "loxone_config"
                ] as NSDictionary
                configAction.isEnabled = server.hasCredentials && server.currentFirmware != nil
                serverMenu.addItem(configAction)

                if let download = server.configDownloadUrl {
                    serverMenu.addItem(.separator())
                    serverMenu.addItem(
                        linkItem(
                            "Stáhnout Loxone Config \(server.configVersion ?? "")",
                            symbol: "arrow.down.circle",
                            url: download
                        )
                    )
                }
                serverItem.submenu = serverMenu
                folderMenu.addItem(serverItem)
            }
            folderItem.submenu = folderMenu
            evoraMenu.addItem(folderItem)
        }
    }

    @objc func refreshEvoraMenu() {
        guard !evoraRefreshInFlight else { return }
        guard evoraToken() != nil else {
            evoraServers = []
            evoraStatus = "Evora Smart Hub: nepřipojeno"
            rebuildEvoraMenu()
            return
        }
        evoraRefreshInFlight = true
        evoraStatus = "Evora Smart Hub: načítám…"
        rebuildEvoraMenu()
        evoraRequest(
            path: "/api/integrations/worklog/v1/miniservers"
        ) { [weak self] (result: Result<EvoraFleetResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                self.evoraRefreshInFlight = false
                self.evoraLastRefresh = Date()
                switch result {
                case .success(let response):
                    self.evoraServers = response.items
                    self.loadEvoraDeviceImages(response.items)
                    let launcher = response.launcherAgent?.available == true
                        ? "Windows Launcher online"
                        : "Windows Launcher offline"
                    self.evoraStatus = "\(response.items.count) Miniserverů · \(launcher)"
                case .failure(let error):
                    self.evoraServers = []
                    self.evoraStatus = "Chyba: \(error.localizedDescription)"
                }
                self.rebuildEvoraMenu()
            }
        }
    }

    func menuWillOpen(_ menu: NSMenu) {
        guard menu === evoraMenu else { return }
        if Date().timeIntervalSince(evoraLastRefresh) > 30 {
            refreshEvoraMenu()
        }
    }

    // MARK: - Shift state

    func loadShift() -> ShiftState {
        let url = URL(fileURLWithPath: shiftPath)

        guard
            let data = try? Data(contentsOf: url),
            let state = try? JSONDecoder().decode(
                ShiftState.self,
                from: data
            )
        else {
            return ShiftState(
                active: false,
                mode: "",
                accumulated: 0,
                lastTick: Date().timeIntervalSince1970
            )
        }

        return state
    }

    func saveShift(_ state: ShiftState) {
        let url = URL(fileURLWithPath: shiftPath)

        try? FileManager.default.createDirectory(
            at: url.deletingLastPathComponent(),
            withIntermediateDirectories: true
        )

        if let data = try? JSONEncoder().encode(state) {
            try? data.write(
                to: url,
                options: .atomic
            )
        }
    }

    // MARK: - Icons

    func sf(_ name: String) -> NSImage? {
        let config = NSImage.SymbolConfiguration(
            pointSize: 13,
            weight: .medium
        )

        let img = NSImage(
            systemSymbolName: name,
            accessibilityDescription: nil
        )?.withSymbolConfiguration(config)

        img?.isTemplate = true

        return img
    }

    func loxoneLikeIcon() -> NSImage {
        let size = NSSize(
            width: 18,
            height: 18
        )

        let image = NSImage(size: size)

        image.lockFocus()

        let outer = NSBezierPath()
        outer.lineWidth = 1.6

        outer.move(
            to: NSPoint(x: 9, y: 1.6)
        )

        outer.line(
            to: NSPoint(x: 15.4, y: 5.1)
        )

        outer.line(
            to: NSPoint(x: 15.4, y: 12.9)
        )

        outer.line(
            to: NSPoint(x: 9, y: 16.4)
        )

        outer.line(
            to: NSPoint(x: 2.6, y: 12.9)
        )

        outer.line(
            to: NSPoint(x: 2.6, y: 5.1)
        )

        outer.close()

        NSColor.labelColor.setStroke()
        outer.stroke()

        let inner = NSBezierPath()
        inner.lineWidth = 1.7

        inner.move(
            to: NSPoint(x: 6.2, y: 5.0)
        )

        inner.line(
            to: NSPoint(x: 6.2, y: 12.8)
        )

        inner.line(
            to: NSPoint(x: 11.8, y: 12.8)
        )

        inner.stroke()

        image.unlockFocus()

        image.isTemplate = true

        return image
    }

    // MARK: - Menu items

    func item(
        _ title: String,
        symbol: String?,
        action: Selector
    ) -> NSMenuItem {

        let item = NSMenuItem(
            title: title,
            action: action,
            keyEquivalent: ""
        )

        item.target = self

        return item
    }

    func linkItem(
        _ title: String,
        symbol: String?,
        url: String
    ) -> NSMenuItem {

        let item = NSMenuItem(
            title: title,
            action: #selector(openURL(_:)),
            keyEquivalent: ""
        )

        item.target = self
        item.representedObject = url

        return item
    }

    func statusAttributed(
        label: String,
        value: String,
        color: NSColor
    ) -> NSAttributedString {

        let output = NSMutableAttributedString(
            string: "\(label)    "
        )

        output.addAttributes(
            [
                .foregroundColor: NSColor.labelColor,
                .font: NSFont.systemFont(
                    ofSize: NSFont.systemFontSize
                )
            ],
            range: NSRange(
                location: 0,
                length: output.length
            )
        )

        let state = NSAttributedString(
            string: value,
            attributes: [
                .foregroundColor: color,
                .font: NSFont.systemFont(
                    ofSize: NSFont.systemFontSize,
                    weight: .semibold
                )
            ]
        )

        output.append(state)

        return output
    }

    // MARK: - Build menu

    func buildMenu() {
        menu = NSMenu()

        let header = NSMenuItem(
            title: "WorkLog AI",
            action: nil,
            keyEquivalent: ""
        )

        header.isEnabled = false

        menu.addItem(header)

        macStatusItem = NSMenuItem(
            title: "Mac agent: kontroluji…",
            action: nil,
            keyEquivalent: ""
        )

        macStatusItem.isEnabled = false

        menu.addItem(macStatusItem)

        windowsStatusItem = NSMenuItem(
            title: "Windows klient: kontroluji…",
            action: nil,
            keyEquivalent: ""
        )

        windowsStatusItem.isEnabled = false

        menu.addItem(windowsStatusItem)

        shiftStatusItem = NSMenuItem(
            title: "Pracovní čas: neaktivní",
            action: nil,
            keyEquivalent: ""
        )

        shiftStatusItem.isEnabled = false

        menu.addItem(shiftStatusItem)

        menu.addItem(.separator())

        startAgentItem = item(
            "▶  Spustit Mac agent",
            symbol: "play.circle.fill",
            action: #selector(startAgent)
        )

        restartAgentItem = item(
            "🔄  Restartovat Mac agent",
            symbol: "arrow.clockwise.circle.fill",
            action: #selector(restartAgent)
        )

        stopAgentItem = item(
            "⏹️  Zastavit Mac agent",
            symbol: "stop.circle.fill",
            action: #selector(stopAgent)
        )

        menu.addItem(startAgentItem)
        menu.addItem(restartAgentItem)
        menu.addItem(stopAgentItem)

        menu.addItem(.separator())

        menu.addItem(
            item(
                "🏢  Začít kancelář",
                symbol: "briefcase.fill",
                action: #selector(startOffice)
            )
        )

        menu.addItem(
            item(
                "🏠  Začít Home office",
                symbol: "house.fill",
                action: #selector(startHome)
            )
        )

        menu.addItem(
            item(
                "🏁  Ukončit pracovní čas",
                symbol: "stop.fill",
                action: #selector(stopShift)
            )
        )

        menu.addItem(.separator())

        menu.addItem(
            item(
                "📝  Přidat poznámku…",
                symbol: "square.and.pencil",
                action: #selector(addNote)
            )
        )

        menu.addItem(
            item(
                "📞  Telefon / hovor…",
                symbol: "phone.fill",
                action: #selector(addCall)
            )
        )

        menu.addItem(
            item(
                "🚗  Výjezd / cesta…",
                symbol: "car.fill",
                action: #selector(addTravel)
            )
        )

        menu.addItem(
            item(
                "🛠️  Práce mimo PC…",
                symbol: "wrench.and.screwdriver.fill",
                action: #selector(addOffPC)
            )
        )

        menu.addItem(.separator())

        menu.addItem(
            item(
                "📋  Průběžný souhrn",
                symbol: "list.bullet.rectangle",
                action: #selector(showSummary)
            )
        )

        menu.addItem(
            item(
                "✨  AI souhrn",
                symbol: "sparkles",
                action: #selector(showAISummary)
            )
        )

        menu.addItem(
            item(
                "🕘  Poslední aktivita",
                symbol: "clock.arrow.circlepath",
                action: #selector(showRecent)
            )
        )

        menu.addItem(
            item(
                "📊  Vytvořit výkaz",
                symbol: "doc.text.fill",
                action: #selector(makeReport)
            )
        )

        menu.addItem(
            item(
                "📗  Otevřít Excel",
                symbol: "tablecells.fill",
                action: #selector(openExcel)
            )
        )

        menu.addItem(.separator())

        let ha = NSMenuItem(
            title: "🏠  Home Assistant odkazy",
            action: nil,
            keyEquivalent: ""
        )

        let haMenu = NSMenu(
            title: "🏠  Home Assistant odkazy"
        )

        haMenu.addItem(
            linkItem(
                "Herškovič",
                symbol: "person.crop.circle",
                url: "https://homeassistant-herskovic.skunk-atria.ts.net"
            )
        )

        haMenu.addItem(
            linkItem(
                "Vágner",
                symbol: "person.crop.circle",
                url: "https://homeassistant-vagner.skunk-atria.ts.net"
            )
        )

        haMenu.addItem(
            linkItem(
                "Evora",
                symbol: "building.2.fill",
                url: "https://homeassistant-work.skunk-atria.ts.net"
            )
        )

        haMenu.addItem(
            linkItem(
                "Domov",
                symbol: "house.fill",
                url: "https://homeassistant.skunk-atria.ts.net"
            )
        )

        ha.submenu = haMenu

        menu.addItem(ha)

        let evora = NSMenuItem(
            title: "💠  Evora Smart Hub",
            action: nil,
            keyEquivalent: ""
        )
        evoraMenu = NSMenu(title: "💠  Evora Smart Hub")
        evoraMenu.delegate = self
        evora.submenu = evoraMenu
        menu.addItem(evora)
        rebuildEvoraMenu()

        menu.addItem(
            linkItem(
                "🌐  Intranet Evora",
                symbol: "globe",
                url: "https://intranet.evora.cz/moje"
            )
        )

        menu.addItem(.separator())

        menu.addItem(
            item(
                "⏸️  Pozastavit sledování",
                symbol: "pause.circle.fill",
                action: #selector(pauseAgent)
            )
        )

        menu.addItem(
            item(
                "▶️  Pokračovat ve sledování",
                symbol: "play.circle.fill",
                action: #selector(resumeAgent)
            )
        )

        menu.addItem(.separator())

        menu.addItem(
            item(
                "❌  Ukončit pouze menu",
                symbol: "xmark.circle",
                action: #selector(quitMenu)
            )
        )

        statusItem.menu = menu
    }

    // MARK: - Refresh

    @objc func tickClock() {
        let shift = loadShift()

        guard shift.active else {
            return
        }

        let now = Date().timeIntervalSince1970

        var displayed =
            shift.accumulated

        if cachedAgent {
            displayed +=
                max(
                    0,
                    Int(
                        now
                        - shift.lastTick
                    )
                )
        }

        let h =
            displayed
            / 3600

        let m =
            (displayed % 3600)
            / 60

        let sec =
            displayed
            % 60

        let label =
            shift.mode == "office"
            ? "Kancelář"
            : "Home office"

        shiftStatusItem.attributedTitle =
            statusAttributed(
                label: "Pracovní režim",
                value: String(
                    format:
                        "%@ · %02d:%02d:%02d",
                    label,
                    h,
                    m,
                    sec
                ),
                color:
                    cachedAgent
                    ? .systemBlue
                    : .systemRed
            )

        if let button = statusItem.button {
            let symbolName =
                shift.mode == "office"
                ? "building.2.fill"
                : "house.fill"

            button.image = NSImage(
                systemSymbolName: symbolName,
                accessibilityDescription: nil
            )

            button.imagePosition = .imageLeading

            let windowsMark =
                cachedWindows == "ONLINE"
                ? " W✓"
                : " W!"

            button.title =
                String(
                    format: " %02d:%02d:%02d%@",
                    h,
                    m,
                    sec,
                    windowsMark
                )
        }
    }

    @objc func refreshAll() {
        if refreshInFlight {
            return
        }

        refreshInFlight = true

        DispatchQueue.global(qos: .utility).async { [weak self] in
            guard let self = self else {
                return
            }

            let q = self.quick()

            DispatchQueue.main.async { [weak self] in
                guard let self = self else {
                    return
                }

                self.refreshInFlight = false
                self.applyRefresh(q)
            }
        }
    }

    private func applyRefresh(_ q: [String: Any]) {



        let agent =
            (q["agent_running"] as? Bool)
            ?? false

        let windows =
            (q["windows"] as? String)
            ?? "NIKDY"

        let windowsAge =
            q["windows_last_seconds"]
            as? Double

        cachedAgent = agent
        cachedWindows = windows

        // Mac agent status
        if agent {
            macStatusItem.attributedTitle =
                statusAttributed(
                    label: "Mac agent",
                    value: "● ONLINE",
                    color: .systemGreen
                )
        } else {
            macStatusItem.attributedTitle =
                statusAttributed(
                    label: "Mac agent",
                    value: "● OFFLINE",
                    color: .systemRed
                )
        }

        // Windows status
        if windows == "ONLINE" {

            let age =
                Int(
                    windowsAge
                    ?? 0
                )

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● ONLINE · \(age) s",
                    color: .systemGreen
                )

        } else if windows == "ZPOZDENI" {

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● ZPOŽDĚNÍ",
                    color: .systemOrange
                )

        } else if windows == "OFFLINE" {

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● OFFLINE",
                    color: .systemRed
                )

        } else {

            windowsStatusItem.attributedTitle =
                statusAttributed(
                    label: "Windows klient",
                    value: "● BEZ DAT",
                    color: .secondaryLabelColor
                )
        }

        // Agent action visibility
        startAgentItem.isHidden = agent
        restartAgentItem.isHidden = !agent
        stopAgentItem.isHidden = !agent

        // Shift
        var shift = loadShift()

        let now =
            Date()
                .timeIntervalSince1970

        if shift.active {

            if agent {

                let delta =
                    max(
                        0,
                        Int(
                            now
                            - shift.lastTick
                        )
                    )

                shift.accumulated += delta
            }

            shift.lastTick = now

            saveShift(shift)
        }

        let h =
            shift.accumulated
            / 3600

        let m =
            (
                shift.accumulated
                % 3600
            )
            / 60

        let s =
            shift.accumulated
            % 60

        if shift.active {

            let label =
                shift.mode == "office"
                ? "Kancelář"
                : "Home office"

            shiftStatusItem.attributedTitle =
                statusAttributed(
                    label: "Pracovní režim",
                    value: String(
                        format:
                            "%@ · %02d:%02d:%02d",
                        label,
                        h,
                        m,
                        s
                    ),
                    color:
                        agent
                        ? .systemBlue
                        : .systemRed
                )

            // Horní lištu při aktivní směně aktualizuje pouze tickClock()
        

        } else {

            shiftStatusItem.attributedTitle =
                statusAttributed(
                    label: "Pracovní režim",
                    value: "NEAKTIVNÍ",
                    color: .secondaryLabelColor
                )

            if let button = statusItem.button {
                button.title = ""
                button.image = loxoneLikeIcon()
            }
        }
    
    }

    // MARK: - Agent control

    func ensureAgent() -> Bool {

        let q1 = quick()

        if
            (
                q1[
                    "agent_running"
                ]
                as? Bool
            )
            == true
        {
            return true
        }

        _ = runWork(
            [
                "spustit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1.5
        )

        let q2 = quick()

        return
            (
                q2[
                    "agent_running"
                ]
                as? Bool
            )
            == true
    }

    @objc func startAgent() {

        _ = runWork(
            [
                "spustit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        refreshAll()
    }

    @objc func restartAgent() {

        _ = runWork(
            [
                "zastavit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        _ = runWork(
            [
                "spustit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        refreshAll()
    }

    @objc func stopAgent() {

        _ = runWork(
            [
                "zastavit"
            ]
        )

        Thread.sleep(
            forTimeInterval: 1
        )

        refreshAll()
    }

    // MARK: - Shift control

    func startShift(
        _ mode: String
    ) {

        guard ensureAgent()
        else {

            showAlert(
                "WorkLog",
                "Mac agent se nepodařilo spustit. Pracovní čas nebyl zahájen."
            )

            return
        }

        let cmd =
            mode == "office"
            ? "kancelar"
            : "homeoffice"

        _ = runWork(
            [
                cmd
            ]
        )

        let shift =
            ShiftState(
                active: true,
                mode: mode,
                accumulated: 0,
                lastTick:
                    Date()
                        .timeIntervalSince1970
            )

        saveShift(shift)

        refreshAll()
    }

    @objc func startOffice() {
        startShift(
            "office"
        )
    }

    @objc func startHome() {
        startShift(
            "homeoffice"
        )
    }

    @objc func stopShift() {

        _ = runWork(
            [
                "konec-prace"
            ]
        )

        saveShift(
            ShiftState(
                active: false,
                mode: "",
                accumulated: 0,
                lastTick:
                    Date()
                        .timeIntervalSince1970
            )
        )

        refreshAll()
    }

    // MARK: - Alerts

    func showAlert(
        _ title: String,
        _ body: String
    ) {

        NSApp.activate(
            ignoringOtherApps: true
        )

        let alert =
            NSAlert()

        alert.messageText =
            title

        alert.informativeText =
            body

        alert.addButton(
            withTitle: "OK"
        )

        alert.runModal()
    }

    func showScrollableAlert(
        _ title: String,
        _ body: String
    ) {

        NSApp.activate(
            ignoringOtherApps: true
        )

        let alert = NSAlert()
        alert.messageText = title
        alert.addButton(withTitle: "Zavřít")

        let scroll = NSScrollView(
            frame: NSRect(
                x: 0,
                y: 0,
                width: 560,
                height: 500
            )
        )

        scroll.hasVerticalScroller = true
        scroll.hasHorizontalScroller = false
        scroll.autohidesScrollers = true
        scroll.borderType = .bezelBorder

        let textView = NSTextView(
            frame: NSRect(
                x: 0,
                y: 0,
                width: 540,
                height: 500
            )
        )

        textView.isEditable = false
        textView.isSelectable = true
        textView.drawsBackground = false
        textView.isRichText = false
        textView.font = NSFont.monospacedSystemFont(
            ofSize: 12,
            weight: .regular
        )
        textView.textContainerInset = NSSize(
            width: 10,
            height: 10
        )
        textView.textContainer?.widthTracksTextView = true
        textView.textContainer?.containerSize = NSSize(
            width: 540,
            height: CGFloat.greatestFiniteMagnitude
        )
        textView.isVerticallyResizable = true
        textView.isHorizontallyResizable = false
        textView.autoresizingMask = [.width]
        textView.string = body

        scroll.documentView = textView
        alert.accessoryView = scroll

        alert.runModal()
    }

    func inputDialog(
        _ title: String,
        command: String
    ) {

        NSApp.activate(
            ignoringOtherApps: true
        )

        let alert =
            NSAlert()

        alert.messageText =
            title

        alert.informativeText =
            "Napiš stručně, co se řešilo. Délka v minutách je volitelná."

        alert.addButton(
            withTitle: "Uložit"
        )

        alert.addButton(
            withTitle: "Zrušit"
        )

        let container =
            NSView(
                frame:
                    NSRect(
                        x: 0,
                        y: 0,
                        width: 440,
                        height: 72
                    )
            )

        let textField =
            NSTextField(
                frame:
                    NSRect(
                        x: 0,
                        y: 40,
                        width: 440,
                        height: 26
                    )
            )

        textField.placeholderString =
            "Co se řešilo?"

        let minutesField =
            NSTextField(
                frame:
                    NSRect(
                        x: 0,
                        y: 4,
                        width: 180,
                        height: 26
                    )
            )

        minutesField.placeholderString =
            "Délka v minutách"

        container.addSubview(
            textField
        )

        container.addSubview(
            minutesField
        )

        alert.accessoryView =
            container

        alert.window
            .initialFirstResponder =
            textField

        guard
            alert.runModal()
            == .alertFirstButtonReturn
        else {
            return
        }

        let body =
            textField
                .stringValue
                .trimmingCharacters(
                    in:
                        .whitespacesAndNewlines
                )

        if body.isEmpty {
            return
        }

        var args =
            [
                command,
                body
            ]

        let mins =
            minutesField
                .stringValue
                .trimmingCharacters(
                    in:
                        .whitespacesAndNewlines
                )

        if !mins.isEmpty {

            args +=
                [
                    "--minutes",
                    mins
                ]
        }

        showAlert(
            "WorkLog",
            runWork(args)
        )
    }

    // MARK: - Manual entries

    @objc func addNote() {
        inputDialog(
            "Přidat poznámku",
            command:
                "poznamka"
        )
    }

    @objc func addCall() {
        inputDialog(
            "Telefon / hovor",
            command:
                "hovor"
        )
    }

    @objc func addTravel() {
        inputDialog(
            "Výjezd / cesta",
            command:
                "vyjezd"
        )
    }

    @objc func addOffPC() {
        inputDialog(
            "Práce mimo PC",
            command:
                "mimo-pc"
        )
    }

    // MARK: - Reports

    @objc func showSummary() {
        showAlert(
            "📋  Průběžný souhrn",
            runWork(
                [
                    "souhrn"
                ]
            )
        )
    }

    @objc func showAISummary() {
        showAlert(
            "✨  AI souhrn",
            runWork(
                [
                    "souhrn-ai"
                ]
            )
        )
    }

    @objc func showRecent() {
        showScrollableAlert(
            "🕘  Poslední aktivita",
            runWork(
                [
                    "posledni",
                    "8"
                ]
            )
        )
    }

    @objc func makeReport() {
        showAlert(
            "Výkaz práce",
            runWork(
                [
                    "vykaz"
                ]
            )
        )
    }

    @objc func openExcel() {

        NSWorkspace.shared.open(
            URL(
                fileURLWithPath:
                    "\(home)/Documents/WorkLogAI/Pracovni_vykaz.xlsx"
            )
        )
    }

    // MARK: - Evora actions

    @objc func configureEvoraConnection() {
        NSApp.activate(ignoringOtherApps: true)
        let alert = NSAlert()
        alert.messageText = "Evora Smart Hub"
        alert.informativeText = "Vložte adresu Hubu a osobní WorkLog token vytvořený v Nastavení Evora Smart Hubu. Token se uloží pouze do macOS Klíčenky."
        alert.addButton(withTitle: "Uložit")
        alert.addButton(withTitle: "Odpojit tento Mac")
        alert.addButton(withTitle: "Zrušit")

        let container = NSView(
            frame: NSRect(x: 0, y: 0, width: 480, height: 104)
        )
        let urlLabel = NSTextField(labelWithString: "Adresa Evora Smart Hubu")
        urlLabel.frame = NSRect(x: 0, y: 82, width: 480, height: 17)
        let urlField = NSTextField(
            frame: NSRect(x: 0, y: 52, width: 480, height: 26)
        )
        urlField.stringValue = evoraHubURL()
        let tokenLabel = NSTextField(labelWithString: "Osobní WorkLog token")
        tokenLabel.frame = NSRect(x: 0, y: 30, width: 480, height: 17)
        let tokenField = NSSecureTextField(
            frame: NSRect(x: 0, y: 0, width: 480, height: 26)
        )
        tokenField.placeholderString = evoraToken() == nil
            ? "esh_worklog_…"
            : "ponechte prázdné, pokud token neměníte"
        container.addSubview(urlLabel)
        container.addSubview(urlField)
        container.addSubview(tokenLabel)
        container.addSubview(tokenField)
        alert.accessoryView = container
        alert.window.initialFirstResponder = evoraToken() == nil
            ? tokenField
            : urlField

        let answer = alert.runModal()
        if answer == .alertSecondButtonReturn {
            deleteEvoraToken()
            evoraServers = []
            evoraStatus = "Evora Smart Hub: nepřipojeno"
            rebuildEvoraMenu()
            return
        }
        guard answer == .alertFirstButtonReturn else { return }
        guard let normalizedURL = validEvoraHubURL(urlField.stringValue) else {
            showAlert(
                "Evora Smart Hub",
                "Použijte platnou HTTPS adresu bez parametrů. HTTP je povolené pouze pro localhost."
            )
            return
        }
        let newToken = tokenField.stringValue.trimmingCharacters(
            in: .whitespacesAndNewlines
        )
        if evoraToken() == nil && newToken.isEmpty {
            showAlert("Evora Smart Hub", "Osobní WorkLog token je povinný.")
            return
        }
        if !newToken.isEmpty {
            guard newToken.hasPrefix("esh_worklog_") else {
                showAlert("Evora Smart Hub", "Vložený token nemá platný formát.")
                return
            }
            guard saveEvoraToken(newToken) else {
                showAlert("Evora Smart Hub", "Token se nepodařilo uložit do macOS Klíčenky.")
                return
            }
        }
        UserDefaults.standard.set(normalizedURL, forKey: evoraHubDefaultsKey)
        evoraLastRefresh = .distantPast
        refreshEvoraMenu()
    }

    @objc func runEvoraAction(_ sender: NSMenuItem) {
        guard
            let payload = sender.representedObject as? NSDictionary,
            let serial = payload["serial"] as? String,
            let action = payload["action"] as? String
        else {
            return
        }
        evoraStatus = action == "loxone_app"
            ? "Připravuji Loxone App pro \(serial)…"
            : "Předávám \(serial) do Windows…"
        rebuildEvoraMenu()
        evoraRequest(
            path: "/api/integrations/worklog/v1/miniservers/\(serial)/actions",
            method: "POST",
            body: ["action": action]
        ) { [weak self] (result: Result<EvoraActionResponse, Error>) in
            DispatchQueue.main.async {
                guard let self else { return }
                switch result {
                case .success(let response):
                    if response.action == "loxone_app" {
                        guard
                            let value = response.url,
                            let url = URL(string: value),
                            url.scheme?.lowercased() == "loxone"
                        else {
                            self.evoraStatus = "Loxone App: neplatná odpověď"
                            self.rebuildEvoraMenu()
                            self.showAlert("Evora Smart Hub", "Hub nevrátil bezpečný odkaz pro Loxone App.")
                            return
                        }
                        self.evoraStatus = "Loxone App otevřena pro \(serial)"
                        self.rebuildEvoraMenu()
                        if !NSWorkspace.shared.open(url) {
                            self.showAlert("Loxone App", "macOS nedokázal otevřít schéma loxone://. Ověřte instalaci Loxone App.")
                        }
                        return
                    }
                    guard let job = response.job else {
                        self.evoraStatus = "Config: neplatná odpověď"
                        self.rebuildEvoraMenu()
                        self.showAlert("Loxone Config", "Hub nevrátil vytvořený požadavek.")
                        return
                    }
                    self.evoraStatus = "Windows Launcher převzal požadavek…"
                    self.rebuildEvoraMenu()
                    self.pollEvoraConfigJob(job.id, attempt: 0)
                case .failure(let error):
                    self.evoraStatus = "Chyba: \(error.localizedDescription)"
                    self.rebuildEvoraMenu()
                    self.showAlert("Evora Smart Hub", error.localizedDescription)
                }
            }
        }
    }

    func pollEvoraConfigJob(_ id: String, attempt: Int) {
        guard attempt < 150 else {
            evoraStatus = "Loxone Config: vypršel čas kontroly"
            rebuildEvoraMenu()
            showAlert("Loxone Config", "Windows Launcher nepotvrdil výsledek v časovém limitu.")
            return
        }
        DispatchQueue.main.asyncAfter(deadline: .now() + 1.2) { [weak self] in
            guard let self else { return }
            self.evoraRequest(
                path: "/api/integrations/worklog/v1/config-jobs/\(id)"
            ) { [weak self] (result: Result<EvoraJobResponse, Error>) in
                DispatchQueue.main.async {
                    guard let self else { return }
                    switch result {
                    case .failure(let error):
                        self.evoraStatus = "Config: \(error.localizedDescription)"
                        self.rebuildEvoraMenu()
                        self.showAlert("Loxone Config", error.localizedDescription)
                    case .success(let response):
                        let job = response.job
                        if job.state == "succeeded" {
                            self.evoraStatus = "Loxone Config \(job.requiredVersion) je otevřený"
                            self.rebuildEvoraMenu()
                        } else if ["missing_config", "failed", "expired"].contains(job.state) {
                            self.evoraStatus = "Config: \(job.message)"
                            self.rebuildEvoraMenu()
                            self.showEvoraConfigFailure(job)
                        } else {
                            self.evoraStatus = job.message
                            self.rebuildEvoraMenu()
                            self.pollEvoraConfigJob(id, attempt: attempt + 1)
                        }
                    }
                }
            }
        }
    }

    func showEvoraConfigFailure(_ job: EvoraConfigJob) {
        NSApp.activate(ignoringOtherApps: true)
        let alert = NSAlert()
        alert.messageText = job.state == "missing_config"
            ? "Požadovaný Loxone Config chybí"
            : "Loxone Config se nepodařilo otevřít"
        alert.informativeText = job.message
        if job.state == "missing_config", job.configUrl != nil {
            alert.addButton(withTitle: "Stáhnout Config \(job.requiredVersion)")
            alert.addButton(withTitle: "Zavřít")
            if alert.runModal() == .alertFirstButtonReturn,
               let value = job.configUrl,
               let url = URL(string: value) {
                NSWorkspace.shared.open(url)
            }
        } else {
            alert.addButton(withTitle: "OK")
            alert.runModal()
        }
    }

    // MARK: - Links

    @objc func openURL(
        _ sender: NSMenuItem
    ) {

        guard
            let value =
                sender
                    .representedObject
                as? String,

            let url =
                URL(
                    string:
                        value
                )

        else {
            return
        }

        NSWorkspace
            .shared
            .open(url)
    }

    // MARK: - Misc

    @objc func pauseAgent() {
        showAlert(
            "WorkLog",
            runWork(
                [
                    "pauza"
                ]
            )
        )
    }

    @objc func resumeAgent() {
        showAlert(
            "WorkLog",
            runWork(
                [
                    "pokracovat"
                ]
            )
        )
    }

    @objc func quitMenu() {
        NSApp.terminate(nil)
    }
}

let app =
    NSApplication.shared

let delegate =
    AppDelegate()

app.delegate =
    delegate

app.setActivationPolicy(
    .accessory
)

app.run()
