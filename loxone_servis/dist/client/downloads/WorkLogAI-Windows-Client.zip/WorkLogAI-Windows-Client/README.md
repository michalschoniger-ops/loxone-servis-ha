# Evora Smart Menu 3.0.1 – Windows klient

Windows klient běží po přihlášení uživatele trvale a každých pět sekund posílá Mac Hubu samostatný heartbeat. To je oddělené od sběru pracovních dat: záznam se vytváří pouze při aktivní docházce, nepřerušeném sledování, skutečném používání počítače a platném kontextu aplikace.

## Instalace a oprava

1. Rozbalte celý ZIP do lokální složky ve Windows.
2. Spusťte `install_windows.ps1` v PowerShellu pod stejným uživatelem, který Windows běžně používá.
3. Instalátor najde uživatelský Python, zachová data a konfiguraci, vytvoří položku Po spuštění a uživatelskou naplánovanou úlohu s minutovým watchdogem.
4. Stav ověříte příkazem `WORK status` nebo `work.cmd status`.

Stav `Agent: BEZI - watchdog aktivni` znamená, že klient běží i tehdy, když je sběr dat vypnutý. `Sber dat: VYPNUT - klient zustava online` je běžný stav mimo aktivní docházku. Při krátkém výpadku spojení klient zůstane spuštěný, opakovaně hledá Hub a stav ukáže `Hub: OBNOVUJE SPOJENI - agent stale bezi`.

Klient je offline pouze při vypnutých Windows, odhlášeném uživateli nebo během maximálně minutového automatického obnovení po pádu. Instalace nemaže databázi, výkazy ani pracovní záznamy.
