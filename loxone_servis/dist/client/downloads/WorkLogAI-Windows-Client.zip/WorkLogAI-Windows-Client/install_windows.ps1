param(
  [string]$HubUrl = "",
  [switch]$NonInteractive
)

$ErrorActionPreference = "Stop"
$SourceRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$Base = Join-Path $env:USERPROFILE "Documents\WorkLogAI"
$App = Join-Path $Base "app"
$Bin = Join-Path $Base "bin"
$InstalledScript = Join-Path $App "worklog.py"
$TaskName = "Evora Smart Menu Windows Client"

$PythonW = Get-ChildItem "$env:LOCALAPPDATA\Programs\Python" -Filter pythonw.exe -Recurse -ErrorAction SilentlyContinue |
  Select-Object -First 1 -ExpandProperty FullName
if (-not $PythonW) {
  Write-Host "Python 3/pythonw.exe nebyl nalezen."
  if (-not $NonInteractive) { Read-Host "Enter" | Out-Null }
  exit 1
}
$PythonExe = Join-Path (Split-Path $PythonW) "python.exe"

New-Item -ItemType Directory -Force -Path $App, $Bin | Out-Null
Copy-Item -LiteralPath (Join-Path $SourceRoot "worklog.py") -Destination $InstalledScript -Force
foreach ($OptionalFile in @("worklog_prompt.md", "worklog.schema.json")) {
  $OptionalSource = Join-Path $SourceRoot $OptionalFile
  if (Test-Path -LiteralPath $OptionalSource) {
    Copy-Item -LiteralPath $OptionalSource -Destination (Join-Path $App $OptionalFile) -Force
  }
}

$Command = "@echo off`r`n`"$PythonExe`" `"$InstalledScript`" %*"
Set-Content (Join-Path $Bin "work.cmd") $Command -Encoding ASCII
$UserPath = [Environment]::GetEnvironmentVariable("Path", "User")
if ($UserPath -notlike "*$Bin*") {
  [Environment]::SetEnvironmentVariable("Path", ($UserPath.TrimEnd(';') + ";" + $Bin), "User")
}

$SetupArguments = @($InstalledScript, "setup", "sensor")
if (-not [string]::IsNullOrWhiteSpace($HubUrl)) { $SetupArguments += @("--hub", $HubUrl.TrimEnd('/')) }
& $PythonExe @SetupArguments

# Nejdřív požádáme všechny starší kopie o čisté ukončení. Nová kopie
# přepíše řídicí soubor až po krátkém čekání, takže nevzniknou dva senzory.
& $PythonExe $InstalledScript stop
Start-Sleep -Seconds 7

$Startup = [Environment]::GetFolderPath("Startup")
Get-ChildItem $Startup -ErrorAction SilentlyContinue |
  Where-Object { $_.Name -match "WorkLog|Evora Smart Menu Windows Client" } |
  Remove-Item -Force -ErrorAction SilentlyContinue
$Shell = New-Object -ComObject WScript.Shell
$Shortcut = $Shell.CreateShortcut((Join-Path $Startup "Evora Smart Menu Windows Client.lnk"))
$Shortcut.TargetPath = $PythonW
$Shortcut.Arguments = "`"$InstalledScript`" start"
$Shortcut.WorkingDirectory = $App
$Shortcut.WindowStyle = 7
$Shortcut.Description = "Evora Smart Menu - staly Windows heartbeat a bezpecny sber pri aktivni dochazce"
$Shortcut.Save()

# Kontrolní úloha se spustí po přihlášení a pak jednou za minutu. Příkaz
# `start` používá stav procesu a pojmenovaný mutex, takže nikdy nevytvoří
# paralelní sběr, ale po pádu klienta ho bezpečně obnoví.
try {
  $Action = New-ScheduledTaskAction -Execute $PythonW -Argument "`"$InstalledScript`" start" -WorkingDirectory $App
  $LogonTrigger = New-ScheduledTaskTrigger -AtLogOn -User "$env:USERDOMAIN\$env:USERNAME"
  $WatchdogTrigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) `
    -RepetitionInterval (New-TimeSpan -Minutes 1) -RepetitionDuration (New-TimeSpan -Days 3650)
  $Principal = New-ScheduledTaskPrincipal -UserId "$env:USERDOMAIN\$env:USERNAME" -LogonType Interactive -RunLevel Limited
  $Settings = New-ScheduledTaskSettingsSet -StartWhenAvailable -AllowStartIfOnBatteries `
    -DontStopIfGoingOnBatteries -ExecutionTimeLimit (New-TimeSpan -Minutes 2) `
    -RestartCount 3 -RestartInterval (New-TimeSpan -Minutes 1)
  Register-ScheduledTask -TaskName $TaskName -Action $Action -Trigger @($LogonTrigger, $WatchdogTrigger) `
    -Principal $Principal -Settings $Settings -Description "Evora Smart Menu Windows client watchdog" -Force | Out-Null
} catch {
  Write-Warning "Kontrolni uloha nesla zaregistrovat; automaticky start po prihlaseni zustal aktivni."
}

Start-Process $PythonW -ArgumentList @("`"$InstalledScript`"", "start") -WorkingDirectory $App -WindowStyle Hidden
Start-Sleep -Seconds 3
& $PythonExe $InstalledScript status
Write-Host "Evora Smart Menu 3.0.1: Windows klient je nainstalovan lokalne, stale hlidany a data sbira jen pri aktivni dochazce a pouzivani pocitace."
if (-not $NonInteractive) { Read-Host "Enter" | Out-Null }
