#!/usr/bin/env python3
from __future__ import annotations
import argparse, base64, ctypes, datetime as dt, html, http.server, json, os, platform, re
import shutil, socketserver, sqlite3, subprocess, sys, threading, time
import urllib.parse, urllib.request, uuid, zipfile
from pathlib import Path

VERSION="3.0.1"; SYSTEM=platform.system(); APP="Evora Smart Menu"
DEFAULTS={
 "mode":"hub" if SYSTEM=="Darwin" else "sensor","hub_url":"","hub_token":"","port":8765,
 "sample_seconds":5,"idle_seconds":180,
 "screenshot_enabled":True,"screenshot_interval_seconds":600,"screenshot_min_gap_seconds":45,
 "screenshot_jpeg_quality":12,"screenshot_max_width":800,"screenshot_on_context_change":True,
 "max_screenshots_per_day":80,"screenshot_max_cache_mb":25,"screenshot_failed_retention_hours":24,
 "delete_screenshots_after_successful_report":True,"raw_event_retention_days":30,
 "codex_enabled":True,"codex_max_images":18,"excel_filename":"Pracovni_vykaz.xlsx",
 "auto_report_hour":23,"auto_report_minute":50,"project_aliases":{},
 "activity_v2_enabled":True,"windows_only_when_vm_frontmost":True,
 "visual_loxone_enabled":True,"visual_capture_interval_seconds":5,"visual_jpeg_quality":15,"visual_max_width":960,
 "visual_codex_max_images":20,"visual_session_keep_images":60,"visual_min_session_seconds":12,"visual_delete_after_success":True,
 "visual_keep_failed_hours":24,
 "visual_outlook_enabled":True,"visual_outlook_capture_interval_seconds":5,"visual_outlook_codex_max_images":20,
 "outlook_sent_probe_enabled":True,"outlook_sent_probe_window_seconds":180,
 "record_only_when_workmode_active":True,"intranet_primary_source":True,
 "input_activity_enabled":True,"file_watch_enabled":True,"file_watch_interval_seconds":30,
 "file_watch_roots":(["~/Library/Application Support/WorkLogAI"] if SYSTEM=="Darwin" else ["~/Documents/WorkLogAI"]),
 "diagnostic_context":True
}
CZ={"spustit":"start","zastavit":"stop","stav":"status","posledni":"recent","poslední":"recent",
"poznamka":"note","poznámka":"note","hovor":"call","telefon":"call","vyjezd":"travel","výjezd":"travel",
"mimo-pc":"offpc","mimopc":"offpc","pauza":"pause","pokracovat":"resume","pokračovat":"resume",
"souhrn":"summary","souhrn-ai":"summary-ai","vykaz":"report","výkaz":"report","uloziste":"storage",
"úložiště":"storage","uklid":"cleanup","úklid":"cleanup","prihlasit":"login","přihlásit":"login",
"prehlasit":"relogin","přehlásit":"relogin","odhlasit":"logout","odhlásit":"logout","iphone":"iphone",
"projekt":"project","diagnostika":"diagnostic","diagnostic":"diagnostic","visual-status":"visual-status","vizual-status":"visual-status","excel-opravit":"excel-repair","rychle":"quick","kancelar":"office","kancelář":"office","homeoffice":"homeoffice","home-office":"homeoffice","konec-prace":"work-end","konec-práce":"work-end","pracovni-rezim":"work-mode","pracovní-režim":"work-mode"}
MANUAL={"note":"POZNÁMKA","call":"HOVOR","travel":"VÝJEZD","offpc":"MIMO PC"}
GENERIC={"","Loxone Config","Vyhledávání","Vyhledavani","Search","Searching","Připojit k Miniserveru","Pripojit k Miniserveru"}
INVALID={"","Bez názvu","Bez nazvu","Untitled"}; MOJI=("Ã","Ä","Ĺ","Ă","Å","Â","â€")

def documents(): return (Path(os.environ.get("USERPROFILE",str(Path.home())))/"Documents") if SYSTEM=="Windows" else Path.home()/"Documents"
def home(): return Path(os.environ.get("WORKLOG_HOME",str(documents()/APP))).expanduser()
def cfg_path(): return home()/"config.json"
def state_path(): return home()/"state.json"
def control_path(): return home()/"control.json"
def sensor_runtime_path(): return home()/"sensor_runtime.json"
def windows_client_state_path(): return home()/"windows_client_state.json"
def db_path(): return home()/"data"/"worklog.sqlite3"
def codex_home(): return home()/"codex-home"
def prompt_path(): return Path(__file__).resolve().with_name("worklog_prompt.md")
def schema_path(): return Path(__file__).resolve().with_name("worklog.schema.json")
def project_state_path(): return home()/"project_state.json"
def today(): return dt.datetime.now().strftime("%Y-%m-%d")
def iso(ts=None): return dt.datetime.fromtimestamp(ts or time.time()).astimezone().isoformat(timespec="seconds")
def fmt(mins):
    try:m=max(0,int(round(float(mins))))
    except:m=0
    return f"{m//60}:{m%60:02d}"

def ensure_dirs():
    for p in [home(),home()/"data",home()/"screenshots",home()/"screenshots"/"visual",home()/"reports",home()/"tmp",home()/"backups",codex_home()]: p.mkdir(parents=True,exist_ok=True)
    if not cfg_path().exists():
        c=dict(DEFAULTS); c["mobile_token"]=uuid.uuid4().hex; cfg_path().write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding="utf-8")
    else:
        c=load_raw(); changed=False
        for k,v in DEFAULTS.items():
            if k not in c:c[k]=v;changed=True
        if not c.get("mobile_token"):c["mobile_token"]=uuid.uuid4().hex;changed=True
        if changed:cfg_path().write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding="utf-8")
    ch=codex_home()/"config.toml"
    if not ch.exists():ch.write_text('cli_auth_credentials_store = "file"\n',encoding="utf-8")
def load_raw():
    try:
        x=json.loads(cfg_path().read_text(encoding="utf-8")); return x if isinstance(x,dict) else {}
    except:return {}
def cfg():
    ensure_dirs(); c=dict(DEFAULTS); c.update(load_raw())
    if SYSTEM=="Darwin" and "Library/Application Support/WorkLogAI" in str(home()):
        # LaunchAgent nemá bez uživatelského dialogu přístup k celé složce
        # Documents. Runtime proto sleduje jen vlastní privátní adresář.
        c["file_watch_roots"]=[str(home())]
    return c
def save_cfg(c):cfg_path().write_text(json.dumps(c,ensure_ascii=False,indent=2),encoding="utf-8")
def save_json_atomic(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(f".{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
    try:
        tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding="utf-8")
        os.replace(tmp,path)
    finally:
        tmp.unlink(missing_ok=True)
def save_sensor_runtime(hub,connected,collecting,is_paused,work_active,idle_seconds=None):
    state={
        "updated_ts":time.time(),"updated_at":iso(),"version":VERSION,
        "agent_online":True,"hub_connected":bool(connected),
        "hub_url":str(hub or ""),"collecting":bool(collecting),
        "paused":bool(is_paused),"workmode_active":bool(work_active)
    }
    if isinstance(idle_seconds,(int,float)) and idle_seconds>=0:state["idle_seconds"]=round(float(idle_seconds),1)
    try:save_json_atomic(sensor_runtime_path(),state)
    except:pass
def load_sensor_runtime():
    try:
        state=json.loads(sensor_runtime_path().read_text(encoding="utf-8"))
        return state if isinstance(state,dict) else {}
    except:return {}
def repair(s):
    if not isinstance(s,str) or not any(x in s for x in MOJI):return s
    vals=[s]
    for enc in ("cp1250","cp1252","latin1"):
        try:vals.append(s.encode(enc).decode("utf-8"))
        except:pass
    return min(vals,key=lambda x:sum(x.count(m) for m in MOJI))
def deep(x):
    if isinstance(x,str):return repair(x)
    if isinstance(x,list):return [deep(v) for v in x]
    if isinstance(x,dict):return {k:deep(v) for k,v in x.items()}
    return x

SCHEMA='''PRAGMA journal_mode=WAL; PRAGMA synchronous=NORMAL;
CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY AUTOINCREMENT,ts REAL NOT NULL,iso TEXT NOT NULL,day TEXT NOT NULL,source TEXT,os TEXT,app TEXT,title TEXT,url TEXT,idle_seconds REAL DEFAULT 0,is_idle INTEGER DEFAULT 0,screenshot TEXT,kind TEXT DEFAULT 'sample',note TEXT DEFAULT '',duration_minutes REAL DEFAULT 0,meta_json TEXT DEFAULT '{}');
CREATE INDEX IF NOT EXISTS idx_events_day_ts ON events(day,ts);
CREATE TABLE IF NOT EXISTS reports(day TEXT PRIMARY KEY,created_ts REAL,report_json TEXT);'''
def db():
    ensure_dirs();con=sqlite3.connect(db_path(),timeout=10,check_same_thread=False);con.executescript(SCHEMA)
    cols={r[1] for r in con.execute("PRAGMA table_info(events)").fetchall()}
    if "duration_minutes" not in cols:con.execute("ALTER TABLE events ADD COLUMN duration_minutes REAL DEFAULT 0")
    if "meta_json" not in cols:con.execute("ALTER TABLE events ADD COLUMN meta_json TEXT DEFAULT '{}'")
    con.commit();return con

def aliases(name):
    raw=(name or "").strip();a=cfg().get("project_aliases",{}) or {}
    if raw in a:return str(a[raw]).strip() or raw
    for k,v in a.items():
        if str(k).casefold()==raw.casefold():return str(v).strip() or raw
    return raw
def loxproj(title):
    m=re.search(r"\[([^\]]+)\]",title or "")
    if not m:return ""
    x=m.group(1).strip();return "" if x in INVALID else x
def load_pstate():
    try:
        x=json.loads(project_state_path().read_text(encoding="utf-8"));return x if isinstance(x,dict) else {}
    except:return {}
def save_pstate(x):
    try:project_state_path().write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding="utf-8")
    except:pass
def normalize_event(e):
    e=dict(e)
    if (e.get("app") or "").lower()=="loxoneconfig.exe":
        src=e.get("source","Windows");st=load_pstate();p=loxproj(e.get("title",""))
        if p:st[src]={"project":p,"updated":e.get("iso",iso())};save_pstate(st)
        else:
            p=(st.get(src,{}) or {}).get("project","");t=(e.get("title") or "").strip()
            if p and (t in GENERIC or t.startswith("Loxone Config - [Bez ")):e["title"]=f"Loxone Config - [{p}]"
    return e

def workmode_active():
    """Fail-closed: automaticky sběr, screenshoty a AI běží jen při aktivním pracovním režimu."""
    if not cfg().get("record_only_when_workmode_active",True):
        return True
    try:
        state=load_workmode()
        if state.get("source")=="evora_intranet":
            # Intranet je primární zdroj. Starý snapshot nesmí nechat
            # sledování běžet po výpadku menu nebo přihlášení.
            synced=float(state.get("synced_ts",0) or 0)
            if synced<=0 or time.time()-synced>300:
                return False
        return bool(state.get("active"))
    except Exception:
        return False

def _discard_path(path):
    try:
        if path: Path(path).unlink(missing_ok=True)
    except Exception:
        pass

def add_event(e):

    if not workmode_active():
        _discard_path(e.get("screenshot",""))
        return False

    # WorkLog: obecny Windows heartbeat/transport neni pracovni aktivita.
    # Skutecne Windows aplikace (Loxone, PowerShell, Chrome...) zustavaji.
    _app = str(e.get("app", "") or "").strip().lower()
    _title = str(e.get("title", "") or "").strip().lower()
    _source = str(e.get("source", "") or "").strip().lower()

    if (
        _app in ("windows", "windows app", "")
        and _title in ("windows", "")
    ):
        return

    e=normalize_event(e);con=db();cols=["ts","iso","day","source","os","app","title","url","idle_seconds","is_idle","screenshot","kind","note","duration_minutes","meta_json"]
    meta=e.get("meta") or {};vals=[json.dumps(meta,ensure_ascii=False) if c=="meta_json" else e.get(c) for c in cols]
    con.execute("INSERT INTO events("+",".join(cols)+") VALUES("+",".join("?" for _ in cols)+")",vals);con.commit();con.close()
    try:visual_session_ingest(e)
    except Exception:pass
    try:outlook_visual_session_ingest(e)
    except Exception:pass
def remote_request(path, method="GET", obj=None, timeout=8):
    raise RuntimeError("V5.2 nepouziva vzdaleny HA Hub.")

def remote_state():
    return {}

def remote_workmode(mode):
    return {}

def complete_remote(day):
    return None

def events(day):
    con=db()
    cur=con.execute("SELECT ts,iso,day,source,os,app,title,url,idle_seconds,is_idle,screenshot,kind,note,duration_minutes,meta_json FROM events WHERE day=? ORDER BY ts",(day,))
    names=[d[0] for d in cur.description];out=[]
    for r in cur.fetchall():
        e=dict(zip(names,r))
        try:e["meta"]=json.loads(e.pop("meta_json") or "{}")
        except:e["meta"]={};e.pop("meta_json",None)
        out.append(e)
    con.close();return out

def run(cmd,timeout=3,env=None):
    try:
        kw={"capture_output":True,"text":True,"timeout":timeout,"env":env}
        if SYSTEM=="Windows":kw["creationflags"]=getattr(subprocess,"CREATE_NO_WINDOW",0)
        p=subprocess.run(cmd,**kw);return (p.stdout or "").strip()
    except:return ""
def cenv():
    ensure_dirs()
    e=os.environ.copy()
    e["CODEX_HOME"]=str(codex_home())
    e["CODEX_SQLITE_HOME"]=str(codex_home())
    extra=[
        "/opt/homebrew/bin","/usr/local/bin","/usr/bin","/bin",
        str(Path.home()/".local"/"bin"),
        str(Path.home()/".npm-global"/"bin"),
        str(Path.home()/".volta"/"bin"),
        str(Path.home()/".bun"/"bin"),
        str(Path.home()/".cargo"/"bin"),
    ]
    cur=e.get("PATH","")
    e["PATH"]=":".join([p for p in extra+[cur] if p])
    return e

def codex_bin():
    """Najde Codex CLI i kdyz WorkLog bezi z launchd s omezenym PATH."""
    env=cenv()
    p=shutil.which("codex", path=env.get("PATH"))
    if p and Path(p).exists():
        return p

    for shell in (os.environ.get("SHELL",""), "/bin/zsh", "/bin/bash"):
        if not shell or not Path(shell).exists():
            continue
        try:
            q=subprocess.run(
                [shell,"-lc","command -v codex 2>/dev/null || true"],
                capture_output=True,text=True,timeout=8,env=env
            )
            cand=(q.stdout or "").strip().splitlines()
            if cand and cand[0] and Path(cand[0]).exists():
                return cand[0]
        except Exception:
            pass

    candidates=[
        Path("/opt/homebrew/bin/codex"),
        Path("/usr/local/bin/codex"),
        Path.home()/".local"/"bin"/"codex",
        Path.home()/".npm-global"/"bin"/"codex",
        Path.home()/".volta"/"bin"/"codex",
        Path.home()/".bun"/"bin"/"codex",
    ]
    for cand in candidates:
        if cand.exists() and os.access(cand,os.X_OK):
            return str(cand)
    return ""

INPUT_HELPER_SWIFT = r'''import Cocoa
import ApplicationServices

let outPath = CommandLine.arguments.count > 1 ? CommandLine.arguments[1] : "/tmp/worklog_input.json"
var keys = 0
var clicks = 0
var scrolls = 0
var moves = 0
var lastWrite = Date().timeIntervalSince1970

func writeState() {
    let obj: [String: Any] = ["ts": Date().timeIntervalSince1970, "keys": keys, "clicks": clicks, "scrolls": scrolls, "moves": moves]
    if let data = try? JSONSerialization.data(withJSONObject: obj) { try? data.write(to: URL(fileURLWithPath: outPath), options: .atomic) }
}

let mask = CGEventMask((1 << CGEventType.keyDown.rawValue) | (1 << CGEventType.leftMouseDown.rawValue) | (1 << CGEventType.rightMouseDown.rawValue) | (1 << CGEventType.otherMouseDown.rawValue) | (1 << CGEventType.scrollWheel.rawValue) | (1 << CGEventType.mouseMoved.rawValue) | (1 << CGEventType.leftMouseDragged.rawValue) | (1 << CGEventType.rightMouseDragged.rawValue))
let callback: CGEventTapCallBack = { proxy, type, event, refcon in
    switch type {
    case .keyDown: keys += 1
    case .leftMouseDown, .rightMouseDown, .otherMouseDown: clicks += 1
    case .scrollWheel: scrolls += 1
    case .mouseMoved, .leftMouseDragged, .rightMouseDragged: moves += 1
    default: break
    }
    let now = Date().timeIntervalSince1970
    if now - lastWrite >= 1.0 { writeState(); lastWrite = now }
    return Unmanaged.passUnretained(event)
}
if let tap = CGEvent.tapCreate(tap: .cgSessionEventTap, place: .headInsertEventTap, options: .listenOnly, eventsOfInterest: mask, callback: callback, userInfo: nil) {
    let src = CFMachPortCreateRunLoopSource(kCFAllocatorDefault, tap, 0)
    CFRunLoopAddSource(CFRunLoopGetCurrent(), src, .commonModes)
    CGEvent.tapEnable(tap: tap, enable: true)
    Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { _ in writeState() }
    RunLoop.current.run()
} else { writeState() }
'''

def input_state_path(): return home()/"activity_input.json"
def input_helper_bin(): return home()/"bin"/"worklog-input-monitor"

def ensure_input_helper(c=None):
    c=c or cfg()
    if SYSTEM!="Darwin" or not c.get("input_activity_enabled",True): return
    try:
        b=input_helper_bin();b.parent.mkdir(parents=True,exist_ok=True);src=home()/"tmp"/"worklog_input_monitor.swift"
        if not b.exists():
            src.write_text(INPUT_HELPER_SWIFT,encoding="utf-8")
            cp=subprocess.run(["swiftc",str(src),"-framework","Cocoa","-framework","ApplicationServices","-o",str(b)],capture_output=True,text=True,timeout=60)
            if cp.returncode!=0:return
        if not run(["pgrep","-f",str(b)],2):
            subprocess.Popen([str(b),str(input_state_path())],start_new_session=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,stdin=subprocess.DEVNULL)
    except:pass

def read_input_state():
    try:
        x=json.loads(input_state_path().read_text(encoding="utf-8"))
        return x if time.time()-float(x.get("ts",0))<=10 else {}
    except:return {}

_FILE_WATCH_STATE={"last":0.0,"mtimes":{},"recent":[]}
def file_watch(c=None):
    c=c or cfg()
    if not c.get("file_watch_enabled",True):return []
    now=time.time();interval=max(10,int(c.get("file_watch_interval_seconds",30)))
    if now-_FILE_WATCH_STATE["last"]<interval:return list(_FILE_WATCH_STATE["recent"])
    roots=[]
    for raw in c.get("file_watch_roots",[]) or []:
        try:
            r=Path(os.path.expanduser(str(raw))).resolve()
            if r.exists():roots.append(r)
        except:pass
    prev=_FILE_WATCH_STATE["mtimes"];cur={};changed=[];limit=5000
    for root in roots:
        try:
            for base,dirs,files in os.walk(root):
                dirs[:]=[d for d in dirs if d not in {".git","node_modules","__pycache__","backups","screenshots"}]
                for fn in files:
                    if len(cur)>=limit:break
                    fp=Path(base)/fn
                    try:
                        mt=fp.stat().st_mtime;key=str(fp);cur[key]=mt
                        if key in prev and mt>prev[key]+0.001:changed.append(key)
                    except:pass
                if len(cur)>=limit:break
        except:pass
    _FILE_WATCH_STATE.update({"last":now,"mtimes":cur,"recent":changed[-20:]})
    return list(_FILE_WATCH_STATE["recent"])

def safe_ax_context(app):
    if SYSTEM!="Darwin" or not app:return {}
    sc=r'''tell application "System Events"
try
set p to first application process whose frontmost is true
set fe to value of attribute "AXFocusedUIElement" of p
set rr to ""
set tt to ""
set dd to ""
try
set rr to role of fe as text
end try
try
set tt to title of fe as text
end try
try
set dd to description of fe as text
end try
return rr & linefeed & tt & linefeed & dd
on error
return ""
end try
end tell'''
    out=run(["osascript","-e",sc],2);parts=out.splitlines()
    return {"focused_role":parts[0] if parts else "","focused_title":parts[1] if len(parts)>1 else "","focused_description":parts[2] if len(parts)>2 else ""}

def activity_semantics(ctx):
    app=(ctx.get("app") or "").strip();title=(ctx.get("title") or "").strip();url=(ctx.get("url") or "").strip();low=app.casefold();act="Práce v aplikaci"
    if "chatgpt" in low:act="Technická konzultace / práce s ChatGPT"
    elif low in {"terminal","iterm2","warp"} or "terminal" in low:act="Práce v terminálu"
    elif any(x in low for x in ["safari","chrome","edge","brave"]):act="Práce ve webovém prohlížeči"
    elif "loxone" in low:act="Programování / diagnostika Loxone"
    elif any(x in low for x in ["code","cursor","xcode"]):act="Programování / editace zdrojů"
    project=loxproj(title) if "loxone" in low else ""
    meta=ctx.get("meta") or {};inp=meta.get("input") or {};active_events=sum(int(inp.get(k,0) or 0) for k in ("keys","clicks","scrolls"))
    conf=0.45;evidence=[]
    if app:conf+=0.1;evidence.append("frontmost_app")
    if title:conf+=0.1;evidence.append("focused_window")
    if meta.get("focused_role"):conf+=0.1;evidence.append("accessibility_focus")
    if active_events>0:conf+=0.15;evidence.append("keyboard_mouse_activity")
    if meta.get("files_changed"):conf+=0.05;evidence.append("file_change")
    if project:conf+=0.05;evidence.append("project_in_title")
    if float(ctx.get("idle_seconds",0) or 0)>30:conf-=0.15
    return {"activity":act,"project":aliases(project) if project else "","confidence":round(max(0.05,min(0.99,conf)),2),"evidence":evidence,"domain":urllib.parse.urlparse(url).netloc if url else ""}

def mac_vm_frontmost():
    if SYSTEM!="Darwin":return True
    x=mac_ctx(light=True)
    a=(x.get("app") or "").casefold().strip()
    t=(x.get("title") or "").casefold().strip()
    direct_windows_apps=(
        "loxone config","loxoneconfig",
        "windows powershell","powershell",
        "command prompt","cmd.exe",
        "file explorer","explorer.exe",
        "remote desktop",
    )
    return (
        any(k in a for k in ["prl_client_app","parallels","microsoft remote desktop"])
        or a=="windows"
        or a.startswith("windows ")
        or "windows 11" in a
        or "windows 10" in a
        or any(k in a for k in direct_windows_apps)
        or "parallels" in t
        or "windows 11" in t
        or "windows 10" in t
    )

def mac_ctx(light=False):
    sc='''tell application "System Events"
set p to first application process whose frontmost is true
set a to name of p
set t to ""
try
set t to name of front window of p
end try
return a & linefeed & t
end tell'''
    out=run(["osascript","-e",sc]);parts=out.splitlines();app=parts[0] if parts else "";title=parts[1] if len(parts)>1 else "";url=""
    bs={"Google Chrome":'tell application "Google Chrome" to get URL of active tab of front window',"Brave Browser":'tell application "Brave Browser" to get URL of active tab of front window',"Microsoft Edge":'tell application "Microsoft Edge" to get URL of active tab of front window',"Safari":'tell application "Safari" to get URL of front document'}
    if app in bs:url=run(["osascript","-e",bs[app]],2)
    idle=0.;o=run(["ioreg","-c","IOHIDSystem"],2);m='"HIDIdleTime" = '
    for l in o.splitlines():
        if m in l:
            try:idle=int(l.split(m,1)[1].strip())/1e9
            except:pass
            break
    ctx={"source":platform.node()+"/Mac","os":"macOS","app":app,"title":title,"url":url,"idle_seconds":idle}
    if light:return ctx
    meta={};meta.update(safe_ax_context(app));meta["input_raw"]=read_input_state();meta["files_changed"]=file_watch(cfg());ctx["meta"]=meta;meta.update(activity_semantics(ctx));return ctx
class LII(ctypes.Structure):_fields_=[("cbSize",ctypes.c_uint),("dwTime",ctypes.c_uint)]
def win_ctx():
    u=ctypes.windll.user32;k=ctypes.windll.kernel32;h=u.GetForegroundWindow();n=u.GetWindowTextLengthW(h);b=ctypes.create_unicode_buffer(n+1);u.GetWindowTextW(h,b,n+1);title=b.value
    pid=ctypes.c_ulong();u.GetWindowThreadProcessId(h,ctypes.byref(pid));app="Windows app";ph=k.OpenProcess(0x1000,False,pid.value)
    if ph:
        try:
            sz=ctypes.c_ulong(32768);ex=ctypes.create_unicode_buffer(sz.value)
            if k.QueryFullProcessImageNameW(ph,0,ex,ctypes.byref(sz)):app=Path(ex.value).name
        finally:k.CloseHandle(ph)
    if app.lower()=="loxoneconfig.exe":
        pf=home()/"loxone_project.json";last=""
        try:
            if pf.exists():last=str(json.loads(pf.read_text(encoding="utf-8")).get("project","")).strip()
        except:pass
        cand=loxproj(title)
        if cand:
            last=cand
            try:pf.write_text(json.dumps({"project":cand,"updated":iso()},ensure_ascii=False,indent=2),encoding="utf-8")
            except:pass
        elif last and ((title or "").strip() in GENERIC or (title or "").startswith("Loxone Config - [Bez ")):title=f"Loxone Config - [{last}]"
    li=LII();li.cbSize=ctypes.sizeof(LII);idle=0.
    if u.GetLastInputInfo(ctypes.byref(li)):idle=max(0,(k.GetTickCount()-li.dwTime)/1000)
    if str(app).lower()=="loxoneconfig.exe":

        title=windows_best_loxone_title(title)

    return {"source":platform.node()+"/Windows","os":"Windows","app":app,"title":title,"url":"","idle_seconds":idle}
def context():return mac_ctx() if SYSTEM=="Darwin" else win_ctx() if SYSTEM=="Windows" else {"source":platform.node(),"os":SYSTEM,"app":"","title":"","url":"","idle_seconds":0,"meta":{}}


def windows_best_loxone_title(fallback=""):
    """
    Na Windows projde viditelna top-level okna LoxoneConfig.exe a
    vybere nejpravdepodobnejsi hlavni okno s nazvem projektu.

    Zivy Win32 titul ma prednost pred historickou pameti projektu.
    """
    if SYSTEM!="Windows":
        return fallback

    try:
        user32=ctypes.windll.user32
        kernel32=ctypes.windll.kernel32

        results=[]

        WNDENUMPROC=ctypes.WINFUNCTYPE(
            ctypes.c_bool,
            ctypes.c_void_p,
            ctypes.c_void_p
        )

        def callback(hwnd,lparam):
            try:
                if not user32.IsWindowVisible(hwnd):
                    return True

                n=user32.GetWindowTextLengthW(hwnd)

                if n<=0:
                    return True

                buf=ctypes.create_unicode_buffer(n+1)
                user32.GetWindowTextW(hwnd,buf,n+1)

                title=(buf.value or "").strip()

                if not title:
                    return True

                pid=ctypes.c_ulong()
                user32.GetWindowThreadProcessId(
                    hwnd,
                    ctypes.byref(pid)
                )

                h=kernel32.OpenProcess(
                    0x1000,
                    False,
                    pid.value
                )

                if not h:
                    return True

                try:
                    size=ctypes.c_ulong(32768)
                    exe=ctypes.create_unicode_buffer(
                        size.value
                    )

                    if kernel32.QueryFullProcessImageNameW(
                        h,
                        0,
                        exe,
                        ctypes.byref(size)
                    ):
                        name=Path(exe.value).name.lower()

                        if name=="loxoneconfig.exe":
                            results.append(title)

                finally:
                    kernel32.CloseHandle(h)

            except Exception:
                pass

            return True

        cb=WNDENUMPROC(callback)
        user32.EnumWindows(cb,0)

        if not results:
            return fallback

        # Vyhazujeme pomocna/dialogova okna.
        bad_exact={
            "Loxone Config",
            "Vyhledávání",
            "Vyhledavani",
            "Připojit k Miniserveru",
            "Pripojit k Miniserveru",
            "Bez názvu",
            "Bez nazvu"
        }

        candidates=[]

        for title in results:

            t=title.strip()

            if t in bad_exact:
                continue

            score=0

            # Projektove cislo typu PRO-22-026 ma nejvyssi prioritu.
            if re.search(
                r'\bPRO-\d{2}-\d+\b',
                t,
                re.I
            ):
                score+=100

            # Projekt v hranatych zavorkach.
            if re.search(
                r'Loxone\s*Config.*\[[^\]]+\]',
                t,
                re.I
            ):
                score+=80

            if " - " in t:
                score+=10

            if len(t)>20:
                score+=5

            candidates.append(
                (score,len(t),t)
            )

        if not candidates:
            return fallback

        candidates.sort(
            reverse=True
        )

        best=candidates[0][2]

        # Pokud titul obsahuje [projekt], zachovame standardni format.
        m=re.search(
            r'\[([^\]]+)\]',
            best
        )

        if m:
            project=m.group(1).strip()

            if project not in {
                "",
                "Bez názvu",
                "Bez nazvu",
                "Untitled"
            }:
                return (
                    "Loxone Config - ["
                    + project
                    + "]"
                )

        # Nektere verze Loxone maji projekt primo v title baru.
        m=re.search(
            r'(PRO-\d{2}-\d+\s*-\s*.+)',
            best,
            re.I
        )

        if m:
            project=m.group(1).strip()

            return (
                "Loxone Config - ["
                + project
                + "]"
            )

        return best or fallback

    except Exception:
        return fallback


def screenshot(dest,c):
    dest.parent.mkdir(parents=True,exist_ok=True);q=max(8,min(50,int(c.get("screenshot_jpeg_quality",12))));w=max(640,min(1600,int(c.get("screenshot_max_width",800))))
    try:
        if SYSTEM=="Darwin":
            raw=dest.with_name(dest.stem+"_raw.jpg");subprocess.run(["screencapture","-x","-t","jpg",str(raw)],check=True,timeout=8,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            subprocess.run(["sips","-Z",str(w),"-s","format","jpeg","-s","formatOptions",str(q),str(raw),"--out",str(dest)],check=True,timeout=12,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);raw.unlink(missing_ok=True)
        elif SYSTEM=="Windows":
            pp=str(dest).replace("'","''");ps=f'''Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$b=[System.Windows.Forms.Screen]::PrimaryScreen.Bounds;$s=[Math]::Min(1.0,{w}.0/$b.Width);$W=[int]($b.Width*$s);$H=[int]($b.Height*$s)
$a=New-Object Drawing.Bitmap $b.Width,$b.Height;$g=[Drawing.Graphics]::FromImage($a);$g.CopyFromScreen($b.Location,[Drawing.Point]::Empty,$b.Size)
$d=New-Object Drawing.Bitmap $W,$H;$g2=[Drawing.Graphics]::FromImage($d);$g2.DrawImage($a,0,0,$W,$H)
$j=[Drawing.Imaging.ImageCodecInfo]::GetImageEncoders()|? {{$_.MimeType -eq 'image/jpeg'}};$e=New-Object Drawing.Imaging.EncoderParameters(1);$e.Param[0]=New-Object Drawing.Imaging.EncoderParameter([Drawing.Imaging.Encoder]::Quality,[long]{q});$d.Save('{pp}',$j,$e)
$g.Dispose();$g2.Dispose();$a.Dispose();$d.Dispose();$e.Dispose()'''
            subprocess.run(["powershell.exe","-NoProfile","-NonInteractive","-Command",ps],check=True,timeout=15,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
        return dest if dest.exists() else None
    except:
        dest.unlink(missing_ok=True);return None

# -----------------------------------------------------------------------------
# Loxone Visual Session Analyzer
# -----------------------------------------------------------------------------
VISUAL_LOCK=threading.RLock()
VISUAL_SESSION={"project":"","start":0.0,"last":0.0,"screens":[],"last_hash":"","source":""}


def visual_screenshot(dest,c):
    # Minimalni screenshot pouze aktivniho okna. Na Windows se snima foreground okno.
    dest.parent.mkdir(parents=True,exist_ok=True)
    q=max(8,min(35,int(c.get("visual_jpeg_quality",15))))
    w=max(720,min(1400,int(c.get("visual_max_width",960))))
    try:
        if SYSTEM=="Windows":
            pp=str(dest).replace("'","''")
            ps=f'''Add-Type -AssemblyName System.Drawing
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class WLV {{
 [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
 [DllImport("user32.dll")] public static extern bool GetWindowRect(IntPtr hWnd, out RECT r);
 public struct RECT {{ public int Left; public int Top; public int Right; public int Bottom; }}
}}
"@
$h=[WLV]::GetForegroundWindow();$r=New-Object WLV+RECT;[WLV]::GetWindowRect($h,[ref]$r)|Out-Null
$ww=[Math]::Max(1,$r.Right-$r.Left);$hh=[Math]::Max(1,$r.Bottom-$r.Top);$scale=[Math]::Min(1.0,{w}.0/$ww);$W=[int]($ww*$scale);$H=[int]($hh*$scale)
$a=New-Object Drawing.Bitmap $ww,$hh;$g=[Drawing.Graphics]::FromImage($a);$g.CopyFromScreen($r.Left,$r.Top,0,0,(New-Object Drawing.Size($ww,$hh)))
$d=New-Object Drawing.Bitmap $W,$H;$g2=[Drawing.Graphics]::FromImage($d);$g2.InterpolationMode=[Drawing.Drawing2D.InterpolationMode]::HighQualityBilinear;$g2.DrawImage($a,0,0,$W,$H)
$j=[Drawing.Imaging.ImageCodecInfo]::GetImageEncoders()|? {{$_.MimeType -eq 'image/jpeg'}};$e=New-Object Drawing.Imaging.EncoderParameters(1);$e.Param[0]=New-Object Drawing.Imaging.EncoderParameter([Drawing.Imaging.Encoder]::Quality,[long]{q});$d.Save('{pp}',$j,$e)
$g.Dispose();$g2.Dispose();$a.Dispose();$d.Dispose();$e.Dispose()'''
            subprocess.run(["powershell.exe","-NoProfile","-NonInteractive","-Command",ps],check=True,timeout=15,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))
            return dest if dest.exists() else None
        cc=dict(c);cc["screenshot_jpeg_quality"]=q;cc["screenshot_max_width"]=w
        return screenshot(dest,cc)
    except Exception:
        dest.unlink(missing_ok=True)
        return None


def _visual_hash(path):
    try:
        import hashlib
        return hashlib.sha1(Path(path).read_bytes()).hexdigest()
    except Exception:
        return ""


def _visual_project(e):
    try:
        p=eventproj(e) or (e.get("meta") or {}).get("project","") or ""
    except Exception:
        p=(e.get("meta") or {}).get("project","") or ""
    return aliases(str(p).strip())


def _visual_is_loxone(e):
    app=str(e.get("app","") or "").casefold()
    return app=="loxoneconfig.exe" or "loxone config" in app


def _visual_pick_images(paths,maxn):
    paths=[str(p) for p in paths if p and Path(p).exists()]
    if len(paths)<=maxn:return paths
    if maxn<=1:return [paths[-1]]
    idx=[]
    for i in range(maxn):
        j=round(i*(len(paths)-1)/(maxn-1))
        if j not in idx:idx.append(j)
    return [paths[i] for i in idx]


def _visual_schema_file():
    p=home()/"tmp"/"visual_session.schema.json"
    if not p.exists():
        p.write_text(json.dumps({
            "type":"object","additionalProperties":False,
            "required":["activity","detail","confidence","evidence"],
            "properties":{
                "activity":{"type":"string"},
                "detail":{"type":"string"},
                "confidence":{"type":"integer","minimum":0,"maximum":100},
                "evidence":{"type":"array","items":{"type":"string"}}
            }
        },ensure_ascii=False,indent=2),encoding="utf-8")
    return p


def _visual_update_events(sess,result):
    project=sess.get("project","")
    start=float(sess.get("start",0) or 0);end=float(sess.get("last",start) or start)
    con=db()
    rows=con.execute("SELECT id,meta_json,title,app FROM events WHERE ts>=? AND ts<=? ORDER BY ts",(start,end+1)).fetchall()
    for rid,mj,title,app in rows:
        if str(app or "").casefold()!="loxoneconfig.exe":continue
        try:meta=json.loads(mj or "{}")
        except:meta={}
        ep=str(meta.get("project","") or "").strip() or loxproj(title or "")
        # Kratke Loxone vzorky bez projektu patri do stejne vizualni relace.
        # Nezahazuj je, jinak se vysledek Codexu nepropise do casti bloku.
        if project and ep and aliases(ep).casefold()!=project.casefold():continue
        if project and not ep:
            meta["project"]=project
        meta["activity"]=result.get("activity",meta.get("activity", "aktivní práce v Loxone Config"))
        meta["visual_activity"]=result.get("activity","")
        meta["visual_detail"]=result.get("detail","")
        meta["visual_confidence"]=int(result.get("confidence",0) or 0)
        try:old=float(meta.get("confidence",0) or 0)
        except:old=0
        meta["confidence"]=max(old,min(0.99,max(0,int(result.get("confidence",0) or 0))/100.0))
        ev=list(meta.get("evidence",[]) or [])
        if "visual_codex_session" not in ev:ev.append("visual_codex_session")
        for x in result.get("evidence",[]) or []:
            x=str(x).strip()
            if x and x not in ev:ev.append(x)
        meta["evidence"]=ev
        con.execute("UPDATE events SET meta_json=? WHERE id=?",(json.dumps(meta,ensure_ascii=False),rid))
    con.commit();con.close()


def _visual_clear_screens(paths):
    paths=[str(p) for p in paths if p]
    if not paths:return
    con=db()
    for p in paths:
        con.execute("UPDATE events SET screenshot='' WHERE screenshot=?",(p,))
        try:Path(p).unlink(missing_ok=True)
        except:pass
    con.commit();con.close()


def _visual_log(sess,result,status="ok",error=""):
    try:
        p=home()/"reports"/"visual_sessions.jsonl"
        row={"created":iso(),"project":sess.get("project","") ,"start":iso(sess.get("start")),"end":iso(sess.get("last")),"screens":len(sess.get("screens",[])),"status":status,"result":result,"error":error}
        with p.open("a",encoding="utf-8") as f:f.write(json.dumps(row,ensure_ascii=False)+"\n")
    except:pass


def _visual_analyze_session(sess):
    if not workmode_active():
        _visual_clear_screens(list(sess.get("screens",[]) or []))
        return
    c=cfg();duration=float(sess.get("last",0) or 0)-float(sess.get("start",0) or 0)
    paths=list(sess.get("screens",[]) or [])
    if duration<float(c.get("visual_min_session_seconds",12)) or not paths:
        _visual_clear_screens(paths)
        return
    ok,msg=codexok()
    if not ok:
        _visual_log(sess,{},"failed","Codex: "+msg)
        return
    imgs=_visual_pick_images(paths,max(1,int(c.get("visual_codex_max_images",20))))
    if not imgs:return
    _visual_log(sess,{"phase":"codex_started","images":len(imgs)},"started","")
    cb=codex_bin();h=run([cb,"exec","--help"],10,cenv()) if cb else ""
    if "--image" not in h:
        _visual_log(sess,{},"failed","Codex CLI nema --image")
        return
    project=sess.get("project","") or "Nezařazeno"
    prompt=f'''Jsi analyzator pracovni relace v Loxone Configu. Dostavas casove serazene screenshoty jedne souvisle relace.
Projekt: {project}
Cas: {dt.datetime.fromtimestamp(sess['start']).strftime('%H:%M:%S')}–{dt.datetime.fromtimestamp(sess['last']).strftime('%H:%M:%S')}
Pocet zachycenych zmen: {len(paths)}; pro analyzu vybrano: {len(imgs)}.

Z obrazovek urci, CO uzivatel v Loxone Configu skutecne delal. Sleduj zejmena programove bloky, nazvy stran, vybrane objekty, online diagnostiku, parametry, virtualni vstupy/vystupy, Modbus/DALI/HVAC logiku a zmeny mezi snimky.
Nevymyslej zadne konkretni upravy, ktere nejsou vizualne podlozene. Pokud jde jen o prohlizeni nebo kontrolu, rekni to.

Vrat JSON dle schematu:
- activity: jedna kratka veta vhodna do pracovniho vykazu (cesky)
- detail: 1–3 konkretni vety co se resilo (cesky)
- confidence: 0–100
- evidence: kratke body, co bylo na screenshotech videt
'''
    out=home()/"tmp"/f"visual_{int(sess['start'])}_{uuid.uuid4().hex[:6]}.json";out.unlink(missing_ok=True)
    cmd=[cb,"exec","--ephemeral","--skip-git-repo-check","--sandbox","read-only","--output-schema",str(_visual_schema_file()),"-o",str(out)]
    for p in imgs:cmd += ["--image",p]
    try:
        pr=subprocess.run(cmd+["-"],input=prompt,capture_output=True,text=True,timeout=600,env=cenv())
        if pr.returncode!=0:raise RuntimeError((pr.stderr or pr.stdout or "")[-3000:])
        result=deep(json.loads(out.read_text(encoding="utf-8")))
        _visual_update_events(sess,result)
        _visual_log(sess,result,"ok","")
        if c.get("visual_delete_after_success",True):_visual_clear_screens(paths)
    except Exception as ex:
        _visual_log(sess,{},"failed",str(ex)[-2000:])
    finally:
        out.unlink(missing_ok=True)


def _visual_finalize_locked():
    global VISUAL_SESSION
    if not VISUAL_SESSION.get("project"):
        return None
    sess={k:(list(v) if isinstance(v,list) else v) for k,v in VISUAL_SESSION.items()}
    VISUAL_SESSION={"project":"","start":0.0,"last":0.0,"screens":[],"last_hash":"","source":""}
    return sess


def visual_session_ingest(e):
    # Na Mac HUBu sklada Loxone relaci a pri opusteni projektu ji asynchronne preda Codexu.
    if SYSTEM!="Darwin" or not cfg().get("visual_loxone_enabled",True) or not workmode_active():return

    app_cf=str(e.get("app","") or "").casefold()
    os_cf=str(e.get("os","") or "").casefold()

    # Mac collector pri praci ve VM vidi pouze Parallels transport. Ten nesmi ukoncit
    # Windows Loxone session ani vytvaret novou pracovni aktivitu.
    if os_cf=="macos" and any(x in app_cf for x in ("prl_client_app","parallels desktop","windows app")):
        return

    ts=float(e.get("ts",time.time()) or time.time())
    islox=_visual_is_loxone(e) and not bool(e.get("is_idle"))
    project=_visual_project(e) if islox else ""
    shot=str(e.get("screenshot","") or "")
    to_finalize=None

    with VISUAL_LOCK:
        active=str(VISUAL_SESSION.get("project","") or "")

        if active:
            # DULEZITE: Loxone Config pri nekterych dialozich/prechodech na par sekund
            # nema projekt v titulku. To NENI konec session. Drzime posledni projekt.
            if islox and not project:
                project=active
            # Skutecny odchod z Loxone nebo jasna zmena projektu session ukonci.
            elif (not islox) or (project and project.casefold()!=active.casefold()):
                to_finalize=_visual_finalize_locked()
                active=""

        if islox and project:
            if not VISUAL_SESSION.get("project"):
                VISUAL_SESSION.update({
                    "project":project,"start":ts,"last":ts,"screens":[],
                    "last_hash":"","source":str(e.get("source","") or "")
                })
            VISUAL_SESSION["last"]=ts

            if shot and Path(shot).exists():
                hh=_visual_hash(shot)
                if hh and hh==VISUAL_SESSION.get("last_hash"):
                    _visual_clear_screens([shot])
                else:
                    VISUAL_SESSION["screens"].append(shot)
                    VISUAL_SESSION["last_hash"]=hh
                    limit=max(20,int(cfg().get("visual_session_keep_images",60)))
                    if len(VISUAL_SESSION["screens"])>limit:
                        oldscreens=list(VISUAL_SESSION["screens"])
                        keep=oldscreens[::2]
                        if oldscreens[-1] not in keep:keep.append(oldscreens[-1])
                        dropped=[p for p in oldscreens if p not in set(keep)]
                        VISUAL_SESSION["screens"]=keep
                        _visual_clear_screens(dropped)

    if to_finalize:
        # Nedaemon thread: analyza se nesmi ztratit jen proto, ze se zrovna restartuje menu/agent.
        threading.Thread(
            target=_visual_analyze_session,
            args=(to_finalize,),
            daemon=False,
            name="WorkLogVisualCodex"
        ).start()

def visual_flush_session():
    if SYSTEM!="Darwin":return
    with VISUAL_LOCK:sess=_visual_finalize_locked()
    if sess:_visual_analyze_session(sess)



# -----------------------------------------------------------------------------
# Outlook Visual Session Analyzer
# -----------------------------------------------------------------------------
OUTLOOK_VISUAL_LOCK=threading.RLock()
OUTLOOK_VISUAL_SESSION={"start":0.0,"last":0.0,"screens":[],"last_hash":"","source":"","project":""}

def _visual_is_outlook(e):
    app=str(e.get("app","") or "").casefold()
    title=str(e.get("title","") or "").casefold()
    return "outlook" in app or app in ("olk.exe","outlook.exe") or "microsoft outlook" in title

def _outlook_schema_file():
    p=home()/"tmp"/"outlook_visual_session.schema.json"
    if not p.exists():
        p.write_text(json.dumps({
            "type":"object","additionalProperties":False,
            "required":["activity","detail","action","project","recipients","subject","message_summary","sent_time","confidence","evidence"],
            "properties":{
                "activity":{"type":"string"},
                "detail":{"type":"string"},
                "action":{"type":"string","enum":["reading","writing","sent","searching","organizing","other"]},
                "project":{"type":"string"},
                "recipients":{"type":"array","items":{"type":"string"}},
                "subject":{"type":"string"},
                "message_summary":{"type":"string"},
                "sent_time":{"type":"string"},
                "confidence":{"type":"integer","minimum":0,"maximum":100},
                "evidence":{"type":"array","items":{"type":"string"}}
            }
        },ensure_ascii=False,indent=2),encoding="utf-8")
    return p

def _outlook_latest_project(ts):
    try:
        con=db()
        rows=con.execute(
            "SELECT ts,title,meta_json,app FROM events WHERE ts<=? AND ts>=? ORDER BY ts DESC LIMIT 80",
            (ts,ts-900)
        ).fetchall()
        con.close()
        for ets,title,mj,app in rows:
            try:meta=json.loads(mj or "{}")
            except:meta={}
            p=str(meta.get("project","") or "").strip()
            if not p and str(app or "").casefold()=="loxoneconfig.exe":
                p=loxproj(title or "")
            if p:return aliases(p)
    except Exception:
        pass
    return ""

def _outlook_update_events(sess,result):
    start=float(sess.get("start",0) or 0);end=float(sess.get("last",start) or start)
    con=db()
    rows=con.execute("SELECT id,meta_json,app,kind FROM events WHERE ts>=? AND ts<=? ORDER BY ts",(start,end+2)).fetchall()
    for rid,mj,app,kind in rows:
        if not _visual_is_outlook({"app":app}) and str(kind or "")!="email_sent":
            continue
        try:meta=json.loads(mj or "{}")
        except:meta={}
        meta["activity"]=result.get("activity",meta.get("activity","Práce s e-mailem v Outlooku"))
        meta["visual_activity"]=result.get("activity","")
        meta["visual_detail"]=result.get("detail","")
        meta["visual_confidence"]=int(result.get("confidence",0) or 0)
        meta["outlook_action"]=result.get("action","")
        meta["outlook_project"]=result.get("project","")
        meta["outlook_recipients"]=result.get("recipients",[]) or meta.get("email_recipients",[])
        meta["outlook_subject"]=result.get("subject","") or meta.get("email_subject","")
        meta["outlook_message_summary"]=result.get("message_summary","")
        meta["outlook_sent_time"]=result.get("sent_time","") or meta.get("email_sent_at","")
        if result.get("project") and not meta.get("project"):
            meta["project"]=result.get("project")
        try:old=float(meta.get("confidence",0) or 0)
        except:old=0
        meta["confidence"]=max(old,min(0.99,max(0,int(result.get("confidence",0) or 0))/100.0))
        ev=list(meta.get("evidence",[]) or [])
        if "outlook_visual_codex_session" not in ev:ev.append("outlook_visual_codex_session")
        for x in result.get("evidence",[]) or []:
            x=str(x).strip()
            if x and x not in ev:ev.append(x)
        meta["evidence"]=ev
        con.execute("UPDATE events SET meta_json=? WHERE id=?",(json.dumps(meta,ensure_ascii=False),rid))
    con.commit();con.close()

def _outlook_log(sess,result,status="ok",error=""):
    try:
        p=home()/"reports"/"outlook_visual_sessions.jsonl"
        row={"created":iso(),"start":iso(sess.get("start")),"end":iso(sess.get("last")),
             "screens":len(sess.get("screens",[])),"project":sess.get("project",""),
             "status":status,"result":result,"error":error}
        with p.open("a",encoding="utf-8") as f:f.write(json.dumps(row,ensure_ascii=False)+"\\n")
    except Exception:pass

def _outlook_analyze_session(sess):
    if not workmode_active():
        _visual_clear_screens(list(sess.get("screens",[]) or []))
        return
    c=cfg()
    duration=float(sess.get("last",0) or 0)-float(sess.get("start",0) or 0)
    paths=list(sess.get("screens",[]) or [])
    if duration<float(c.get("visual_min_session_seconds",12)) or not paths:
        _visual_clear_screens(paths);return
    ok,msg=codexok()
    if not ok:
        _outlook_log(sess,{},"failed","Codex: "+msg);return
    imgs=_visual_pick_images(paths,max(1,int(c.get("visual_outlook_codex_max_images",20))))
    if not imgs:return
    _outlook_log(sess,{"phase":"codex_started","images":len(imgs)},"started","")
    cb=codex_bin();h=run([cb,"exec","--help"],10,cenv()) if cb else ""
    if "--image" not in h:
        _outlook_log(sess,{},"failed","Codex CLI nema --image");return
    project=sess.get("project","") or "Nezařazeno"
    prompt=f'''Jsi analyzator pracovni relace v Microsoft Outlooku. Dostavas casove serazene screenshoty jedne souvisle relace.
Predchozi projektovy kontext: {project}
Cas relace: {dt.datetime.fromtimestamp(sess["start"]).strftime("%H:%M:%S")} - {dt.datetime.fromtimestamp(sess["last"]).strftime("%H:%M:%S")}

Zjisti co uzivatel v Outlooku delal. Rozlis cteni e-mailu, psani odpovedi/noveho e-mailu, odeslani, hledani nebo trideni.
Pokud je na snimcich videt prijemce, predmet a obsah psaneho/odeslaneho e-mailu, shrn je presne, ale strucne.
Pokud je skutecne odeslani dolozeno samostatnou Outlook/MAPI udalosti nebo jasnym vizualnim prechodem po odeslani, action="sent".
Jestlize odeslani neni dolozeno, NIKDY netvrd, ze byl e-mail odeslan.
sent_time vypln jen pokud je cas odeslani dolozeny; jinak prazdny retezec.
project vypln jen pokud je z predmetu/obsahu nebo kontextu rozumne identifikovatelny.

Vrat JSON:
- activity: kratka veta do pracovniho vykazu
- detail: 1-3 konkretni vety co se resilo
- action
- project
- recipients
- subject
- message_summary
- sent_time
- confidence 0-100
- evidence
'''
    out=home()/"tmp"/f"outlook_visual_{int(sess['start'])}_{uuid.uuid4().hex[:6]}.json";out.unlink(missing_ok=True)
    cmd=[cb,"exec","--ephemeral","--skip-git-repo-check","--sandbox","read-only","--output-schema",str(_outlook_schema_file()),"-o",str(out)]
    for p in imgs:cmd += ["--image",p]
    try:
        pr=subprocess.run(cmd+["-"],input=prompt,capture_output=True,text=True,timeout=600,env=cenv())
        if pr.returncode!=0:raise RuntimeError((pr.stderr or pr.stdout or "")[-3000:])
        result=deep(json.loads(out.read_text(encoding="utf-8")))
        _outlook_update_events(sess,result)
        _outlook_log(sess,result,"ok","")
        if c.get("visual_delete_after_success",True):_visual_clear_screens(paths)
    except Exception as ex:
        _outlook_log(sess,{},"failed",str(ex)[-2000:])
    finally:
        out.unlink(missing_ok=True)

def _outlook_finalize_locked():
    global OUTLOOK_VISUAL_SESSION
    if not OUTLOOK_VISUAL_SESSION.get("start"):
        return None
    sess={k:(list(v) if isinstance(v,list) else v) for k,v in OUTLOOK_VISUAL_SESSION.items()}
    OUTLOOK_VISUAL_SESSION={"start":0.0,"last":0.0,"screens":[],"last_hash":"","source":"","project":""}
    return sess

def outlook_visual_session_ingest(e):
    if SYSTEM!="Darwin" or not cfg().get("visual_outlook_enabled",True) or not workmode_active():
        return
    app_cf=str(e.get("app","") or "").casefold()
    os_cf=str(e.get("os","") or "").casefold()
    if os_cf=="macos" and any(x in app_cf for x in ("prl_client_app","parallels desktop","windows app")):
        return
    ts=float(e.get("ts",time.time()) or time.time())
    isout=_visual_is_outlook(e) and not bool(e.get("is_idle"))
    shot=str(e.get("screenshot","") or "")
    to_finalize=None
    with OUTLOOK_VISUAL_LOCK:
        active=bool(OUTLOOK_VISUAL_SESSION.get("start"))
        if active and not isout:
            to_finalize=_outlook_finalize_locked()
            active=False
        if isout:
            if not OUTLOOK_VISUAL_SESSION.get("start"):
                OUTLOOK_VISUAL_SESSION.update({
                    "start":ts,"last":ts,"screens":[],"last_hash":"",
                    "source":str(e.get("source","") or ""),"project":_outlook_latest_project(ts)
                })
            OUTLOOK_VISUAL_SESSION["last"]=ts
            if shot and Path(shot).exists():
                hh=_visual_hash(shot)
                if hh and hh==OUTLOOK_VISUAL_SESSION.get("last_hash"):
                    _visual_clear_screens([shot])
                else:
                    OUTLOOK_VISUAL_SESSION["screens"].append(shot)
                    OUTLOOK_VISUAL_SESSION["last_hash"]=hh
                    limit=max(20,int(cfg().get("visual_session_keep_images",60)))
                    if len(OUTLOOK_VISUAL_SESSION["screens"])>limit:
                        old=list(OUTLOOK_VISUAL_SESSION["screens"])
                        keep=old[::2]
                        if old[-1] not in keep:keep.append(old[-1])
                        dropped=[p for p in old if p not in set(keep)]
                        OUTLOOK_VISUAL_SESSION["screens"]=keep
                        _visual_clear_screens(dropped)
    if to_finalize and workmode_active():
        threading.Thread(target=_outlook_analyze_session,args=(to_finalize,),daemon=False,name="WorkLogOutlookVisualCodex").start()
    elif to_finalize:
        _visual_clear_screens(to_finalize.get("screens",[]))

def outlook_visual_flush_session(analyze=True):
    if SYSTEM!="Darwin":return
    with OUTLOOK_VISUAL_LOCK:sess=_outlook_finalize_locked()
    if not sess:return
    if analyze and workmode_active():_outlook_analyze_session(sess)
    else:_visual_clear_screens(sess.get("screens",[]))

def visual_discard_all():
    try:
        with VISUAL_LOCK:s1=_visual_finalize_locked()
        if s1:_visual_clear_screens(s1.get("screens",[]))
    except Exception:pass
    try:
        with OUTLOOK_VISUAL_LOCK:s2=_outlook_finalize_locked()
        if s2:_visual_clear_screens(s2.get("screens",[]))
    except Exception:pass

def outlook_sent_probe(last_entry_id=""):
    if SYSTEM!="Windows" or not cfg().get("outlook_sent_probe_enabled",True):
        return None
    ps=r'''$ErrorActionPreference="Stop"
try {
  $o=[Runtime.InteropServices.Marshal]::GetActiveObject("Outlook.Application")
  $ns=$o.GetNamespace("MAPI")
  $f=$ns.GetDefaultFolder(5)
  $items=$f.Items
  $items.Sort("[SentOn]",$true)
  $m=$items.GetFirst()
  if($null -eq $m){exit 0}
  $body=[string]$m.Body
  if($body.Length -gt 2000){$body=$body.Substring(0,2000)}
  [pscustomobject]@{
    entry_id=[string]$m.EntryID
    sent_on=$m.SentOn.ToString("yyyy-MM-ddTHH:mm:ss")
    to=[string]$m.To
    cc=[string]$m.CC
    subject=[string]$m.Subject
    body=$body
  } | ConvertTo-Json -Compress
} catch { exit 0 }'''
    raw=run(["powershell.exe","-NoProfile","-NonInteractive","-Command",ps],12)
    if not raw:return None
    try:o=json.loads(raw)
    except:return None
    eid=str(o.get("entry_id","") or "")
    if not eid or eid==last_entry_id:return None
    try:
        sent=dt.datetime.fromisoformat(str(o.get("sent_on","")))
        age=abs((dt.datetime.now()-sent).total_seconds())
    except:
        age=999999
    if age>float(cfg().get("outlook_sent_probe_window_seconds",180)):
        return None
    return o


class TH(socketserver.ThreadingMixIn,http.server.HTTPServer):daemon_threads=True
def save_windows_client_heartbeat(payload):
    payload=payload if isinstance(payload,dict) else {}
    hostname=re.sub(r"[^A-Za-z0-9_.-]","",str(payload.get("hostname","") or ""))[:80]
    state={
        "last_seen":time.time(),
        "last_seen_iso":iso(),
        "hostname":hostname,
        "version":str(payload.get("version","") or "")[:24],
        "collecting":bool(payload.get("collecting",False)),
        "paused":bool(payload.get("paused",False)),
        "workmode_active":bool(payload.get("workmode_active",False)),
    }
    idle=payload.get("idle_seconds")
    if isinstance(idle,(int,float)) and idle>=0:state["idle_seconds"]=round(float(idle),1)
    save_json_atomic(windows_client_state_path(),state)
    return state
def load_windows_client_heartbeat():
    try:
        state=json.loads(windows_client_state_path().read_text(encoding="utf-8"))
        return state if isinstance(state,dict) else {}
    except:return {}
def tokenok(h,p):
    c=cfg();tok=(p.get("token") or [""])[0] or h.headers.get("X-WorkLog-Token","");return c.get("mobile_enabled",True) and tok==c.get("mobile_token")
def mobile(tok,msg=""):
    ok=f'<div class="ok">{html.escape(msg)}</div>' if msg else ""
    return f"""<!doctype html><html lang="cs"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Evora Smart Menu</title>
<style>:root{{color-scheme:light dark}}body{{font-family:-apple-system,sans-serif;margin:0;padding:24px;background:Canvas;color:CanvasText}}main{{max-width:620px;margin:auto}}h1{{margin:0}}.sub{{opacity:.65;margin:5px 0 20px}}.card{{border:1px solid #8885;border-radius:18px;padding:16px}}label{{display:block;font-weight:600;margin:12px 0 6px}}textarea,input,select{{width:100%;box-sizing:border-box;padding:12px;border-radius:12px;font:inherit;background:Canvas;color:CanvasText;border:1px solid #8887}}textarea{{min-height:110px}}button{{width:100%;padding:14px;margin-top:14px;border:0;border-radius:14px;background:#278a57;color:white;font-weight:700;font-size:16px}}.ok{{padding:12px;border-radius:12px;background:#278a5733;margin-bottom:14px}}.small{{font-size:13px;opacity:.65}}</style></head>
<body><main><h1>Evora Smart Menu</h1><div class="sub">Rychlý zápis práce z iPhonu</div>{ok}<div class="card"><form method="post" action="/manual?token={html.escape(tok)}">
<label>Typ</label><select name="kind"><option value="note">📝 Poznámka</option><option value="call">📞 Hovor</option><option value="travel">🚗 Výjezd / cesta</option><option value="offpc">🔧 Práce mimo PC</option></select>
<label>Co se řešilo?</label><textarea name="text" placeholder="Např. Majer – Wellness, kontrola regulace KT"></textarea>
<label>Délka v minutách <span class="small">(volitelně)</span></label><input name="duration" type="number" inputmode="numeric" min="0" max="1440" placeholder="např. 15"><button>Uložit</button></form></div>
<p class="small">WorkLog se pokusí poznámku přiřadit k aktuálnímu projektu. U hovoru nebo práce mimo PC je vhodné zadat délku, pokud ji znáš.</p></main></body></html>"""
class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self,*a):pass
    def sendx(self,code,x,ct="application/json; charset=utf-8"):
        b=(json.dumps(x,ensure_ascii=False) if isinstance(x,(dict,list)) else str(x)).encode();self.send_response(code);self.send_header("Content-Type",ct);self.send_header("Content-Length",str(len(b)));self.end_headers();self.wfile.write(b)
    def do_GET(self):
        u=urllib.parse.urlparse(self.path);p=urllib.parse.parse_qs(u.query)
        if u.path=="/ping":return self.sendx(200,{"ok":True,"version":VERSION,"workmode_active":workmode_active()})
        if u.path=="/mobile":
            if not tokenok(self,p):return self.sendx(403,"Neplatný token","text/plain; charset=utf-8")
            return self.sendx(200,mobile((p.get("token") or [""])[0]),"text/html; charset=utf-8")
        if u.path=="/quick":
            if not tokenok(self,p):return self.sendx(403,{"ok":False})
            return self.sendx(200,quick())
        self.sendx(404,{"ok":False})
    def do_POST(self):
        u=urllib.parse.urlparse(self.path);p=urllib.parse.parse_qs(u.query);n=int(self.headers.get("Content-Length","0"))
        if u.path=="/client-heartbeat":
            if n<0 or n>4096:return self.sendx(413,{"ok":False,"error":"heartbeat_too_large"})
            try:
                payload=json.loads(self.rfile.read(n).decode("utf-8","replace"))
                save_windows_client_heartbeat(payload)
                return self.sendx(200,{"ok":True,"workmode_active":workmode_active()})
            except Exception:return self.sendx(400,{"ok":False,"error":"invalid_heartbeat"})
        if u.path=="/event":
            try:
                o=json.loads(self.rfile.read(n));shot=o.pop("screenshot_b64","")
                if not workmode_active():
                    return self.sendx(200,{"ok":True,"ignored":True,"reason":"workmode_inactive"})
                if shot:
                    d=home()/"screenshots"/o.get("day",today());d.mkdir(parents=True,exist_ok=True);f=d/f'{int(o.get("ts",time.time()))}_{uuid.uuid4().hex[:6]}_win.jpg';f.write_bytes(base64.b64decode(shot));o["screenshot"]=str(f)
                if str(o.get("os","")).lower()=="windows" and cfg().get("windows_only_when_vm_frontmost",True) and not mac_vm_frontmost():
                    if o.get("screenshot"):
                        try:Path(o["screenshot"]).unlink(missing_ok=True)
                        except:pass
                    return self.sendx(200,{"ok":True,"ignored":True,"reason":"windows_vm_not_frontmost"})
                add_event(o);return self.sendx(200,{"ok":True})
            except Exception as ex:return self.sendx(400,{"ok":False,"error":str(ex)})
        if u.path=="/manual":
            if not tokenok(self,p):return self.sendx(403,"Neplatný token","text/plain; charset=utf-8")
            try:
                form=urllib.parse.parse_qs(self.rfile.read(n).decode());kind=(form.get("kind") or ["note"])[0];text=(form.get("text") or [""])[0].strip();dur=float((form.get("duration") or ["0"])[0] or 0)
                if not text:raise ValueError("Text je prázdný")
                manual(kind,text,dur,"iPhone");tok=(p.get("token") or [""])[0];return self.sendx(200,mobile(tok,"Uloženo do WorkLogu."),"text/html; charset=utf-8")
            except Exception as ex:return self.sendx(400,str(ex),"text/plain; charset=utf-8")
        self.sendx(404,{"ok":False})

def hub_info(u):
    try:
        with urllib.request.urlopen(u.rstrip("/")+"/ping",timeout=2) as r:
            if r.status!=200:return {}
            x=json.loads(r.read().decode("utf-8","replace"))
            return x if isinstance(x,dict) and x.get("ok") is True and "workmode_active" in x else {}
    except:return {}
def ping(u):return bool(hub_info(u))
def gateway():
    o=run(["powershell.exe","-NoProfile","-NonInteractive","-Command","(Get-NetRoute -DestinationPrefix '0.0.0.0/0' | Sort RouteMetric | Select -First 1).NextHop"],4);return o.splitlines()[0].strip() if o else ""
def windows_host_candidates():
    if SYSTEM!="Windows":return []
    script=(
        "$out=@();"
        "$out+=Get-NetRoute -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue | ForEach-Object {$_.NextHop};"
        "$out+=Get-NetIPAddress -AddressFamily IPv4 -ErrorAction SilentlyContinue | "
        "Where-Object {$_.IPAddress -notlike '127.*' -and $_.IPAddress -notlike '169.254.*'} | "
        "ForEach-Object {$p=$_.IPAddress.Split('.'); if($p.Count -eq 4){\"$($p[0]).$($p[1]).$($p[2]).2\"}};"
        "$out | Where-Object {$_} | Select-Object -Unique"
    )
    o=run(["powershell.exe","-NoProfile","-NonInteractive","-Command",script],5)
    return [x.strip() for x in o.splitlines() if re.fullmatch(r"\d{1,3}(?:\.\d{1,3}){3}",x.strip())]
def findhub(c):
    cs=[str(c.get("hub_url","") or "").rstrip("/")]
    if SYSTEM=="Windows":
        ports=[]
        for p in (c.get("port",8765),8765,8766):
            try:p=int(p)
            except:continue
            if 1<=p<=65535 and p not in ports:ports.append(p)
        hosts=windows_host_candidates()+["10.37.129.2","10.211.55.2","10.0.0.99"]
        seen_hosts=[]
        for h in hosts:
            if h and h not in seen_hosts:seen_hosts.append(h)
        cs += [f"http://{h}:{p}" for h in seen_hosts for p in ports]
    seen=set()
    for u in cs:
        if not u or u in seen:continue
        seen.add(u)
        if ping(u):
            if SYSTEM=="Windows" and u!=str(c.get("hub_url","") or "").rstrip("/"):
                updated=dict(c);updated["hub_url"]=u
                try:save_cfg(updated);c["hub_url"]=u
                except:pass
            return u
    return ""

def hub_workmode_active(u):
    return bool(hub_info(u).get("workmode_active")) if u else False

def sendheartbeat(u,collecting=False,is_paused=False,work_active=False,idle_seconds=None):
    if not u:return False
    payload={
        "hostname":platform.node(),"version":VERSION,"collecting":bool(collecting),
        "paused":bool(is_paused),"workmode_active":bool(work_active)
    }
    if isinstance(idle_seconds,(int,float)) and idle_seconds>=0:payload["idle_seconds"]=float(idle_seconds)
    try:
        req=urllib.request.Request(
            u.rstrip("/")+"/client-heartbeat",data=json.dumps(payload).encode(),
            headers={"Content-Type":"application/json"},method="POST"
        )
        with urllib.request.urlopen(req,timeout=4) as r:return r.status==200
    except:return False

def sendevent(u,e,p=None):
    o=dict(e)
    if p and Path(p).exists():
        o["screenshot_b64"]=base64.b64encode(Path(p).read_bytes()).decode()
    try:
        req=urllib.request.Request(
            u.rstrip("/")+"/event",
            data=json.dumps(o,ensure_ascii=False).encode(),
            headers={"Content-Type":"application/json"},
            method="POST"
        )
        with urllib.request.urlopen(req,timeout=12) as r:
            return r.status==200
    except:
        return False

def codexok():
    cb=codex_bin()
    if not cb:return False,"Codex CLI nenalezen (ani pres login shell)"
    try:
        p=subprocess.run([cb,"login","status"],capture_output=True,text=True,timeout=15,env=cenv())
        msg=((p.stdout or "")+(p.stderr or "")).strip()
        return p.returncode==0,(msg or cb)
    except Exception as ex:return False,str(ex)
def login(force=False):
    if SYSTEM!="Darwin":print("Codex se přihlašuje pouze na Mac HUBu.");return
    cb=codex_bin()
    if not cb:
        print("Codex CLI nenalezen.");return
    if force:subprocess.run([cb,"logout"],env=cenv(),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    subprocess.run([cb,"login","--device-auth"],env=cenv())
def logout():
    cb=codex_bin()
    if cb:subprocess.run([cb,"logout"],env=cenv())
def condense(es):
    out=[];last=None;anchor=0
    for e in es:
        k=(e["source"],e["app"],e["title"],e["url"],e["is_idle"],e["kind"],e["note"],e.get("duration_minutes",0))
        if k!=last or e["ts"]-anchor>=120:out.append(e);last=k;anchor=e["ts"]
    return out
def analyze(day,es,c):
    ok,msg=codexok()
    if not ok:raise RuntimeError(msg)
    ev=[]
    for e in condense(es):ev.append({"time":e["iso"],"source":e["source"],"os":e["os"],"app":e["app"],"window":e["title"],"url":e["url"],"idle_seconds":round(float(e["idle_seconds"] or 0),1),"idle":bool(e["is_idle"]),"kind":e["kind"],"note":e["note"],"duration_minutes":float(e.get("duration_minutes",0) or 0),"activity":(e.get("meta") or {}).get("activity",""),"detected_project":(e.get("meta") or {}).get("project",""),"confidence":(e.get("meta") or {}).get("confidence",0),"evidence":(e.get("meta") or {}).get("evidence",[]),"focused_role":(e.get("meta") or {}).get("focused_role",""),"focused_title":(e.get("meta") or {}).get("focused_title",""),"files_changed":(e.get("meta") or {}).get("files_changed",[]),"input":(e.get("meta") or {}).get("input",{}),"screenshot_file":e["screenshot"] or ""})
    pr=prompt_path().read_text(encoding="utf-8")+"\n\nDATUM: "+day+"\n\nTELEMETRIE JSON:\n"+json.dumps(ev,ensure_ascii=False,indent=2);out=home()/"tmp"/f"codex_{day}.json";out.unlink(missing_ok=True)
    cb=codex_bin();cmd=[cb,"exec","--ephemeral","--skip-git-repo-check","--sandbox","read-only","--output-schema",str(schema_path()),"-o",str(out)]
    cb=codex_bin();h=run([cb,"exec","--help"],10,cenv()) if cb else ""
    if "--image" in h:
        imgs=[];seen=set()
        for e in reversed(es):
            p=e.get("screenshot")
            if p and p not in seen and Path(p).exists():imgs.append(p);seen.add(p)
            if len(imgs)>=int(c.get("codex_max_images",18)):break
        for p in reversed(imgs):cmd+=["--image",p]
    p=subprocess.run(cmd+["-"],input=pr,capture_output=True,text=True,timeout=900,env=cenv())
    if p.returncode!=0:raise RuntimeError(((p.stderr or p.stdout or "")[-5000:]))
    return deep(json.loads(out.read_text(encoding="utf-8")))
def worst(v):
    o={"high":0,"medium":1,"low":2};x=[a for a in v if a in o];return max(x,key=lambda a:o[a]) if x else "medium"
def consolidate(r):
    r=deep(r);g={};order=[]
    for b in r.get("work_blocks",[]) or []:
        p=aliases((b.get("project") or "").strip() or "Nezařazeno");k=p.casefold()
        if k not in g:g[k]={"p":p,"s":[],"e":[],"m":0.,"c":[],"sum":[],"conf":[],"ev":[]};order.append(k)
        x=g[k];x["s"] += [str(b["start"])] if b.get("start") else [];x["e"] += [str(b["end"])] if b.get("end") else []
        try:x["m"]+=float(b.get("minutes",0) or 0)
        except:pass
        for f,d in [("category","c"),("summary","sum"),("confidence","conf"),("evidence","ev")]:
            v=repair(str(b.get(f,"") or "").strip())
            if v and v not in x[d]:x[d].append(v)
    blocks=[]
    for k in order:
        x=g[k];blocks.append({"start":min(x["s"]) if x["s"] else "","end":max(x["e"]) if x["e"] else "","minutes":round(x["m"],1),"project":x["p"],"category":" / ".join(x["c"][:4]),"summary":"; ".join(x["sum"]),"confidence":worst(x["conf"]),"evidence":"; ".join(x["ev"][:8])})
    z=dict(r);z["work_blocks"]=blocks;return z

def eventproj(e):
    if (e.get("app") or "").lower()=="loxoneconfig.exe":
        p=loxproj(e.get("title",""))
        if p:return aliases(p)
    m=re.search(r"@Projekt\s*:\s*([^;]+)",e.get("note","") or "",re.I);return aliases(m.group(1).strip()) if m else ""
def qsummary(day=None):
    day=day or today();es=events(day);sample=int(cfg().get("sample_seconds",5));slots={};recent="";rt=0;manuals={}
    for e in es:
        if e.get("is_idle"):continue
        p=eventproj(e)
        if p:recent=p;rt=e["ts"]
        if e["kind"]!="sample":
            d=float(e.get("duration_minutes",0) or 0)
            if d>0:
                pp=p or (recent if e["ts"]-rt<=600 else "Nezařazeno");manuals[pp]=manuals.get(pp,0)+d*60
            continue
        if e["os"]=="macOS" and (e["app"] or "").lower()=="prl_client_app":continue
        pp=p or (recent if recent and e["ts"]-rt<=600 else "Nezařazeno");score=3 if e["os"]=="Windows" and p else 2 if p else 1;sl=int(e["ts"]//sample)
        if sl not in slots or score>slots[sl][0]:slots[sl]=(score,pp)
    sec={}
    for _,p in slots.values():sec[p]=sec.get(p,0)+sample
    for p,s in manuals.items():sec[p]=max(sec.get(p,0),s)
    arr=[{"project":p,"minutes":round(s/60,1)} for p,s in sec.items()];arr.sort(key=lambda x:x["minutes"],reverse=True)
    return {"day":day,"projects":arr,"total_minutes":round(sum(x["minutes"] for x in arr if x["project"]!="Nezařazeno"),1),"unassigned_minutes":round(sum(x["minutes"] for x in arr if x["project"]=="Nezařazeno"),1)}
def printsum(day=None):
    q=qsummary(day);print(f"\nPRŮBĚŽNÝ SOUHRN – {q['day']}\n"+"─"*64)
    for x in q["projects"]:print(f"{x['project']:<46} {fmt(x['minutes']):>8}")
    print("─"*64);print(f"{'Rozpoznané projekty celkem':<46} {fmt(q['total_minutes']):>8}");print(f"{'Nezařazený čas':<46} {fmt(q['unassigned_minutes']):>8}\nPozn.: lokální odhad bez spotřeby Codex kvóty.")
def aisum(day=None):
    day=day or today()
    try:r=consolidate(analyze(day,events(day),cfg()))
    except Exception as ex:print("AI souhrn selhal:",str(ex)[-1200:]);return
    print(f"\nAI SOUHRN – {day}\n"+"─"*64)
    for b in r.get("work_blocks",[]):print(f"{b['project']}  {fmt(b['minutes'])}\n• {b['summary']}\n")
def lastwin():
    heartbeat=load_windows_client_heartbeat()
    try:
        seen=float(heartbeat.get("last_seen",0) or 0)
        if seen>0:return seen
    except:pass
    con=db()
    r=con.execute(
        """SELECT ts FROM events
           WHERE source LIKE '%/Windows'
             AND lower(trim(coalesce(app,''))) NOT IN ('','windows','windows app')
             AND lower(trim(coalesce(title,''))) NOT IN ('','windows')
           ORDER BY ts DESC LIMIT 1"""
    ).fetchone()
    con.close()
    return r[0] if r else 0
def quick():
    q=qsummary()
    con=db()
    rows=con.execute("SELECT app,title FROM events WHERE day=? ORDER BY ts DESC LIMIT 100",(today(),)).fetchall()
    con.close()
    cur="Nezařazeno"
    for a,t in rows:
        p=eventproj({"app":a,"title":t})
        if p:
            cur=p
            break
    lw=lastwin()
    age=time.time()-lw if lw else None
    if age is None:
        wh="NIKDY"
    elif age<=20:
        wh="ONLINE"
    elif age<=90:
        wh="ZPOZDENI"
    else:
        wh="OFFLINE"
    wm=load_workmode()
    heartbeat=load_windows_client_heartbeat()
    return {
        "version":VERSION,
        "agent_running":bool(readstate()),
        "paused":paused(),
        "current_project":cur,
        "today":fmt(q["total_minutes"]),
        "unassigned":fmt(q["unassigned_minutes"]),
        "windows":wh,
        "windows_last_seconds":round(age,1) if age is not None else None,
        "windows_collecting":bool(heartbeat.get("collecting",False)) if heartbeat else False,
        "windows_paused":bool(heartbeat.get("paused",False)) if heartbeat else False,
        "workmode":wm
    }
def manual(kind,text,duration=0,source=None):
    if kind not in MANUAL:
        kind="note"
    e={
        "ts":time.time(),"iso":iso(),"day":today(),
        "source":source or platform.node()+"/"+SYSTEM,
        "os":SYSTEM,"app":"","title":"","url":"",
        "idle_seconds":0,"is_idle":0,"screenshot":"",
        "kind":kind,"note":f"{MANUAL[kind]}: {text.strip()}",
        "duration_minutes":max(0,float(duration or 0))
    }
    if cfg().get("mode")=="hub":
        add_event(e)
        return True
    u=findhub(cfg())
    return bool(u and sendevent(u,e))

def dsize(p):
    s=0
    if p.exists():
        for f in p.rglob("*"):
            try:
                if f.is_file():s+=f.stat().st_size
            except:pass
    return s
def prune(c=None):
    c=c or cfg();now=time.time();root=home()/"screenshots";cut=now-float(c.get("screenshot_failed_retention_hours",24))*3600;fs=[]
    for p in (home()/"tmp").glob("*_sensor.jpg"):
        try:
            if now-p.stat().st_mtime>3600:p.unlink()
        except:pass
    if root.exists():
        for p in root.rglob("*.jpg"):
            try:
                if p.stat().st_mtime<cut:p.unlink();continue
                fs.append((p.stat().st_mtime,p.stat().st_size,p))
            except:pass
    cap=int(float(c.get("screenshot_max_cache_mb",25))*1024*1024);tot=sum(x[1] for x in fs)
    for _,sz,p in sorted(fs):
        if tot<=cap:break
        try:p.unlink();tot-=sz
        except:pass
    cd=(dt.datetime.now()-dt.timedelta(days=int(c.get("raw_event_retention_days",30)))).strftime("%Y-%m-%d");con=db();con.execute("DELETE FROM events WHERE day<? AND day IN(SELECT day FROM reports)",(cd,));con.commit();con.close()
def storage():
    c=cfg();x=home()/c["excel_filename"];print(f"Screenshoty: {dsize(home()/'screenshots')/1024/1024:.1f} MB\nDatabáze: {(db_path().stat().st_size if db_path().exists() else 0)/1024/1024:.1f} MB\nExcel: {(x.stat().st_size if x.exists() else 0)/1024:.0f} kB\nCelkem: {dsize(home())/1024/1024:.1f} MB")
def delshots(day):
    shutil.rmtree(home()/"screenshots"/day,ignore_errors=True);con=db();con.execute("UPDATE events SET screenshot='' WHERE day=?",(day,));con.commit();con.close()

def xx(s):return html.escape("" if s is None else str(s),quote=False)
def col(n):
    s=""
    while n:n,r=divmod(n-1,26);s=chr(65+r)+s
    return s
ST='''<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="2"><font><sz val="11"/><name val="Aptos"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Aptos"/></font></fonts><fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF1F4E78"/><bgColor indexed="64"/></patternFill></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1"/></cellXfs></styleSheet>'''
def sheet(rows,widths):
    z=['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>','<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews><cols>']
    for i,w in enumerate(widths,1):z.append(f'<col min="{i}" max="{i}" width="{w}" customWidth="1"/>')
    z+=['</cols><sheetData>']
    for r,row in enumerate(rows,1):
        z.append(f'<row r="{r}">')
        for c,v in enumerate(row,1):z.append(f'<c r="{col(c)}{r}" t="inlineStr"'+(' s="1"' if r==1 else '')+f'><is><t xml:space="preserve">{xx(repair(v))}</t></is></c>')
        z.append('</row>')
    z.append('</sheetData>');z.append(f'<autoFilter ref="A1:{col(len(rows[0]))}{len(rows)}"/>' if rows else '');z.append('</worksheet>');return ''.join(z)
def xlsx(path,sheets):
    with zipfile.ZipFile(path,"w",zipfile.ZIP_DEFLATED) as z:
        ovs=''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1,len(sheets)+1));z.writestr("[Content_Types].xml",f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>{ovs}</Types>')
        z.writestr("_rels/.rels",'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>');tags=''.join(f'<sheet name="{xx(s[0])}" sheetId="{i}" r:id="rId{i}"/>' for i,s in enumerate(sheets,1));z.writestr("xl/workbook.xml",f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>{tags}</sheets></workbook>')
        rel=''.join(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in range(1,len(sheets)+1))+f'<Relationship Id="rId{len(sheets)+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>';z.writestr("xl/_rels/workbook.xml.rels",f'<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">{rel}</Relationships>');z.writestr("xl/styles.xml",ST)
        for i,(_,r,w) in enumerate(sheets,1):z.writestr(f"xl/worksheets/sheet{i}.xml",sheet(r,w))
def reports():
    con=db();rs=con.execute("SELECT day,report_json FROM reports ORDER BY day").fetchall();con.close();out=[]
    for d,r in rs:
        try:x=consolidate(deep(json.loads(r)));x["date"]=x.get("date") or d;out.append(x)
        except:pass
    return out
def export():
    rr=[["Datum","Projekt","Čas","Od","Do","Kategorie","Práce"]];mem=[["Datum","Denní souhrn","Paměť / pokračování"]];tot=[["Datum","Celkový čas","Počet projektů"]];un=[["Datum","Od","Do","Čas","Popis"]]
    for r in reports():
        total=0;pc=0
        for b in r.get("work_blocks",[]):
            total+=float(b.get("minutes",0) or 0)
            if str(b.get("project","")).casefold()=="nezařazeno":un.append([r["date"],b.get("start",""),b.get("end",""),fmt(b.get("minutes",0)),b.get("summary","")]);continue
            pc+=1;rr.append([r["date"],b.get("project",""),fmt(b.get("minutes",0)),b.get("start",""),b.get("end",""),b.get("category",""),b.get("summary","")])
        mem.append([r["date"],r.get("day_summary",""),"\n".join(r.get("memory_notes",[]))]);tot.append([r["date"],fmt(total),str(pc)])
    if len(rr)==1:rr.append(["","Zatím není vytvořen úspěšný AI výkaz.","","","","","Spusť: work vykaz"])
    ss=[("Výkaz práce",rr,[12,34,10,8,8,22,76]),("Denní součty",tot,[12,16,16]),("Paměť",mem,[12,72,82])]
    if len(un)>1:ss.append(("Nezařazeno",un,[12,8,8,10,80]))
    p=home()/cfg()["excel_filename"];tmp=p.with_suffix(".tmp.xlsx");xlsx(tmp,ss);tmp.replace(p);return p
def excelrepair():
    p=home()/cfg()["excel_filename"]
    if p.exists():b=home()/"backups"/f"Pracovni_vykaz_pred_opravou_{dt.datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx";shutil.copy2(p,b);print("Záloha:",b)
    print("Nový čistý Excel:",export())
def report(day):
    c=cfg();es=events(day)
    if not es:print("Pro tento den nejsou data.");return
    try:r=consolidate(analyze(day,es,c))
    except Exception as ex:print("Codex analýza selhala. Data a screenshoty zůstávají.\n",str(ex)[-1600:]);prune(c);return
    con=db();con.execute("INSERT OR REPLACE INTO reports(day,created_ts,report_json) VALUES(?,?,?)",(day,time.time(),json.dumps(r,ensure_ascii=False)));con.commit();con.close();p=export();md=home()/"reports"/(day+".md");lines=[f"# Výkaz práce – {day}","",r.get("day_summary",""),""]
    for b in r.get("work_blocks",[]):lines.append(f'- **{b.get("project","")} – {fmt(b.get("minutes",0))}** | {b.get("summary","")}')
    lines+=["","## Paměť / pokračování"]+[f"- {x}" for x in r.get("memory_notes",[])];md.write_text("\n".join(lines),encoding="utf-8")
    if c.get("delete_screenshots_after_successful_report",True):
        delshots(day)
    prune(c);print("AI analýza: ÚSPĚŠNÁ\nExcel:",p,"\nReport:",md,"\nScreenshoty po úspěchu odstraněny.")

def stopreq():
    try:return bool(json.loads(control_path().read_text()).get("stop"))
    except:return False
def paused():
    try:return bool(json.loads(control_path().read_text()).get("paused"))
    except:return False
def writestate(mode):state_path().write_text(json.dumps({"pid":os.getpid(),"mode":mode,"started":iso()}))
def local(c):
    last=None;lastshot=0;lastoutlookvisual=0;shots=0;lastrep="";lastprune=0;last_input={}
    ensure_input_helper(c)
    while not stopreq():
        if paused():time.sleep(1);continue
        if not workmode_active():
            visual_discard_all()
            time.sleep(1)
            continue
        t=time.time();x=context();

        if not windows_context_valid(x):
            time.sleep(max(1, int(c["sample_seconds"])))
            continue

        meta=x.setdefault("meta",{});raw=meta.pop("input_raw",{}) or {};delta={}
        for k in ("keys","clicks","scrolls","moves"):
            try:delta[k]=max(0,int(raw.get(k,0))-int(last_input.get(k,raw.get(k,0))))
            except:delta[k]=0
        if raw:last_input=raw
        meta["input"]=delta;meta.update(activity_semantics(x))
        idle=x["idle_seconds"]>=c["idle_seconds"];key=(x["app"],x["title"],x["url"],idle);p=None
        is_visual_outlook=_visual_is_outlook(x) and not idle and bool(c.get("visual_outlook_enabled",True))
        if is_visual_outlook and t-lastoutlookvisual>=max(3,int(c.get("visual_outlook_capture_interval_seconds",5))):
            p=visual_screenshot(home()/"screenshots"/"visual"/f"{int(t)}_outlook_mac.jpg",c)
            if p:lastoutlookvisual=t
        elif c.get("screenshot_enabled") and shots<c["max_screenshots_per_day"] and t-lastshot>=c["screenshot_min_gap_seconds"] and ((c.get("screenshot_on_context_change") and key!=last) or t-lastshot>=c["screenshot_interval_seconds"]):
            p=screenshot(home()/"screenshots"/today()/f"{int(t)}_mac.jpg",c)
            if p:shots+=1;lastshot=t
        add_event({"ts":t,"iso":iso(t),"day":today(),**x,"is_idle":1 if idle else 0,"screenshot":str(p) if p else "","kind":"sample","note":"","duration_minutes":0})
        if t-lastprune>600:prune(c);lastprune=t
        now=dt.datetime.now()
        if now.hour==int(c["auto_report_hour"]) and now.minute>=int(c["auto_report_minute"]) and lastrep!=today():report(today());lastrep=today()
        last=key;time.sleep(max(1,int(c["sample_seconds"])))

def windows_context_valid(x):
    """
    Windows nekdy na okamzik nedokaze zjistit foreground proces
    a vrati pouze obecny kontext Windows/Windows app.

    Takovy vzorek se nesmi ulozit jako pracovni aktivita.
    """
    if SYSTEM != "Windows":
        return True

    app = str(x.get("app", "") or "").strip()
    title = str(x.get("title", "") or "").strip()

    app_l = app.lower()
    title_l = title.lower()

    if app_l in ("", "windows", "windows app"):
        return False

    if title_l in ("", "windows"):
        return False

    return True

def windows_should_collect(c,x,work_active,is_paused):
    if is_paused or not work_active or not windows_context_valid(x):return False
    try:return float(x.get("idle_seconds",0) or 0)<float(c.get("idle_seconds",180) or 180)
    except:return False

def sensor(c):
    hub=findhub(c);last=None;lastshot=0;lastvisual=0;lastoutlookvisual=0;last_sent_id="";shots=0;lastheartbeat=0;lastruntime=0
    save_sensor_runtime(hub,bool(hub),False,paused(),False)
    while not stopreq():
        if not hub or not ping(hub):hub=findhub(c)
        is_paused=paused();work_active=hub_workmode_active(hub)
        t=time.time();x=None;idle_seconds=None;collecting=False
        if not is_paused and work_active and hub:
            x=context();idle_seconds=float(x.get("idle_seconds",0) or 0)
            collecting=windows_should_collect(c,x,work_active,is_paused)
        if hub and (t-lastheartbeat>=5):
            if not sendheartbeat(hub,collecting,is_paused,work_active,idle_seconds):hub=""
            lastheartbeat=t
        if t-lastruntime>=5:
            save_sensor_runtime(hub,bool(hub),collecting,is_paused,work_active,idle_seconds)
            lastruntime=t
        if not collecting or x is None:
            time.sleep(1)
            continue
        x.setdefault("meta",{}).update(activity_semantics(x));idle=False;key=(x["app"],x["title"],x["url"],idle);p=None
        is_visual_lox=(str(x.get("app","") or "").casefold()=="loxoneconfig.exe" and bool(c.get("visual_loxone_enabled",True)))
        is_visual_outlook=(_visual_is_outlook(x) and bool(c.get("visual_outlook_enabled",True)))
        if is_visual_lox and t-lastvisual>=max(3,int(c.get("visual_capture_interval_seconds",5))):
            p=visual_screenshot(home()/"tmp"/f"{int(t)}_loxone_visual.jpg",c)
            if p:lastvisual=t
        elif is_visual_outlook and t-lastoutlookvisual>=max(3,int(c.get("visual_outlook_capture_interval_seconds",5))):
            p=visual_screenshot(home()/"tmp"/f"{int(t)}_outlook_visual.jpg",c)
            if p:lastoutlookvisual=t
        elif c.get("screenshot_enabled") and shots<c["max_screenshots_per_day"] and t-lastshot>=c["screenshot_min_gap_seconds"] and ((c.get("screenshot_on_context_change") and key!=last) or t-lastshot>=c["screenshot_interval_seconds"]):
            p=screenshot(home()/"tmp"/f"{int(t)}_sensor.jpg",c)
            if p:shots+=1;lastshot=t
        e={"ts":t,"iso":iso(t),"day":today(),**x,"is_idle":1 if idle else 0,"screenshot":"","kind":"sample","note":"","duration_minutes":0}
        if hub:sendevent(hub,e,p)

        if is_visual_outlook and c.get("outlook_sent_probe_enabled",True):
            sent=outlook_sent_probe(last_sent_id)
            if sent:
                last_sent_id=str(sent.get("entry_id","") or last_sent_id)
                recipients=[x.strip() for x in re.split(r"[;,]",str(sent.get("to","") or "")) if x.strip()]
                cc=[x.strip() for x in re.split(r"[;,]",str(sent.get("cc","") or "")) if x.strip()]
                subject=str(sent.get("subject","") or "").strip()
                meta={
                    "activity":"Odeslání e-mailu v Outlooku",
                    "email_recipients":recipients,
                    "email_cc":cc,
                    "email_subject":subject,
                    "email_sent_at":str(sent.get("sent_on","") or ""),
                    "email_body_excerpt":str(sent.get("body","") or "")[:2000],
                    "confidence":0.99,
                    "evidence":["outlook_mapi_sent_item"]
                }
                se={"ts":t,"iso":iso(t),"day":today(),**x,"title":subject or x.get("title",""),
                    "is_idle":0,"screenshot":"","kind":"email_sent",
                    "note":f"E-mail odeslán: {subject or '(bez předmětu)'} → {', '.join(recipients) or '(příjemce nezjištěn)'}",
                    "duration_minutes":0,"meta":meta}
                if hub:sendevent(hub,se,None)

        if p:Path(p).unlink(missing_ok=True)
        last=key;time.sleep(max(1,int(c["sample_seconds"])))
def acquire_daemon_lock():
    if SYSTEM!="Windows":return True
    kernel=ctypes.windll.kernel32
    kernel.CreateMutexW.restype=ctypes.c_void_p
    handle=kernel.CreateMutexW(None,False,"Local\\EvoraSmartMenuWorkLogAgent")
    if not handle:return None
    if kernel.GetLastError()==183:
        kernel.CloseHandle(ctypes.c_void_p(handle));return None
    return handle
def release_daemon_lock(lock):
    if SYSTEM=="Windows" and lock not in (None,True):
        try:
            ctypes.windll.kernel32.ReleaseMutex(ctypes.c_void_p(lock))
            ctypes.windll.kernel32.CloseHandle(ctypes.c_void_p(lock))
        except:pass
def daemon():
    lock=acquire_daemon_lock()
    if lock is None:return
    c=cfg();prune(c);mode=c["mode"];writestate(mode);control_path().write_text(json.dumps({"stop":False,"paused":False}))
    try:
        if mode=="hub":
            srv=TH(("0.0.0.0",int(c["port"])),Handler);threading.Thread(target=srv.serve_forever,daemon=True).start();local(c);srv.shutdown()
        else:sensor(c)
    finally:
        try:
            if workmode_active():
                visual_flush_session()
                outlook_visual_flush_session(analyze=True)
            else:
                visual_discard_all()
        except Exception:pass
        state_path().unlink(missing_ok=True)
        if mode=="sensor":
            save_sensor_runtime("",False,False,paused(),False)
        release_daemon_lock(lock)
def spawn():
    cmd=[sys.executable,str(Path(__file__).resolve()),"daemon"]
    if SYSTEM=="Windows":subprocess.Popen(cmd,creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0)|getattr(subprocess,"DETACHED_PROCESS",0),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,stdin=subprocess.DEVNULL)
    else:subprocess.Popen(cmd,start_new_session=True,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,stdin=subprocess.DEVNULL)
def readstate():
    try:
        s=json.loads(state_path().read_text());p=int(s.get("pid",0))
        if p<=0:return {}
        if SYSTEM=="Windows":
            kernel=ctypes.windll.kernel32
            kernel.OpenProcess.restype=ctypes.c_void_p
            handle=kernel.OpenProcess(0x1000,False,p)
            if not handle:raise ProcessLookupError(p)
            try:
                code=ctypes.c_ulong()
                if not kernel.GetExitCodeProcess(ctypes.c_void_p(handle),ctypes.byref(code)) or code.value!=259:
                    raise ProcessLookupError(p)
            finally:kernel.CloseHandle(ctypes.c_void_p(handle))
        else:os.kill(p,0)
        return s
    except:
        state_path().unlink(missing_ok=True);return {}

def diagnostic(n=30):
    es=events(today())[-max(1,int(n)):]
    print(f"Diagnostika poslednich {len(es)} vzorku:")
    for e in es:
        m=e.get("meta") or {};inp=m.get("input") or {}
        print(f"{dt.datetime.fromtimestamp(e['ts']).strftime('%H:%M:%S')} | {e.get('os','')} | {e.get('app','')} | {e.get('title','')} | idle={round(float(e.get('idle_seconds',0) or 0),1)}s | activity={m.get('activity','')} | project={m.get('project','')} | conf={m.get('confidence','')} | input=k{inp.get('keys',0)}/c{inp.get('clicks',0)}/s{inp.get('scrolls',0)} | AX={m.get('focused_role','')}:{m.get('focused_title','')} | files={len(m.get('files_changed',[]) or [])} | evidence={','.join(m.get('evidence',[]) or [])}")

def _recent_app_name(e):
    app=str(e.get("app","") or "").strip()
    low=app.casefold()
    mapping={
        "loxoneconfig.exe":"Loxone Config",
        "powershell.exe":"Windows PowerShell",
        "pwsh.exe":"Windows PowerShell",
        "windowsterminal.exe":"Windows PowerShell",
        "cmd.exe":"Příkazový řádek",
        "explorer.exe":"Průzkumník Windows",
        "chrome.exe":"Google Chrome",
        "msedge.exe":"Microsoft Edge",
        "firefox.exe":"Firefox",
        "code.exe":"Visual Studio Code",
        "cursor.exe":"Cursor",
        "notepad.exe":"Poznámkový blok",
    }
    return mapping.get(low,app or "Neznámá aplikace")

def _recent_generic_windows(e):
    if str(e.get("os","") or "").casefold()!="windows":
        return False
    app=str(e.get("app","") or "").strip().casefold()
    title=str(e.get("title","") or "").strip().casefold()
    return app in ("","windows","windows app") or title in ("","windows")

def _recent_project(e,last_project="",last_project_ts=0):
    meta=e.get("meta") or {}
    project=str(meta.get("project","") or "").strip()
    if not project:
        try: project=eventproj(e) or ""
        except Exception: project=""
    if project:
        return aliases(project),"direct"
    app=_recent_app_name(e).casefold()
    # ChatGPT/Terminal/editor casto patri k projektu, ktery byl aktivni tesne predtim.
    # Drzime jen kratky kontext; nejde o definitivni fakt, proto snizime confidence.
    if last_project and float(e.get("ts",0) or 0)-float(last_project_ts or 0)<=600:
        if (
            "chatgpt" in app
            or "terminal" in app
            or "powershell" in app
            or "cursor" in app
            or "visual studio code" in app
        ):
            return last_project,"recent_context"
    return "",""

def _recent_semantics(e,app_name,project,project_source):
    meta=e.get("meta") or {}
    activity=str(meta.get("visual_activity","") or meta.get("activity","") or "").strip()
    if not activity:
        low=app_name.casefold()
        if "loxone" in low: activity="aktivní úprava / diagnostika konfigurace"
        elif "chatgpt" in low: activity="technická konzultace / práce s ChatGPT"
        elif "powershell" in low or "terminal" in low: activity="práce v terminálu"
        elif any(x in low for x in ("chrome","edge","safari","firefox","brave")): activity="práce ve webovém prohlížeči"
        elif any(x in low for x in ("cursor","visual studio code","xcode")): activity="programování / editace zdrojů"
        else: activity="aktivní práce v aplikaci"
    evidence=list(meta.get("evidence",[]) or [])
    if project_source=="recent_context" and "recent_project_context" not in evidence:
        evidence.append("recent_project_context")
    try:
        vc=float(meta.get("visual_confidence",0) or 0)
        conf=(vc/100.0) if vc>0 else float(meta.get("confidence",0) or 0)
    except Exception: conf=0
    if conf<=0:
        conf=0.55
        if e.get("app"):conf+=0.10
        if e.get("title"):conf+=0.10
        if project:conf+=0.05
    if project_source=="recent_context":
        conf=min(conf,0.82)
    return activity,max(0.05,min(0.99,conf)),evidence

def _recent_pick_slots(es):
    """Vybere jeden nejlepsi sample na casovy slot a odstrani prekryv Mac/Windows."""
    sample=max(1,int(cfg().get("sample_seconds",5)))
    slots={}
    manuals=[]
    for e in es:
        if str(e.get("kind","sample") or "sample")!="sample":
            manuals.append(e);continue
        if e.get("is_idle"):continue
        if _recent_generic_windows(e):continue
        app=(e.get("app") or "").casefold()
        osname=str(e.get("os","") or "")
        # Mac reprezentace VM neni pracovni aplikace; je jen transport.
        if osname=="macOS" and any(x in app for x in ("prl_client_app","parallels desktop","windows app")):
            continue
        slot=int(float(e.get("ts",0) or 0)//sample)
        try:p=eventproj(e) or (e.get("meta") or {}).get("project","") or ""
        except:p=""
        score=0
        if osname=="Windows":score+=100
        elif osname=="macOS":score+=80
        if p:score+=20
        if e.get("title"):score+=5
        if (e.get("meta") or {}).get("focused_role"):score+=3
        old=slots.get(slot)
        if old is None or score>old[0]:
            slots[slot]=(score,e)
    chosen=[v[1] for _,v in sorted(slots.items())]
    # Manualni udalosti ponechame v casove rade.
    return sorted(chosen+manuals,key=lambda e:float(e.get("ts",0) or 0))

def _recent_build_blocks(es):
    sample=max(1,int(cfg().get("sample_seconds",5)))
    es=_recent_pick_slots(es)
    prepared=[]
    last_project=""
    last_project_ts=0.0
    for e in es:
        kind=str(e.get("kind","sample") or "sample")
        ts=float(e.get("ts",0) or 0)
        if kind!="sample":
            prepared.append({"event":e,"kind":kind,"ts":ts,"key":("manual",kind,str(e.get("note","") or ""))})
            continue
        project,psrc=_recent_project(e,last_project,last_project_ts)
        if project and psrc=="direct":
            last_project=project;last_project_ts=ts
        app_name=_recent_app_name(e)
        activity,conf,evidence=_recent_semantics(e,app_name,project,psrc)
        meta=e.get("meta") or {}
        inp=meta.get("input") or {}
        item={
            "event":e,"kind":"sample","ts":ts,
            "app":app_name,"project":project,"project_source":psrc,
            "activity":activity,"detail":str(meta.get("visual_detail","") or "").strip(),"confidence":conf,"evidence":evidence,
            "keys":int(inp.get("keys",0) or 0),
            "clicks":int(inp.get("clicks",0) or 0),
            "scrolls":int(inp.get("scrolls",0) or 0),
            "moves":int(inp.get("moves",0) or 0),
            "files":list(meta.get("files_changed",[]) or []),
        }
        item["key"]=("sample",app_name.casefold(),project.casefold(),activity.casefold())
        prepared.append(item)

    blocks=[]
    cur=None
    for x in prepared:
        if x["kind"]!="sample":
            if cur:blocks.append(cur);cur=None
            e=x["event"]
            blocks.append({
                "manual":True,"first":e,"last":e,"start":x["ts"],"end":x["ts"],
                "key":x["key"],"samples":1,"keys":0,"clicks":0,"scrolls":0,"moves":0,
                "files":set(),"save_events":0,"conf":[],"evidence":set()
            })
            continue
        if cur is None:
            cur={
                "manual":False,"first":x["event"],"last":x["event"],
                "start":x["ts"],"end":x["ts"],"key":x["key"],
                "app":x["app"],"project":x["project"],"activity":x["activity"],"detail":x.get("detail",""),
                "project_source":x["project_source"],"samples":1,
                "keys":x["keys"],"clicks":x["clicks"],"scrolls":x["scrolls"],"moves":x["moves"],
                "files":set(x["files"]),"save_events":1 if x["files"] else 0,
                "conf":[x["confidence"]],"evidence":set(x["evidence"])
            }
            continue
        gap=x["ts"]-cur["end"]
        if x["key"]==cur["key"] and gap<=max(15,sample*3):
            cur["last"]=x["event"];cur["end"]=x["ts"];cur["samples"]+=1
            cur["keys"]+=x["keys"];cur["clicks"]+=x["clicks"];cur["scrolls"]+=x["scrolls"];cur["moves"]+=x["moves"]
            cur["files"].update(x["files"]);cur["save_events"]+=1 if x["files"] else 0
            cur["conf"].append(x["confidence"]);cur["evidence"].update(x["evidence"])
            if len(x.get("detail", ""))>len(cur.get("detail", "")):cur["detail"]=x.get("detail", "")
        else:
            blocks.append(cur)
            cur={
                "manual":False,"first":x["event"],"last":x["event"],
                "start":x["ts"],"end":x["ts"],"key":x["key"],
                "app":x["app"],"project":x["project"],"activity":x["activity"],"detail":x.get("detail",""),
                "project_source":x["project_source"],"samples":1,
                "keys":x["keys"],"clicks":x["clicks"],"scrolls":x["scrolls"],"moves":x["moves"],
                "files":set(x["files"]),"save_events":1 if x["files"] else 0,
                "conf":[x["confidence"]],"evidence":set(x["evidence"])
            }
    if cur:blocks.append(cur)

    # Potlaceni kratkeho "bliknuti": A - kratky B - A => jeden A blok.
    changed=True
    while changed and len(blocks)>=3:
        changed=False;out=[];i=0
        while i<len(blocks):
            if i+2<len(blocks):
                a,b,c=blocks[i],blocks[i+1],blocks[i+2]
                bdur=(b["end"]-b["start"])+sample if not b.get("manual") else 999
                if (
                    not a.get("manual") and not b.get("manual") and not c.get("manual")
                    and a.get("key")==c.get("key")
                    and bdur<=10
                    and c["start"]-a["end"]<=30
                ):
                    merged=dict(a)
                    merged["last"]=c["last"];merged["end"]=c["end"]
                    for fld in ("samples","keys","clicks","scrolls","moves","save_events"):
                        merged[fld]=int(a.get(fld,0))+int(b.get(fld,0))+int(c.get(fld,0))
                    merged["files"]=set(a.get("files",set()))|set(b.get("files",set()))|set(c.get("files",set()))
                    merged["conf"]=list(a.get("conf",[]))+list(b.get("conf",[]))+list(c.get("conf",[]))
                    merged["evidence"]=set(a.get("evidence",set()))|set(b.get("evidence",set()))|set(c.get("evidence",set()))
                    out.append(merged);i+=3;changed=True;continue
            out.append(blocks[i]);i+=1
        blocks=out
    return blocks

def recent(n):
    """
    Activity Collector v2: lidsky citelne agregovane bloky.
    RAW vzorky zustavaji v SQLite; tento vystup je urceny pro menu.
    """
    es=events(today())
    if not es:
        print("Dnes zatím nejsou žádné záznamy.")
        return
    limit=min(max(1,int(n)),8)
    blocks=_recent_build_blocks(es)[-limit:]
    print(f"Posledních {len(blocks)} agregovaných bloků:")
    print()
    sample=max(1,int(cfg().get("sample_seconds",5)))
    for idx,b in enumerate(blocks):
        start_s=dt.datetime.fromtimestamp(b["start"]).strftime("%H:%M:%S")
        end_ts=b["end"] if b.get("manual") else b["end"]+sample
        end_s=dt.datetime.fromtimestamp(end_ts).strftime("%H:%M:%S")
        if b.get("manual"):
            e=b["first"];note=str(e.get("note","") or e.get("kind","")).strip()
            mins=float(e.get("duration_minutes",0) or 0)
            meta=e.get("meta") or {}
            print(f"{start_s}")
            print(f"ACTIVITY: {note}")
            if str(e.get("kind",""))=="email_sent":
                tos=meta.get("outlook_recipients") or meta.get("email_recipients") or []
                subject=meta.get("outlook_subject") or meta.get("email_subject") or ""
                sentat=meta.get("outlook_sent_time") or meta.get("email_sent_at") or e.get("iso","")
                summary=meta.get("outlook_message_summary") or ""
                project=meta.get("outlook_project") or meta.get("project") or ""
                if project:print(f"PROJECT: {project}")
                if tos:print("TO: "+", ".join(str(x) for x in tos))
                if subject:print(f"SUBJECT: {subject}")
                if sentat:print(f"SENT: {sentat}")
                if summary:print(f"DETAIL: {summary}")
            if mins>0:print(f"DURATION: {mins:g} min")
            if idx!=len(blocks)-1:print()
            continue

        confs=[float(x) for x in b.get("conf",[]) if x is not None]
        conf=(sum(confs)/len(confs)) if confs else 0.55
        # Delsi stabilni blok zvysuje duveru, odhad projektu z kontextu ji omezuje.
        if b.get("samples",0)>=3:conf=min(0.99,conf+0.05)
        if b.get("project_source")=="recent_context":conf=min(conf,0.82)
        evidence=sorted(set(b.get("evidence",set())))
        project=b.get("project") or "Nezařazeno"
        app=b.get("app") or "Neznámá aplikace"
        activity=b.get("activity") or "aktivní práce v aplikaci"

        print(f"{start_s}–{end_s}")
        print(f"PROJECT: {project}")
        print(f"APP: {app}")
        print(f"ACTIVITY: {activity}")
        if b.get("detail"):print(f"DETAIL: {b.get('detail')}")

        # Mac umí přesný počet vstupních událostí bez obsahu kláves.
        has_input=(b.get("keys",0)+b.get("clicks",0)+b.get("scrolls",0)+b.get("moves",0))>0
        if has_input:
            print(f"KEY_ACTIVITY: {b.get('keys',0)}")
            print(f"MOUSE_CLICKS: {b.get('clicks',0)}")
            print(f"SCROLL: {b.get('scrolls',0)}")
        else:
            print("KEY_ACTIVITY: —")
            print("MOUSE_CLICKS: —")
            print("SCROLL: —")

        print(f"FILES_CHANGED: {len(b.get('files',set()))}")
        print(f"SAVES: {len(b.get('files',set()))}")
        print(f"CONFIDENCE: {int(round(conf*100))} %")
        if idx!=len(blocks)-1:print()


def visual_status():
    print(f"Evora Smart Menu v{VERSION} - Loxone Visual")
    c=cfg()
    print("Pracovni rezim:","AKTIVNI" if workmode_active() else "NEAKTIVNI - sběr/screeny/AI OFF")
    print("Loxone Visual:","ZAPNUTO" if c.get("visual_loxone_enabled",True) else "VYPNUTO",f"/ {int(c.get('visual_capture_interval_seconds',5))} s")
    print("Outlook Visual:","ZAPNUTO" if c.get("visual_outlook_enabled",True) else "VYPNUTO",f"/ {int(c.get('visual_outlook_capture_interval_seconds',5))} s")
    ok,msg=codexok() if SYSTEM=="Darwin" else (False,"Codex bezi na Mac HUBu")
    print("Codex:","PRIHLASEN" if ok else ("NA MAC HUBU" if SYSTEM!="Darwin" else "CHYBA"))
    if SYSTEM=="Darwin":
        print("Codex bin:",codex_bin() or "NENALEZEN")
        if not ok:print("Codex detail:",msg)
        mc=mac_ctx(light=True)
        print("Mac frontmost:",mc.get("app",""),"|",mc.get("title",""))
        print("VM gate:","OTEVRENA" if mac_vm_frontmost() else "ZAVRENA")
        try:
            con=db()
            r=con.execute("SELECT ts,app,title FROM events WHERE os='Windows' ORDER BY ts DESC LIMIT 1").fetchone()
            con.close()
            if r:
                print("Posledni Windows event:",f"{max(0,int(time.time()-float(r[0])))} s","|",r[1],"|",r[2])
            else:
                print("Posledni Windows event: zadny")
        except Exception as ex:
            print("Windows event diagnostika:",ex)
    with VISUAL_LOCK:
        vs=dict(VISUAL_SESSION)
    if vs.get("project"):
        print("Aktivni session:",vs.get("project"),f"/ {len(vs.get('screens',[]))} screenu")
        print("Cas:",iso(vs.get("start")),"->",iso(vs.get("last")))
    else:
        print("Aktivni session: zadna")
    with OUTLOOK_VISUAL_LOCK:
        osess=dict(OUTLOOK_VISUAL_SESSION)
    if osess.get("start"):
        print("Outlook session:",dt.datetime.fromtimestamp(osess["start"]).strftime("%H:%M:%S"),"/",len(osess.get("screens",[])),"screenu")
    else:
        print("Outlook session: zadna")
    olp=home()/"reports"/"outlook_visual_sessions.jsonl"
    if olp.exists():
        try:
            lines=olp.read_text(encoding="utf-8").splitlines()[-5:]
            print("Posledni Outlook visual logy:")
            for line in lines:
                x=json.loads(line)
                print(" -",x.get("created",""),x.get("status",""),x.get("result",{}).get("action",""),x.get("result",{}).get("subject",""),x.get("error",""))
        except Exception as ex:print("Outlook visual log:",ex)

    lp=home()/"reports"/"visual_sessions.jsonl"
    if lp.exists():
        try:
            lines=lp.read_text(encoding="utf-8",errors="replace").splitlines()[-5:]
            print("Posledni visual logy:")
            for line in lines:
                try:
                    x=json.loads(line);print(" -",x.get("created"),x.get("status"),x.get("project"),x.get("error","")[:180])
                except:print(" -",line[:220])
        except Exception as ex:print("Visual log chyba:",ex)
    else:print("Visual log: zatim neexistuje")

def status():
    c=cfg()
    s=readstate()
    runtime=load_sensor_runtime() if c["mode"]=="sensor" else {}
    print(f"Evora Smart Menu v{VERSION}")
    print("Rezim:",c["mode"])
    print("Agent:","BEZI - watchdog aktivni" if s else "CEKA NA OBNOVENI WATCHDOGEM")
    active_work=bool(runtime.get("workmode_active",False)) if runtime else workmode_active()
    print("Pracovni rezim:","AKTIVNI" if active_work else "NEAKTIVNI - automaticky sber OFF")
    print("Loxone Visual:","ZAPNUTO" if c.get("visual_loxone_enabled",True) else "VYPNUTO",f"/ {int(c.get('visual_capture_interval_seconds',5))} s")
    print("Outlook Visual:","ZAPNUTO" if c.get("visual_outlook_enabled",True) else "VYPNUTO",f"/ {int(c.get('visual_outlook_capture_interval_seconds',5))} s")
    if c["mode"]=="hub":
        ok,msg=codexok()
        print("Codex WorkLog ucet:","PRIHLASEN" if ok else "NENI PRIHLASEN")
        lw=lastwin()
        if lw:
            age=max(0,int(time.time()-lw))
            print("Windows klient:", "ONLINE" if age<=20 else "OFFLINE", f"({age}s)")
        else:
            print("Windows klient: ZATIM BEZ DAT")
        print("Codex profil:",codex_home())
    else:
        print("Codex: pouziva AI ucet na Mac HUBu")
        runtime_age=time.time()-float(runtime.get("updated_ts",0) or 0) if runtime else 999999
        connected=bool(s and runtime_age<=15 and runtime.get("hub_connected"))
        if connected:
            print("Hub: PRIPOJEN - staly heartbeat")
        elif s:
            print("Hub: OBNOVUJE SPOJENI - agent stale bezi")
        else:
            print("Hub: ODPOJEN - minutovy watchdog klienta znovu spusti")
        if runtime.get("collecting"):
            print("Sber dat: AKTIVNI - dochazka i pouzivani potvrzeny")
        elif runtime.get("paused"):
            print("Sber dat: POZASTAVEN")
        else:
            print("Sber dat: VYPNUT - klient zustava online")
    print("Data:",home())
    print("Excel:",home()/c["excel_filename"])
def iphone():
    c=cfg();tok=c["mobile_token"];ips=[]
    if SYSTEM=="Darwin":
        for iface in ("en0","en1"):
            ip=run(["ipconfig","getifaddr",iface],2)
            if ip:ips.append(ip)
        o=run(["ifconfig"],2)
        for m in re.findall(r"inet (100\.\d+\.\d+\.\d+)",o):
            if m not in ips:ips.append(m)
    base=c.get("iphone_base_url","").rstrip("/");urls=[base+"/mobile?token="+tok] if base else [];urls += [f"http://{ip}:{c['port']}/mobile?token={tok}" for ip in ips]
    print("iPhone vstup:")
    for u in urls:print(u)
    if urls and SYSTEM=="Darwin":subprocess.run(["pbcopy"],input=urls[0],text=True);print("\nPrvní odkaz byl zkopírován do schránky.")
def setproject(name):
    q=quick();raw=q["current_project"]
    if raw=="Nezařazeno":print("Aktuální projekt se nepodařilo zjistit.");return
    c=cfg();a=c.get("project_aliases",{}) or {};a[raw]=name;c["project_aliases"]=a;save_cfg(c);print(f'"{raw}" → "{name}"')

def workmode_path():
    return home()/"work_mode.json"

def load_workmode():
    try:
        x=json.loads(workmode_path().read_text(encoding="utf-8"))
        return x if isinstance(x,dict) else {}
    except:
        return {}

def save_workmode(x):
    workmode_path().write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding="utf-8")

def workmode(mode,source="manual"):
    now=time.time()
    cur=load_workmode()
    history=cur.get("history",[]) or []
    desired_active=mode!="off"
    desired_mode="" if mode=="off" else mode
    if bool(cur.get("active"))==desired_active and str(cur.get("mode","") or "")==desired_mode:
        cur.update({"source":source,"synced_ts":now})
        save_workmode(cur)
        return
    if cur.get("active") and cur.get("started_ts"):
        history.append({
            "mode":cur.get("mode",""),
            "started_ts":cur.get("started_ts"),
            "ended_ts":now,
            "source":cur.get("source","manual")
        })
    if mode=="off":
        save_workmode({"active":False,"mode":"","started_ts":0,"ended_ts":now,"source":source,"synced_ts":now,"history":history[-500:]})
        try:visual_discard_all()
        except Exception:pass
        print("Pracovni cas ukoncen - automaticke zaznamy, screenshoty a AI analyzy VYPNUTY")
        return
    save_workmode({
        "active":True,"mode":mode,"started_ts":now,
        "started_iso":iso(now),"source":source,"synced_ts":now,"history":history[-500:]
    })
    print("Kancelar" if mode=="office" else "Home office")

def workmode_print():
    w=load_workmode()
    stale=w.get("source")=="evora_intranet" and time.time()-float(w.get("synced_ts",0) or 0)>300
    if not w.get("active") or stale:
        print("Neaktivni 00:00:00"+(" - data Evora Intranetu jsou zastarala" if stale else ""))
        return
    sec=max(0,int(time.time()-float(w.get("started_ts",time.time()))))
    label="Kancelar" if w.get("mode")=="office" else "Home office"
    print(f"{label} {sec//3600:02d}:{(sec%3600)//60:02d}:{sec%60:02d}")

def setup(mode,hub=""):
    c=cfg()
    c["mode"]=mode
    if hub:
        c["hub_url"]=hub.rstrip("/")
    elif mode=="hub":
        c["hub_url"]=""
    save_cfg(c)
    print("Ulozeno:",cfg_path())

def main():
    ensure_dirs()
    if len(sys.argv)>1:sys.argv[1]=CZ.get(sys.argv[1].lower(),sys.argv[1])
    ap=argparse.ArgumentParser(prog="work");sp=ap.add_subparsers(dest="cmd",required=True)
    for x in ("daemon","start","stop","pause","resume","status","visual-status","login","relogin","logout","storage","cleanup","summary","summary-ai","iphone","excel-repair","quick","office","homeoffice","work-end","work-mode","diagnostic"):sp.add_parser(x)
    intranet_sync=sp.add_parser("intranet-sync");intranet_sync.add_argument("mode",choices=["office","homeoffice","off"])
    q=sp.add_parser("recent");q.add_argument("n",nargs="?",type=int,default=20)
    for x in ("note","call","travel","offpc"):
        p=sp.add_parser(x);p.add_argument("text");p.add_argument("--minutes",type=float,default=0)
    r=sp.add_parser("report");r.add_argument("day",nargs="?",default=today());p=sp.add_parser("project");p.add_argument("name");s=sp.add_parser("setup");s.add_argument("mode",choices=["hub","sensor"]);s.add_argument("--hub",default="");a=ap.parse_args()
    if a.cmd=="daemon":return daemon()
    if a.cmd=="start":
        if readstate():return print("Agent už běží.")
        control_path().write_text(json.dumps({"stop":False,"paused":False}));spawn();time.sleep(1);return status()
    if a.cmd=="stop":control_path().write_text(json.dumps({"stop":True,"paused":False}));return print("Agent zastavuji.")
    if a.cmd in ("pause","resume"):control_path().write_text(json.dumps({"stop":False,"paused":a.cmd=="pause"}));return print("Pozastaveno." if a.cmd=="pause" else "Obnoveno.")
    if a.cmd=="status":return status()
    if a.cmd=="visual-status":return visual_status()
    if a.cmd=="login":return login(False)
    if a.cmd=="relogin":return login(True)
    if a.cmd=="logout":return logout()
    if a.cmd=="recent":return recent(a.n)
    if a.cmd=="diagnostic":return diagnostic(30)
    if a.cmd=="storage":return storage()
    if a.cmd=="cleanup":prune(cfg());return storage()
    if a.cmd=="summary":return printsum()
    if a.cmd=="summary-ai":return aisum()
    if a.cmd=="iphone":return iphone()
    if a.cmd=="excel-repair":return excelrepair()
    if a.cmd=="quick":return print(json.dumps(quick(),ensure_ascii=False,indent=2))
    if a.cmd in MANUAL:
        ok=manual(a.cmd,a.text,a.minutes);return print(MANUAL[a.cmd]+": uloženo." if ok else "Hub nenalezen – záznam nebyl uložen.")
    if a.cmd=="report":return report(a.day)
    if a.cmd=="project":return setproject(a.name)
    if a.cmd=="intranet-sync":return workmode(a.mode,"evora_intranet")
    if a.cmd in ("office","homeoffice","work-end") and cfg().get("intranet_primary_source",True):
        return print("Dochazku ridi Evora Intranet. Pouzijte Evora Smart Menu; lokalni rezim nebyl zmenen.")
    if a.cmd=="office":return workmode("office")
    if a.cmd=="homeoffice":return workmode("homeoffice")
    if a.cmd=="work-end":return workmode("off")
    if a.cmd=="work-mode":return workmode_print()
    if a.cmd=="setup":return setup(a.mode,a.hub)
if __name__=="__main__":main()
